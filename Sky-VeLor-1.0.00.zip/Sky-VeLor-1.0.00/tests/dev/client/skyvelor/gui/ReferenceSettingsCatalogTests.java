package dev.client.skyvelor.gui;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Headless integrity checks for the migrated settings GUI catalog. */
public final class ReferenceSettingsCatalogTests {
    private static int passed;
    private static int failed;

    public static void main(String[] args) {
        check("nine navigation categories", ReferenceSettingsCatalog.TABS.length == 9);
        check("all required feature routes are present", ReferenceSettingsCatalog.routesAreComplete());
        check("catalog IDs are unique", ReferenceSettingsCatalog.idsAreUnique());
        check("dropdowns have two or more entries", ReferenceSettingsCatalog.everyDropdownHasAtLeastTwoOptions());
        check("choice controls have two or more options", ReferenceSettingsCatalog.everyChoiceHasAtLeastTwoOptions());
        check("dropdown nesting stays flat", ReferenceSettingsCatalog.maxDropdownDepth() <= 1);
        check("player-facing text audit is clean", ReferenceSettingsCatalog.playerTextViolations().isEmpty());

        List<String> ids = ReferenceSettingsCatalog.allIds();
        Set<String> expected = new HashSet<String>(Arrays.asList(
                "color-mode", "accent-color", "item-lock-swap", "dungeon-map-player-heads",
                "hud-dungeon-run", "room-clear-alert", "smooth-aspect-teleport"));
        check("appearance and requested feature controls are retained", ids.containsAll(expected));
        check("settings are configurable without creating a second config schema",
                ReferenceSettingsCatalog.configurableIds().size() >= 100);

        System.out.println("settings catalog: passed " + passed + ", failed " + failed);
        if (failed > 0) System.exit(1);
    }

    private static void check(String name, boolean ok) {
        if (ok) passed++;
        else {
            failed++;
            System.out.println("FAIL " + name);
        }
    }
}
