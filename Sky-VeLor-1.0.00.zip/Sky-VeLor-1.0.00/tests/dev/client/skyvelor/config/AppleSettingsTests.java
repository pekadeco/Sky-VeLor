package dev.client.skyvelor.config;

import java.util.Properties;

/** Checks fresh-install performance defaults and explicit saved choices. */
public final class AppleSettingsTests {

    private static int passed;
    private static int failed;

    public static void main(String[] args) {
        check("fresh adaptive quality defaults off", !AppleSettings.adaptive);
        check("fresh Performance Boost Beta defaults on", AppleSettings.experimentalPerformance);
        check("first-person scale defaults to vanilla", AppleSettings.firstPersonItemScale == 100
                && AppleSettings.effectiveFirstPersonItemScale() == 100);
        check("first-person animation speed defaults to vanilla", AppleSettings.firstPersonAnimSpeed == 100
                && AppleSettings.effectiveFirstPersonAnimSpeed() == 100);
        check("fresh panel opacity is slightly transparent", AppleSettings.DEFAULT_GLASS_OPACITY == 88);
        check("smooth GUI scrolling defaults on", AppleSettings.smoothScrolling);
        check("GUI scroll multiplier is 1.0 at 100%", Math.abs(AppleSettings.guiScrollMultiplier() - 1.0F) < 0.001F);
        int previousScrollSpeed = AppleSettings.scrollSpeed;
        boolean previousScrollSpeedOn = AppleSettings.scrollSpeedOn;
        AppleSettings.scrollSpeedOn = true;
        AppleSettings.scrollSpeed = 150;
        check("GUI scroll multiplier follows 150% scroll speed", Math.abs(AppleSettings.guiScrollMultiplier() - 1.5F) < 0.001F);
        AppleSettings.scrollSpeedOn = false;
        check("GUI scroll multiplier respects disabled speed override", Math.abs(AppleSettings.guiScrollMultiplier() - 1.0F) < 0.001F);
        AppleSettings.scrollSpeed = previousScrollSpeed;
        AppleSettings.scrollSpeedOn = previousScrollSpeedOn;
        check("dungeon map enabled by default", AppleSettings.dungeonMap);
        check("dungeon map rotation follows Better NEF by default", AppleSettings.dungeonMapRotate);
        check("player labels enabled by default", AppleSettings.dungeonMapShowPlayerNames);
        check("player heads are optional and disabled by default", !AppleSettings.dungeonMapPlayerHeads);
        check("room-clear alert sound defaults off", !AppleSettings.dungeonRoomClearSound);
        check("room-clear alert duration is bounded", AppleSettings.effectiveDungeonRoomClearDurationMillis()
                >= AppleSettings.DUNGEON_ROOM_CLEAR_DURATION_MIN_MILLIS
                && AppleSettings.effectiveDungeonRoomClearDurationMillis()
                <= AppleSettings.DUNGEON_ROOM_CLEAR_DURATION_MAX_MILLIS);
        check("blood mob highlight is opt-in", !AppleSettings.bloodMobHighlight);
        check("item protection is enabled by default", AppleSettings.itemProtectionEnabled);
        check("item protection notifications are enabled by default", AppleSettings.itemProtectionNotifications);
        check("retired slot-lock gesture stays off on a fresh install", !AppleSettings.slotLockingEnabled);
        check("retired slot binding stays off on a fresh install", !AppleSettings.slotBindingEnabled);
        check("slot-lock notifications are enabled by default", AppleSettings.slotLockNotifications);
        check("inventory search defaults on", AppleSettings.inventorySearchEnabled);
        check("inventory potion panel hiding defaults on", AppleSettings.hideInventoryPotionEffects);
        check("auto sprint defaults on", AppleSettings.autoSprintEnabled);
        check("numeric tooltip levels default on", AppleSettings.romanNumeralsInTooltips);
        check("scrollable tooltips are enabled by default like Better NEF", AppleSettings.scrollableTooltipsEnabled);
        check("starred mob display defaults to Box mode", AppleSettings.starredMobDisplayMode == dev.client.skyvelor.feature.StarredMobPolicy.DISPLAY_BOX);
        check("starred dungeon mobs are highlighted by default", AppleSettings.starredMobHighlights);
        check("starred mob ESP defaults on like Better NEF", AppleSettings.starredMobEsp);
        check("starred mob default color matches source default", AppleSettings.DEFAULT_STARRED_MOB_COLOR.equals(AppleSettings.starredMobColor));
        check("Better NEF-style chat cleanup is enabled by default", AppleSettings.removeIrritatingMessagesEnabled);
        check("dungeon irrelevant dialogue filter defaults on", AppleSettings.muteDungeonBossCrowdMessages);
        check("270 Score notifier matches Better NEF default", AppleSettings.dungeonSNotifier);
        check("S+ reminder matches Better NEF default", AppleSettings.dungeonSPlusReminder);
        check("S+ party message matches Better NEF default", AppleSettings.dungeonSPlusPartyMessage);
        check("simple score overlay matches Better NEF default", AppleSettings.dungeonScoreSimple);
        check("Paul bonus is an explicit manual score setting", !AppleSettings.dungeonPaulBonus);
        check("Watchdog/Info filter follows Better NEF default", AppleSettings.chatDisableWatchdogInfo);
        check("friend join/leave filter stays opt-in like Better NEF", !AppleSettings.chatDisableFriendJoin);
        check("rare-drop filter follows Better NEF default", AppleSettings.chatDisableZombieRareDrops);
        check("selling-rank filter stays opt-in like Better NEF", !AppleSettings.chatDisableSellingRanks);
        check("server announcement filter follows Better NEF default", AppleSettings.chatDisableServerAnnouncements);
        check("game invite filter follows Better NEF default", AppleSettings.chatDisableGameInvites);
        check("rarity outlines default on", AppleSettings.itemRarityBordersEnabled);
        check("chat copy defaults to enabled like Better NEF", AppleSettings.chatCopyEnabled);
        check("Chat Length defaults to the 256-character limit", AppleSettings.chatLengthEnabled);
        check("chat tabs default to All", AppleSettings.chatFilterMode == 0);
        check("no hurt camera defaults to the Better NEF-style enabled state", AppleSettings.noHurtCamEnabled);
        check("block-hit and breaking particles are hidden by default", AppleSettings.hideBlockBreakingParticles);
        check("dead non-player mobs are hidden immediately by default like Better NEF", AppleSettings.hideDeadMobs);
        check("Flaming Fists are hidden by default in supported SkyBlock contexts", AppleSettings.hideFlamingFists);
        check("Wardrobe shortcut is opt-in", !AppleSettings.wardrobeShortcutEnabled);
        check("Pets shortcut is opt-in", !AppleSettings.petsShortcutEnabled);
        check("mining ability notifier is opt-in", !AppleSettings.miningAbilityNotifier);
        check("Dwarven Puzzler helper is opt-in", !AppleSettings.miningPuzzlerSolver);
        check("blood mob highlight defaults to green", AppleSettings.bloodMobHighlightColor.equals("0:255:0:255:0"));
        check("puzzle labels enabled by default", AppleSettings.dungeonMapShowPuzzleName);
        check("dungeon map scale defaults to 100%", AppleSettings.dungeonMapScale == 100);
        check("dungeon map scale is enabled by default", AppleSettings.dungeonMapScaleOn);
        check("dungeon map content zoom defaults to 100%", AppleSettings.dungeonMapZoom == 100);
        check("map content zoom supports down to 50%", AppleSettings.DUNGEON_MAP_ZOOM_MIN == 50);
        check("map content zoom supports up to 200%", AppleSettings.DUNGEON_MAP_ZOOM_MAX == 200);
        check("map content zoom factor is 1.0 at 100%", Math.abs(AppleSettings.dungeonMapZoomFactor() - 1.0F) < 0.001F);
        AppleSettings.dungeonMapZoom = 999;
        check("map content zoom clamps to 200%", AppleSettings.effectiveDungeonMapZoom() == 200);
        AppleSettings.dungeonMapZoom = 20;
        check("map content zoom clamps to 50%", AppleSettings.effectiveDungeonMapZoom() == 50);
        AppleSettings.dungeonMapZoom = 100;
        check("map scale supports down to 70%", AppleSettings.DUNGEON_MAP_SCALE_MIN == 70);
        check("map scale supports up to 250%", AppleSettings.DUNGEON_MAP_SCALE_MAX == 250);
        check("map scale default remains within the expanded range", AppleSettings.dungeonMapScale >= AppleSettings.DUNGEON_MAP_SCALE_MIN
                && AppleSettings.dungeonMapScale <= AppleSettings.DUNGEON_MAP_SCALE_MAX);
        check("map scale factor uses 100% on a large viewport",
                Math.abs(AppleSettings.dungeonMapScaleFactor(1920, 1080) - 1.0F) < 0.001F);
        check("map size at 100% is 128 GUI pixels", AppleSettings.dungeonMapPixelSize(1920, 1080) == 128);
        AppleSettings.dungeonMapScaleOn = true;
        AppleSettings.dungeonMapScale = 250;
        check("map size expands to 250% when viewport permits", AppleSettings.dungeonMapPixelSize(1920, 1080) == 320);
        check("map size remains viewport-fitted on a short screen", AppleSettings.dungeonMapPixelSize(854, 200) == 200);
        AppleSettings.dungeonMapScaleOn = false;
        check("disabled map scale uses native 100% geometry", AppleSettings.dungeonMapPixelSize(1920, 1080) == 128);
        check("effective map scale is native size while scale is disabled", AppleSettings.effectiveDungeonMapScale() == 100);
        AppleSettings.dungeonMapScaleOn = true;
        AppleSettings.dungeonMapScale = 100;
        check("dungeon map starts near the upper-left", AppleSettings.dungeonMapXPercent == 2 && AppleSettings.dungeonMapYPercent == 2);
        AppleSettings.setDungeonMapPosition(400, 300, 128, -140, 350, false, 0);
        check("map placement can be moved left of the viewport", AppleSettings.dungeonMapLeft(400, 300, 128) == -140);
        check("map placement can be moved below the viewport", AppleSettings.dungeonMapTop(400, 300, 128) == 350);
        AppleSettings.resetDungeonMapPosition();

        AppleSettings.adaptive = AppleSettings.DEFAULT_ADAPTIVE_QUALITY;
        AppleSettings.experimentalPerformance = AppleSettings.DEFAULT_PERFORMANCE_BOOST_BETA;
        AppleSettings.loadPerformanceSettings(new Properties());
        check("empty fresh config keeps adaptive disabled", !AppleSettings.adaptive);
        check("empty fresh config keeps Performance Boost Beta enabled",
                AppleSettings.experimentalPerformance);

        Properties saved = new Properties();
        saved.setProperty("dungeon.bloodMobHighlight", "true");
        saved.setProperty("itemProtection.enabled", "false");
        saved.setProperty("itemProtection.notifications", "false");
        saved.setProperty("slotLocking.enabled", "true");
        saved.setProperty("slotLocking.binding", "false");
        saved.setProperty("slotLocking.notifications", "false");
        check("item protection persisted setting reads false", !AppleSettings.readBool(saved, "itemProtection.enabled", true));
        check("item protection notifications persisted setting reads false", !AppleSettings.readBool(saved, "itemProtection.notifications", true));
        check("slot locking persisted setting reads true", AppleSettings.readBool(saved, "slotLocking.enabled", false));
        check("slot binding persisted setting reads false", !AppleSettings.readBool(saved, "slotLocking.binding", true));
        check("slot-lock notifications persisted setting reads false", !AppleSettings.readBool(saved, "slotLocking.notifications", true));
        saved.setProperty("qol.inventorySearch", "true");
        saved.setProperty("qol.hideInventoryPotionEffects", "true");
        saved.setProperty("movement.autoSprint", "true");
        saved.setProperty("qol.romanNumerals", "true");
        saved.setProperty("qol.scrollableTooltips", "true");
        saved.setProperty("qol.itemRarityBorders", "true");
        saved.setProperty("qol.chatCopy", "true");
        saved.setProperty("qol.noHurtCam", "false");
        saved.setProperty("qol.hideBlockBreakingParticles", "true");
        saved.setProperty("qol.hideDeadMobs", "false");
        saved.setProperty("qol.hideFlamingFists", "true");
        saved.setProperty("qol.wardrobeShortcut", "true");
        saved.setProperty("qol.petsShortcut", "true");
        check("inventory search setting can be read", AppleSettings.readBool(saved, "qol.inventorySearch", false));
        check("inventory potion-panel setting can be read", AppleSettings.readBool(saved, "qol.hideInventoryPotionEffects", false));
        check("auto sprint setting can be read", AppleSettings.readBool(saved, "movement.autoSprint", false));
        check("Roman numeral setting can be read", AppleSettings.readBool(saved, "qol.romanNumerals", false));
        check("scrollable tooltip setting can be read", AppleSettings.readBool(saved, "qol.scrollableTooltips", false));
        saved.setProperty("starredMobHighlights", "false");
        saved.setProperty("qol.removeIrritatingMessages", "false");
        saved.setProperty("dungeon.muteBossCrowdMessages", "false");
        check("starred mob setting can be read", !AppleSettings.readBool(saved, "starredMobHighlights", true));
        check("chat cleaner master can be read", !AppleSettings.readBool(saved, "qol.removeIrritatingMessages", true));
        check("dungeon mute setting can be read", !AppleSettings.readBool(saved, "dungeon.muteBossCrowdMessages", true));
        check("rarity border setting can be read", AppleSettings.readBool(saved, "qol.itemRarityBorders", false));
        check("chat copy setting can be read", AppleSettings.readBool(saved, "qol.chatCopy", false));
        check("no hurt camera setting can be read", !AppleSettings.readBool(saved, "qol.noHurtCam", true));
        check("block particle setting can be read", AppleSettings.readBool(saved, "qol.hideBlockBreakingParticles", false));
        check("dead-mob visibility setting can be disabled", !AppleSettings.readBool(saved, "qol.hideDeadMobs", true));
        check("Flaming Fists setting can be enabled", AppleSettings.readBool(saved, "qol.hideFlamingFists", false));
        check("Wardrobe shortcut setting can be read", AppleSettings.readBool(saved, "qol.wardrobeShortcut", false));
        check("Pets shortcut setting can be read", AppleSettings.readBool(saved, "qol.petsShortcut", false));
        saved.setProperty("mining.abilityNotifier", "true");
        saved.setProperty("mining.puzzlerSolver", "true");
        check("mining ability notifier setting can be read", AppleSettings.readBool(saved, "mining.abilityNotifier", false));
        check("Puzzler helper setting can be read", AppleSettings.readBool(saved, "mining.puzzlerSolver", false));
        check("blood mob highlight setting reads true", AppleSettings.readBool(saved, "dungeon.bloodMobHighlight", false));
        check("blood highlight color validates known palette value",
                AppleSettings.readColor("0:255:255:0:0", "0:255:0:255:0").equals("0:255:255:0:0"));
        check("invalid blood highlight color falls back safely",
                AppleSettings.readColor("0:999:255:0:0", "0:255:0:255:0").equals("0:255:0:255:0"));
        saved.setProperty("dungeonMapRotate", "false");
        check("static-map config value parses false", !AppleSettings.readBool(saved, "dungeonMapRotate", true));
        saved.setProperty("dungeonMapScaleOn", "false");
        check("disabled map scale config value parses false",
                !AppleSettings.readBool(saved, "dungeonMapScaleOn", true));
        saved.setProperty("dungeonMapZoom", "165");
        check("saved map content zoom is read as an integer", AppleSettings.readInt(saved, "dungeonMapZoom", 100,
                AppleSettings.DUNGEON_MAP_ZOOM_MIN, AppleSettings.DUNGEON_MAP_ZOOM_MAX) == 165);
        saved.setProperty("adaptive", "true");
        Properties chatTabs = new Properties();
        check("missing chat tab setting defaults to All", AppleSettings.readChatTabMode(chatTabs) == 0);
        chatTabs.setProperty("chat.tabMode", "3");
        check("new chat tab setting reads PM", AppleSettings.readChatTabMode(chatTabs) == 3);
        chatTabs.clear();
        chatTabs.setProperty("chat.filterMode", "2");
        check("legacy Co-op tab migrates to the fifth tab", AppleSettings.readChatTabMode(chatTabs) == 4);
        chatTabs.setProperty("chat.filterMode", "1");
        check("legacy Party tab preserves its identity", AppleSettings.readChatTabMode(chatTabs) == 1);

        saved.setProperty("adaptive", "true");
        saved.setProperty("experimentalPerformance", "false");
        AppleSettings.loadPerformanceSettings(saved);
        check("saved adaptive choice is preserved", AppleSettings.adaptive);
        check("saved Performance Boost Beta choice is preserved", !AppleSettings.experimentalPerformance);

        AppleSettings.loadPerformanceSettings(new Properties());
        check("missing keys do not overwrite effective adaptive choice", AppleSettings.adaptive);
        check("missing keys do not overwrite effective performance choice",
                !AppleSettings.experimentalPerformance);

        System.out.println();
        System.out.println("apple settings: passed " + passed + ", failed " + failed);
        if (failed > 0) {
            System.exit(1);
        }
    }

    private static void check(String name, boolean ok) {
        if (ok) {
            passed++;
        } else {
            failed++;
            System.out.println("FAIL " + name);
        }
    }
}
