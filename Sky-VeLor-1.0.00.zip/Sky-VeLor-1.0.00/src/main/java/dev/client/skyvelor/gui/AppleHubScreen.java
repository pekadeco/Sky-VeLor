package dev.client.skyvelor.gui;

import net.minecraft.client.gui.GuiScreen;

/**
 * Compatibility entry point for the original /sv settings command. The Beta settings shell is now primary.
 * Keeping this alias avoids breaking existing commands and GUI integrations while maintaining one visible surface.
 */
@Deprecated
public final class AppleHubScreen extends AppleSettingsScreen {
    public AppleHubScreen(GuiScreen parent) {
        super(parent);
    }

    private AppleHubScreen(GuiScreen parent, ReferenceSettingsCatalog.Tab initialTab) {
        super(parent, initialTab);
    }

    public static AppleHubScreen dungeonHud(GuiScreen parent) {
        return new AppleHubScreen(parent, ReferenceSettingsCatalog.Tab.DUNGEON);
    }
}
