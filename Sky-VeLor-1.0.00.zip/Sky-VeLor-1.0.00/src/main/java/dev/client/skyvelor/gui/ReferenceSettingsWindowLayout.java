package dev.client.skyvelor.gui;

/** Geometry policy for the compact and fullscreen settings shell. */
public final class ReferenceSettingsWindowLayout {
    private static final float COMPACT_MAX_WIDTH = 1120f;
    private static final float COMPACT_MAX_HEIGHT = 820f;
    private static final float COMPACT_MARGIN = 24f;
    private static final float FULLSCREEN_MARGIN = 6f;

    private ReferenceSettingsWindowLayout() {
    }

    public static void layout(GuiLayoutToolkit.Rect panel, float screenWidth, float screenHeight,
                              boolean fullscreen, float offsetX, float offsetY) {
        if (panel == null) return;
        float width = Math.max(1f, screenWidth);
        float height = Math.max(1f, screenHeight);
        if (fullscreen) {
            panel.set(FULLSCREEN_MARGIN, FULLSCREEN_MARGIN,
                    Math.max(1f, width - FULLSCREEN_MARGIN * 2f),
                    Math.max(1f, height - FULLSCREEN_MARGIN * 2f));
            return;
        }
        float panelWidth = Math.min(COMPACT_MAX_WIDTH, Math.max(1f, width - COMPACT_MARGIN * 2f));
        float panelHeight = Math.min(COMPACT_MAX_HEIGHT, Math.max(1f, height - COMPACT_MARGIN * 2f));
        float x = centeredX(width, panelWidth) + offsetX;
        float y = centeredY(height, panelHeight) + offsetY;
        GuiLayoutToolkit.clampPanel(panel, x, y, panelWidth, panelHeight, width, height);
    }

    public static float centeredX(float screenWidth, float panelWidth) {
        return (screenWidth - panelWidth) * 0.5f;
    }

    public static float centeredY(float screenHeight, float panelHeight) {
        return (screenHeight - panelHeight) * 0.5f;
    }
}
