package dev.client.skyvelor.render.itemanimation;

import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;
import dev.client.skyvelor.itemlockswap.ItemLockSwapHookStatus;
import dev.client.skyvelor.itemlockswap.ItemLockSwapTransformer;
import dev.client.skyvelor.assist.visual.AspectTeleportCameraTransformer;

import java.util.Map;

/**
 * Existing Forge 1.8.9 coremod entry point for three narrowly scoped client-side transformers:
 * first-person item animation, protected inventory clicks/drops, and render-only Aspect camera smoothing.
 */
@IFMLLoadingPlugin.Name("Sky VeLor Item Animation")
@IFMLLoadingPlugin.MCVersion("1.8.9")
@IFMLLoadingPlugin.SortingIndex(1001)
@IFMLLoadingPlugin.TransformerExclusions({"dev.client.skyvelor.render.itemanimation", "dev.client.skyvelor.itemlockswap", "dev.client.skyvelor.assist.visual"})
public final class ItemAnimationLoadingPlugin implements IFMLLoadingPlugin {

    @Override
    public String[] getASMTransformerClass() {
        ItemAnimationHookStatus.noteCoremodRegistered();
        ItemLockSwapHookStatus.noteCoremodRegistered();
        return new String[] {
                ItemAnimationTransformer.class.getName(),
                ItemLockSwapTransformer.class.getName(),
                AspectTeleportCameraTransformer.class.getName()
        };
    }

    @Override
    public String getModContainerClass() {
        return null;
    }

    @Override
    public String getSetupClass() {
        return null;
    }

    @Override
    public void injectData(Map<String, Object> data) {
        // The transformer is deliberately independent of Minecraft during coremod discovery.
    }

    @Override
    public String getAccessTransformerClass() {
        return null;
    }
}
