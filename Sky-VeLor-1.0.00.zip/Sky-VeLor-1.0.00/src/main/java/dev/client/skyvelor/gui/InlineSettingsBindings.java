package dev.client.skyvelor.gui;

import dev.client.skyvelor.chat.ChatMenuPolicy;
import dev.client.skyvelor.config.AppleSettings;
import dev.client.skyvelor.config.ChatQolSettings;
import dev.client.skyvelor.config.FontSettings;
import dev.client.skyvelor.dungeon.M7OverlayRenderer;
import dev.client.skyvelor.dungeon.M7Settings;
import dev.client.skyvelor.dungeon.sync.DungeonPuzzleSyncConfig;
import dev.client.skyvelor.feature.StarredMobPolicy;
import dev.client.skyvelor.fishing.FishingStats;
import dev.client.skyvelor.hud.HudManager;
import dev.client.skyvelor.itemlockswap.ItemLockSwapSettings;
import dev.client.skyvelor.render.GlobalFontManager;
import dev.client.skyvelor.slayer.SlayerTracker;
import dev.client.skyvelor.slayer.SlayerType;
import net.minecraft.client.Minecraft;

/**
 * Bridges the Beta settings presentation to the established v1.0.0 configuration owners.
 * This class intentionally does not introduce a second persistence schema or duplicate feature flags.
 */
final class InlineSettingsBindings {
    private InlineSettingsBindings() { }

    static boolean booleanValue(String id) {
        if (id == null) return false;
        switch (id) {
            case "no-block-particles": return AppleSettings.hideBlockBreakingParticles;
            case "no-hurt-cam": return AppleSettings.noHurtCamEnabled;
            case "smooth-aspect-teleport": return AppleSettings.smoothAspectTeleport;
            case "hide-dead-mobs": return AppleSettings.hideDeadMobs;
            case "hide-flaming-fists": return AppleSettings.hideFlamingFists;
            case "auto-sprint": return AppleSettings.autoSprintEnabled;
            case "item-lock-swap": return ItemLockSwapSettings.enabled;
            case "item-lock-icons": return ItemLockSwapSettings.showLockIcons;
            case "item-lock-hotbar": return ItemLockSwapSettings.showIconsOnHotbar;
            case "item-lock-message": return ItemLockSwapSettings.showBlockedMessage;
            case "item-protection": return AppleSettings.itemProtectionEnabled;
            case "item-protection-notifications": return AppleSettings.itemProtectionNotifications;
            case "inventory-search": return AppleSettings.inventorySearchEnabled;
            case "hide-potions": return AppleSettings.hideInventoryPotionEffects;
            case "roman-numerals": return AppleSettings.romanNumeralsInTooltips;
            case "tooltip-scroll": return AppleSettings.scrollableTooltipsEnabled;
            case "rarity-highlight": return AppleSettings.itemRarityBordersEnabled;
            case "chat-length-256": return AppleSettings.chatLengthEnabled;
            case "chat-copy": return AppleSettings.chatCopyEnabled;
            case "chat-filter-master": return AppleSettings.removeIrritatingMessagesEnabled;
            case "global-font-enabled": return FontSettings.enabled;
            case "global-font-all-minecraft": return FontSettings.applyToEverything;
            case "chat-filter-watchdog": return AppleSettings.chatDisableWatchdogInfo;
            case "chat-filter-friend-join": return AppleSettings.chatDisableFriendJoin;
            case "chat-filter-rare-drops": return AppleSettings.chatDisableZombieRareDrops;
            case "chat-filter-rank-ads": return AppleSettings.chatDisableSellingRanks;
            case "chat-filter-announcements": return AppleSettings.chatDisableServerAnnouncements;
            case "chat-filter-invites": return AppleSettings.chatDisableGameInvites;
            case "equipment-overlay": return AppleSettings.equipmentOverlayEnabled;
            case "show-current-pet": return AppleSettings.showCurrentPet;
            case "chat-qol": return ChatQolSettings.enabled;
            case "chat-tabs": return ChatQolSettings.tabsEnabled;
            case "chat-smooth": return ChatQolSettings.smoothMessages;
            case "chat-compact": return ChatQolSettings.compactMessages;
            case "chat-hover": return ChatQolSettings.hoverHighlight;
            case "chat-background-fit-width": return ChatQolSettings.backgroundFitWidth;
            case "slayer-tracker": return AppleSettings.slayerTracker;
            case "slayer-boss-timer": return AppleSettings.slayerBossTimer;
            case "slayer-pricing": return AppleSettings.slayerPricing;
            case "wardrobe-shortcut": return AppleSettings.wardrobeShortcutEnabled;
            case "pets-shortcut": return AppleSettings.petsShortcutEnabled;
            case "dungeon-map": return AppleSettings.dungeonMap;
            case "dungeon-map-player-heads": return AppleSettings.dungeonMapPlayerHeads;
            case "dungeon-map-player-names": return AppleSettings.dungeonMapShowPlayerNames;
            case "dungeon-map-rotate": return AppleSettings.dungeonMapRotate;
            case "dungeon-map-puzzle-names": return AppleSettings.dungeonMapShowPuzzleName;
            case "dungeon-map-scale-on": return AppleSettings.dungeonMapScaleOn;
            case "hud-dungeon-secrets": return HudManager.DUNGEON_SECRETS.enabled;
            case "solver-three-weirdos": return AppleSettings.solverThreeWeirdos;
            case "solver-creeper": return AppleSettings.solverCreeper;
            case "solver-boulder": return AppleSettings.solverBoulder;
            case "solver-silverfish": return AppleSettings.solverSilverfish;
            case "solver-water": return AppleSettings.solverWater;
            case "solver-teleport-maze": return AppleSettings.solverTeleportMaze;
            case "solver-first-device": return AppleSettings.solverFirstDevice;
            case "solver-third-device": return AppleSettings.solverThirdDevice;
            case "terminal-custom-starting": return AppleSettings.terminalCustomStartsWith;
            case "terminal-custom-colors": return AppleSettings.terminalCustomColors;
            case "terminal-custom-click-order": return AppleSettings.terminalCustomClickIn;
            case "terminal-custom-maze": return AppleSettings.terminalCustomMaze;
            case "terminal-custom-panes": return AppleSettings.terminalCustomPanes;
            case "terminal-tracker": return AppleSettings.terminalTracker;
            case "terminal-starting": return AppleSettings.terminalStartsWithSolver;
            case "terminal-colors": return AppleSettings.terminalColorsSolver;
            case "terminal-click-order": return AppleSettings.terminalClickInOrderSolver;
            case "terminal-maze": return AppleSettings.terminalMazeSolver;
            case "terminal-correct-panes": return AppleSettings.terminalCorrectPanesSolver;
            case "terminal-hide-tooltips": return AppleSettings.terminalHideTooltips;
            case "terminal-hide-wrong": return AppleSettings.terminalHideIncorrect;
            case "terminal-prevent-clicks": return AppleSettings.terminalPreventMissclicks;
            case "terminal-waypoints": return AppleSettings.terminalWaypoints;
            case "spirit-leap": return AppleSettings.leapMenu;
            case "leap-key": return AppleSettings.leapKey;
            case "dungeon-boss-hud": return HudManager.DUNGEON_BOSS_HP.enabled;
            case "dungeon-score-hud": return HudManager.DUNGEON_SCORE.enabled;
            case "dungeon-score-compact": return AppleSettings.dungeonScoreSimple;
            case "room-clear-alert": return HudManager.ROOM_CLEAR_ALERT.enabled;
            case "room-clear-sound": return AppleSettings.dungeonRoomClearSound;
            case "dungeon-auto-chest-close": return AppleSettings.dungeonAutoCloseSecretChests;
            case "spirit-bow-locator": return AppleSettings.dungeonSpiritBowTracer;
            case "dungeon-s-plus-reminder": return AppleSettings.dungeonSPlusReminder;
            case "dungeon-s-notifier": return AppleSettings.dungeonSNotifier;
            case "dungeon-s-plus-party-message": return AppleSettings.dungeonSPlusPartyMessage;
            case "dungeon-paul-bonus": return AppleSettings.dungeonPaulBonus;
            case "dungeon-blood-ready-title": return AppleSettings.dungeonBloodReadyTitle;
            case "m7-overlay": return M7Settings.isOverlayEnabled();
            case "m7-relic-areas": return M7Settings.isStatueZonesEnabled();
            case "m7-areas-persist": return M7Settings.isAreasPersistAfterDragonSpawn();
            case "dragon-alerts": return M7Settings.isDragonKillAlertEnabled();
            case "m7-boss-maxor": return M7Settings.isBossHitboxEnabled(M7OverlayRenderer.M7HitboxTarget.MAXOR);
            case "m7-boss-storm": return M7Settings.isBossHitboxEnabled(M7OverlayRenderer.M7HitboxTarget.STORM);
            case "m7-boss-goldor": return M7Settings.isBossHitboxEnabled(M7OverlayRenderer.M7HitboxTarget.GOLDOR);
            case "m7-boss-necron": return M7Settings.isBossHitboxEnabled(M7OverlayRenderer.M7HitboxTarget.NECRON);
            case "m7-dragon-power": return M7Settings.isDragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.POWER);
            case "m7-dragon-apex": return M7Settings.isDragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.APEX);
            case "m7-dragon-soul": return M7Settings.isDragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.SOUL);
            case "m7-dragon-ice": return M7Settings.isDragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.ICE);
            case "m7-dragon-flame": return M7Settings.isDragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.FLAME);
            case "dungeon-sync-enabled": return DungeonPuzzleSyncConfig.isEnabled(Minecraft.getMinecraft());
            case "dungeon-sync-debug": return DungeonPuzzleSyncConfig.isDiagnosticsEnabled(Minecraft.getMinecraft());
            case "starred-mob-highlights": return AppleSettings.starredMobDisplayMode != StarredMobPolicy.DISPLAY_DISABLED;
            case "mob-highlights": return AppleSettings.mobHighlights;
            case "starred-mob-through-walls": return AppleSettings.starredMobEsp;
            case "fel-esp": return AppleSettings.felEsp;
            case "blood-mob-highlight": return AppleSettings.bloodMobHighlight;
            case "wither-doors-highlight": return AppleSettings.dungeonWitherDoorsHighlight;
            case "hide-unable-to-locate": return AppleSettings.dungeonHideUnableToLocateSign;
            case "mute-boss-crowd": return AppleSettings.muteDungeonBossCrowdMessages;
            case "mining-bps": return HudManager.MINING.enabled;
            case "mining-ability-alert": return AppleSettings.miningAbilityNotifier;
            case "mining-puzzler": return AppleSettings.miningPuzzlerSolver;
            case "mining-assistant-hud": return HudManager.MINING_ASSISTANT.enabled;
            case "catch-counter":
            case "fishing-counter": return AppleSettings.fishingCounter;
            case "fishing-festival": return AppleSettings.fishingFestival;
            case "sea-hp-hud-route": return HudManager.SEA_HP.enabled;
            case "jawbus": return AppleSettings.fishingJawbusAlert;
            case "hud-player-doll": return HudManager.DOLL.enabled;
            case "hud-inventory": return HudManager.INVENTORY.enabled;
            case "hud-dungeon-run": return HudManager.DUNGEON_RUN.enabled;
            case "item-animation": return AppleSettings.itemAnimationEnabled;
            case "appearance-corners-on": return AppleSettings.cornerRadiusOn;
            case "appearance-opacity-on": return AppleSettings.glassOpacityOn;
            case "shadows": return AppleSettings.shadows;
            case "animations": return AppleSettings.animations;
            case "animation-speed-on": return AppleSettings.animSpeedOn;
            case "adaptive-quality": return AppleSettings.adaptive;
            case "performance-boost": return AppleSettings.experimentalPerformance;
            case "smooth-scrolling": return AppleSettings.smoothScrolling;
            case "sv-command": return AppleSettings.svCommand;
            case "qn-command": return AppleSettings.qnCommand;
            default: return false;
        }
    }

    static void setBoolean(String id, boolean value) {
        if (id == null) return;
        switch (id) {
            case "no-block-particles": AppleSettings.hideBlockBreakingParticles = value; break;
            case "no-hurt-cam": AppleSettings.noHurtCamEnabled = value; break;
            case "smooth-aspect-teleport": AppleSettings.smoothAspectTeleport = value; break;
            case "hide-dead-mobs": AppleSettings.hideDeadMobs = value; break;
            case "hide-flaming-fists": AppleSettings.hideFlamingFists = value; break;
            case "auto-sprint": AppleSettings.autoSprintEnabled = value; break;
            case "item-lock-swap": ItemLockSwapSettings.enabled = value; break;
            case "item-lock-icons": ItemLockSwapSettings.showLockIcons = value; break;
            case "item-lock-hotbar": ItemLockSwapSettings.showIconsOnHotbar = value; break;
            case "item-lock-message": ItemLockSwapSettings.showBlockedMessage = value; break;
            case "item-protection": AppleSettings.itemProtectionEnabled = value; break;
            case "item-protection-notifications": AppleSettings.itemProtectionNotifications = value; break;
            case "inventory-search": AppleSettings.inventorySearchEnabled = value; break;
            case "hide-potions": AppleSettings.hideInventoryPotionEffects = value; break;
            case "roman-numerals": AppleSettings.romanNumeralsInTooltips = value; break;
            case "tooltip-scroll": AppleSettings.scrollableTooltipsEnabled = value; break;
            case "rarity-highlight": AppleSettings.itemRarityBordersEnabled = value; break;
            case "chat-length-256": AppleSettings.chatLengthEnabled = value; ChatQolSettings.extendedChatLength = value; break;
            case "chat-copy": AppleSettings.chatCopyEnabled = value; break;
            case "chat-filter-master": AppleSettings.removeIrritatingMessagesEnabled = value; break;
            case "global-font-enabled": FontSettings.enabled = value; GlobalFontManager.reload(); break;
            case "global-font-all-minecraft": FontSettings.applyToEverything = value; break;
            case "chat-filter-watchdog": AppleSettings.chatDisableWatchdogInfo = value; break;
            case "chat-filter-friend-join": AppleSettings.chatDisableFriendJoin = value; break;
            case "chat-filter-rare-drops": AppleSettings.chatDisableZombieRareDrops = value; break;
            case "chat-filter-rank-ads": AppleSettings.chatDisableSellingRanks = value; break;
            case "chat-filter-announcements": AppleSettings.chatDisableServerAnnouncements = value; break;
            case "chat-filter-invites": AppleSettings.chatDisableGameInvites = value; break;
            case "equipment-overlay": AppleSettings.equipmentOverlayEnabled = value; break;
            case "show-current-pet": AppleSettings.showCurrentPet = value; break;
            case "chat-qol": ChatQolSettings.enabled = value; break;
            case "chat-tabs": ChatQolSettings.tabsEnabled = value; break;
            case "chat-smooth": ChatQolSettings.smoothMessages = value; break;
            case "chat-compact": ChatQolSettings.compactMessages = value; break;
            case "chat-hover": ChatQolSettings.hoverHighlight = value; break;
            case "chat-background-fit-width": ChatQolSettings.backgroundFitWidth = value; break;
            case "slayer-tracker": AppleSettings.slayerTracker = value; break;
            case "slayer-boss-timer": AppleSettings.slayerBossTimer = value; break;
            case "slayer-pricing": AppleSettings.slayerPricing = value; break;
            case "wardrobe-shortcut": AppleSettings.wardrobeShortcutEnabled = value; break;
            case "pets-shortcut": AppleSettings.petsShortcutEnabled = value; break;
            case "dungeon-map": AppleSettings.dungeonMap = value; break;
            case "dungeon-map-player-heads": AppleSettings.dungeonMapPlayerHeads = value; break;
            case "dungeon-map-player-names": AppleSettings.dungeonMapShowPlayerNames = value; break;
            case "dungeon-map-rotate": AppleSettings.dungeonMapRotate = value; break;
            case "dungeon-map-puzzle-names": AppleSettings.dungeonMapShowPuzzleName = value; break;
            case "dungeon-map-scale-on": AppleSettings.dungeonMapScaleOn = value; if (!value) AppleSettings.dungeonMapScale = 100; break;
            case "hud-dungeon-secrets": HudManager.DUNGEON_SECRETS.enabled = value; break;
            case "solver-three-weirdos": AppleSettings.solverThreeWeirdos = value; break;
            case "solver-creeper": AppleSettings.solverCreeper = value; break;
            case "solver-boulder": AppleSettings.solverBoulder = value; break;
            case "solver-silverfish": AppleSettings.solverSilverfish = value; break;
            case "solver-water": AppleSettings.solverWater = value; break;
            case "solver-teleport-maze": AppleSettings.solverTeleportMaze = value; break;
            case "solver-first-device": AppleSettings.solverFirstDevice = value; break;
            case "solver-third-device": AppleSettings.solverThirdDevice = value; break;
            case "terminal-custom-starting": AppleSettings.terminalCustomStartsWith = value; break;
            case "terminal-custom-colors": AppleSettings.terminalCustomColors = value; break;
            case "terminal-custom-click-order": AppleSettings.terminalCustomClickIn = value; break;
            case "terminal-custom-maze": AppleSettings.terminalCustomMaze = value; break;
            case "terminal-custom-panes": AppleSettings.terminalCustomPanes = value; break;
            case "terminal-tracker": AppleSettings.terminalTracker = value; break;
            case "terminal-starting": AppleSettings.terminalStartsWithSolver = value; break;
            case "terminal-colors": AppleSettings.terminalColorsSolver = value; break;
            case "terminal-click-order": AppleSettings.terminalClickInOrderSolver = value; break;
            case "terminal-maze": AppleSettings.terminalMazeSolver = value; break;
            case "terminal-correct-panes": AppleSettings.terminalCorrectPanesSolver = value; break;
            case "terminal-hide-tooltips": AppleSettings.terminalHideTooltips = value; break;
            case "terminal-hide-wrong": AppleSettings.terminalHideIncorrect = value; break;
            case "terminal-prevent-clicks": AppleSettings.terminalPreventMissclicks = value; break;
            case "terminal-waypoints": AppleSettings.terminalWaypoints = value; break;
            case "spirit-leap": AppleSettings.leapMenu = value; break;
            case "leap-key": AppleSettings.leapKey = value; break;
            case "dungeon-boss-hud": HudManager.DUNGEON_BOSS_HP.enabled = value; break;
            case "dungeon-score-hud": HudManager.DUNGEON_SCORE.enabled = value; break;
            case "dungeon-score-compact": AppleSettings.dungeonScoreSimple = value; break;
            case "room-clear-alert": HudManager.ROOM_CLEAR_ALERT.enabled = value; break;
            case "room-clear-sound": AppleSettings.dungeonRoomClearSound = value; break;
            case "dungeon-auto-chest-close": AppleSettings.dungeonAutoCloseSecretChests = value; break;
            case "spirit-bow-locator": AppleSettings.dungeonSpiritBowTracer = value; break;
            case "dungeon-s-plus-reminder": AppleSettings.dungeonSPlusReminder = value; break;
            case "dungeon-s-notifier": AppleSettings.dungeonSNotifier = value; break;
            case "dungeon-s-plus-party-message": AppleSettings.dungeonSPlusPartyMessage = value; break;
            case "dungeon-paul-bonus": AppleSettings.dungeonPaulBonus = value; break;
            case "dungeon-blood-ready-title": AppleSettings.dungeonBloodReadyTitle = value; break;
            case "m7-overlay": M7Settings.setOverlayEnabled(value); break;
            case "m7-relic-areas": M7Settings.setStatueZonesEnabled(value); break;
            case "m7-areas-persist": M7Settings.setAreasPersistAfterDragonSpawn(value); break;
            case "dragon-alerts": M7Settings.setDragonKillAlertEnabled(value); break;
            case "m7-boss-maxor": M7Settings.setBossHitboxEnabled(M7OverlayRenderer.M7HitboxTarget.MAXOR, value); break;
            case "m7-boss-storm": M7Settings.setBossHitboxEnabled(M7OverlayRenderer.M7HitboxTarget.STORM, value); break;
            case "m7-boss-goldor": M7Settings.setBossHitboxEnabled(M7OverlayRenderer.M7HitboxTarget.GOLDOR, value); break;
            case "m7-boss-necron": M7Settings.setBossHitboxEnabled(M7OverlayRenderer.M7HitboxTarget.NECRON, value); break;
            case "m7-dragon-power": M7Settings.setDragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.POWER, value); break;
            case "m7-dragon-apex": M7Settings.setDragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.APEX, value); break;
            case "m7-dragon-soul": M7Settings.setDragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.SOUL, value); break;
            case "m7-dragon-ice": M7Settings.setDragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.ICE, value); break;
            case "m7-dragon-flame": M7Settings.setDragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.FLAME, value); break;
            case "dungeon-sync-enabled": DungeonPuzzleSyncConfig.setEnabled(Minecraft.getMinecraft(), value); break;
            case "dungeon-sync-debug": DungeonPuzzleSyncConfig.setDiagnosticsEnabled(Minecraft.getMinecraft(), value); break;
            case "starred-mob-highlights":
                AppleSettings.setStarredMobDisplayMode(value ? StarredMobPolicy.DISPLAY_BOX : StarredMobPolicy.DISPLAY_DISABLED); break;
            case "mob-highlights": AppleSettings.mobHighlights = value; break;
            case "starred-mob-through-walls": AppleSettings.starredMobEsp = value; break;
            case "fel-esp": AppleSettings.felEsp = value; break;
            case "blood-mob-highlight": AppleSettings.bloodMobHighlight = value; break;
            case "wither-doors-highlight": AppleSettings.dungeonWitherDoorsHighlight = value; break;
            case "hide-unable-to-locate": AppleSettings.dungeonHideUnableToLocateSign = value; break;
            case "mute-boss-crowd": AppleSettings.muteDungeonBossCrowdMessages = value; break;
            case "mining-bps": HudManager.MINING.enabled = value; break;
            case "mining-ability-alert": AppleSettings.miningAbilityNotifier = value; break;
            case "mining-puzzler": AppleSettings.miningPuzzlerSolver = value; break;
            case "mining-assistant-hud": HudManager.MINING_ASSISTANT.enabled = value; break;
            case "catch-counter":
            case "fishing-counter": AppleSettings.fishingCounter = value; break;
            case "fishing-festival": AppleSettings.fishingFestival = value; break;
            case "sea-hp-hud-route": HudManager.SEA_HP.enabled = value; break;
            case "jawbus": AppleSettings.fishingJawbusAlert = value; break;
            case "hud-player-doll": HudManager.DOLL.enabled = value; break;
            case "hud-inventory": HudManager.INVENTORY.enabled = value; break;
            case "hud-dungeon-run": HudManager.DUNGEON_RUN.enabled = value; break;
            case "item-animation": AppleSettings.itemAnimationEnabled = value; break;
            case "appearance-corners-on": AppleSettings.cornerRadiusOn = value; break;
            case "appearance-opacity-on": AppleSettings.glassOpacityOn = value; break;
            case "shadows": AppleSettings.shadows = value; break;
            case "animations": AppleSettings.animations = value; break;
            case "animation-speed-on": AppleSettings.animSpeedOn = value; break;
            case "adaptive-quality": AppleSettings.adaptive = value; break;
            case "performance-boost": AppleSettings.experimentalPerformance = value; break;
            case "smooth-scrolling": AppleSettings.smoothScrolling = value; break;
            case "sv-command": AppleSettings.svCommand = value; break;
            case "qn-command": AppleSettings.qnCommand = value; break;
            default: break;
        }
    }

    static int intValue(String id) {
        if (id == null) return 0;
        switch (id) {
            case "item-lock-cooldown": return ItemLockSwapSettings.cooldownTenths;
            case "item-lock-badge-opacity": return ItemLockSwapSettings.iconOpacity;
            case "item-lock-line-opacity": return ItemLockSwapSettings.swapLineOpacity;
            case "item-lock-line-width": return ItemLockSwapSettings.swapLineWidth;
            case "chat-background-open-opacity": return ChatQolSettings.backgroundOpacityOpen;
            case "chat-background-closed-opacity": return ChatQolSettings.backgroundOpacityClosed;
            case "chat-background-radius": return ChatQolSettings.backgroundRadius;
            case "chat-message-animation": return ChatQolSettings.messageAnimationMillis;
            case "chat-fade-seconds": return ChatQolSettings.fadeSeconds;
            case "chat-tab-opacity": return ChatQolSettings.tabOpacity;
            case "chat-tab-active-opacity": return ChatQolSettings.tabActiveOpacity;
            case "chat-hover-opacity": return ChatQolSettings.hoverOpacity;
            case "room-clear-duration": return AppleSettings.effectiveDungeonRoomClearDurationMillis();
            case "terminal-scale": return Math.round(AppleSettings.terminalGuiScale * 10.0f);
            case "dungeon-map-scale": return AppleSettings.effectiveDungeonMapScale();
            case "dungeon-map-zoom": return AppleSettings.effectiveDungeonMapZoom();
            case "terminal-tracker-scale": return Math.round(AppleSettings.terminalTrackerScale * 10f);
            case "global-font-scale": return FontSettings.scale;
            case "appearance-corners": return AppleSettings.cornerRadius;
            case "appearance-opacity": return AppleSettings.glassOpacity;
            case "animation-speed": return AppleSettings.animSpeed;
            case "global-scroll": return AppleSettings.effectiveScrollSpeed();
            case "starred-mob-chroma": return StarredMobPolicy.chromaSpeed(AppleSettings.starredMobColor);
            case "starred-mob-stormy-chroma": return StarredMobPolicy.chromaSpeed(AppleSettings.starredMobStormyColor);
            case "starred-mob-wither-chroma": return StarredMobPolicy.chromaSpeed(AppleSettings.starredMobWithermancerColor);
            case "starred-mob-zombie-chroma": return StarredMobPolicy.chromaSpeed(AppleSettings.starredMobZombieCommanderColor);
            case "starred-mob-skeleton-chroma": return StarredMobPolicy.chromaSpeed(AppleSettings.starredMobSkeletonMasterColor);
            default: return 0;
        }
    }

    static void setInt(String id, int value) {
        if (id == null) return;
        switch (id) {
            case "item-lock-cooldown": ItemLockSwapSettings.cooldownTenths = clamp(value, ItemLockSwapSettings.MIN_COOLDOWN_TENTHS, ItemLockSwapSettings.MAX_COOLDOWN_TENTHS); break;
            case "item-lock-badge-opacity": ItemLockSwapSettings.iconOpacity = clamp(value, ItemLockSwapSettings.MIN_ICON_OPACITY, ItemLockSwapSettings.MAX_ICON_OPACITY); break;
            case "item-lock-line-opacity": ItemLockSwapSettings.swapLineOpacity = clamp(value, ItemLockSwapSettings.MIN_LINE_OPACITY, ItemLockSwapSettings.MAX_LINE_OPACITY); break;
            case "item-lock-line-width": ItemLockSwapSettings.swapLineWidth = clamp(value, ItemLockSwapSettings.MIN_LINE_WIDTH, ItemLockSwapSettings.MAX_LINE_WIDTH); break;
            case "chat-background-open-opacity": ChatQolSettings.backgroundOpacityOpen = clamp(value, 0, 100); break;
            case "chat-background-closed-opacity": ChatQolSettings.backgroundOpacityClosed = clamp(value, 0, 100); break;
            case "chat-background-radius": ChatQolSettings.backgroundRadius = clamp(value, 0, 12); break;
            case "chat-message-animation": ChatQolSettings.messageAnimationMillis = clamp(value, 0, 600); break;
            case "chat-fade-seconds": ChatQolSettings.fadeSeconds = clamp(value, 0, 60); break;
            case "chat-tab-opacity": ChatQolSettings.tabOpacity = clamp(value, 0, 100); break;
            case "chat-tab-active-opacity": ChatQolSettings.tabActiveOpacity = clamp(value, 0, 100); break;
            case "chat-hover-opacity": ChatQolSettings.hoverOpacity = clamp(value, 0, 100); break;
            case "room-clear-duration": AppleSettings.dungeonRoomClearDurationMillis = clamp(value, AppleSettings.DUNGEON_ROOM_CLEAR_DURATION_MIN_MILLIS, AppleSettings.DUNGEON_ROOM_CLEAR_DURATION_MAX_MILLIS); break;
            case "terminal-scale": AppleSettings.terminalGuiScale = clamp(value, 10, 50) / 10.0f; break;
            case "dungeon-map-scale": AppleSettings.dungeonMapScale = clamp(value, AppleSettings.DUNGEON_MAP_SCALE_MIN, AppleSettings.DUNGEON_MAP_SCALE_MAX); break;
            case "dungeon-map-zoom": AppleSettings.dungeonMapZoom = clamp(value, AppleSettings.DUNGEON_MAP_ZOOM_MIN, AppleSettings.DUNGEON_MAP_ZOOM_MAX); break;
            case "terminal-tracker-scale": AppleSettings.terminalTrackerScale = clamp(value, 5, 30) / 10.0f; break;
            case "global-font-scale": FontSettings.scale = clamp(value, 70, 140); break;
            case "appearance-corners": AppleSettings.cornerRadius = clamp(value, 4, 18); break;
            case "appearance-opacity": AppleSettings.glassOpacity = clamp(value, 60, 100); break;
            case "animation-speed": AppleSettings.animSpeed = clamp(value, 40, 200); break;
            case "global-scroll": AppleSettings.scrollSpeedOn = true; AppleSettings.scrollSpeed = clamp(value, 50, 300); break;
            case "starred-mob-chroma": AppleSettings.starredMobColor = StarredMobPolicy.withChromaSpeed(AppleSettings.starredMobColor, clamp(value, 0, 255)); break;
            case "starred-mob-stormy-chroma": AppleSettings.starredMobStormyColor = StarredMobPolicy.withChromaSpeed(AppleSettings.starredMobStormyColor, clamp(value, 0, 255)); break;
            case "starred-mob-wither-chroma": AppleSettings.starredMobWithermancerColor = StarredMobPolicy.withChromaSpeed(AppleSettings.starredMobWithermancerColor, clamp(value, 0, 255)); break;
            case "starred-mob-zombie-chroma": AppleSettings.starredMobZombieCommanderColor = StarredMobPolicy.withChromaSpeed(AppleSettings.starredMobZombieCommanderColor, clamp(value, 0, 255)); break;
            case "starred-mob-skeleton-chroma": AppleSettings.starredMobSkeletonMasterColor = StarredMobPolicy.withChromaSpeed(AppleSettings.starredMobSkeletonMasterColor, clamp(value, 0, 255)); break;
            default: break;
        }
    }

    static int choiceValue(String id) {
        if (id == null) return 0;
        switch (id) {
            case "item-lock-badge-color": return ItemLockSwapSettings.iconColor;
            case "item-lock-line-mode": return ItemLockSwapSettings.swapLineMode;
            case "item-lock-line-color": return ItemLockSwapSettings.swapLineColor;
            case "color-mode": return AppleSettings.darkMode ? 0 : 1;
            case "accent-color": return Math.max(0, Math.min(AppleSettings.ACCENT_NAMES.length - 1, AppleSettings.accent));
            case "chat-background-open-area": return ChatQolSettings.backgroundOpenFullArea ? 1 : 0;
            case "chat-menu-mode": return ChatQolSettings.menuOpenMode == ChatMenuPolicy.LEFT ? 1 : ChatQolSettings.menuOpenMode == ChatMenuPolicy.BOTH ? 2 : 0;
            case "curve-quality": return AppleSettings.curveQuality;
            case "starred-mob-mode": return StarredMobPolicy.clampDisplayMode(AppleSettings.starredMobDisplayMode);
            case "solver-correct-color": return solverColorIndex(AppleSettings.solverCorrectColor);
            case "solver-alternative-color": return solverColorIndex(AppleSettings.solverAlternativeColor);
            case "fel-esp-color": return solverColorIndex(AppleSettings.felEspColor);
            case "blood-mob-color": return solverColorIndex(AppleSettings.bloodMobHighlightColor);
            case "terminal-tracker-color": return solverColorIndex(AppleSettings.terminalTrackerColor);
            case "starred-mob-color": return starredColorIndex(AppleSettings.starredMobColor, AppleSettings.DEFAULT_STARRED_MOB_COLOR);
            case "starred-mob-stormy-color": return starredColorIndex(AppleSettings.starredMobStormyColor, AppleSettings.DEFAULT_STARRED_MOB_STORMY_COLOR);
            case "starred-mob-wither-color": return starredColorIndex(AppleSettings.starredMobWithermancerColor, AppleSettings.DEFAULT_STARRED_MOB_WITHERMANCER_COLOR);
            case "starred-mob-zombie-color": return starredColorIndex(AppleSettings.starredMobZombieCommanderColor, AppleSettings.DEFAULT_STARRED_MOB_ZOMBIE_COMMANDER_COLOR);
            case "starred-mob-skeleton-color": return starredColorIndex(AppleSettings.starredMobSkeletonMasterColor, AppleSettings.DEFAULT_STARRED_MOB_SKELETON_MASTER_COLOR);
            case "font-selected": return selectedFontIndex();
            default: return 0;
        }
    }

    static void setChoice(String id, int value) {
        if (id == null) return;
        switch (id) {
            case "item-lock-badge-color": ItemLockSwapSettings.iconColor = clamp(value, 0, ItemLockSwapSettings.ICON_COLOR_NAMES.length - 1); break;
            case "item-lock-line-mode": ItemLockSwapSettings.swapLineMode = clamp(value, 0, ItemLockSwapSettings.SWAP_LINE_MODE_NAMES.length - 1); break;
            case "item-lock-line-color": ItemLockSwapSettings.swapLineColor = clamp(value, 0, ItemLockSwapSettings.ICON_COLOR_NAMES.length - 1); break;
            case "color-mode": AppleSettings.darkMode = value == 0; break;
            case "accent-color": AppleSettings.accent = clamp(value, 0, AppleSettings.ACCENT_NAMES.length - 1); break;
            case "chat-background-open-area": ChatQolSettings.backgroundOpenFullArea = value == 1; break;
            case "chat-menu-mode": ChatQolSettings.setMenuOpenMode(value == 1 ? ChatMenuPolicy.LEFT : value == 2 ? ChatMenuPolicy.BOTH : ChatMenuPolicy.RIGHT); break;
            case "curve-quality": AppleSettings.curveQuality = clamp(value, 0, AppleSettings.CURVE_NAMES.length - 1); break;
            case "starred-mob-mode": AppleSettings.setStarredMobDisplayMode(value); break;
            case "solver-correct-color": AppleSettings.solverCorrectColor = solverColorValue(value, AppleSettings.solverCorrectColor); break;
            case "solver-alternative-color": AppleSettings.solverAlternativeColor = solverColorValue(value, AppleSettings.solverAlternativeColor); break;
            case "fel-esp-color": AppleSettings.felEspColor = solverColorValue(value, AppleSettings.felEspColor); break;
            case "blood-mob-color": AppleSettings.bloodMobHighlightColor = solverColorValue(value, AppleSettings.bloodMobHighlightColor); break;
            case "terminal-tracker-color": AppleSettings.terminalTrackerColor = solverColorValue(value, AppleSettings.terminalTrackerColor); break;
            case "starred-mob-color": AppleSettings.starredMobColor = starredColorValue(value, AppleSettings.starredMobColor, AppleSettings.DEFAULT_STARRED_MOB_COLOR); break;
            case "starred-mob-stormy-color": AppleSettings.starredMobStormyColor = starredColorValue(value, AppleSettings.starredMobStormyColor, AppleSettings.DEFAULT_STARRED_MOB_STORMY_COLOR); break;
            case "starred-mob-wither-color": AppleSettings.starredMobWithermancerColor = starredColorValue(value, AppleSettings.starredMobWithermancerColor, AppleSettings.DEFAULT_STARRED_MOB_WITHERMANCER_COLOR); break;
            case "starred-mob-zombie-color": AppleSettings.starredMobZombieCommanderColor = starredColorValue(value, AppleSettings.starredMobZombieCommanderColor, AppleSettings.DEFAULT_STARRED_MOB_ZOMBIE_COMMANDER_COLOR); break;
            case "starred-mob-skeleton-color": AppleSettings.starredMobSkeletonMasterColor = starredColorValue(value, AppleSettings.starredMobSkeletonMasterColor, AppleSettings.DEFAULT_STARRED_MOB_SKELETON_MASTER_COLOR); break;
            case "font-selected": FontSettings.selected = fontChoice(value); GlobalFontManager.reload(); break;
            default: break;
        }
    }

    /** Returns true when a non-screen action was handled. Screen-owned actions are handled by AppleSettingsScreen. */
    static boolean runAction(String id) {
        if (id == null) return false;
        if ("hud-reset-positions".equals(id)) {
            HudManager.resetPositions();
            AppleSettings.resetDungeonMapPosition();
            HudManager.save();
            AppleSettings.save();
            return true;
        }
        if ("appearance-reset".equals(id)) {
            AppleSettings.darkMode = true;
            AppleSettings.accent = 0;
            AppleSettings.cornerRadius = AppleSettings.DEFAULT_CORNER_RADIUS;
            AppleSettings.cornerRadiusOn = true;
            AppleSettings.glassOpacity = AppleSettings.DEFAULT_GLASS_OPACITY;
            AppleSettings.glassOpacityOn = true;
            return true;
        }
        if ("performance-reset".equals(id)) {
            AppleSettings.curveQuality = 1;
            AppleSettings.shadows = true;
            AppleSettings.animations = true;
            AppleSettings.animSpeedOn = true;
            AppleSettings.animSpeed = AppleSettings.DEFAULT_ANIM_SPEED;
            AppleSettings.adaptive = AppleSettings.DEFAULT_ADAPTIVE_QUALITY;
            AppleSettings.experimentalPerformance = AppleSettings.DEFAULT_PERFORMANCE_BOOST_BETA;
            return true;
        }
        if ("system-general-reset".equals(id)) {
            AppleSettings.scrollSpeedOn = true;
            AppleSettings.scrollSpeed = AppleSettings.DEFAULT_SCROLL_SPEED;
            AppleSettings.smoothScrolling = AppleSettings.DEFAULT_SMOOTH_SCROLLING;
            return true;
        }
        if ("inventory-assist-reset".equals(id)) {
            AppleSettings.inventorySearchEnabled = true;
            AppleSettings.hideInventoryPotionEffects = true;
            AppleSettings.romanNumeralsInTooltips = true;
            AppleSettings.scrollableTooltipsEnabled = true;
            AppleSettings.itemRarityBordersEnabled = true;
            AppleSettings.itemProtectionEnabled = true;
            AppleSettings.itemProtectionNotifications = true;
            return true;
        }
        if ("shortcut-reset".equals(id)) {
            AppleSettings.wardrobeShortcutEnabled = false;
            AppleSettings.petsShortcutEnabled = false;
            return true;
        }
        if ("item-lock-reset".equals(id)) {
            ItemLockSwapSettings.enabled = true;
            ItemLockSwapSettings.keyCode = ItemLockSwapSettings.DEFAULT_KEY_CODE;
            ItemLockSwapSettings.cooldownTenths = ItemLockSwapSettings.DEFAULT_COOLDOWN_TENTHS;
            ItemLockSwapSettings.showLockIcons = true;
            ItemLockSwapSettings.showIconsOnHotbar = true;
            ItemLockSwapSettings.showBlockedMessage = true;
            ItemLockSwapSettings.iconColor = 0;
            ItemLockSwapSettings.iconOpacity = 100;
            ItemLockSwapSettings.swapLineMode = ItemLockSwapSettings.SWAP_LINES_ALWAYS;
            ItemLockSwapSettings.swapLineColor = 0;
            ItemLockSwapSettings.swapLineOpacity = 100;
            ItemLockSwapSettings.swapLineWidth = ItemLockSwapSettings.DEFAULT_LINE_WIDTH;
            ItemLockSwapSettings.clearLocks();
            ItemLockSwapSettings.clearPairs();
            return true;
        }
        if ("commands-reset".equals(id)) { AppleSettings.svCommand = true; AppleSettings.qnCommand = true; return true; }
        if ("mining-assistant-reset".equals(id)) { AppleSettings.miningAbilityNotifier = false; AppleSettings.miningPuzzlerSolver = false; return true; }
        if ("spirit-leap-reset".equals(id)) { AppleSettings.leapMenu = true; AppleSettings.leapKey = true; return true; }
        if ("dungeon-solvers-reset".equals(id)) {
            AppleSettings.solverThreeWeirdos = true;
            AppleSettings.solverCreeper = true;
            AppleSettings.solverBoulder = true;
            AppleSettings.solverSilverfish = true;
            AppleSettings.solverWater = true;
            AppleSettings.solverTeleportMaze = true;
            AppleSettings.solverFirstDevice = true;
            AppleSettings.solverThirdDevice = true;
            AppleSettings.terminalCustomStartsWith = true;
            AppleSettings.terminalCustomColors = true;
            AppleSettings.terminalCustomClickIn = true;
            AppleSettings.terminalCustomMaze = true;
            AppleSettings.terminalCustomPanes = true;
            AppleSettings.terminalStartsWithSolver = true;
            AppleSettings.terminalColorsSolver = true;
            AppleSettings.terminalClickInOrderSolver = true;
            AppleSettings.terminalMazeSolver = true;
            AppleSettings.terminalCorrectPanesSolver = true;
            AppleSettings.terminalHideIncorrect = true;
            AppleSettings.terminalPreventMissclicks = true;
            AppleSettings.terminalHideTooltips = true;
            AppleSettings.terminalWaypoints = true;
            AppleSettings.terminalGuiScale = 3.0f;
            AppleSettings.save();
            return true;
        }
        if ("terminal-reset".equals(id)) {
            AppleSettings.terminalStartsWithSolver = true;
            AppleSettings.terminalColorsSolver = true;
            AppleSettings.terminalClickInOrderSolver = true;
            AppleSettings.terminalMazeSolver = true;
            AppleSettings.terminalCorrectPanesSolver = true;
            AppleSettings.terminalHideIncorrect = true;
            AppleSettings.terminalPreventMissclicks = true;
            AppleSettings.terminalHideTooltips = true;
            AppleSettings.terminalWaypoints = true;
            AppleSettings.terminalGuiScale = 3f;
            return true;
        }
        if ("m7-reset".equals(id)) {
            M7Settings.setOverlayEnabled(true);
            M7Settings.setStatueZonesEnabled(true);
            M7Settings.setAreasPersistAfterDragonSpawn(true);
            M7Settings.setDragonKillAlertEnabled(true);
            for (M7OverlayRenderer.M7HitboxTarget target : M7OverlayRenderer.M7HitboxTarget.values()) M7Settings.setBossHitboxEnabled(target, true);
            for (M7OverlayRenderer.M7DragonStatue dragon : M7OverlayRenderer.M7DragonStatue.values()) M7Settings.setDragonHitboxEnabled(dragon, true);
            return true;
        }
        if ("slayer-reset".equals(id)) { AppleSettings.slayerBossTimer = true; AppleSettings.slayerPricing = true; return true; }
        if ("item-lock-clear-locks".equals(id)) { ItemLockSwapSettings.clearLocks(); return true; }
        if ("item-lock-clear-pairs".equals(id)) { ItemLockSwapSettings.clearPairs(); return true; }
        if ("fishing-reset".equals(id)) { FishingStats.reset(); return true; }
        if ("slayer-clear-spider".equals(id)) { SlayerTracker.clearHistory(SlayerType.SPIDER); return true; }
        if ("slayer-clear-revenant".equals(id)) { SlayerTracker.clearHistory(SlayerType.REVENANT); return true; }
        if ("slayer-clear-blaze".equals(id)) { SlayerTracker.clearHistory(SlayerType.BLAZE); return true; }
        if ("slayer-clear-wolf".equals(id)) { SlayerTracker.clearHistory(SlayerType.WOLF); return true; }
        if ("slayer-clear-enderman".equals(id)) { SlayerTracker.clearHistory(SlayerType.ENDERMAN); return true; }
        return false;
    }

    private static final String[] SOLVER_COLOR_NAMES = {"Green", "Yellow", "Cyan", "Magenta", "Red", "Blue", "White"};
    private static final String[] SOLVER_COLOR_VALUES = {
            "0:255:0:255:0", "0:255:255:255:0", "0:255:0:255:255", "0:255:255:0:255",
            "0:255:255:0:0", "0:255:0:100:255", "0:255:255:255:255"
    };
    private static final String[] STARRED_COLOR_VALUES = {
            null, "0:255:0:255:0", "0:255:255:255:0", "0:255:0:255:255", "0:255:255:0:255",
            "0:255:255:0:0", "0:255:0:100:255", "0:255:255:255:255"
    };
    private static int solverColorIndex(String current) {
        if (current == null) return 0;
        String normalized = StarredMobPolicy.withChromaSpeed(current, 0);
        for (int i = 0; i < SOLVER_COLOR_VALUES.length; i++) {
            if (StarredMobPolicy.withChromaSpeed(SOLVER_COLOR_VALUES[i], 0).equals(normalized)) return i;
        }
        return 0;
    }
    private static String solverColorValue(int index, String current) {
        String selected = SOLVER_COLOR_VALUES[clamp(index, 0, SOLVER_COLOR_VALUES.length - 1)];
        return preserveColorModifiers(selected, current);
    }
    private static int starredColorIndex(String current, String defaultColor) {
        if (current == null) return 0;
        if (StarredMobPolicy.withChromaSpeed(defaultColor, 0).equals(StarredMobPolicy.withChromaSpeed(current, 0))) return 0;
        String normalized = StarredMobPolicy.withChromaSpeed(current, 0);
        for (int i = 0; i < SOLVER_COLOR_VALUES.length; i++) {
            if (StarredMobPolicy.withChromaSpeed(SOLVER_COLOR_VALUES[i], 0).equals(normalized)) return i + 1;
        }
        return 0;
    }
    private static String starredColorValue(int index, String current, String defaultColor) {
        if (index <= 0) return StarredMobPolicy.withChromaSpeed(defaultColor, StarredMobPolicy.chromaSpeed(current));
        return preserveColorModifiers(STARRED_COLOR_VALUES[clamp(index, 1, STARRED_COLOR_VALUES.length - 1)], current);
    }
    private static String preserveColorModifiers(String selected, String current) {
        if (selected == null) return current;
        if (current == null) return selected;
        String[] oldParts = current.split(":");
        String[] newParts = selected.split(":");
        if (oldParts.length == 5 && newParts.length == 5) {
            newParts[0] = oldParts[0];
            newParts[1] = oldParts[1];
            selected = newParts[0] + ":" + newParts[1] + ":" + newParts[2] + ":" + newParts[3] + ":" + newParts[4];
        }
        return selected;
    }
    private static int selectedFontIndex() {
        String[] names = GlobalFontManager.availableFonts();
        for (int i = 0; i < names.length; i++) if (names[i].equals(FontSettings.selected)) return i;
        return 0;
    }
    private static String fontChoice(int index) {
        String[] names = GlobalFontManager.availableFonts();
        if (names.length == 0) return FontSettings.MINECRAFT_DEFAULT;
        return names[clamp(index, 0, names.length - 1)];
    }

    private static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }

}
