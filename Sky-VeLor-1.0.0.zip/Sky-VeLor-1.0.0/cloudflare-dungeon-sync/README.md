# Sky VeLor Dungeon Sync Worker

The Minecraft client uses the project's deployed Worker URL by default, so players do not need to copy the same endpoint into their local settings. This source tree is for maintenance/redeployment by the project owner; a new deployment URL must be updated in `DungeonPuzzleSyncConfig.DEFAULT_ENDPOINT` and the project documentation.

## Setup for maintainers

```sh
npm install
npm test
npm run deploy
```

The local client setting is opt-in: set `enabled=true` in `config/skyvelor-dungeon-sync.properties`. The endpoint is prefilled by the mod and does not need to be shared. See the root `CLOUDFLARE-DUNGEON-SYNC.md` for payload disclosure, session-ID limitations and privacy notes.

The Durable Object temporarily stores accepted Puzzle labels and coordinates while the session is active, then deletes them 5 seconds after the last WebSocket closes. It also clears stale puzzle state when a new first connection arrives with no active peers, covering quick same-party restarts. It never receives raw player names. Cloudflare still processes normal transport metadata such as client IP addresses.


## Runtime diagnostics

The Worker exposes a read-only `GET /health` endpoint returning the service name, protocol version and `ok` status. WebSocket clients receive a `welcome` message with the number of connected clients in that exact session and the number of stored puzzle rooms. A valid puzzle upload receives a `puzzle_ack` from the Worker, including the confidence value actually stored for that room; clients use this to avoid uploading the same or lower-confidence room again after reconnecting. Rejected messages return a safe reason code such as `puzzle_not_allowed`, `invalid_room_coordinates`, `invalid_confidence`, `rate_limited`, or `room_limit_reached`. These responses never include player names or the temporary session hash. Accepted discoveries are broadcast to other connected members of the same session; clients display a local chat notice when a new teammate discovery is applied to their map memory.

## Performance and usage notes

- The Durable Object uses `ctx.acceptWebSocket()` (the WebSocket Hibernation API) so idle sessions can hibernate without disconnecting clients.
- The Java client backs off reconnect attempts from 1.5 seconds up to 30 seconds when the service is unavailable; stable connections reset the delay.
- The client waits for the Worker `welcome` room snapshot before replaying local memory, then skips rooms already known by the Worker at equal or higher confidence.
- A new/empty session checks whether stored puzzle state exists before deleting it, avoiding an unnecessary storage delete write when the key is absent. The Worker continues to purge room data after the last socket disconnects.
- These source changes do not change the session hash, player-name privacy behavior, WebSocket route or protocol version. Deploy the updated Worker source separately from replacing the Minecraft mod.
