import test from "node:test";
import assert from "node:assert/strict";
import { validatePuzzleEvent, puzzleEventErrorCode } from "../src/protocol.js";

test("accepts a known puzzle at a 32-block room origin", () => {
  assert.deepEqual(validatePuzzleEvent({
    type: "puzzle_discovered", name: " Silver   Fish ", x: -32, y: 70, z: 64, confidence: 0.91,
  }), { type: "puzzle_discovered", name: "silver fish", x: -32, y: 70, z: 64, confidence: 0.91 });
});

test("rejects unknown puzzle names", () => {
  assert.equal(validatePuzzleEvent({ type: "puzzle_discovered", name: "secret player name", x: 0, y: 70, z: 0, confidence: 1 }), null);
});

test("rejects non-room coordinates and invalid confidence", () => {
  assert.equal(validatePuzzleEvent({ type: "puzzle_discovered", name: "boulder", x: 17, y: 70, z: 0, confidence: 1 }), null);
  assert.equal(validatePuzzleEvent({ type: "puzzle_discovered", name: "boulder", x: 0, y: 70, z: 0, confidence: 2 }), null);
});

test("rejects out-of-world coordinates and wrong message type", () => {
  assert.equal(validatePuzzleEvent({ type: "chat", name: "boulder", x: 0, y: 70, z: 0, confidence: 1 }), null);
  assert.equal(validatePuzzleEvent({ type: "puzzle_discovered", name: "boulder", x: 50000000, y: 70, z: 0, confidence: 1 }), null);
});

test("diagnostics classify rejected server events without echoing player data", () => {
  assert.equal(puzzleEventErrorCode({ type: "chat", name: "ii8we_" }), "unexpected_message_type");
  assert.equal(puzzleEventErrorCode({ type: "puzzle_discovered", name: "not-a-puzzle", x: 0, y: 70, z: 0, confidence: 1 }), "puzzle_not_allowed");
  assert.equal(puzzleEventErrorCode({ type: "puzzle_discovered", name: "boulder", x: 17, y: 70, z: 0, confidence: 1 }), "invalid_room_coordinates");
  assert.equal(puzzleEventErrorCode({ type: "puzzle_discovered", name: "boulder", x: 0, y: 70, z: 0, confidence: 2 }), "invalid_confidence");
});
