import { DurableObject } from "cloudflare:workers";
import { validatePuzzleEvent, puzzleEventErrorCode } from "./protocol.js";

const SESSION_ID = /^[0-9a-f]{64}$/;
const MEMBER_ID = /^[0-9a-f]{32}$/;
const MAX_MESSAGE_LENGTH = 4096;
const MAX_SESSION_CONNECTIONS = 8;
const MAX_STORED_ROOMS = 64;
const IDLE_CLEANUP_MS = 5_000;
const RATE_WINDOW_MS = 60_000;
const MAX_PUZZLE_EVENTS_PER_WINDOW = 30;

function jsonError(status, message) {
  return new Response(JSON.stringify({ error: message }), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });
}

export class DungeonSession extends DurableObject {
  async fetch(request) {
    const url = new URL(request.url);
    const match = /^\/ws\/([0-9a-f]{64})\/?$/.exec(url.pathname);
    if (!match || !SESSION_ID.test(match[1])) return jsonError(404, "not found");
    if (request.method !== "GET" || request.headers.get("Upgrade")?.toLowerCase() !== "websocket") {
      return jsonError(426, "websocket upgrade required");
    }
    // Serialize first-connection cleanup with socket acceptance. Without this short critical
    // section, two clients arriving together could both see an empty room and clear each other's state.
    return this.ctx.blockConcurrencyWhile(async () => {
      const existingSockets = this.ctx.getWebSockets();
      if (existingSockets.length >= MAX_SESSION_CONNECTIONS) {
        return jsonError(429, "session connection limit reached");
      }

      // If no participant is connected, a new connection is the start/restart of this roster-keyed
      // session. Purge stale room state even when a previous cleanup alarm has not fired yet.
      const hasOpenPeer = existingSockets.some((socket) => socket.readyState === WebSocket.OPEN);
      if (!hasOpenPeer) {
        // Reads are a much larger free-tier allowance than writes. Avoid billing a row deletion
        // for every new/empty session; only delete puzzle state when it actually exists.
        const stalePuzzleState = await this.ctx.storage.get("puzzles");
        if (stalePuzzleState !== undefined) await this.ctx.storage.delete("puzzles");
      }

      const pair = new WebSocketPair();
      const [client, server] = Object.values(pair);
      this.ctx.acceptWebSocket(server);
      server.serializeAttachment({ memberId: "", windowStartedAt: 0, windowCount: 0 });
      try { await this.ctx.storage.deleteAlarm(); } catch (_) { /* first connection */ }
      return new Response(null, { status: 101, webSocket: client });
    });
  }

  async webSocketMessage(ws, message) {
    if (typeof message !== "string" || message.length > MAX_MESSAGE_LENGTH) {
      ws.close(1009, "message too large");
      return;
    }

    let payload;
    try { payload = JSON.parse(message); }
    catch (_) { return; }

    const attachment = ws.deserializeAttachment() || { memberId: "", windowStartedAt: 0, windowCount: 0 };
    if (!attachment.memberId) {
      if (!payload || payload.type !== "hello" || payload.protocol !== 1 || !MEMBER_ID.test(payload.memberId || "")) {
        ws.close(1008, "hello required");
        return;
      }
      for (const existing of this.ctx.getWebSockets()) {
        if (existing === ws || existing.readyState !== WebSocket.OPEN) continue;
        const existingState = existing.deserializeAttachment();
        if (existingState && existingState.memberId === payload.memberId) {
          try { existing.close(4001, "replaced by reconnect"); } catch (_) { /* already closed */ }
        }
      }
      ws.serializeAttachment({ memberId: payload.memberId, windowStartedAt: Date.now(), windowCount: 0 });
      const rooms = await this.readRooms();
      const connectedMembers = this.activeMemberCount();
      ws.send(JSON.stringify({ type: "welcome", protocol: 1, connectedMembers, roomCount: rooms.length, rooms }));
      const status = JSON.stringify({ type: "session_status", connectedMembers });
      for (const peer of this.ctx.getWebSockets()) {
        if (peer === ws || peer.readyState !== WebSocket.OPEN) continue;
        const peerState = peer.deserializeAttachment();
        if (peerState && peerState.memberId) {
          try { peer.send(status); } catch (_) { /* stale socket will be removed by runtime */ }
        }
      }
      return;
    }

    if (payload && payload.type === "leave") {
      try { ws.close(1000, "member left dungeon"); } catch (_) { /* already closed */ }
      return;
    }

    const event = validatePuzzleEvent(payload);
    if (!event) {
      ws.send(JSON.stringify({ type: "sync_error", code: puzzleEventErrorCode(payload) }));
      return;
    }

    const now = Date.now();
    let windowStartedAt = Number(attachment.windowStartedAt) || now;
    let windowCount = Number(attachment.windowCount) || 0;
    if (now - windowStartedAt >= RATE_WINDOW_MS) {
      windowStartedAt = now;
      windowCount = 0;
    }
    if (windowCount >= MAX_PUZZLE_EVENTS_PER_WINDOW) {
      ws.serializeAttachment({ memberId: attachment.memberId, windowStartedAt, windowCount });
      try { ws.send(JSON.stringify({ type: "sync_error", code: "rate_limited" })); } catch (_) { /* socket is closing */ }
      ws.close(1008, "event rate limit exceeded");
      return;
    }
    windowCount++;
    ws.serializeAttachment({ memberId: attachment.memberId, windowStartedAt, windowCount });

    const rooms = await this.readRooms();
    const key = `${event.x},${event.y},${event.z}`;
    const existingIndex = rooms.findIndex((room) => `${room.x},${room.y},${room.z}` === key);
    if (existingIndex >= 0) {
      const existing = rooms[existingIndex];
      if (existing.confidence >= event.confidence) {
        ws.send(JSON.stringify({ type: "puzzle_ack", accepted: true, duplicate: true,
          name: existing.name, x: existing.x, y: existing.y, z: existing.z, confidence: existing.confidence,
          roomCount: rooms.length, connectedMembers: this.activeMemberCount() }));
        return;
      }
      rooms[existingIndex] = event;
    } else {
      if (rooms.length >= MAX_STORED_ROOMS) {
        ws.send(JSON.stringify({ type: "sync_error", code: "room_limit_reached" }));
        return;
      }
      rooms.push(event);
    }
    rooms.sort((a, b) => a.x - b.x || a.z - b.z || a.y - b.y);
    await this.ctx.storage.put("puzzles", rooms);
    ws.send(JSON.stringify({ type: "puzzle_ack", accepted: true, duplicate: false,
      name: event.name, x: event.x, y: event.y, z: event.z, confidence: event.confidence,
      roomCount: rooms.length, connectedMembers: this.activeMemberCount() }));

    const encoded = JSON.stringify(event);
    for (const peer of this.ctx.getWebSockets()) {
      if (peer === ws || peer.readyState !== WebSocket.OPEN) continue;
      try { peer.send(encoded); } catch (_) { /* stale socket will be removed by runtime */ }
    }
  }

  async webSocketClose(ws) {
    try { ws.close(1000, "connection closed"); } catch (_) { /* already closed */ }
    const anyOpen = this.ctx.getWebSockets().some((socket) => socket.readyState === WebSocket.OPEN);
    if (!anyOpen) await this.ctx.storage.setAlarm(Date.now() + IDLE_CLEANUP_MS);
  }

  async webSocketError(ws) {
    try { ws.close(1011, "connection error"); } catch (_) { /* already closed */ }
  }

  async alarm() {
    const anyOpen = this.ctx.getWebSockets().some((socket) => socket.readyState === WebSocket.OPEN);
    if (anyOpen) return;
    await this.ctx.storage.delete("puzzles");
  }

  activeMemberCount() {
    let count = 0;
    for (const socket of this.ctx.getWebSockets()) {
      if (socket.readyState !== WebSocket.OPEN) continue;
      const state = socket.deserializeAttachment();
      if (state && MEMBER_ID.test(state.memberId || "")) count++;
    }
    return count;
  }

  async readRooms() {
    const value = await this.ctx.storage.get("puzzles");
    return Array.isArray(value) ? value.filter((entry) => validatePuzzleEvent(entry) !== null).slice(0, MAX_STORED_ROOMS) : [];
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/health" && request.method === "GET") {
      return new Response(JSON.stringify({ service: "skyvelor-dungeon-sync", status: "ok", protocol: 1 }), {
        status: 200,
        headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
      });
    }
    const match = /^\/ws\/([0-9a-f]{64})\/?$/.exec(url.pathname);
    if (!match || !SESSION_ID.test(match[1])) return jsonError(404, "not found");
    if (request.method !== "GET" || request.headers.get("Upgrade")?.toLowerCase() !== "websocket") {
      return jsonError(426, "websocket upgrade required");
    }
    const id = env.DUNGEON_SESSIONS.idFromName(match[1]);
    return env.DUNGEON_SESSIONS.get(id).fetch(request);
  },
};
