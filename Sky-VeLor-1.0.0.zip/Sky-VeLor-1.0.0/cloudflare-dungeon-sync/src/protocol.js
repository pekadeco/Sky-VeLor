const ALLOWED_PUZZLES = new Set([
  "silver fish", "warping", "3 wierdos", "creaper beams", "boulder", "water", "tic tac toe",
]);

export function normalizePuzzleName(value) {
  return typeof value === "string" ? value.trim().toLowerCase().replace(/\s+/g, " ") : "";
}

export function validatePuzzleEvent(value) {
  if (!value || typeof value !== "object" || value.type !== "puzzle_discovered") return null;
  const name = normalizePuzzleName(value.name);
  const x = value.x;
  const y = value.y;
  const z = value.z;
  const confidence = value.confidence;
  if (!ALLOWED_PUZZLES.has(name)) return null;
  if (!Number.isInteger(x) || !Number.isInteger(y) || !Number.isInteger(z)) return null;
  if (Math.abs(x) > 30_000_000 || Math.abs(z) > 30_000_000 || y < 1 || y > 250) return null;
  if (x % 32 !== 0 || z % 32 !== 0) return null;
  if (typeof confidence !== "number" || !Number.isFinite(confidence) || confidence < 0.65 || confidence > 1) return null;
  return { type: "puzzle_discovered", name, x, y, z, confidence };
}

export function puzzleEventErrorCode(value) {
  if (!value || typeof value !== "object" || value.type !== "puzzle_discovered") return "unexpected_message_type";
  const name = normalizePuzzleName(value.name);
  if (!ALLOWED_PUZZLES.has(name)) return "puzzle_not_allowed";
  const { x, y, z, confidence } = value;
  if (!Number.isInteger(x) || !Number.isInteger(y) || !Number.isInteger(z)
      || Math.abs(x) > 30_000_000 || Math.abs(z) > 30_000_000 || y < 1 || y > 250 || x % 32 !== 0 || z % 32 !== 0) {
    return "invalid_room_coordinates";
  }
  if (typeof confidence !== "number" || !Number.isFinite(confidence) || confidence < 0.65 || confidence > 1) return "invalid_confidence";
  return "invalid_puzzle_event";
}
