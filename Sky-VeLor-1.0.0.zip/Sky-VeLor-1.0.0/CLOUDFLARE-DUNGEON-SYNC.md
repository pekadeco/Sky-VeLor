# Sky VeLor Dungeon Puzzle Sync

Read the root [privacy.md](privacy.md) for the player-facing privacy notice, including Cloudflare IP-address handling and opt-out instructions.

This optional service shares only discovered Puzzle-room labels between clients that derive the same local dungeon-session identifier. It does not use Party Chat and does not send `[code]` chat messages.

## What starts a session

The client listens for the exact message `Dungeon starts in 1 second.`, whether Fakepixel delivers it as ordinary chat or system text. It then waits for three matching local snapshots, separated by about half a second, before opening a WebSocket. The server ID is read from the Tab List and the floor from the scoreboard. A stable shared session requires a consistent declared `Party (2)` through `Party (5)` size. If the Tab List exposes only a larger server list, the mod filters profile usernames using recognized dungeon-class evidence from formatted Tab List/team rows and may complete the exact roster with the local player's own profile only when exactly n−1 unique teammate profiles remain. The local player must be present in the selected roster, and the selected roster must match the declared party size. Solo `Party (1)`, unknown party size, conflicting party-size headers, or an incomplete roster are rejected; the mod does not open a shared session by guessing. It never includes rank labels, class badges, class levels, player levels, or raw names in network messages.

Each client derives the session ID locally from:

- the visible `sbdung-N` server ID found in the tab list;
- the dungeon floor found on the scoreboard;
- the sorted, case-normalized exact Minecraft usernames in the dungeon-party roster.

Player names are used only on the client to calculate a SHA-256 session ID. The hash algorithm is order independent, so clients with the same tab-list profile names derive the same ID regardless of tab ordering or capitalization. The roster contains only valid, unique Minecraft usernames from profile data. The roster is rejected if the local player is missing or the selected roster exceeds five profiles. Stable mode requires at least two distinct account names and rejects `Party (1)` or an unknown/conflicting party size. This keeps single-player runs from opening a non-shared session.

### Offline-mode (cracked) account compatibility

Dungeon Sync does not require a Mojang-authenticated account and does not use player UUIDs to identify party members. It reads each account name from the Minecraft client/server Tab List profile and uses those exact usernames, normalized for case, only when deriving the local session hash. This works with offline-mode servers when Fakepixel exposes the same usernames to each member of the run. If the server hides or changes the names differently for different clients, the roster cannot be made reliable by substituting UUIDs; diagnostics should be used to determine which displayed profile rows are missing.

## Deploy the Cloudflare backend

The project's Cloudflare Worker has been deployed at `skyvelor-dungeon-sync.bombadzalge.workers.dev`. The endpoint is bundled in Sky VeLor, so players do not need to paste the URL into their configs or share it with each other. The project owner is responsible for keeping this Worker available and maintaining its privacy notice. A custom Worker can still be set manually in the local config if the project changes hosting.

The names-only session identity is compatible with the existing Worker protocol. To activate the quick-restart cleanup added in this revision, deploy the updated `cloudflare-dungeon-sync/src/index.js` once. On Windows 7, use the included **SkyVeLor Cloudflare Direct Deployer v1.2**; it uploads the updated Worker without Node.js or GitHub. The new Worker clears stale room state when a new connection starts with no active peers.

Requirements: a recent Node.js LTS release with npm, and access to a Cloudflare account via Wrangler.

```sh
cd cloudflare-dungeon-sync
npm install
npm test
npm run deploy
```

Wrangler prints the deployed HTTPS Worker URL. Change its scheme from `https://` to `wss://` and append `/ws`, for example:

```text
wss://skyvelor-dungeon-sync.<your-subdomain>.workers.dev/ws
```

Do not copy the example hostname literally; use your own deployed hostname.

## Enable it in Minecraft

Start Minecraft once after installing the mod. The client creates a settings file. Its `endpoint` value is prefilled with the project's Worker URL; no URL copy-paste is required:

```text
.minecraft/config/skyvelor-dungeon-sync.properties
```

The preferred way to opt in is from the game: open Sky VeLor settings with `/sv`, select **Dungeon → Dungeon Sync**, then enable **Enable Dungeon Sync**. The setting is saved immediately, works without restarting Minecraft, and turns off the active connection when disabled. Synchronization remains disabled by default. The local file `config/skyvelor-dungeon-sync.properties` is still available for troubleshooting or maintainer overrides; its endpoint is prefilled by the mod. If the endpoint is invalid or is not `wss://`, the mod does not connect to an external service.

## Network payloads and privacy

The client does **not** send raw usernames, rank strings, class badges, class levels, or player levels to the Worker. It calculates the session hash locally. The Worker receives:

- the derived 64-character session hash in the WebSocket URL;
- a randomly generated temporary member ID for connection lifecycle handling;
- Puzzle name, room-origin coordinates, and confidence for each discovery;
- normal network connection metadata, including the source IP address, which is visible to the service provider as part of Internet communication.

The session hash is derived from public Minecraft usernames plus server/floor values. Treat it as **pseudonymous data, not guaranteed anonymous data**: someone who already knows likely party names could test candidate rosters against the hash. The hash prevents raw names from being sent, but does not provide perfect anonymity. The server does not provide a confirmed unique run ID to the client, so consecutive runs with the same server ID, floor, and exact roster derive the same hash. To reduce stale data crossing into a quick restart of the same party, the Worker starts a fresh empty room-state when the first connection arrives and no other connection is active; local puzzle memory can then be replayed by the client.

The Durable Object temporarily stores discovered Puzzle labels and coordinates while the session is active; it deletes stored room state 5 seconds after the last connection closes, and clears any stale room state when a new first connection starts. It does not persist player names because it never receives them, and the Worker does not write application logs containing player names or raw identity attributes. This does not control Cloudflare's provider-level operational logs or connection metadata policies, so do not interpret this design as a legal guarantee of zero data processing.

## Runtime behavior

- No network operations run on Minecraft's game/render thread.
- Local Puzzle discovery and map rendering continue if the service is unavailable.
- Puzzle events are rate-limited, validated against the project's known Puzzle names, and deduplicated by room coordinates.
- Leaving the dungeon closes that client's WebSocket after the world transition and dungeon state have been rechecked. Other clients keep the same session ID until they leave.
- Discovered puzzle labels/coordinates are deleted five seconds after the last active connection closes. A later first connection starts with empty server-side room state; connected clients may replay their still-local puzzle memory.

## Verification status

The pure session-identity tests and Cloudflare event validation tests run locally without a live Minecraft client. The Worker still needs deployment, and the complete mod must be built and tested in Minecraft 1.8.9 to verify the live Fakepixel scoreboard formatting and that different clients derive the same fingerprint.


## Diagnostic mode

Open `/sv` → Dungeon → Dungeon Sync and enable **Dungeon Sync Debug**. It is off by default for new installations, and old files from debugging builds are automatically migrated from their legacy default-on state to off once. Users can opt in whenever they need to troubleshoot; a choice made from the current UI is preserved. The client logs each stage to the Minecraft log and local chat: countdown recognition, tab roster selection, session preparation, TLS/WebSocket handshake, Worker welcome/member count, puzzle upload queueing and server acknowledgement, rejection reason codes, remote puzzle receipt, memory application and map-label rendering/clipping. Repeated identical status lines are suppressed. The diagnostics do not print raw player names or the 64-character session fingerprint.

The Worker also responds to `GET /health` and returns explicit `puzzle_ack` or reason-coded `sync_error` messages. **Deploy the updated `cloudflare-dungeon-sync` Worker code before relying on server acknowledgements or accurate connected-member counts.** Existing deployments can still broadcast the old `puzzle_discovered` messages, but will not provide these added diagnostics until updated.
