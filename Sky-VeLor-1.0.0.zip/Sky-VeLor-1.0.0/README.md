# Sky VeLor — 1.0.0

Sky VeLor is a client-side Forge mod for Minecraft 1.8.9. It provides a configurable HUD, a settings hub, dungeon utilities, Spirit Leap helpers, fishing and Slayer trackers, and quick notes.

## Features

- Settings hub and movable HUD editor with dark and light themes.
- Smooth, frame-rate-independent UI motion: soft hover and press feedback, animated toggles and sliders, a sliding segmented selector, a gently appearing dropdown, and responsive search-field focus.
- Rounded animated buttons in the main/pause menu and Quick Note screen, with distinct primary, secondary and destructive styles.
- Spirit Leap teammate picker, class labels, player heads and isolated preview.
- Dungeon minimap with automatically rotating live map, teammate names, puzzle-room labels and a numeric Secrets counter; optional Cloudflare-based Puzzle discovery sync; Floor VII boss/dragon overlays, dragon alerts, and optional blood-room miniboss highlights.
- Mining foundations: Mining BPS, a movable mining-session panel, optional Fakepixel pickaxe ability alerts, and the Dwarven Mines Puzzler target marker.
- Fishing and Slayer trackers, plus quick notes and client commands.
- Item Protection for uniquely identified SkyBlock items: configurable keybind, persistent local UUID list, protected-item indicators, and guarded drop/trade/sell actions.
- Slot Locking enabled by default with optional inventory-to-hotbar bindings, a persistent local slot map and lock/binding indicators; no slots are pre-locked.
- Dungeon terminal GUI variants and solvers, device helpers, six puzzle solvers, Goldor phase tracker, editable waypoints, and the local `/termsim` practice screen.
- Optional first-person held-item scaling and equip-animation speed controls, both defaulting to vanilla behavior at 100%.
- Local chat cleanup, dungeon starred-mob outlines, and full scrollable item lore. An opt-in hold-left-click attack repeater uses the ordinary controller and normal reach; check server rules before enabling it.

## Mining foundations

The `/sv` hub has a **Mining** tab (renamed from the former Farming tab without changing existing settings keys). Mining BPS continues to count client-visible block breaks and resets when the world/player session changes. The optional **Mining Assistant** HUD shows the rolling rate, session count, and the status of a supported pickaxe ability; it is movable and styled through the HUD editor.

The opt-in **Pickaxe ability ready alert** tracks only recognized Fakepixel system-chat activation messages for Pickobulus (nominal 60 seconds) and Mining Speed Boost (nominal 120 seconds). Cooldown reductions or server-side rule changes can make a local nominal countdown differ from the real cooldown, so treat the alert as a reminder rather than authoritative server state. Unknown abilities are not assigned a guessed cooldown.

The opt-in **Dwarven Mines Puzzler direction helper** parses a valid `[NPC] Puzzler` direction clue and outlines the resulting target block. It is limited to Fakepixel, clears its target when the world changes, and only renders near the expected puzzle coordinates. The powder, drill-fuel, and commission values are intentionally not displayed yet because Sky VeLor does not have a verified parser for the current Fakepixel data layouts.

## First-person item controls

The QoL page in `/sv` has **First-person held item** settings and an **Open Item Animation editor** button. You can also open the dedicated editor with `/sv itemanim` (aliases: `/sv itemanimation` and `/sv animation`). The editor keeps the world running and does not apply a full-screen dark overlay: its translucent panel sits to the left so the real first-person held item stays visible while scale, speed, position, and swing settings update live. Use **Preview** to play a local visual swing without attacking. Swing styling follows actual vanilla swing state only; holding left click by itself does not start or repeat an animation cycle in the Item Animation renderer hook. Item scale and equip-animation speed each have their own on/off switch and 30–200% / 25–400% slider; 100% is vanilla behavior, and disabling either setting restores that option to 100%. Scaling affects the held item and first-person arm visuals only. Equip-animation speed affects the transition and visual swing only, not attack cooldown, eating, bow draw, or server-visible timing. The renderer installation is client-only and reports a failure to the log rather than preventing the rest of Sky VeLor from loading.


The mining ability notifier and Puzzler helper are off by default. Open `/sv` → **Mining** to enable them. Pure-logic tests cover cooldown parsing, rounding, unknown ability handling, Puzzler route directions, malformed clues, and bounded input length. Those tests do not replace validation in a live Forge 1.8.9 session.

## Inventory and Chat QoL

- Chat copy uses a Shift-click gesture: hold **Shift** and left-click a visible chat message to copy the entire wrapped message; hold **Ctrl** too to include formatting codes. A subtle highlight and copy icon are shown while Shift is held.
- **No hurt camera** disables the damage camera shake/roll (enabled by default).
- **Hide block breaking particles** hides both block-hit and block-destroy particles (enabled by default).


Client-side helpers are available from `/sv` under **Inventory & Chat QoL**. Default states are noted for each option:

- **Inventory search and filter** is enabled by default and adds a search box to the player inventory and chest screens. It follows Minecraft's actual GUI coordinates, including the potion-panel offset, so highlights remain aligned when status effects are visible. It searches item names and lore, dims non-matching stacks, and outlines matches; it never disables or intercepts item clicks.
- **Hide potion effects in inventory** is enabled by default; it hides only the effects panel on the player inventory screen and recenters the inventory. Potion effects remain active in gameplay.
- **Auto sprint** is enabled by default and starts sprinting while moving forward when the usual food/flight, use-item, collision, riding, sneaking and blindness restrictions permit it.
- **Roman numerals in tooltips** is enabled by default and converts unambiguous Roman numeral levels such as `VI` to `6` while preserving formatting codes.
- **Scrollable item tooltips** is enabled by default and keeps the complete tooltip available in a compact window. Scroll the mouse wheel or press **Up/Down** while hovering an item in an inventory to move through all lore lines; input is consumed only while scrolling that item tooltip.
- **Item rarity highlight** is enabled by default and draws a static, rarity-colored 16×16 slot gradient. The tint is intentionally more visible, strongest around the lower-middle and fading toward the top; it does not animate or add a border or external glow. The item, stack count, durability bar and enchantment glint render normally above it.
- **Copy chat text** remains available through the legacy Shift-left-click helper while native Chat QoL is off. When native Chat QoL is enabled, its captured message history handles Shift-left-click copying and the context menu; it verifies clipboard read-back and safely falls back across available clipboard backends.
- **Chat length (256 characters)** is enabled by default. Chat input and the outgoing chat packet accept up to 256 characters instead of vanilla's 100. The same persisted setting is shared with the Chat Editor and works independently of whether the native chat renderer is enabled. Servers may still reject or truncate long messages.
- **No hurt camera** is enabled by default and disables the damage camera shake/roll.
- **Hide block breaking particles** is enabled by default and hides block-hit and block-destroy particles.
- **Clean chat spam** locally filters configurable categories: Watchdog/Info, friend join/leave, selected Zombie rare drops, selling-rank ads, server promos, and game invites. **Mute irrelevant messages** independently removes dungeon `[BOSS]` and `[CROWD]` lines only during Catacombs; it does not modify network packets.
- **Wardrobe / Pets shortcuts** can be enabled and bound in `Options → Controls → Sky VeLor`. They send `/wardrobe` or `/pets` only when the connected server address contains `fakepixel`.

The search and rarity visuals operate only on supported inventory/chest screens. A small client-only Mixin hook draws the rarity tint before vanilla draws the slot item, avoiding duplicate item rendering. It does not change server-side inventory data.

## Item Protection

Item Protection is enabled by default. Open an inventory, place the cursor over a SkyBlock item and press **Protect Item** (configure its initially unbound key under **Options → Controls → Sky VeLor**). Outside an inventory, the same key protects or unprotects the currently held item. The feature requires the item's `ExtraAttributes.uuid` (or `ExtraAttributes.UUID`) to be a valid UUID; ordinary items without that identity cannot be protected safely. Protected items are marked with a gold star drawn over the item but below its tooltip in standard inventory and chest screens. Dragging a protected cursor stack outside the container is blocked on both mouse release and the outgoing container-click packet.

The protected UUID list is stored locally in `config/skyvelor/protected-items.txt`. It is readable and versioned, and updates are written atomically. `/sv protect` shows status; `/sv protect on`, `/sv protect off`, and `/sv protect toggle` control the feature. The master switch and notifications are also in **/sv → QoL → Item Protection**. If the store becomes unreadable or a save fails, protection switches to a fail-closed state for known destructive actions rather than treating the list as empty; repair the reported file before relying on the feature again.

Protection blocks known item drops and interactions in recognized trade, sell, salvage and auction-confirmation menus. It is a client-side safety layer, not a server guarantee: unrecognized custom interfaces, server-side menu bugs, items without a stable UUID, or actions taken while protection is disabled cannot be fully covered. Check the held item and destination before confirming any valuable transaction.

## Slot Locking and Binding

Slot Locking is enabled by default, but no slots are locked on a fresh install. Disable it in **/sv → QoL → Slot Locking / Binding** or with `/sv slots off` if desired. Open the player inventory or a chest, hover a player-inventory slot, and tap **Lock Slot** (default **L**, configurable under **Options → Controls → Sky VeLor**) to lock or unlock it. The gold lock icon marks a locked slot at 50% overlay opacity, and the blue binding icon marks a slot binding at 70% overlay opacity. The icons and search/rarity overlays render above slot items but below the active tooltip; their OpenGL state is restored after drawing. Locked player-inventory slots reject ordinary clicks and known drop, hotbar-swap, shift-click, drag-target and collect-all paths that would move items out of or into the slot. If the slot-lock settings file cannot be read, the feature restricts risky operations; `/sv slots off` disables the guard if access needs to be recovered while the file is repaired.

With **Enable slot binding** on, hold **Lock Slot** over a main-inventory or armor slot, then move the cursor onto a hotbar slot while still holding the key, using a drag gesture. The hotbar slots highlight and a link preview follows the cursor. A successful binding automatically protects both connected slots like Slot Locking. Multiple inventory/armor sources can share the same hotbar target; each source retains its own link rather than replacing an earlier item. Release the key after each completed binding; the release fallback prevents a missed GUI key-up event from leaving the gesture stuck. A short tap still toggles a regular slot lock. Right-click or Shift+left-click a bound source to swap that exact item with its target hotbar slot; using the same gesture on the hotbar target uses the most recently bound source as its default. The real `GuiContainer` click is intercepted before vanilla treats a bound/locked slot as a cursor pickup, drop or ordinary move; only a validated bound-swap action moves the stack. Hover a bound source to show its cyan link line; hovering a hotbar target shows the lines for its linked sources. Lines appear only while hovering, so they never permanently cover the inventory. Routine lock, unlock, bind, unbind and blocked-slot notices are silent in chat; storage errors may still be reported. Bindings and locks are stored locally in `config/skyvelor/slot-locks.properties` with atomic updates. `/sv slots` shows status; `/sv slots on`, `/sv slots off`, and `/sv slots toggle` control slot locking without deleting saved bindings.

Slot Locking is a client-side safeguard, not a server guarantee. It uses Forge GUI events, outgoing packet checks, and a narrowly scoped client-only Mixin for the actual slot-click interception. Custom interfaces or actions that bypass these hooks may not be covered. Test it with a non-valuable item and never rely on a client-side lock as the only protection for irreplaceable items.


## Installation

1. Start Minecraft 1.8.9 with Forge `11.15.1.2318` once.
2. Put `skyvelor-1.0.0.jar` in the Minecraft `mods` folder.
3. Launch the Forge profile.

## Compatibility and testing limits

The project targets desktop Java 8. Android/Pojav compatibility is not verified. Automated tests cover logic, settings and configuration; they do not launch Minecraft or verify live-server behavior. Test rendering and gameplay in Minecraft 1.8.9 before publishing a release.

## Developers

Sky VeLor is developed by **ii8we**, **whiteshadow**, and **pekadeco**.

## License and credits

The root `LICENSE` is the sole license and attribution file. It contains the Sky VeLor developer credits, the NotEnoughFakepixel upstream attribution, and the unmodified GNU Lesser General Public License v3.0-or-later text used for code derived from that project. No separate notice directory or duplicate license file is required. Gradle refuses to configure the project if `LICENSE` is missing or its required license/attribution content is incomplete.

Sky VeLor is a separate project; this notice does not claim ownership of the original NotEnoughFakepixel authors' code. Parts of the project were also ported from RNG Carried Bald, so preserve its applicable attribution and license notices for the relevant components.
## Privacy

Read [privacy.md](privacy.md) for the Dungeon Sync data disclosure, IP-address limitations, log configuration, temporary puzzle-data behavior, and how to opt out at any time.

### Additional features

- **Dungeon Boss HP HUD:** optional draggable HUD for Maxor, Storm, Goldor, Necron and the five Master Mode VII dragons. Health parsing uses boss-bar/sidebar/entity sources with safeguards against vanilla-scaled HP; enable it from `/sv` → Dungeon or configure it in the HUD editor.
- **Native Chat QoL (enabled by default):** manage it from `/sv` → **Chat** or run `/sv chat` to open the Chat Editor. It replaces only the default-chat overlay while its guarded Minecraft/Forge bridges are available; if a bridge is unavailable or fails at runtime, it fails open and returns to vanilla chat. The renderer retains its own bounded logical message history, including local client-side messages from Sky VeLor commands and feature notifications (not just server packets), supports All/Party/Reply/custom tabs, smooth scrolling, optional duplicate compaction, configurable background/highlight, and a captured context menu for copy-to-clipboard, copy-to-chat-box and message-player actions. Shift-left-click copies the captured logical message. The context-menu player action appears only when a valid player name can be extracted. The master switch is on by default; turn it off to return to vanilla chat rendering. Chat Length remains a separate setting even though its value is also exposed in the Chat Editor. Skytils attribution and applicable AGPL terms are documented in the root `LICENSE` and `NOTICE.md`.
- **Fishing counter expansion:** individual rare/legendary creature rows, a combined **CC** total for non-legendary catches, a total row, and the pre-existing Festival count/best.
- **Sea Creature HP improvements:** more robust nameplate extraction for Fakepixel scoreboard-composed labels, short detection grace to avoid HUD flicker, and Yeti appearance alerts (with the existing Jawbus chat alert retained).
- **Slayer tracker retention:** rare drops and quantities are written to a separate local history file and survive game restarts until cleared. The HUD can show all stored drops or use its row-limit switch. The Slayer HUD border can be toggled from `/sv` → Slayer.