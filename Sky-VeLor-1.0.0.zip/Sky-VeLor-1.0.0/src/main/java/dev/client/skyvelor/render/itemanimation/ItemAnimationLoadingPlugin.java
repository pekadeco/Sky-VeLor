package dev.client.skyvelor.render.itemanimation;

import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;

import java.util.Map;

/**
 * Narrow Forge 1.8.9 coremod entry point for the first-person Item Animation transformer only.
 * Other Sky VeLor QoL hooks remain managed by the existing Mixin configuration and are not re-registered here.
 */
@IFMLLoadingPlugin.Name("Sky VeLor Item Animation")
@IFMLLoadingPlugin.MCVersion("1.8.9")
@IFMLLoadingPlugin.SortingIndex(1001)
@IFMLLoadingPlugin.TransformerExclusions({"dev.client.skyvelor.render.itemanimation"})
public final class ItemAnimationLoadingPlugin implements IFMLLoadingPlugin {

    @Override
    public String[] getASMTransformerClass() {
        ItemAnimationHookStatus.noteCoremodRegistered();
        return new String[] {ItemAnimationTransformer.class.getName()};
    }

    @Override
    public String getModContainerClass() {
        return null;
    }

    @Override
    public String getSetupClass() {
        return null;
    }

    @Override
    public void injectData(Map<String, Object> data) {
        // The transformer is deliberately independent of Minecraft during coremod discovery.
    }

    @Override
    public String getAccessTransformerClass() {
        return null;
    }
}
