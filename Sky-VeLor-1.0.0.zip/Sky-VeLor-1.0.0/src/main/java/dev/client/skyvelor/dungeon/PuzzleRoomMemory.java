package dev.client.skyvelor.dungeon;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Remembers puzzle rooms discovered during the current dungeon run.
 * Room identity is based on world block coordinates, not the player's current cell or map pixel.
 */
public final class PuzzleRoomMemory {
    private final Map<RoomKey, RoomLabel> rooms = new LinkedHashMap<RoomKey, RoomLabel>();

    public void remember(String name, int originX, int originY, int originZ, double confidence) {
        if (name == null || name.trim().isEmpty() || confidence < 0.65D) return;
        RoomKey key = new RoomKey(originX, originY, originZ);
        RoomLabel existing = rooms.get(key);
        if (existing == null) {
            rooms.put(key, new RoomLabel(name.trim(), originX, originY, originZ, confidence));
            return;
        }
        if (existing.confidence > confidence) return;
        // Keep the same label object so its map-space anchor survives stronger re-matches
        // or a corrected puzzle name at the same world origin.
        existing.name = name.trim();
        existing.confidence = confidence;
    }

    /** Stores the first valid map-texture anchor until the map data instance changes. */
    public boolean rememberMapPosition(int originX, int originY, int originZ, float mapX, float mapY) {
        RoomLabel room = rooms.get(new RoomKey(originX, originY, originZ));
        if (room == null || room.hasMapPosition || Float.isNaN(mapX) || Float.isInfinite(mapX)
                || Float.isNaN(mapY) || Float.isInfinite(mapY)) return false;
        room.mapX = mapX;
        room.mapY = mapY;
        room.hasMapPosition = true;
        return true;
    }

    /** Explicitly replaces a room's map-space anchor. Rendering should prefer rememberMapPosition
     * so updates to live player markers cannot make labels slide between frames.
     */
    public boolean updateMapPosition(int originX, int originY, int originZ, float mapX, float mapY) {
        RoomLabel room = rooms.get(new RoomKey(originX, originY, originZ));
        if (room == null || Float.isNaN(mapX) || Float.isInfinite(mapX)
                || Float.isNaN(mapY) || Float.isInfinite(mapY)) return false;
        boolean firstPosition = !room.hasMapPosition;
        room.mapX = mapX;
        room.mapY = mapY;
        room.hasMapPosition = true;
        return firstPosition;
    }

    /** Snapshot keeps rendering independent from mutations made by the client tick. */
    public List<RoomLabel> snapshot() {
        return new ArrayList<RoomLabel>(rooms.values());
    }

    /** Copies the current room references into a caller-owned reusable list, avoiding per-frame allocations. */
    public void snapshotInto(List<RoomLabel> output) {
        if (output == null) throw new IllegalArgumentException("output must not be null");
        output.clear();
        output.addAll(rooms.values());
    }

    /** Invalidates only texture-space positions if the map item/data instance changes. */
    public void clearMapPositions() {
        for (RoomLabel room : rooms.values()) {
            room.hasMapPosition = false;
            room.mapX = 0.0F;
            room.mapY = 0.0F;
        }
    }

    public int size() { return rooms.size(); }

    public boolean containsRoomAt(int originX, int originY, int originZ) {
        return rooms.containsKey(new RoomKey(originX, originY, originZ));
    }

    public void clear() { rooms.clear(); }

    public static final class RoomLabel {
        public String name;
        public final int originX;
        public final int originY;
        public final int originZ;
        public double confidence;
        private boolean hasMapPosition;
        private float mapX;
        private float mapY;

        private RoomLabel(String name, int originX, int originY, int originZ, double confidence) {
            this.name = name;
            this.originX = originX;
            this.originY = originY;
            this.originZ = originZ;
            this.confidence = confidence;
        }

        public boolean hasMapPosition() { return hasMapPosition; }
        public float mapX() { return mapX; }
        public float mapY() { return mapY; }
    }

    private static final class RoomKey {
        private final int x;
        private final int y;
        private final int z;

        private RoomKey(int x, int y, int z) {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        @Override public boolean equals(Object other) {
            if (this == other) return true;
            if (!(other instanceof RoomKey)) return false;
            RoomKey key = (RoomKey) other;
            return x == key.x && y == key.y && z == key.z;
        }

        @Override public int hashCode() {
            int result = x;
            result = 31 * result + y;
            result = 31 * result + z;
            return result;
        }
    }
}
