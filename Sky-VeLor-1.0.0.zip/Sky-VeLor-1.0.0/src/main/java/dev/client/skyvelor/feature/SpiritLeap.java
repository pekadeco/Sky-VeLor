package dev.client.skyvelor.feature;

import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;

import java.util.List;

/**
 * Detects the server-opened Spirit Leap picker using Better NEF's strict title and dungeon checks.
 * A recent use of a Leap item is deliberately not sufficient: Bazaar/other chest GUIs can contain
 * heads or be opened immediately after buying a Spirit Leap item.
 */
public final class SpiritLeap {
    private SpiritLeap() { }

    /** Pure decision helper so the strict title rule can be regression-tested. */
    public static boolean decide(boolean titleIsLeap, boolean recentUse, boolean inDungeon, int teammateHeads) {
        return titleIsLeap && inDungeon;
    }

    /** Only the explicit Spirit Leap picker title inside a dungeon is eligible for custom rendering. */
    public static boolean isLeapMenu(Container container) {
        if (!(container instanceof ContainerChest) || !DungeonContext.isInDungeonNow()) return false;
        IInventory lower = ((ContainerChest) container).getLowerChestInventory();
        return lower != null && lower.getDisplayName() != null
                && LeapText.isLeapTitle(lower.getDisplayName().getUnformattedText());
    }

    /**
     * The teammate slots of an open Spirit Leap menu, in slot order. Only non-empty player-head slots in the
     * menu's own inventory are listed, so the player's own inventory is never shown.
     */
    public static void teammateSlots(Container container, List<Slot> out) {
        out.clear();
        if (!(container instanceof ContainerChest)) {
            return;
        }
        IInventory lower = ((ContainerChest) container).getLowerChestInventory();
        for (Slot s : container.inventorySlots) {
            if (s.inventory != lower || !s.getHasStack()) {
                continue;
            }
            ItemStack stack = s.getStack();
            if (stack != null && stack.getItem() == Items.skull) {
                out.add(s);
            }
        }
    }

    /** Convenience form that allocates a new list. Not used on the per-frame path. */
    public static List<Slot> teammateSlots(Container container) {
        List<Slot> out = new java.util.ArrayList<Slot>();
        teammateSlots(container, out);
        return out;
    }
}
