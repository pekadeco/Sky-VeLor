package dev.client.skyvelor.feature.qol;

import dev.client.skyvelor.config.AppleSettings;
import dev.client.skyvelor.feature.SkyblockContext;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Local render-only cleanup matching Better NEF's Hide Dead Mobs and Hide Flaming Fists options.
 * This never removes entities from the world or changes packets/server state.
 */
public final class EntityVisualCleanup {
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onRenderLiving(RenderLivingEvent.Pre<?> event) {
        if (event == null || event.entity == null) return;
        EntityLivingBase entity = event.entity;

        if (AppleSettings.hideDeadMobs && EntityVisualPolicy.shouldHideDyingMob(
                entity.isDead, entity instanceof EntityPlayer, entity instanceof EntityArmorStand,
                entity.getHealth(), entity.deathTime)) {
            // Cancelling the pre-render event prevents the body, death animation and nameplate from being drawn.
            event.setCanceled(true);
            return;
        }

        if (!AppleSettings.hideFlamingFists || !SkyblockContext.isInSkyblock()
                || !(entity instanceof EntityArmorStand)) return;

        EntityArmorStand armorStand = (EntityArmorStand) entity;
        ItemStack helmet = armorStand.getEquipmentInSlot(4);
        if (EntityVisualPolicy.isFlamingFistTexture(readSkullTexture(helmet))) {
            // Cancel render only; don't mark the entity invisible, so toggling the setting takes effect immediately.
            event.setCanceled(true);
        }
    }

    private static String readSkullTexture(ItemStack stack) {
        if (stack == null || stack.getItem() != Items.skull || !stack.hasTagCompound()) return "";
        NBTTagCompound root = stack.getTagCompound();
        if (!root.hasKey("SkullOwner", 10)) return "";
        NBTTagCompound owner = root.getCompoundTag("SkullOwner");
        if (!owner.hasKey("Properties", 10)) return "";
        NBTTagCompound properties = owner.getCompoundTag("Properties");
        if (!properties.hasKey("textures", 9)) return "";
        NBTTagList textures = properties.getTagList("textures", 10);
        if (textures.tagCount() == 0) return "";
        NBTTagCompound first = textures.getCompoundTagAt(0);
        return first.hasKey("Value", 8) ? first.getString("Value") : "";
    }
}
