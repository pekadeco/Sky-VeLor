package dev.client.skyvelor.command;

import dev.client.skyvelor.gui.AppleHubScreen;
import dev.client.skyvelor.gui.ChatEditorScreen;
import dev.client.skyvelor.gui.ItemAnimationEditorScreen;
import dev.client.skyvelor.notes.QuickNoteScreen;
import dev.client.skyvelor.notes.QuickNotes;
import net.minecraft.client.Minecraft;

/**
 * Screens that chat commands ask for. A command only sets a flag. The client tick opens the screen,
 * because the chat box closes after the command is sent and would close a screen opened inside the command.
 * This is the same pattern RNG Carried Bald uses.
 */
public final class ClientActions {

    private static boolean hubPending;
    private static boolean notesPending;
    private static boolean chatEditorPending;
    private static boolean itemAnimationEditorPending;
    private static boolean terminalSimulatorPending;

    /** Opens the terminal practice GUI after GuiChat has closed (used by /termsim). */
    public static void requestTerminalSimulator() {
        terminalSimulatorPending = true;
    }

    private ClientActions() {
    }

    public static void requestHub() {
        hubPending = true;
    }

    public static void requestQuickNotes() {
        notesPending = true;
    }

    /** Opens the native r5 Chat Editor after the local chat command screen has closed. */
    public static void requestChatEditor() {
        chatEditorPending = true;
    }

    /** Opens the transparent live Item Animation editor after the local chat command has closed. */
    public static void requestItemAnimationEditor() {
        itemAnimationEditorPending = true;
    }

    /** Called once per client tick, after the chat screen has closed. */
    public static void run(Minecraft mc) {
        if (mc == null) {
            return;
        }
        if (chatEditorPending) {
            chatEditorPending = false;
            hubPending = false;
            mc.displayGuiScreen(new ChatEditorScreen(null));
        } else if (itemAnimationEditorPending) {
            itemAnimationEditorPending = false;
            hubPending = false;
            mc.displayGuiScreen(new ItemAnimationEditorScreen(null));
        } else if (hubPending) {
            hubPending = false;
            mc.displayGuiScreen(new AppleHubScreen(null));
        }
        if (terminalSimulatorPending) {
            terminalSimulatorPending = false;
            mc.displayGuiScreen(new dev.client.skyvelor.dungeon.solver.terminals.TerminalSimulator());
        }
        if (notesPending) {
            notesPending = false;
            mc.displayGuiScreen(new QuickNoteScreen(QuickNotes.store(), null));
        }
    }
}
