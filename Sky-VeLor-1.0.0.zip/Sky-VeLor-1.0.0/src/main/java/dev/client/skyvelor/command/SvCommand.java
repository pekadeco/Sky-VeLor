package dev.client.skyvelor.command;

import dev.client.skyvelor.config.AppleSettings;
import dev.client.skyvelor.feature.ChatChannelTabs;
import dev.client.skyvelor.feature.protection.ItemProtection;
import dev.client.skyvelor.feature.inventory.SlotLocking;
import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;

import java.util.Collections;
import java.util.List;

/** /sv opens the Sky VeLor hub from chat. Client-side only; nothing is sent to the server. */
public final class SvCommand extends CommandBase {

    @Override
    public String getCommandName() {
        return "sv";
    }

    @Override
    public List<String> getCommandAliases() {
        return Collections.emptyList();
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/sv [chat | itemanim | itemanimation | animation | chatdebug | protect [status|on|off|toggle] | slots [status|on|off|toggle]]";
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 0;
    }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        Minecraft mc = Minecraft.getMinecraft();
        if (args != null && args.length > 0 && "chat".equalsIgnoreCase(args[0])) {
            ClientActions.requestChatEditor();
            return;
        }
        if (args != null && args.length > 0 && ("itemanim".equalsIgnoreCase(args[0])
                || "itemanimation".equalsIgnoreCase(args[0]) || "animation".equalsIgnoreCase(args[0]))) {
            ClientActions.requestItemAnimationEditor();
            return;
        }
        if (args != null && args.length > 0 && "chatdebug".equalsIgnoreCase(args[0])) {
            ChatChannelTabs.toggleDebug(sender);
            return;
        }
        if (args != null && args.length > 0 && "protect".equalsIgnoreCase(args[0])) {
            String action = args.length > 1 ? args[1] : "status";
            if (mc.thePlayer != null) {
                mc.thePlayer.addChatMessage(new ChatComponentText(
                        "\u00a7b[Sky VeLor] \u00a7f" + ItemProtection.toggleCommand(action)));
            }
            return;
        }
        if (args != null && args.length > 0 && "slots".equalsIgnoreCase(args[0])) {
            String action = args.length > 1 ? args[1] : "status";
            if (mc.thePlayer != null) {
                mc.thePlayer.addChatMessage(new ChatComponentText(
                        "\u00a7b[Sky VeLor] \u00a7f" + SlotLocking.toggleCommand(action)));
            }
            return;
        }
        if (!AppleSettings.svCommand) {
            if (mc.thePlayer != null) {
                mc.thePlayer.addChatMessage(new ChatComponentText(
                        "\u00a7b[Sky VeLor] \u00a7f/sv is off. Turn it on in the hub, QoL, Commands."));
            }
            return;
        }
        ClientActions.requestHub();
    }
}
