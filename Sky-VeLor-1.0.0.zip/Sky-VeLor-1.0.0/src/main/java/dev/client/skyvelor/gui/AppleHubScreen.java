package dev.client.skyvelor.gui;

import dev.client.skyvelor.gui.ChatEditorScreen;

import dev.client.skyvelor.PekaVersion;
import dev.client.skyvelor.config.AppleSettings;
import dev.client.skyvelor.config.ChatQolSettings;
import dev.client.skyvelor.dungeon.M7OverlayRenderer;
import dev.client.skyvelor.dungeon.M7Settings;
import dev.client.skyvelor.dungeon.sync.DungeonPuzzleSyncConfig;
import dev.client.skyvelor.dungeon.solver.terminals.TerminalTracker;
import dev.client.skyvelor.dungeon.solver.terminals.TerminalSimulator;
import dev.client.skyvelor.fishing.FishingStats;
import dev.client.skyvelor.slayer.SlayerTracker;
import dev.client.skyvelor.slayer.SlayerType;
import dev.client.skyvelor.feature.MiningTracker;
import dev.client.skyvelor.feature.StarredMobPolicy;
import dev.client.skyvelor.feature.ChatChannelTabs;
import dev.client.skyvelor.feature.ItemAnimation;
import dev.client.skyvelor.feature.protection.ItemProtection;
import dev.client.skyvelor.feature.inventory.SlotLocking;
import dev.client.skyvelor.hud.HudElement;
import dev.client.skyvelor.hud.HudManager;
import dev.client.skyvelor.hud.PlayerDollHud;
import dev.client.skyvelor.render.Anim;
import dev.client.skyvelor.render.Icons;
import dev.client.skyvelor.render.Theme;
import dev.client.skyvelor.render.UIRender;
import dev.client.skyvelor.widget.AppleButton;
import dev.client.skyvelor.widget.AppleDropdown;
import dev.client.skyvelor.widget.AppleSegmented;
import dev.client.skyvelor.widget.AppleSlider;
import dev.client.skyvelor.widget.AppleToggle;
import dev.client.skyvelor.widget.SearchField;
import dev.client.skyvelor.widget.Widget;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiControls;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiScreenResourcePacks;
import net.minecraft.client.gui.GuiVideoSettings;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * The Sky VeLor hub: a compact custom settings window with neutral title-bar controls, a sidebar (or
 * tab bar on narrow screens), a search field and scrollable grouped cards.
 *
 * Tabs, in order: QoL, HUD, Mining, Dungeon, Slayer, Fishing. QoL holds the overview, appearance,
 * performance (including the BETA mode), scroll speed and the About card. HUD holds the
 * element switches, the HUD editor and the element settings, with a live preview for the player doll.
 * Mining holds the block-rate HUD, session overlay and mining helpers. Dungeon holds the live minimap, puzzle room labels and Spirit Leap teammate selector. Slayer and Fishing have no
 * modules yet, so they show an empty state rather than placeholder modules.
 *
 * Title-bar controls close the hub, collapse it to the title bar, or expand it to the full screen.
 * Input: mouse wheel and touch swipe scroll the list, with the speed set in QoL. Keys scroll by a fixed step. A swipe
 * never activates a control. Keyboard: Ctrl+1 to Ctrl+6 pick a tab, Left and Right step through tabs,
 * Up, Down, Page Up, Page Down, Home and End scroll.
 */
public class AppleHubScreen extends AppleScreen {

    private static final float TITLE_H = 34f;
    private static final float SIDEBAR_W = 136f;
    private static final float PAD = 14f;
    private static final float ROW_GAP = 6f;
    private static final float NAV_H = 26f;
    private static final float NAV_STEP = 30f;
    private static final float TAB_H = 24f;
    /** Narrowest tab width at which the tab name is drawn. Below this, only the icon is drawn. */
    private static final float TAB_TEXT_MIN = 52f;

    private static final String[] SOLVER_COLOR_NAMES = {
            "Green", "Yellow", "Cyan", "Magenta", "Red", "Blue", "White"
    };
    private static final String[] SOLVER_COLOR_VALUES = {
            "0:255:0:255:0", "0:255:255:255:0", "0:255:0:255:255",
            "0:255:255:0:255", "0:255:255:0:0", "0:255:0:100:255", "0:255:255:255:255"
    };
    private static final int[] SOLVER_COLOR_DOTS = {
            0xFF00FF00, 0xFFFFFF00, 0xFF00FFFF, 0xFFFF00FF,
            0xFFFF0000, 0xFF0064FF, 0xFFFFFFFF
    };
    private static final String[] STARRED_COLOR_NAMES = {
            "Default", "Green", "Yellow", "Cyan", "Magenta", "Red", "Blue", "White"
    };

    private static int[] starredColorDots(String defaultValue) {
        int[] dots = new int[STARRED_COLOR_NAMES.length];
        dots[0] = StarredMobPolicy.parseColor(defaultValue, 0xFF00FFFF);
        System.arraycopy(SOLVER_COLOR_DOTS, 0, dots, 1, SOLVER_COLOR_DOTS.length);
        return dots;
    }

    private static int starredColorIndex(String value, String defaultValue) {
        if (value == null) return 0;
        String normalized = StarredMobPolicy.withChromaSpeed(value, 0);
        if (StarredMobPolicy.withChromaSpeed(defaultValue, 0).equals(normalized)) return 0;
        for (int i = 0; i < SOLVER_COLOR_VALUES.length; i++) {
            if (StarredMobPolicy.withChromaSpeed(SOLVER_COLOR_VALUES[i], 0).equals(normalized)) return i + 1;
        }
        return 0;
    }

    private static String starredColorValue(int index, String currentValue, String defaultValue) {
        String selected = index <= 0 ? defaultValue
                : SOLVER_COLOR_VALUES[Math.max(0, Math.min(SOLVER_COLOR_VALUES.length - 1, index - 1))];
        if (index > 0 && currentValue != null) {
            String[] currentParts = currentValue.trim().split(":");
            String[] selectedParts = selected.split(":");
            if (currentParts.length == 5 && selectedParts.length == 5) {
                // A palette color changes RGB, while keeping the current opacity and chroma selection.
                selectedParts[1] = currentParts[1];
                selected = selectedParts[0] + ":" + selectedParts[1] + ":" + selectedParts[2]
                        + ":" + selectedParts[3] + ":" + selectedParts[4];
            }
        }
        return StarredMobPolicy.withChromaSpeed(selected, StarredMobPolicy.chromaSpeed(currentValue));
    }

    private static AppleSlider starredColorChromaSlider(java.util.function.Supplier<String> colorGetter,
                                                         java.util.function.Consumer<String> colorSetter) {
        return new AppleSlider(0, 255, 1, "", 126f,
                () -> StarredMobPolicy.chromaSpeed(colorGetter.get()),
                speed -> { colorSetter.accept(StarredMobPolicy.withChromaSpeed(colorGetter.get(), speed)); AppleSettings.save(); })
                .valueLabel(speed -> speed == 0 ? "Static" : "Chroma " + speed);
    }

    private static int solverColorIndex(String value) {
        if (value != null) {
            for (int i = 0; i < SOLVER_COLOR_VALUES.length; i++) {
                if (SOLVER_COLOR_VALUES[i].equals(value)) return i;
            }
        }
        return 0;
    }

    static final String[] PAGE_NAMES = {"QoL", "HUD", "Mining", "Dungeon", "Slayer", "Fishing"};
    private static final String[] PAGE_SUBS = {
            "Overview, appearance, performance and camera",
            "Show, place and style the on-screen elements",
            "Mining rate, session statistics and mining helpers",
            "Dungeon map, puzzle-room sync, Spirit Leap and Floor VII (M7) overlays",
            "Drop tracker, boss timer and prices",
            "Legendary catch counter, Festival best, Sea Creature HP and the Lord Jawbus alert"
    };
    /** HUD groups in display order. Each one expands in place to its toggle and settings. */
    private static final HudElement[] HUD_OVERVIEW = {
            HudManager.DOLL, HudManager.INVENTORY, HudManager.MINING, HudManager.MINING_ASSISTANT, HudManager.HOTBAR,
            HudManager.FISHING, HudManager.SEA_HP, HudManager.DUNGEON_BOSS_HP, HudManager.SLAYER,
            HudManager.DUNGEON_SCORE, HudManager.DUNGEON_SECRETS};
    private static final String[] HUD_NAMES = {
            "Player Doll", "Inventory HUD", "Mining BPS", "Mining Assistant", "Hotbar",
            "Fishing counter", "Sea Creature HP", "Dungeon Boss HP", "Slayer tracker", "Dungeon Score", "Dungeon Secrets"};
    private static final String[] HUD_DESCS = {
            "Preview your player model, armor and held item.",
            "Show the main inventory slots and optional armor.",
            "Confirmed blocks broken per second.",
            "Show mining rate, session total and pickaxe ability state.",
            "Display the nine hotbar slots as a separate HUD.",
            "Show rare catches, Common Creature count and Festival best.",
            "Show nearby sea-creature names, levels and health.",
            "Show boss health for F7/M7 bosses and dragons.",
            "Show recorded Slayer drops, profit and boss timer.",
            "Show total score, rank, score components and S+ secret target.",
            "Show secrets found and the S+ secret target."};
    private static final int HUD_MINING = 2; // index into HUD_OVERVIEW
    private static final int HUD_MINING_ASSISTANT = 3;
    private static final int HUD_DUNGEON_BOSS_HP = 7;
    private static final int HUD_DUNGEON_SCORE = 9;
    private static final int HUD_DUNGEON_SECRETS = 10;
    private static final int[] PAGE_ICONS = {
            Icons.BOLT, Icons.HUD, Icons.PICKAXE, Icons.TOWER, Icons.SWORD, Icons.FISH
    };
    private static final int PAGE_QOL = 0;
    private static final int PAGE_HUD = 1;
    private static final int PAGE_MINING = 2;
    private static final int PAGE_FISHING = 5;
    private static final int PAGE_DUNGEON = 3;

    // Indexes into statValues.
    private static final int S_FPS = 0;
    private static final int S_MEM = 1;
    private static final int S_FRAME = 2;
    private static final int S_MINE = 3;

    private final GuiScreen parent;
    private final List<List<Row>> pages = new ArrayList<List<Row>>();
    private int pageIndex;

    private final SearchField search = new SearchField("Search settings");
    private final List<Row> searchRows = new ArrayList<Row>();
    private int searchVersion = -1;
    private boolean searching;
    private String query = "";

    /** Element picked in the HUD tab's element settings. */
    /** Titles of the collapsible groups that are currently expanded. Kept while the screen is open. */
    private final Set<String> expanded = new HashSet<String>();
    private final Map<String, Float> sectionHover = new HashMap<String, Float>();
    private final Map<String, Float> sectionOpen = new HashMap<String, Float>();
    private final Map<Row, Float> itemHover = new java.util.IdentityHashMap<Row, Float>();
    private final Map<Row, Float> rowReveal = new java.util.IdentityHashMap<Row, Float>();
    private long sectionAnimationNs;
    /** Header under the pointer at press time. Toggles on release if the pointer did not drag. */
    private Row pendingHeader;

    // Window state. Collapsed hides everything but the title bar. Zoomed fills the screen.
    private boolean collapsed;
    private boolean zoomed;

    // Player doll preview in the HUD tab: drag to turn.
    private boolean dollVisible;
    private boolean dollDragging;
    private float dollLastX;
    private float dollX;
    private float dollY;
    private float dollW;
    private float dollH;

    private final Anim openAnim = new Anim(0f);
    private final Anim fadeAnim = new Anim(1f);
    private final Anim[] navSel = new Anim[PAGE_NAMES.length];
    private final Anim[] navHover = new Anim[PAGE_NAMES.length];
    private final Anim indicator = new Anim(0f);

    // Scrolling state.
    private final ScrollState scroll = new ScrollState();
    private final Gesture gesture = new Gesture();
    private boolean gestureActive;
    private boolean sliderEngaged;
    private Widget active;

    // Layout (recomputed every frame, in GUI-scaled pixels).
    private float wx, wy, ww, wh;
    private float cx0, cw, headY;
    private float vx, vy, vw, vh;
    private boolean wide;
    private boolean tall;

    // Timing and stats.
    private long lastNs;
    private final float[] frameHistory = new float[90];
    private int histIdx;
    private float dtEma = 1f / 60f;
    private int slowFrames;
    private int fastFrames;
    private boolean autoLow;
    private float statTimer;
    private final String[] statValues = {"--", "--", "--", "--"};
    private int scaleKey = -1;
    private float sf = 2f;

    public AppleHubScreen(GuiScreen parent) {
        this.parent = parent;
        Theme.refresh();
        openAnim.to(1f);
        for (int i = 0; i < PAGE_NAMES.length; i++) {
            navSel[i] = new Anim(i == 0 ? 1f : 0f);
            navHover[i] = new Anim(0f);
        }
        expanded.add("Spirit Leap");
        expanded.add("Dungeon Sync");
        expanded.add("Dungeon Map");
        buildPages();
    }

    // ------------------------------------------------------------------ pages

    private void buildPages() {
        pages.clear();
        pages.add(qolPage());
        pages.add(hudPage());
        pages.add(miningPage());
        pages.add(dungeonPage());
        pages.add(slayerPage());
        pages.add(fishingPage());
    }

    private List<Row> qolPage() {
        final Minecraft mc = Minecraft.getMinecraft();
        List<Row> rows = new ArrayList<Row>();

        rows.add(Row.section("Overview"));
        rows.add(Row.custom(86f, this::paintStats));

        rows.add(Row.header("Appearance"));
        rows.add(Row.item("Color mode", "Choose a dark or light interface.",
                new AppleSegmented(new String[]{"Dark", "Light"}, 132f, 24f,
                        () -> AppleSettings.darkMode ? 0 : 1,
                        v -> {
                            AppleSettings.darkMode = v == 0;
                            Theme.refresh();
                        })));
        rows.add(Row.item("Accent color", "Color used for active controls and highlights.",
                new AppleDropdown(AppleSettings.ACCENT_NAMES, AppleSettings.ACCENT_COLORS, 124f, 24f,
                        () -> AppleSettings.accent,
                        v -> {
                            AppleSettings.accent = v;
                            Theme.refresh();
                        })));
        rows.add(Row.item("Custom corner radius", "Enable adjustable panel and control rounding.",
                new AppleToggle(() -> AppleSettings.cornerRadiusOn, v -> {
                    AppleSettings.cornerRadiusOn = v;
                    Theme.refresh();
                })));
        rows.add(Row.item("Corner radius", "Adjust the rounding of panels and controls.",
                gated(new AppleSlider(4, 18, 1, "px", 150f,
                        () -> AppleSettings.cornerRadius,
                        v -> {
                            AppleSettings.cornerRadius = v;
                            Theme.refresh();
                        }), () -> AppleSettings.cornerRadiusOn)));
        rows.add(Row.item("Custom panel opacity", "Enable adjustable panel transparency.",
                new AppleToggle(() -> AppleSettings.glassOpacityOn, v -> {
                    AppleSettings.glassOpacityOn = v;
                    Theme.refresh();
                })));
        rows.add(Row.item("Panel opacity", "Lower values reveal more of the game behind panels.",
                gated(new AppleSlider(60, 100, 5, "%", 150f,
                        () -> AppleSettings.glassOpacity,
                        v -> {
                            AppleSettings.glassOpacity = v;
                            Theme.refresh();
                        }), () -> AppleSettings.glassOpacityOn)));

        rows.add(Row.header("Commands"));
        rows.add(Row.item("/sv", "Open the settings hub from chat.",
                new AppleToggle(() -> AppleSettings.svCommand, v -> AppleSettings.svCommand = v)));
        rows.add(Row.item("/qn", "Open Quick Notes from chat. Alias: /quicknote.",
                new AppleToggle(() -> AppleSettings.qnCommand, v -> AppleSettings.qnCommand = v)));

        rows.add(Row.header("Inventory & Chat QoL"));
        rows.add(Row.item("Inventory search", "Find items by name or lore in inventories and chests; non-matches are dimmed.",
                new AppleToggle(() -> AppleSettings.inventorySearchEnabled, v -> AppleSettings.inventorySearchEnabled = v)));
        rows.add(Row.item("Equipment overlay", "Show the saved equipment set beside the player inventory.",
                new AppleToggle(() -> AppleSettings.equipmentOverlayEnabled, v -> AppleSettings.equipmentOverlayEnabled = v)));
        rows.add(Row.item("Show current pet", "Mark the equipped pet in the Pets menu.",
                new AppleToggle(() -> AppleSettings.showCurrentPet, v -> AppleSettings.showCurrentPet = v)));
        rows.add(Row.item("Hide inventory potion panel", "Hide the potion-effect panel; potion effects remain active.",
                new AppleToggle(() -> AppleSettings.hideInventoryPotionEffects,
                        v -> AppleSettings.hideInventoryPotionEffects = v)));
        rows.add(Row.item("Numeric enchantment levels", "Show enchantment levels as numbers, for example VI → 6.",
                new AppleToggle(() -> AppleSettings.romanNumeralsInTooltips, v -> AppleSettings.romanNumeralsInTooltips = v)));
        rows.add(Row.item("Scrollable item tooltips", "Scroll long tooltips with the mouse wheel or Up/Down arrows.",
                new AppleToggle(() -> AppleSettings.scrollableTooltipsEnabled, v -> AppleSettings.scrollableTooltipsEnabled = v)));
        rows.add(Row.item("Chat message filters", "Hide selected announcements, invitations, rank ads and rare-drop messages. Choose categories below.",
                new AppleToggle(() -> AppleSettings.removeIrritatingMessagesEnabled, v -> AppleSettings.removeIrritatingMessagesEnabled = v)));
        rows.add(Row.item("Hide Watchdog and player-info notices", "Hide [WATCHDOG ANNOUNCEMENT] and [PLAYER INFORMATION] chat lines.",
                gated(new AppleToggle(() -> AppleSettings.chatDisableWatchdogInfo, v -> AppleSettings.chatDisableWatchdogInfo = v),
                        () -> AppleSettings.removeIrritatingMessagesEnabled)));
        rows.add(Row.item("Hide friend join/leave notices", "Hide Friend > join and leave chat lines.",
                gated(new AppleToggle(() -> AppleSettings.chatDisableFriendJoin, v -> AppleSettings.chatDisableFriendJoin = v),
                        () -> AppleSettings.removeIrritatingMessagesEnabled)));
        rows.add(Row.item("Hide rare zombie drops", "Hide rare Potato, Poisonous Potato and Carrot drop messages.",
                gated(new AppleToggle(() -> AppleSettings.chatDisableZombieRareDrops, v -> AppleSettings.chatDisableZombieRareDrops = v),
                        () -> AppleSettings.removeIrritatingMessagesEnabled)));
        rows.add(Row.item("Hide rank-sale ads", "Hide player messages advertising rank sales.",
                gated(new AppleToggle(() -> AppleSettings.chatDisableSellingRanks, v -> AppleSettings.chatDisableSellingRanks = v),
                        () -> AppleSettings.removeIrritatingMessagesEnabled)));
        rows.add(Row.item("Hide server announcements", "Hide common store, help, report, stream, discount and scam-warning messages.",
                gated(new AppleToggle(() -> AppleSettings.chatDisableServerAnnouncements, v -> AppleSettings.chatDisableServerAnnouncements = v),
                        () -> AppleSettings.removeIrritatingMessagesEnabled)));
        rows.add(Row.item("Hide game invitations", "Hide server-wide invitations to play games.",
                gated(new AppleToggle(() -> AppleSettings.chatDisableGameInvites, v -> AppleSettings.chatDisableGameInvites = v),
                        () -> AppleSettings.removeIrritatingMessagesEnabled)));
        rows.add(Row.item("Hide boss/crowd chat messages", "Hide [BOSS] and [CROWD] chat lines during Catacombs runs.",
                new AppleToggle(() -> AppleSettings.muteDungeonBossCrowdMessages, v -> AppleSettings.muteDungeonBossCrowdMessages = v)));
        rows.add(Row.item("Item rarity highlight", "Add a static rarity-colored tint to item slots.",
                new AppleToggle(() -> AppleSettings.itemRarityBordersEnabled, v -> AppleSettings.itemRarityBordersEnabled = v)));
        rows.add(Row.item("Copy chat messages", "Shift-click a message to copy it; hold Ctrl as well to include formatting colors.",
                new AppleToggle(() -> AppleSettings.chatCopyEnabled, v -> AppleSettings.chatCopyEnabled = v)));
        rows.add(Row.item("Disable hurt camera shake", "Stop the camera shake when you take damage.",
                new AppleToggle(() -> AppleSettings.noHurtCamEnabled, v -> AppleSettings.noHurtCamEnabled = v)));
        rows.add(Row.item("Hide block-hit particles", "Hide particles produced when hitting or breaking blocks.",
                new AppleToggle(() -> AppleSettings.hideBlockBreakingParticles,
                        v -> AppleSettings.hideBlockBreakingParticles = v)));
        rows.add(Row.item("Hide dying mobs", "Hide non-player mobs as soon as their death animation begins.",
                new AppleToggle(() -> AppleSettings.hideDeadMobs, v -> AppleSettings.hideDeadMobs = v)));
        rows.add(Row.item("Hide Flaming Fist armor stands", "Hide recognized Flaming Fist armor stands in SkyBlock.",
                new AppleToggle(() -> AppleSettings.hideFlamingFists, v -> AppleSettings.hideFlamingFists = v)));
        rows.add(Row.item("Wardrobe shortcut", "Enable and bind Wardrobe in Options → Controls → Sky VeLor; sends /wardrobe only on Fakepixel",
                new AppleToggle(() -> AppleSettings.wardrobeShortcutEnabled, v -> AppleSettings.wardrobeShortcutEnabled = v)));
        rows.add(Row.item("Pets shortcut", "Enable and bind Pets in Options → Controls → Sky VeLor; sends /pets only on Fakepixel",
                new AppleToggle(() -> AppleSettings.petsShortcutEnabled, v -> AppleSettings.petsShortcutEnabled = v)));

        rows.add(Row.header("Movement"));
        rows.add(Row.item("Auto sprint", "Sprint while moving forward when allowed.",
                new AppleToggle(() -> AppleSettings.autoSprintEnabled, v -> AppleSettings.autoSprintEnabled = v)));
        rows.add(Row.header("Item Protection"));
        rows.add(Row.item("Protect SkyBlock items",
                "Blocks known drop and risky-menu actions for items with a valid SkyBlock UUID",
                new AppleToggle(() -> AppleSettings.itemProtectionEnabled, ItemProtection::setEnabled)));
        rows.add(Row.item("Protection notifications", "Show blocked-action and storage warnings",
                new AppleToggle(() -> AppleSettings.itemProtectionNotifications,
                        v -> AppleSettings.itemProtectionNotifications = v)));
        rows.add(Row.item("Protection status", "Shows saved UUID count and any storage warning",
                new AppleButton("Show status", 96f, 26f, false, () -> {
                    Minecraft current = Minecraft.getMinecraft();
                    if (current.thePlayer != null) {
                        current.thePlayer.addChatMessage(new net.minecraft.util.ChatComponentText(
                                "\u00a7b[Sky VeLor] \u00a7f" + ItemProtection.getStatusText()));
                    }
                })));

        rows.add(Row.header("Slot Locking / Binding"));
        rows.add(Row.item("Enable slot locking", "Prevents moving, dropping, swapping or shift-clicking through locked player-inventory slots",
                new AppleToggle(() -> AppleSettings.slotLockingEnabled, SlotLocking::setEnabled)));
        rows.add(Row.item("Enable slot binding", "Hold the Lock Slot key on a source slot, drag to a hotbar slot, then release. Right-click either bound slot to swap the pair.",
                gated(new AppleToggle(() -> AppleSettings.slotBindingEnabled, SlotLocking::setBindingEnabled),
                        () -> AppleSettings.slotLockingEnabled)));
        rows.add(Row.item("Slot-lock notifications", "Show blocked-action and storage warnings",
                new AppleToggle(() -> AppleSettings.slotLockNotifications, v -> {
                    AppleSettings.slotLockNotifications = v;
                    AppleSettings.save();
                })));
        rows.add(Row.item("Slot-lock status", "Shows the number of locked slots and active bindings",
                new AppleButton("Show status", 96f, 26f, false, () -> {
                    Minecraft current = Minecraft.getMinecraft();
                    if (current.thePlayer != null) {
                        current.thePlayer.addChatMessage(new net.minecraft.util.ChatComponentText(
                                "\u00a7b[Sky VeLor] \u00a7f" + SlotLocking.getStatusText()));
                    }
                })));

        rows.add(Row.header("Scrolling"));
        rows.add(Row.header("Chat"));
        rows.add(Row.item("Enable native Chat QoL", "Use Sky VeLor's built-in chat renderer, tabs, smooth messages, context menu and safe copy controls",
                new AppleToggle(() -> ChatQolSettings.enabled, v -> {
                    ChatQolSettings.enabled = v;
                    if (!v) ChatChannelTabs.disableAndRestoreAll();
                    AppleSettings.save();
                })));
        rows.add(Row.item("Chat tabs", "Show All, Party, Reply and custom chat tabs.",
                gated(new AppleToggle(() -> ChatQolSettings.tabsEnabled, v -> {
                    ChatQolSettings.tabsEnabled = v;
                    if (!v) ChatChannelTabs.disableAndRestoreAll();
                    AppleSettings.save();
                }), () -> ChatQolSettings.enabled)));
        rows.add(Row.item("Chat editor", "Configure the chat background, tabs, animations, context menu and message layout.",
                new AppleButton("Open editor", 112f, 26f, false, () ->
                        Minecraft.getMinecraft().displayGuiScreen(new ChatEditorScreen(this)))));
        rows.add(Row.item("Chat length (256 characters)", "Allow up to 256 input characters on servers that support longer messages.",
                new AppleToggle(() -> ChatQolSettings.extendedChatLength, v -> {
                    ChatQolSettings.extendedChatLength = v;
                    AppleSettings.chatLengthEnabled = v;
                    AppleSettings.save();
                })));

        rows.add(Row.header("Scrolling"));
        rows.add(Row.item("Custom scroll speed", "Enable adjustable mouse-wheel and swipe speed.",
                new AppleToggle(() -> AppleSettings.scrollSpeedOn, v -> AppleSettings.scrollSpeedOn = v)));
        rows.add(Row.item("Scroll speed", "Adjust wheel and swipe speed; keyboard navigation is unchanged.",
                gated(new AppleSlider(50, 300, 10, "%", 150f,
                        () -> AppleSettings.scrollSpeed,
                        v -> AppleSettings.scrollSpeed = v), () -> AppleSettings.scrollSpeedOn)));

        rows.add(Row.header("Performance"));
        rows.add(Row.item("Curve quality", "Smoothness of rounded corners",
                new AppleDropdown(AppleSettings.CURVE_NAMES, null, 124f, 24f,
                        () -> AppleSettings.curveQuality,
                        v -> AppleSettings.curveQuality = v)));
        rows.add(Row.item("Soft shadows", "Shadows behind panels and menus",
                new AppleToggle(() -> AppleSettings.shadows, v -> AppleSettings.shadows = v)));
        rows.add(Row.item("Animations", "Smooth transitions and motion",
                new AppleToggle(() -> AppleSettings.animations,
                        v -> {
                            AppleSettings.animations = v;
                            Theme.refresh();
                        })));
        rows.add(Row.item("Custom UI animation speed", "Enable adjustable transition speed.",
                new AppleToggle(() -> AppleSettings.animSpeedOn, v -> {
                    AppleSettings.animSpeedOn = v;
                    Theme.refresh();
                })));
        rows.add(Row.item("UI animation speed", "Control how quickly interface transitions play.",
                gated(new AppleSlider(40, 200, 10, "%", 150f,
                        () -> AppleSettings.animSpeed,
                        v -> {
                            AppleSettings.animSpeed = v;
                            Theme.refresh();
                        }), () -> AppleSettings.animSpeedOn)));
        rows.add(Row.item("Adaptive quality", "Reduce visual detail automatically when FPS falls.",
                new AppleToggle(() -> AppleSettings.adaptive, v -> AppleSettings.adaptive = v)));
        rows.add(Row.item("Low-cost UI mode (beta)",
                "Reduce GUI/HUD rendering cost with fewer curve segments and no shadows.",
                new AppleToggle(() -> AppleSettings.experimentalPerformance,
                        v -> AppleSettings.experimentalPerformance = v)));
        rows.add(Row.header("First-person held item"));
        rows.add(Row.item("Open Item Animation editor", "Preview and adjust item scale, position and swing. Command: /sv itemanim.",
                new AppleButton("Open editor", 112f, 26f, false, () ->
                        Minecraft.getMinecraft().displayGuiScreen(new ItemAnimationEditorScreen(this)))));
        rows.add(Row.item("Item Animation", "Customize the held item's first-person position, size and swing.",
                new AppleToggle(() -> AppleSettings.itemAnimationEnabled, v -> AppleSettings.itemAnimationEnabled = v)));
        rows.add(Row.item("Custom item scale", "Enable adjustment of the held item's size.",
                new AppleToggle(() -> AppleSettings.itemAnimationSizeOn,
                        v -> AppleSettings.itemAnimationSizeOn = v)));
        rows.add(Row.item("Item scale", "Set the held non-map item's size (30–200%).",
                gated(new AppleSlider(ItemAnimation.MIN_SIZE_PERCENT, ItemAnimation.MAX_SIZE_PERCENT, 5, "%", 150f,
                        () -> AppleSettings.itemAnimationSize,
                        v -> AppleSettings.itemAnimationSize = ItemAnimation.clampSize(v)),
                        () -> AppleSettings.itemAnimationEnabled && AppleSettings.itemAnimationSizeOn)));
        rows.add(Row.item("Custom held-item animation speed", "Enable custom equip and visual-swing speed.",
                new AppleToggle(() -> AppleSettings.itemAnimationSpeedOn,
                        v -> AppleSettings.itemAnimationSpeedOn = v)));
        rows.add(Row.item("Held-item animation speed", "Set equip and visual-swing speed (25–400%); attacks are unchanged.",
                gated(new AppleSlider(ItemAnimation.MIN_SPEED_PERCENT, ItemAnimation.MAX_SPEED_PERCENT, 5, "%", 150f,
                        () -> AppleSettings.itemAnimationSpeed,
                        v -> AppleSettings.itemAnimationSpeed = ItemAnimation.clampSpeed(v)),
                        () -> AppleSettings.itemAnimationEnabled && AppleSettings.itemAnimationSpeedOn)));
        rows.add(Row.item("Item position X", "Move the held item left or right (-1.50 to +1.50)",
                gated(new AppleSlider(ItemAnimation.MIN_OFFSET, ItemAnimation.MAX_OFFSET, 5, "", 150f,
                        () -> AppleSettings.itemAnimationX,
                        v -> AppleSettings.itemAnimationX = ItemAnimation.clampOffset(v))
                        .valueLabel(v -> String.format(Locale.ROOT, "%+.2f", v / 100.0f)),
                        () -> AppleSettings.itemAnimationEnabled)));
        rows.add(Row.item("Item position Y", "Move the held item down or up (-1.50 to +1.50)",
                gated(new AppleSlider(ItemAnimation.MIN_OFFSET, ItemAnimation.MAX_OFFSET, 5, "", 150f,
                        () -> AppleSettings.itemAnimationY,
                        v -> AppleSettings.itemAnimationY = ItemAnimation.clampOffset(v))
                        .valueLabel(v -> String.format(Locale.ROOT, "%+.2f", v / 100.0f)),
                        () -> AppleSettings.itemAnimationEnabled)));
        rows.add(Row.item("Item position Z", "Move the held item inward or outward (-1.50 to +1.50)",
                gated(new AppleSlider(ItemAnimation.MIN_OFFSET, ItemAnimation.MAX_OFFSET, 5, "", 150f,
                        () -> AppleSettings.itemAnimationZ,
                        v -> AppleSettings.itemAnimationZ = ItemAnimation.clampOffset(v))
                        .valueLabel(v -> String.format(Locale.ROOT, "%+.2f", v / 100.0f)),
                        () -> AppleSettings.itemAnimationEnabled)));
        rows.add(Row.item("Custom swing style", "Choose the shape of the first-person swing effect.",
                gated(new AppleDropdown(AppleSettings.ITEM_ANIMATION_HIT_SLASH_STYLES, null, 124f, 24f,
                        () -> AppleSettings.itemAnimationHitSlashStyle,
                        v -> AppleSettings.itemAnimationHitSlashStyle = ItemAnimation.clampHitSlashStyle(v)),
                        () -> AppleSettings.itemAnimationEnabled)));
        rows.add(Row.item("Smooth swing", "Blend swing progress into a smoother curve.",
                gated(new AppleToggle(() -> AppleSettings.itemAnimationSmoothSwing,
                        v -> AppleSettings.itemAnimationSmoothSwing = v),
                        () -> AppleSettings.itemAnimationEnabled)));
        rows.add(Row.item("Smoothness", "0% is linear; 100% uses the smoothest curve.",
                gated(new AppleSlider(ItemAnimation.MIN_SMOOTHNESS_PERCENT, ItemAnimation.MAX_SMOOTHNESS_PERCENT, 5,
                        "%", 150f, () -> AppleSettings.itemAnimationSmoothness,
                        v -> AppleSettings.itemAnimationSmoothness = ItemAnimation.clampSmoothness(v)),
                        () -> AppleSettings.itemAnimationEnabled && AppleSettings.itemAnimationSmoothSwing)));
        rows.add(Row.item("Ignore Haste for visual swing", "Use custom swing timing; the potion effect remains active.",
                gated(new AppleToggle(() -> AppleSettings.itemAnimationRemoveHasteEffect,
                        v -> AppleSettings.itemAnimationRemoveHasteEffect = v),
                        () -> AppleSettings.itemAnimationEnabled)));
        rows.add(Row.item("Preview swing", "Preview the current animation settings without attacking.",
                new AppleButton("Preview", 96f, 26f, false, ItemAnimation::previewSwing)));
        rows.add(Row.item("Reset item animation", "Restore all item-animation settings to their defaults.",
                new AppleButton("Reset", 96f, 26f, false, () -> {
                    ItemAnimation.resetToDefaults();
                    AppleSettings.save();
                })));

        rows.add(Row.header("Live"));
        rows.add(Row.custom(76f, this::paintGraph));

        rows.add(Row.header("About"));
        rows.add(Row.item("Sky VeLor " + PekaVersion.NAME,
                "Forge client for Minecraft 1.8.9. Settings are saved in skyvelor.properties", null));
        return rows;
    }

    /** Wraps a slider so it only responds while its switch is on. */
    private static AppleSlider gated(AppleSlider s, java.util.function.Supplier<Boolean> on) {
        s.gate(on);
        return s;
    }

    /** Disables a toggle while its parent option is off. */
    private static AppleToggle gated(AppleToggle toggle, java.util.function.Supplier<Boolean> on) {
        toggle.gate(on);
        return toggle;
    }

    /** Disables a dropdown while its parent option is off. */
    private static AppleDropdown gated(AppleDropdown dropdown, java.util.function.Supplier<Boolean> on) {
        dropdown.gate(on);
        return dropdown;
    }

    private List<Row> hudPage() {
        final Minecraft mc = Minecraft.getMinecraft();
        List<Row> rows = new ArrayList<Row>();
        rows.add(Row.section("HUD editor"));
        rows.add(Row.item("Open the HUD editor", "Drag and configure every HUD component on the game screen",
                new AppleButton("Open", 84f, 26f, true, () -> mc.displayGuiScreen(new HudEditorScreen(this)))));
        rows.add(Row.item("Reset positions", "Put all HUD components, including the dungeon map, back in their default places",
                button("Reset", () -> {
                    HudManager.resetPositions();
                    AppleSettings.resetDungeonMapPosition();
                    HudManager.save();
                    AppleSettings.save();
                })));

        for (int i = 0; i < HUD_OVERVIEW.length; i++) {
            final HudElement el = HUD_OVERVIEW[i];
            rows.add(Row.header(HUD_NAMES[i]));
            rows.add(Row.item("Show on screen", HUD_DESCS[i],
                    new AppleToggle(() -> el.enabled, v -> el.enabled = v)));
            for (HudSettingsBuilder.Item it : HudSettingsBuilder.build(el, () -> { }, false)) {
                // Action rows have no label. Use "" so search can always read the label.
                rows.add(Row.item(it.label == null ? "" : it.label, null, it.control));
            }
            if (el == HudManager.DOLL) {
                rows.add(Row.custom(132f, this::paintDollPreview));
            }
        }

        // The dungeon map is a HUD component too. Keep its visibility and scale beside the other
        // HUD controls, while the editor handles exact position and off-screen placement.
        rows.add(Row.header("Dungeon Map"));
        rows.add(Row.item("Show on screen", "Display the dungeon map during a dungeon run",
                new AppleToggle(() -> AppleSettings.dungeonMap, v -> AppleSettings.dungeonMap = v)));
        rows.add(Row.item("Rotate map", "Rotate map contents around your marker while the HUD position stays fixed",
                new AppleToggle(() -> AppleSettings.dungeonMapRotate, v -> AppleSettings.dungeonMapRotate = v)));
        rows.add(Row.item("Player names", "Show resolved player names beside map markers",
                new AppleToggle(() -> AppleSettings.dungeonMapShowPlayerNames,
                        v -> AppleSettings.dungeonMapShowPlayerNames = v)));
        rows.add(Row.item("Puzzle names", "Show detected puzzle-room names on the map",
                new AppleToggle(() -> AppleSettings.dungeonMapShowPuzzleName,
                        v -> AppleSettings.dungeonMapShowPuzzleName = v)));
        rows.add(Row.item("Use scale", "Off uses the native 100% map size",
                new AppleToggle(() -> AppleSettings.dungeonMapScaleOn, v -> {
                    AppleSettings.dungeonMapScaleOn = v;
                    if (!v) AppleSettings.dungeonMapScale = 100;
                })));
        rows.add(Row.item("Scale", "Map size from 70% to 250%, limited by the screen size",
                gated(new AppleSlider(AppleSettings.DUNGEON_MAP_SCALE_MIN,
                        AppleSettings.DUNGEON_MAP_SCALE_MAX, 5, "%", 150f,
                        AppleSettings::effectiveDungeonMapScale,
                        v -> AppleSettings.dungeonMapScale = v),
                        () -> AppleSettings.dungeonMapScaleOn)));
        rows.add(Row.item("Map zoom", "Magnifies map contents independently from HUD size; above 100% crops map edges",
                new AppleSlider(AppleSettings.DUNGEON_MAP_ZOOM_MIN,
                        AppleSettings.DUNGEON_MAP_ZOOM_MAX, 5, "%", 150f,
                        AppleSettings::effectiveDungeonMapZoom,
                        v -> AppleSettings.dungeonMapZoom = v)));
        rows.add(Row.item("Position and layout", "Open the HUD editor to drag the map and place it partly or fully off-screen",
                new AppleButton("Edit map", 96f, 26f, false,
                        () -> mc.displayGuiScreen(new HudEditorScreen(this, true)))));
        return rows;
    }

    /** Expands a HUD group in place and switches to the HUD tab. */
    private void openHud(int index) {
        expanded.add(HUD_NAMES[index]);
        openDropdown = null;
        pendingHeader = null;
        selectPage(PAGE_HUD);
        scroll.reset();
    }

    private List<Row> miningPage() {
        List<Row> rows = new ArrayList<Row>();
        rows.add(Row.section("Mining Rate"));
        rows.add(Row.item("Mining BPS", 
                "Blocks confirmed as broken per second. The counter resets when the world/player session changes",
                new AppleToggle(() -> HudManager.MINING.enabled, v -> HudManager.MINING.enabled = v)));
        rows.add(Row.item("Mining BPS settings", "Label, rolling window and decimals",
                new AppleButton("Open", 84f, 26f, false, () -> openHud(HUD_MINING))));
        rows.add(Row.item("Reset mining session", "Clear the current block total and rate history",
                new AppleButton("Reset", 84f, 26f, false, MiningTracker::reset)));

        rows.add(Row.header("Mining Assistant"));
        rows.add(Row.item("Mining Assistant overlay", "Shows recent blocks/s, session total and the tracked pickaxe ability state. Configure its position in the HUD editor",
                new AppleToggle(() -> HudManager.MINING_ASSISTANT.enabled, v -> HudManager.MINING_ASSISTANT.enabled = v)));
        rows.add(Row.item("Mining Assistant settings", "Edit the overlay's position, scale, opacity and style",
                new AppleButton("Open", 84f, 26f, false, () -> openHud(HUD_MINING_ASSISTANT))));
        rows.add(Row.item("Pickaxe ability ready alert", "Track Pickobulus (60 s) and Mining Speed Boost (120 s) activation messages; cooldown modifiers can change timing.",
                new AppleToggle(() -> AppleSettings.miningAbilityNotifier, v -> AppleSettings.miningAbilityNotifier = v)));

        rows.add(Row.header("Dwarven Mines"));
        rows.add(Row.item("Puzzler direction helper", "Mark the target block from the Puzzler's direction message.",
                new AppleToggle(() -> AppleSettings.miningPuzzlerSolver, v -> AppleSettings.miningPuzzlerSolver = v)));
        // Powder, drill-fuel and commission overlays are omitted until supported data parsing is implemented.
        return rows;
    }

    private List<Row> dungeonPage() {
        final Minecraft mc = Minecraft.getMinecraft();
        List<Row> rows = new ArrayList<Row>();
        rows.add(Row.section("Dungeon Quality of Life"));
        rows.add(Row.item("Auto-close Secret Chest", "Close the 'Secret Chest' window automatically when it opens.",
                new AppleToggle(() -> AppleSettings.dungeonAutoCloseSecretChests, v -> AppleSettings.dungeonAutoCloseSecretChests = v)));
        rows.add(Row.item("Wither Door outlines", "Outline detected Wither Doors in the Sky VeLor accent color.",
                new AppleToggle(() -> AppleSettings.dungeonWitherDoorsHighlight, v -> AppleSettings.dungeonWitherDoorsHighlight = v)));
        rows.add(Row.item("Hide missing-sign warning", "Hide the 'Unable to locate sign' dungeon chat message.",
                new AppleToggle(() -> AppleSettings.dungeonHideUnableToLocateSign, v -> AppleSettings.dungeonHideUnableToLocateSign = v)));
        rows.add(Row.item("Spirit Bow tracer", "Draw a line to the nearest Spirit Bow marker during a dungeon run.",
                new AppleToggle(() -> AppleSettings.dungeonSpiritBowTracer, v -> AppleSettings.dungeonSpiritBowTracer = v)));
        rows.add(Row.item("Blood Ready title", "Show a title when the Watcher announces that the Blood Room is ready.",
                new AppleToggle(() -> AppleSettings.dungeonBloodReadyTitle, v -> AppleSettings.dungeonBloodReadyTitle = v)));
        rows.add(Row.item("S-rank alert (270 score)", "At 270 score, play a sound, show a title and send /pc 270 Score! once per run.",
                new AppleToggle(() -> AppleSettings.dungeonSNotifier, v -> { AppleSettings.dungeonSNotifier = v; AppleSettings.save(); })));
        rows.add(Row.item("S+ alert (300 score)", "At 300 virtual score, play a sound and show a title once per run.",
                new AppleToggle(() -> AppleSettings.dungeonSPlusReminder, v -> { AppleSettings.dungeonSPlusReminder = v; AppleSettings.save(); })));
        rows.add(Row.item("Send S+ party message", "Send a /pc message when the virtual score reaches 300.",
                new AppleToggle(() -> AppleSettings.dungeonSPlusPartyMessage, v -> { AppleSettings.dungeonSPlusPartyMessage = v; AppleSettings.save(); })));
        rows.add(Row.item("S+ party message text", "Edit the message sent at 300 score. Leave blank to use '300 Score!'.",
                new AppleButton("Edit message", 112f, 26f, false,
                        () -> Minecraft.getMinecraft().displayGuiScreen(new DungeonScoreMessageScreen(this)))));
        rows.add(Row.item("Paul score bonus", "Add 10 bonus points when Paul is the active mayor.",
                new AppleToggle(() -> AppleSettings.dungeonPaulBonus, v -> { AppleSettings.dungeonPaulBonus = v; AppleSettings.save(); })));

        rows.add(Row.section("Dungeon HUD"));
        rows.add(Row.item("Compact score overlay", "Show total score, rank and S+ secret target; turn off for the component breakdown.",
                new AppleToggle(() -> AppleSettings.dungeonScoreSimple, v -> { AppleSettings.dungeonScoreSimple = v; AppleSettings.save(); })));
        rows.add(Row.item("Dungeon score overlay", "Show the score panel; adjust its position and appearance in the HUD editor.",
                new AppleToggle(() -> HudManager.DUNGEON_SCORE.enabled, v -> HudManager.DUNGEON_SCORE.enabled = v)));
        rows.add(Row.item("Score overlay settings", "Adjust the score card in the HUD editor.",
                new AppleButton("Open", 84f, 26f, false, () -> openHud(HUD_DUNGEON_SCORE))));
        rows.add(Row.item("Secret overlay", "Show the secrets counter.",
                new AppleToggle(() -> HudManager.DUNGEON_SECRETS.enabled, v -> HudManager.DUNGEON_SECRETS.enabled = v)));
        rows.add(Row.item("Secret overlay settings", "Adjust the secrets counter in the HUD editor.",
                new AppleButton("Open", 84f, 26f, false, () -> openHud(HUD_DUNGEON_SECRETS))));

        rows.add(Row.header("Spirit Leap"));
        rows.add(Row.item("Leap menu",
                "Shows a teammate picker when the server opens Spirit Leap. Clicks match the server menu",
                new AppleToggle(() -> AppleSettings.leapMenu, v -> AppleSettings.leapMenu = v)));
        rows.add(Row.item("Use Spirit Leap key",
                "Unbound by default. Set it in Controls, Sky VeLor. Hold a Spirit Leap item first",
                new AppleToggle(() -> AppleSettings.leapKey, v -> AppleSettings.leapKey = v)));
        rows.add(Row.item("Preview Spirit Leap GUI",
                "Open a local preview of the picker; N/P cycles through the five classes.",
                new AppleButton("Preview", 96f, 26f, false,
                        () -> mc.displayGuiScreen(LeapScreen.createPreview(this)))));

        rows.add(Row.header("Dungeon Sync"));
        rows.add(Row.item("Enable Dungeon Sync",
                "Synchronize detected puzzle names with teammates during the current dungeon run.",
                new AppleToggle(() -> DungeonPuzzleSyncConfig.isEnabled(mc), v -> {
                    if (!DungeonPuzzleSyncConfig.setEnabled(mc, v)) {
                        System.out.println("[Sky VeLor] Could not save Dungeon Sync setting; the previous value was kept.");
                    }
                })));
        rows.add(Row.item("Dungeon Sync debug logs",
                "Show detailed sync and connection logs for troubleshooting. Off by default.",
                new AppleToggle(() -> DungeonPuzzleSyncConfig.isDiagnosticsEnabled(mc), v -> {
                    if (!DungeonPuzzleSyncConfig.setDiagnosticsEnabled(mc, v)) {
                        System.out.println("[Sky VeLor] Could not save Dungeon Sync diagnostics setting; the previous value was kept.");
                    }
                })));
        rows.add(Row.item("Data shared", "Puzzle names, room coordinates and a temporary session hash. Player names are not uploaded.", null));
        rows.add(Row.item("Privacy", "Player names stay local. Cloudflare can still see connection metadata, including your IP address.", null));

        rows.add(Row.header("Combat highlights"));
        rows.add(Row.item("Blood-room miniboss highlight",
                "Outline recognized minibosses in the Blood Room.",
                new AppleToggle(() -> AppleSettings.bloodMobHighlight,
                        v -> AppleSettings.bloodMobHighlight = v)));
        rows.add(Row.item("Blood highlight color", "Color of the miniboss outlines.",
                new AppleDropdown(SOLVER_COLOR_NAMES, SOLVER_COLOR_DOTS, 126f, 24f,
                        () -> solverColorIndex(AppleSettings.bloodMobHighlightColor),
                        v -> AppleSettings.bloodMobHighlightColor = SOLVER_COLOR_VALUES[
                                Math.max(0, Math.min(SOLVER_COLOR_VALUES.length - 1, v))])));
        rows.add(Row.item("Level-tag mob highlights",
                "Optional boxes for regular dungeon mobs detected by a [LvNN] tag",
                new AppleToggle(() -> AppleSettings.mobHighlights, v -> AppleSettings.mobHighlights = v)));
        rows.add(Row.item("Starred mobs display", "Choose boxes, a model silhouette outline, or disable the highlight.",
                new AppleDropdown(new String[]{"Box", "Outline", "Disabled"}, null, 126f, 24f,
                        () -> StarredMobPolicy.clampDisplayMode(AppleSettings.starredMobDisplayMode),
                        AppleSettings::setStarredMobDisplayMode)));
        rows.add(Row.item("Starred mobs ESP", "Show Box highlights through walls and allow outlines without line of sight.",
                new AppleToggle(() -> AppleSettings.starredMobEsp,
                        v -> { AppleSettings.starredMobEsp = v; AppleSettings.save(); })));
        rows.add(Row.item("Starred mob color", "Default Box-mode color for starred mobs without a special override.",
                new AppleDropdown(STARRED_COLOR_NAMES, starredColorDots(AppleSettings.DEFAULT_STARRED_MOB_COLOR), 126f, 24f,
                        () -> starredColorIndex(AppleSettings.starredMobColor, AppleSettings.DEFAULT_STARRED_MOB_COLOR),
                        v -> { AppleSettings.starredMobColor = starredColorValue(v, AppleSettings.starredMobColor, AppleSettings.DEFAULT_STARRED_MOB_COLOR); AppleSettings.save(); })));
        rows.add(Row.item("Starred mob chroma", "Set hue-cycle speed for the default starred-mob color; zero is static.",
                starredColorChromaSlider(() -> AppleSettings.starredMobColor, v -> AppleSettings.starredMobColor = v)));
        rows.add(Row.item("Stormy color", "Box-mode color override for starred Stormy.",
                new AppleDropdown(STARRED_COLOR_NAMES, starredColorDots(AppleSettings.DEFAULT_STARRED_MOB_STORMY_COLOR), 126f, 24f,
                        () -> starredColorIndex(AppleSettings.starredMobStormyColor, AppleSettings.DEFAULT_STARRED_MOB_STORMY_COLOR),
                        v -> { AppleSettings.starredMobStormyColor = starredColorValue(v, AppleSettings.starredMobStormyColor, AppleSettings.DEFAULT_STARRED_MOB_STORMY_COLOR); AppleSettings.save(); })));
        rows.add(Row.item("Stormy chroma", "Set hue-cycle speed for Stormy's Box color; zero is static.",
                starredColorChromaSlider(() -> AppleSettings.starredMobStormyColor, v -> AppleSettings.starredMobStormyColor = v)));
        rows.add(Row.item("Withermancer color", "Box-mode color override for starred Withermancer.",
                new AppleDropdown(STARRED_COLOR_NAMES, starredColorDots(AppleSettings.DEFAULT_STARRED_MOB_WITHERMANCER_COLOR), 126f, 24f,
                        () -> starredColorIndex(AppleSettings.starredMobWithermancerColor, AppleSettings.DEFAULT_STARRED_MOB_WITHERMANCER_COLOR),
                        v -> { AppleSettings.starredMobWithermancerColor = starredColorValue(v, AppleSettings.starredMobWithermancerColor, AppleSettings.DEFAULT_STARRED_MOB_WITHERMANCER_COLOR); AppleSettings.save(); })));
        rows.add(Row.item("Withermancer chroma", "Set hue-cycle speed for Withermancer's Box color; zero is static.",
                starredColorChromaSlider(() -> AppleSettings.starredMobWithermancerColor, v -> AppleSettings.starredMobWithermancerColor = v)));
        rows.add(Row.item("Zombie Commander color", "Box-mode color override for starred Zombie Commander.",
                new AppleDropdown(STARRED_COLOR_NAMES, starredColorDots(AppleSettings.DEFAULT_STARRED_MOB_ZOMBIE_COMMANDER_COLOR), 126f, 24f,
                        () -> starredColorIndex(AppleSettings.starredMobZombieCommanderColor, AppleSettings.DEFAULT_STARRED_MOB_ZOMBIE_COMMANDER_COLOR),
                        v -> { AppleSettings.starredMobZombieCommanderColor = starredColorValue(v, AppleSettings.starredMobZombieCommanderColor, AppleSettings.DEFAULT_STARRED_MOB_ZOMBIE_COMMANDER_COLOR); AppleSettings.save(); })));
        rows.add(Row.item("Zombie Commander chroma", "Set hue-cycle speed for Zombie Commander's Box color; zero is static.",
                starredColorChromaSlider(() -> AppleSettings.starredMobZombieCommanderColor, v -> AppleSettings.starredMobZombieCommanderColor = v)));
        rows.add(Row.item("Skeleton Master color", "Box-mode color override for starred Skeleton Master.",
                new AppleDropdown(STARRED_COLOR_NAMES, starredColorDots(AppleSettings.DEFAULT_STARRED_MOB_SKELETON_MASTER_COLOR), 126f, 24f,
                        () -> starredColorIndex(AppleSettings.starredMobSkeletonMasterColor, AppleSettings.DEFAULT_STARRED_MOB_SKELETON_MASTER_COLOR),
                        v -> { AppleSettings.starredMobSkeletonMasterColor = starredColorValue(v, AppleSettings.starredMobSkeletonMasterColor, AppleSettings.DEFAULT_STARRED_MOB_SKELETON_MASTER_COLOR); AppleSettings.save(); })));
        rows.add(Row.item("Skeleton Master chroma", "Set hue-cycle speed for Skeleton Master's Box color; zero is static.",
                starredColorChromaSlider(() -> AppleSettings.starredMobSkeletonMasterColor, v -> AppleSettings.starredMobSkeletonMasterColor = v)));

        rows.add(Row.item("Fel ESP", "Outline Fel armor stands carrying the Enderman head. Dungeon-only.",
                new AppleToggle(() -> AppleSettings.felEsp,
                        v -> { AppleSettings.felEsp = v; AppleSettings.save(); })));
        rows.add(Row.item("Fel ESP color", "Color of the Fel hitbox outline.",
                new AppleDropdown(SOLVER_COLOR_NAMES, SOLVER_COLOR_DOTS, 126f, 24f,
                        () -> solverColorIndex(AppleSettings.felEspColor),
                        v -> { AppleSettings.felEspColor = SOLVER_COLOR_VALUES[Math.max(0, Math.min(SOLVER_COLOR_VALUES.length - 1, v))]; AppleSettings.save(); })));

        rows.add(Row.header("Puzzle solvers"));
        rows.add(Row.item("Three Weirdos", "Highlight the correct NPC response for the room's riddle.",
                new AppleToggle(() -> AppleSettings.solverThreeWeirdos, v -> AppleSettings.solverThreeWeirdos = v)));
        rows.add(Row.item("Creeper Beams", "Highlight the path through the Creeper puzzle.",
                new AppleToggle(() -> AppleSettings.solverCreeper, v -> AppleSettings.solverCreeper = v)));
        rows.add(Row.item("Boulder", "Highlight the next boulder or pad interaction.",
                new AppleToggle(() -> AppleSettings.solverBoulder, v -> AppleSettings.solverBoulder = v)));
        rows.add(Row.item("Silverfish", "Highlight the relevant silverfish and hopper targets.",
                new AppleToggle(() -> AppleSettings.solverSilverfish, v -> AppleSettings.solverSilverfish = v)));
        rows.add(Row.item("Water Board", "Highlight the correct levers and water route.",
                new AppleToggle(() -> AppleSettings.solverWater, v -> AppleSettings.solverWater = v)));
        rows.add(Row.item("Teleport Maze", "Track the correct route through the maze.",
                new AppleToggle(() -> AppleSettings.solverTeleportMaze, v -> AppleSettings.solverTeleportMaze = v)));

        rows.add(Row.header("Terminal GUI and solvers"));
        rows.add(Row.item("Terminal GUI scale", "Scale for the custom terminal grids (1.0x to 5.0x)",
                new AppleSlider(10, 50, 1, "x", 126f,
                        () -> Math.round(AppleSettings.terminalGuiScale * 10f),
                        v -> AppleSettings.terminalGuiScale = v / 10f)));
        rows.add(Row.item("Starts With solver", "Custom GUI and correct-slot highlighting for the Starts With terminal",
                new AppleToggle(() -> AppleSettings.terminalStartsWithSolver, v -> AppleSettings.terminalStartsWithSolver = v)));
        rows.add(Row.item("Custom Starts With GUI", "Replaces the vanilla terminal grid with the custom scaled layout",
                new AppleToggle(() -> AppleSettings.terminalCustomStartsWith, v -> AppleSettings.terminalCustomStartsWith = v)));
        rows.add(Row.item("Click in Order solver", "Tracks the next number and highlights the next safe terminal click",
                new AppleToggle(() -> AppleSettings.terminalClickInOrderSolver, v -> AppleSettings.terminalClickInOrderSolver = v)));
        rows.add(Row.item("Custom Click in Order GUI", "Uses the custom numbered terminal grid and queue",
                new AppleToggle(() -> AppleSettings.terminalCustomClickIn, v -> AppleSettings.terminalCustomClickIn = v)));
        rows.add(Row.item("Select All Colors solver", "Highlight the requested color in Select All the ... terminals.",
                new AppleToggle(() -> AppleSettings.terminalColorsSolver, v -> AppleSettings.terminalColorsSolver = v)));
        rows.add(Row.item("Custom Select Colors GUI", "Uses the custom scaled colored terminal grid",
                new AppleToggle(() -> AppleSettings.terminalCustomColors, v -> AppleSettings.terminalCustomColors = v)));
        rows.add(Row.item("Terminal Maze solver", "Solves and highlights the route in the maze terminal",
                new AppleToggle(() -> AppleSettings.terminalMazeSolver, v -> AppleSettings.terminalMazeSolver = v)));
        rows.add(Row.item("Custom Terminal Maze GUI", "Uses the custom maze rendering and path overlay",
                new AppleToggle(() -> AppleSettings.terminalCustomMaze, v -> AppleSettings.terminalCustomMaze = v)));
        rows.add(Row.item("Correct Panes solver", "Highlights the panes that need to be clicked",
                new AppleToggle(() -> AppleSettings.terminalCorrectPanesSolver, v -> AppleSettings.terminalCorrectPanesSolver = v)));
        rows.add(Row.item("Custom Correct Panes GUI", "Replaces the vanilla pane grid with the custom layout",
                new AppleToggle(() -> AppleSettings.terminalCustomPanes, v -> AppleSettings.terminalCustomPanes = v)));
        rows.add(Row.item("Hide incorrect choices", "Hides irrelevant numbered/color slots while solving supported terminals",
                new AppleToggle(() -> AppleSettings.terminalHideIncorrect, v -> AppleSettings.terminalHideIncorrect = v)));
        rows.add(Row.item("Prevent terminal misclicks", "Block clicks on invalid choices in supported terminals.",
                new AppleToggle(() -> AppleSettings.terminalPreventMissclicks, v -> AppleSettings.terminalPreventMissclicks = v)));
        rows.add(Row.item("Hide terminal item tooltips", "Hide item tooltips while a terminal is open.",
                new AppleToggle(() -> AppleSettings.terminalHideTooltips, v -> AppleSettings.terminalHideTooltips = v)));
        rows.add(Row.item("Correct solver color", "Highlight color for the next correct choice.",
                new AppleDropdown(SOLVER_COLOR_NAMES, SOLVER_COLOR_DOTS, 126f, 24f,
                        () -> solverColorIndex(AppleSettings.solverCorrectColor),
                        v -> AppleSettings.solverCorrectColor = SOLVER_COLOR_VALUES[Math.max(0, Math.min(SOLVER_COLOR_VALUES.length - 1, v))])));
        rows.add(Row.item("Secondary solver color", "Highlight color for the next alternative choice.",
                new AppleDropdown(SOLVER_COLOR_NAMES, SOLVER_COLOR_DOTS, 126f, 24f,
                        () -> solverColorIndex(AppleSettings.solverAlternativeColor),
                        v -> AppleSettings.solverAlternativeColor = SOLVER_COLOR_VALUES[Math.max(0, Math.min(SOLVER_COLOR_VALUES.length - 1, v))])));

        rows.add(Row.header("Devices and waypoints"));
        rows.add(Row.item("First Device solver", "Track the sea-lantern sequence and block out-of-order clicks.",
                new AppleToggle(() -> AppleSettings.solverFirstDevice, v -> AppleSettings.solverFirstDevice = v)));
        rows.add(Row.item("Third Device solver", "Track arrow rotations and block duplicate or completed clicks.",
                new AppleToggle(() -> AppleSettings.solverThirdDevice, v -> AppleSettings.solverThirdDevice = v)));
        rows.add(Row.item("Inactive device and terminal waypoints", "Mark inactive terminals and devices on Floor VII.",
                new AppleToggle(() -> AppleSettings.terminalWaypoints, v -> AppleSettings.terminalWaypoints = v)));

        rows.add(Row.header("Terminal tracker"));
        rows.add(Row.item("Goldor terminal tracker", "Track terminals, devices and levers by phase; summarize team progress at Core.",
                new AppleToggle(() -> AppleSettings.terminalTracker, v -> AppleSettings.terminalTracker = v)));
        rows.add(Row.item("Tracker scale", "Set the tracker size (0.5x–3.0x).",
                new AppleSlider(5, 30, 1, "x", 126f,
                        () -> Math.round(AppleSettings.terminalTrackerScale * 10f),
                        v -> AppleSettings.terminalTrackerScale = v / 10f)));
        rows.add(Row.item("Tracker color", "Set the Goldor tracker text color.",
                new AppleDropdown(SOLVER_COLOR_NAMES, SOLVER_COLOR_DOTS, 126f, 24f,
                        () -> solverColorIndex(AppleSettings.terminalTrackerColor),
                        v -> AppleSettings.terminalTrackerColor = SOLVER_COLOR_VALUES[Math.max(0, Math.min(SOLVER_COLOR_VALUES.length - 1, v))])));
        rows.add(Row.item("Move tracker", "Close this window, then drag the tracker; right-click or press Esc to save",
                new AppleButton("Edit", 78f, 24f, false, () -> {
                    AppleSettings.terminalTracker = true;
                    TerminalTracker.beginPositionEdit();
                    mc.displayGuiScreen(null);
                })));
        rows.add(Row.item("Terminal Simulator", "Practice Starts With, Click in Order, Correct Panes and Colors locally.",
                new AppleButton("Open", 78f, 24f, false, () -> mc.displayGuiScreen(new TerminalSimulator()))));

        rows.add(Row.header("Floor VII / Master VII boss health"));
        rows.add(Row.item("Boss HP HUD", "Show HP for Maxor, Storm, Goldor, Necron and the five M7 dragons.",
                new AppleToggle(() -> HudManager.DUNGEON_BOSS_HP.enabled,
                        v -> HudManager.DUNGEON_BOSS_HP.enabled = v)));
        rows.add(Row.item("Boss HP HUD settings", "Adjust position, scale, border and panel style.",
                new AppleButton("Open", 84f, 26f, false, () -> openHud(HUD_DUNGEON_BOSS_HP))));

        rows.add(Row.header("Floor VII (M7) overlay"));
        rows.add(Row.item("M7 overlay",
                "Show boss-room, dragon-spawn and relic areas during M7.",
                new AppleToggle(M7Settings::isOverlayEnabled, M7Settings::setOverlayEnabled)));
        rows.add(Row.item("Relic kill areas",
                "Shows the five relic areas around the dragon statues",
                new AppleToggle(M7Settings::isStatueZonesEnabled, M7Settings::setStatueZonesEnabled)));
        rows.add(Row.item("Keep relic areas after spawn",
                "Leave relic markers visible after the dragons appear.",
                new AppleToggle(M7Settings::isAreasPersistAfterDragonSpawn,
                        M7Settings::setAreasPersistAfterDragonSpawn)));
        rows.add(Row.item("Dragon at statue alert",
                "Show a title when a dragon reaches its statue.",
                new AppleToggle(M7Settings::isDragonKillAlertEnabled, M7Settings::setDragonKillAlertEnabled)));

        rows.add(Row.header("Boss hitboxes"));
        for (final M7OverlayRenderer.M7HitboxTarget t : new M7OverlayRenderer.M7HitboxTarget[] {
                M7OverlayRenderer.M7HitboxTarget.MAXOR, M7OverlayRenderer.M7HitboxTarget.STORM,
                M7OverlayRenderer.M7HitboxTarget.GOLDOR, M7OverlayRenderer.M7HitboxTarget.NECRON}) {
            rows.add(Row.item(bossName(t), "Draw the boss hitbox outline.",
                    new AppleToggle(() -> M7Settings.isBossHitboxEnabled(t),
                            v -> M7Settings.setBossHitboxEnabled(t, v))));
        }

        rows.add(Row.header("Dragon hitboxes"));
        for (final M7OverlayRenderer.M7DragonStatue d : M7OverlayRenderer.M7DragonStatue.values()) {
            rows.add(Row.item(d.dragonName, "Draw its hitbox while it is alive.",
                    new AppleToggle(() -> M7Settings.isDragonHitboxEnabled(d),
                            v -> M7Settings.setDragonHitboxEnabled(d, v))));
        }
        return rows;
    }

    private List<Row> fishingPage() {
        List<Row> rows = new ArrayList<Row>();
        rows.add(Row.section("Catch counter"));
        rows.add(Row.item("Track sea-creature catches",
                "Track legendary catches and the combined Common Creature count.",
                new AppleToggle(() -> AppleSettings.fishingCounter, v -> AppleSettings.fishingCounter = v)));
        rows.add(Row.item("Festival best",
                "Show Great White Sharks caught this Festival and your best total.",
                new AppleToggle(() -> AppleSettings.fishingFestival, v -> AppleSettings.fishingFestival = v)));
        rows.add(Row.item("Reset counters", "Clears every catch count and the Festival best",
                button("Reset", () -> {
                    FishingStats.reset();
                })));

        rows.add(Row.header("Sea creature alerts"));
        rows.add(Row.item("Arrival alert",
                "Show one title when Lord Jawbus or Yeti is detected nearby.",
                new AppleToggle(() -> AppleSettings.fishingJawbusAlert,
                        v -> AppleSettings.fishingJawbusAlert = v)));

        rows.add(Row.header("On screen"));
        rows.add(Row.item("Fishing counter",
                "Display catch counts in the HUD",
                new AppleToggle(() -> HudManager.FISHING.enabled, v -> HudManager.FISHING.enabled = v)));
        rows.add(Row.item("Sea Creature HP",
                "Show nearby sea-creature levels and health.",
                new AppleToggle(() -> HudManager.SEA_HP.enabled, v -> HudManager.SEA_HP.enabled = v)));
        return rows;
    }

    private static String bossName(M7OverlayRenderer.M7HitboxTarget t) {
        String lower = t.name().toLowerCase(java.util.Locale.ROOT);
        return Character.toUpperCase(lower.charAt(0)) + lower.substring(1);
    }

    private List<Row> slayerPage() {
        List<Row> rows = new ArrayList<Row>();
        rows.add(Row.section("Tracker"));
        rows.add(Row.item("Track Slayer drops",
                "Record rare drops for each Slayer until history is cleared.",
                new AppleToggle(() -> AppleSettings.slayerTracker, v -> AppleSettings.slayerTracker = v)));
        rows.add(Row.item("Slayer tracker on screen",
                "Display recorded drops, profit and the timer in the HUD",
                new AppleToggle(() -> HudManager.SLAYER.enabled, v -> HudManager.SLAYER.enabled = v)));
        rows.add(Row.item("Slayer HUD border",
                "Show a border around the Slayer tracker",
                new AppleToggle(() -> HudManager.SLAYER.border, v -> HudManager.SLAYER.border = v)));

        rows.add(Row.header("Boss timer"));
        rows.add(Row.item("Boss timer",
                "Time each Slayer fight from boss spawn to quest completion.",
                new AppleToggle(() -> AppleSettings.slayerBossTimer, v -> AppleSettings.slayerBossTimer = v)));

        rows.add(Row.header("Prices"));
        rows.add(Row.item("Use custom drop prices",
                "Calculate profit using your saved prices; enables /setprice.",
                new AppleToggle(() -> AppleSettings.slayerPricing, v -> AppleSettings.slayerPricing = v)));
        rows.add(Row.item("Set a price",
                "/setprice <price> for the held item, or /setprice <item name> <price>", null));

        rows.add(Row.header("Clear history"));
        for (final SlayerType type : SlayerType.values()) {
            String name = SlayerTracker.displayName(type);
            rows.add(Row.item(name, "Clears the drops and profit for " + name,
                    button("Clear", () -> SlayerTracker.clearHistory(type))));
        }
        return rows;
    }

    /** Painter for the doll preview. Records the rectangle so a drag on it turns the doll. */
    private void paintDollPreview(float x, float y, float w, float h) {
        FontRenderer fr = fr();
        dollVisible = true;
        dollX = x;
        dollY = y;
        dollW = w;
        dollH = h;
        UIRender.roundRectBorder(x, y, w, h, cardRadius(), Theme.card, Theme.card, Theme.border);
        UIRender.text(fr, "Drag to turn", x + 12f, y + 10f, Theme.textTertiary, 0.8f, false);
        PlayerDollHud.drawDoll(x + w * 0.5f, y + h - 14f, 40f, HudManager.DOLL.effectiveAngle());
        if (Minecraft.getMinecraft().thePlayer == null) {
            String none = "Join a world to see your doll";
            UIRender.text(fr, none, x + (w - fr.getStringWidth(none)) * 0.5f, y + h * 0.5f,
                    Theme.textSecondary, 1f, false);
        }
    }

    /** Empty state for a category with no modules. Honest: no fake settings. */
    private List<Row> emptyPage(String name, final int icon) {
        List<Row> rows = new ArrayList<Row>();
        rows.add(Row.section("Modules"));
        rows.add(Row.custom(64f, (x, y, w, h) -> paintEmpty(x, y, w, h, icon)));
        return rows;
    }

    private List<Row> currentRows() {
        return searching ? searchRows : pages.get(pageIndex);
    }

    private void selectPage(int index) {
        if (index == pageIndex && !searching) {
            return;
        }
        pageIndex = index;
        if (index == PAGE_HUD) {
            pages.set(PAGE_HUD, hudPage());
        } else if (index == PAGE_MINING) {
            pages.set(PAGE_MINING, miningPage());
        } else if (index == PAGE_DUNGEON) {
            pages.set(PAGE_DUNGEON, dungeonPage());
        } else if (index == PAGE_FISHING) {
            pages.set(PAGE_FISHING, fishingPage());
        }
        scroll.reset();
        gestureActive = false;
        active = null;
        openDropdown = null;
        search.clear();
        search.setFocused(false);
        fadeAnim.snap(0f);
        fadeAnim.to(1f);
    }

    // ------------------------------------------------------------------ frame loop

    @Override
    public void initGui() {
        super.initGui();
        Keyboard.enableRepeatEvents(true);
        HudManager.ensureLoaded();
    }

    @Override
    public void onGuiClosed() {
        super.onGuiClosed();
        Keyboard.enableRepeatEvents(false);
        AppleSettings.save();
        HudManager.save();
    }

    @Override
    public void drawScreen(int mx, int my, float partialTicks) {
        Minecraft mc = Minecraft.getMinecraft();
        long now = System.nanoTime();
        float dt = lastNs == 0L ? 1f / 60f : Math.min(0.1f, (now - lastNs) / 1.0e9f);
        lastNs = now;

        refreshScale(mc);
        trackFrame(dt);
        syncSearch();
        updateStats(dt);
        updateAnims(dt);
        computeLayout();

        // Experimental performance mode lowers only GUI work: fewer curve segments and no shadows.
        boolean perf = AppleSettings.experimentalPerformance;
        int q = (autoLow || perf) ? 2 : AppleSettings.curveQuality;
        UIRender.segCap = AppleSettings.CURVE_SEGMENTS[q];
        UIRender.shadows = AppleSettings.shadows && !autoLow && !perf;

        drawDefaultBackground();

        UIRender.beginFrame();
        float open = openAnim.get();
        float fade = fadeAnim.get();
        dollVisible = false;

        // Both themes: the vanilla backdrop shows through a translucent veil (dark or milky white).
        UIRender.alphaMul = open;
        UIRender.rect(0f, 0f, width, height, Theme.veil);
        UIRender.pushScaleAt(wx + ww * 0.5f, wy + wh * 0.5f,
                Theme.animations ? 0.965f + open * 0.035f : 1f);
        drawWindowChrome(mx, my);

        if (!collapsed) {
            UIRender.alphaMul = open * fade;
            drawHeader();
            search.draw(mx, my);
            boolean inView = inside(mx, my, vx, vy, vw, vh);
            drawContent(inView ? mx : -10000, inView ? my : -10000);
        }

        UIRender.alphaMul = open;
        if (openDropdown != null && !collapsed) {
            openDropdown.drawPopup(mx, my, wy, wy + wh, wx + ww, wx);
        }
        UIRender.popTransform();
        UIRender.alphaMul = 1f;
        UIRender.endFrame();
    }

    private void refreshScale(Minecraft mc) {
        int key = mc.displayWidth * 31 + mc.displayHeight * 7 + mc.gameSettings.guiScale;
        if (key != scaleKey) {
            scaleKey = key;
            sf = new ScaledResolution(mc).getScaleFactor();
        }
    }

    /** Tracks frame times and drops detail when the client is struggling (adaptive quality). */
    private void trackFrame(float dt) {
        frameHistory[histIdx] = dt * 1000f;
        histIdx = (histIdx + 1) % frameHistory.length;
        dtEma += (dt - dtEma) * 0.1f;

        if (!AppleSettings.adaptive) {
            autoLow = false;
            slowFrames = 0;
            fastFrames = 0;
            return;
        }
        if (dt > 0.05f) {
            slowFrames++;
            fastFrames = 0;
            if (slowFrames > 30) {
                autoLow = true;
            }
        } else if (dt < 0.03f) {
            fastFrames++;
            slowFrames = 0;
            if (fastFrames > 180) {
                autoLow = false;
            }
        }
    }

    private void syncSearch() {
        if (search.version() == searchVersion) {
            return;
        }
        searchVersion = search.version();
        query = search.text().toLowerCase(Locale.ROOT).trim();
        searchRows.clear();
        if (!query.isEmpty()) {
            for (List<Row> page : pages) {
                for (Row r : page) {
                    if (r.kind != Row.ITEM) {
                        continue;
                    }
                    if (r.label.toLowerCase(Locale.ROOT).contains(query)
                            || (r.desc != null && r.desc.toLowerCase(Locale.ROOT).contains(query))) {
                        searchRows.add(r);
                    }
                }
            }
        }
        searching = !query.isEmpty();
        scroll.reset();
        openDropdown = null;
    }

    private void updateStats(float dt) {
        statTimer -= dt;
        if (statTimer > 0f) {
            return;
        }
        // The experimental performance mode refreshes these stats half as often.
        statTimer = AppleSettings.experimentalPerformance ? 1.0f : 0.5f;
        Runtime rt = Runtime.getRuntime();
        statValues[S_FPS] = Minecraft.getDebugFPS() + " fps";
        statValues[S_MEM] = ((rt.totalMemory() - rt.freeMemory()) >> 20) + " MB";
        statValues[S_FRAME] = String.format(Locale.ROOT, "%.1f ms", dtEma * 1000f);
        statValues[S_MINE] = String.format(Locale.ROOT, "%.2f BPS", MiningTracker.rate());
    }

    private void updateAnims(float dt) {
        openAnim.update(dt, 10f);
        fadeAnim.update(dt, 14f);
        indicator.update(dt, 10f);
        search.update(dt);
        for (int i = 0; i < navSel.length; i++) {
            navSel[i].to(!searching && i == pageIndex ? 1f : 0f);
            navSel[i].update(dt, 14f);
            navHover[i].update(dt, 16f);
        }

        scroll.update(dt, gestureActive && gesture.kind == Gesture.SCROLL, Theme.animations, Theme.speed);
        boolean moving = gestureActive || scroll.moving();
        indicator.to(moving ? 1f : 0f);

        List<Row> rows = currentRows();
        for (int i = 0, n = rows.size(); i < n; i++) {
            Widget c = rows.get(i).control;
            if (c != null) {
                c.update(dt);
            }
        }
    }

    // ------------------------------------------------------------------ layout

    private void computeLayout() {
        if (zoomed) {
            ww = Math.max(160f, width - 8f);
            wh = Math.max(120f, height - 8f);
        } else {
            ww = Math.max(160f, Math.min(width - 16f, 620f));
            wh = Math.max(120f, Math.min(height - 16f, 400f));
        }
        if (collapsed) {
            // Collapsed: only the title bar remains. The body is hidden and cannot be used.
            wh = TITLE_H + 1f;
        }
        wide = ww >= 460f;
        tall = wh >= 230f;
        wx = (width - ww) * 0.5f;
        wy = (height - wh) * 0.5f + (1f - openAnim.get()) * 12f;
        if (zoomed) {
            wx = 4f;
            wy = 4f;
        }

        float side = wide ? SIDEBAR_W : 0f;
        float inset = wide ? 16f : PAD;
        cx0 = wx + side + inset;
        cw = ww - side - inset - PAD;
        headY = wy + TITLE_H + (wide ? 12f : 40f);

        if (tall) {
            search.x = cx0;
            search.y = headY + 36f;
            search.w = cw;
            search.h = 22f;
        } else {
            float sw = Math.min(170f, cw * 0.5f);
            search.x = cx0 + cw - sw;
            search.y = headY - 3f;
            search.w = sw;
            search.h = 20f;
        }

        vx = cx0;
        vw = cw;
        vy = tall ? headY + 68f : headY + 26f;
        vh = Math.max(20f, wy + wh - 12f - vy);

        if (!searching) {
            applyGroups(pages.get(pageIndex));
        }
        List<Row> rows = currentRows();
        scroll.setMax(Math.max(0f, contentHeight(rows) + 4f - vh));
        layoutRows(rows, vy - scroll.value());
    }

    /** Total height of a row list, without the top gap. Does not move the rows. */
    private float contentHeight(List<Row> rows) {
        float total = 0f;
        boolean first = true;
        for (int i = 0, n = rows.size(); i < n; i++) {
            Row r = rows.get(i);
            if (!shown(r)) {
                continue;
            }
            total += r.height + (first ? 0f : ROW_GAP);
            first = false;
        }
        return Math.max(0f, total);
    }

    /** Whether a row is drawn and hit-tested. Search shows every match, even inside a collapsed group. */
    private boolean shown(Row r) {
        return searching || r.visible;
    }

    /** Sets each row's visibility from its group and counts the rows under each header. */
    private void applyGroups(List<Row> rows) {
        Row header = null;
        for (int i = 0, n = rows.size(); i < n; i++) {
            Row r = rows.get(i);
            if (r.kind == Row.HEADER) {
                header = r;
                r.visible = true;
                r.children = 0;
            } else if (r.kind == Row.SECTION) {
                header = null;
                r.visible = true;
            } else {
                r.visible = header == null || expanded.contains(header.label);
                if (header != null) {
                    header.children++;
                }
            }
        }
    }

    /** Toggles a group. Closing it also closes any dropdown that lives inside it. */
    private void toggleGroup(String title) {
        boolean opening;
        if (!expanded.remove(title)) {
            expanded.add(title);
            opening = true;
        } else {
            opening = false;
        }
        if (opening) {
            List<Row> rows = currentRows();
            boolean insideGroup = false;
            for (Row row : rows) {
                if (row.kind == Row.HEADER) {
                    if (insideGroup) break;
                    insideGroup = row.label.equals(title);
                    continue;
                }
                if (insideGroup && row.kind != Row.SECTION) rowReveal.put(row, 0f);
            }
        }
        openDropdown = null;
    }

    private void layoutRows(List<Row> rows, float top) {
        float y = top;
        for (int i = 0, n = rows.size(); i < n; i++) {
            Row r = rows.get(i);
            if (!shown(r)) {
                continue;
            }
            r.y = y;
            Widget c = r.control;
            if (c != null) {
                c.x = cx0 + cw - 12f - c.w;
                c.y = y + (r.height - c.h) * 0.5f;
            }
            y += r.height + ROW_GAP;
        }
    }

    // ------------------------------------------------------------------ drawing

    private void drawWindowChrome(int mx, int my) {
        UIRender.shadow(wx, wy, ww, wh, Theme.radius);
        UIRender.roundRectBorder(wx, wy, ww, wh, Theme.radius, Theme.windowTop, Theme.windowBottom, Theme.border);
        if (!AppleSettings.darkMode) {
            // Light mode frosting: a soft sheen over the top of the milky panel. No real blur is used.
            float sheenH = Math.min(wh * 0.35f, 90f);
            UIRender.roundRect(wx + 1f, wy + 1f, ww - 2f, sheenH, Math.max(0f, Theme.radius - 1f),
                    0x59FFFFFF, 0x00FFFFFF, 1f);
        }
        UIRender.rect(wx + 1f, wy + TITLE_H, ww - 2f, 1f, Theme.divider);

        // Neutral title-bar controls: close, collapse, and zoom. All three are live in the hub.
        WindowControls.draw(wx + 16f, wy + 17f, mx, my, 0b111, zoomed);

        FontRenderer fr = fr();
        String title = searching ? "Search" : PekaVersion.DISPLAY_NAME;
        UIRender.text(fr, title, wx + (ww - fr.getStringWidth(title)) * 0.5f, wy + 12.5f,
                Theme.textSecondary, 1f, false);

        // The version is small and sits in the title bar, out of the way of the content.
        String ver = PekaVersion.NAME;
        float verW = fr.getStringWidth(ver) * 0.8f;
        UIRender.text(fr, ver, wx + ww - 12f - verW, wy + 13.5f, Theme.textTertiary, 0.8f, false);

        if (collapsed) {
            return;
        }
        if (wide) {
            UIRender.rect(wx + SIDEBAR_W, wy + TITLE_H + 1f, 1f, wh - TITLE_H - 2f, Theme.divider);
            drawSidebar(mx, my);
        } else {
            drawTabs(mx, my);
        }
    }

    private void drawSidebar(int mx, int my) {
        FontRenderer fr = fr();
        for (int i = 0; i < PAGE_NAMES.length; i++) {
            float x = wx + 8f;
            float w = SIDEBAR_W - 16f;
            float y = wy + TITLE_H + 10f + i * NAV_STEP;
            boolean hov = inside(mx, my, x, y, w, NAV_H);
            navHover[i].to(hov ? 1f : 0f);
            float sel = navSel[i].get();
            float hv = navHover[i].get();
            UIRender.pushScaleAt(x + w * 0.5f, y + NAV_H * 0.5f,
                    Theme.animations ? 1f + hv * 0.018f : 1f);

            if (hv > 0.01f) {
                UIRender.roundRect(x, y, w, NAV_H, 8f, UIRender.withAlpha(Theme.cardHover, hv), UIRender.withAlpha(Theme.cardHover, hv), 1f);
            }
            if (sel > 0.01f) {
                int pill = UIRender.withAlpha(Theme.accent, 0.20f * sel);
                UIRender.roundRect(x, y, w, NAV_H, 8f, pill, pill, 1f);
            }
            int iconCol = UIRender.mix(Theme.textSecondary, Theme.accent, sel);
            Icons.draw(PAGE_ICONS[i], x + 13f, y + NAV_H * 0.5f, 12f, iconCol);
            UIRender.text(fr, PAGE_NAMES[i], x + 28f, y + (NAV_H - 9f) * 0.5f + 1f,
                    UIRender.mix(Theme.textSecondary, Theme.textPrimary, Math.max(sel, hv * 0.55f)), 1f, false);
            UIRender.popTransform();
        }

        // Version footer, only when the sidebar is tall enough to show it without overlapping the tabs.
        if (wh >= 260f && !collapsed) {
            float fy = wy + wh - 34f;
            UIRender.rect(wx + 14f, fy - 6f, SIDEBAR_W - 28f, 1f, Theme.divider);
            UIRender.text(fr, "VERSION", wx + 14f, fy, Theme.textTertiary, 0.75f, false);
            UIRender.text(fr, PekaVersion.NAME, wx + 14f, fy + 11f, Theme.textSecondary, 0.9f, false);
        }
    }

    /** Narrow layout: a segmented tab bar. Names are shown when there is room, otherwise icons only. */
    private void drawTabs(int mx, int my) {
        FontRenderer fr = fr();
        float x = wx + PAD;
        float y = wy + TITLE_H + 6f;
        float w = ww - PAD * 2f;
        float h = TAB_H;
        UIRender.roundRect(x, y, w, h, h * 0.5f, Theme.track, Theme.track, 1f);
        float seg = w / PAGE_NAMES.length;
        boolean names = seg >= TAB_TEXT_MIN;
        for (int i = 0; i < PAGE_NAMES.length; i++) {
            float sx = x + i * seg;
            boolean hot = inside(mx, my, sx, y, seg, h);
            navHover[i].to(hot ? 1f : 0f);
            float hv = navHover[i].get();
            if (hv > 0.01f && navSel[i].get() < 0.99f) {
                int hoverFill = UIRender.withAlpha(Theme.cardHover, hv * 0.62f);
                UIRender.roundRect(sx + 2f, y + 2f, seg - 4f, h - 4f, (h - 4f) * 0.5f,
                        hoverFill, hoverFill, 0.6f);
            }
            float sel = navSel[i].get();
            if (sel > 0.01f) {
                float inner = h - 4f;
                int pill = UIRender.withAlpha(Theme.segSelected, sel);
                UIRender.roundRect(sx + 2f, y + 2f, seg - 4f, inner, inner * 0.5f, pill, pill, 1f);
            }
            int col = UIRender.mix(Theme.textSecondary, Theme.textPrimary, Math.max(sel, hv * 0.48f));
            if (names) {
                float tw = fr.getStringWidth(PAGE_NAMES[i]);
                UIRender.text(fr, PAGE_NAMES[i], sx + (seg - tw) * 0.5f, y + (h - 9f) * 0.5f + 1f, col, 1f, false);
            } else {
                Icons.draw(PAGE_ICONS[i], sx + seg * 0.5f, y + h * 0.5f, 11f, col);
            }
        }
    }

    private void drawHeader() {
        FontRenderer fr = fr();
        String title = searching ? "Search" : PAGE_NAMES[pageIndex];
        String sub = searching ? searchRows.size() + (searchRows.size() == 1 ? " match" : " matches")
                : PAGE_SUBS[pageIndex];
        UIRender.text(fr, title, cx0, headY, Theme.textPrimary, 1.5f, false);
        if (tall) {
            UIRender.text(fr, sub, cx0, headY + 19f, Theme.textSecondary, 1f, false);
        }
    }

    private void drawContent(int mx, int my) {
        FontRenderer fr = fr();
        List<Row> rows = currentRows();
        UIRender.scissorBegin(vx, vy, vw, vh, sf);

        if (searching && rows.isEmpty()) {
            String none = "No matching settings";
            UIRender.text(fr, none, vx + (vw - fr.getStringWidth(none)) * 0.5f, vy + 16f,
                    Theme.textTertiary, 1f, false);
        }

        float top = vy;
        float bottom = vy + vh;
        for (int i = 0, n = rows.size(); i < n; i++) {
            Row r = rows.get(i);
            if (!shown(r) || r.y + r.height < top || r.y > bottom) {
                continue;
            }
            float reveal = rowReveal.containsKey(r) ? rowReveal.get(r) : 0f;
            float revealEase = 1f - (float) Math.exp(-dtEma * 13f * Math.max(0.1f, Theme.speed));
            reveal += (1f - reveal) * (Theme.animations ? revealEase : 1f);
            rowReveal.put(r, reveal);
            float priorAlpha = UIRender.alphaMul;
            UIRender.alphaMul = priorAlpha * reveal;
            UIRender.pushScaleAt(vx + vw * 0.5f, r.y + r.height * 0.5f,
                    Theme.animations ? 0.982f + reveal * 0.018f : 1f);
            if (r.kind == Row.SECTION) {
                boolean hot = inside(mx, my, vx, r.y, vw, r.height);
                float value = itemHover.containsKey(r) ? itemHover.get(r) : 0f;
                float target = Theme.animations && hot ? 1f : 0f;
                float ease = 1f - (float) Math.exp(-dtEma * 17f * Math.max(0.1f, Theme.speed));
                value += (target - value) * (Theme.animations ? ease : 1f);
                itemHover.put(r, value);
                UIRender.text(fr, r.label, vx + 2f, r.y + 4f,
                        UIRender.mix(Theme.textTertiary, Theme.textSecondary, value * 0.8f), 0.85f, false);
                if (value > 0.01f) {
                    float lineWidth = Math.min(vw * 0.42f, fr.getStringWidth(r.label) * 0.7f) * value;
                    UIRender.roundRect(vx + 2f, r.y + r.height - 1.5f, lineWidth, 1f, 0.5f,
                            Theme.accent, Theme.accent, 0.2f);
                }
            } else if (r.kind == Row.HEADER) {
                drawGroupHeader(fr, r, mx, my);
            } else if (r.kind == Row.ITEM) {
                drawItem(fr, r, mx, my);
            } else {
                r.painter.paint(vx, r.y, vw, r.height);
            }
            UIRender.popTransform();
            UIRender.alphaMul = priorAlpha;
        }
        drawScrollIndicator();
        UIRender.scissorEnd();
    }

    /** Collapsible category: a chevron (right when closed, down when open), the title, and the row count. */
    private void drawGroupHeader(FontRenderer fr, Row r, int mx, int my) {
        float x = vx;
        float y = r.y;
        float w = vw;
        float h = r.height;
        boolean open = expanded.contains(r.label);
        boolean hov = mx >= x && mx < x + w && my >= y && my < y + h;
        float dt = dtEma;
        float value = sectionHover.containsKey(r.label) ? sectionHover.get(r.label) : 0f;
        float target = Theme.animations && hov ? 1f : 0f;
        float blend = 1f - (float) Math.exp(-dt * 17f * Math.max(0.1f, Theme.speed));
        value += (target - value) * (Theme.animations ? blend : 1f);
        sectionHover.put(r.label, value);
        float openValue = sectionOpen.containsKey(r.label) ? sectionOpen.get(r.label) : (open ? 1f : 0f);
        openValue += ((open ? 1f : 0f) - openValue) * (Theme.animations ? blend : 1f);
        sectionOpen.put(r.label, openValue);
        int fill = UIRender.mix(Theme.card, Theme.buttonHover, value * 0.48f);
        int edge = UIRender.mix(Theme.border, Theme.accent, value * 0.55f);
        UIRender.roundRectBorder(x, y, w, h, cardRadius(), fill, fill, edge);
        int ink = UIRender.mix(Theme.textSecondary, Theme.accent, value);
        float cx = x + 14f;
        float cy = y + h * 0.5f;
        // The chevron morphs from right-facing to down-facing as the category opens.
        float t = openValue;
        float ax = (cx - 2.2f) * (1f - t) + (cx - 3.2f) * t;
        float ay = (cy - 3.2f) * (1f - t) + (cy - 1.8f) * t;
        float bx = (cx + 2.6f) * (1f - t) + cx * t;
        float by = cy;
        float cx2 = (cx - 2.2f) * (1f - t) + (cx + 3.2f) * t;
        float cy2 = (cy + 3.2f) * (1f - t) + (cy - 1.8f) * t;
        UIRender.line(ax, ay, bx, by, 1.4f, ink);
        UIRender.line(bx, by, cx2, cy2, 1.4f, ink);
        float ty = y + (h - 9f) * 0.5f + 1f;
        UIRender.text(fr, r.label, x + 26f, ty, UIRender.mix(Theme.textPrimary, Theme.accent, value * 0.28f), 1.05f, false);
        if (value > 0.01f) {
            float underlineW = Math.min(w - 36f, fr.getStringWidth(r.label) * 0.62f) * value;
            UIRender.roundRect(x + 26f, y + h - 2f, Math.max(0f, underlineW), 1.2f, 0.6f,
                    Theme.accent, Theme.accent, 0.2f);
        }
        String count = r.children + (r.children == 1 ? " setting" : " settings");
        float cwid = fr.getStringWidth(count) * 0.9f;
        UIRender.text(fr, count, x + w - 12f - cwid, ty, Theme.textTertiary, 0.9f, false);
    }

    private void drawItem(FontRenderer fr, Row r, int mx, int my) {
        float x = vx;
        float y = r.y;
        float w = vw;
        float h = r.height;
        boolean hot = inside(mx, my, x, y, w, h);
        float hover = itemHover.containsKey(r) ? itemHover.get(r) : 0f;
        float target = Theme.animations && hot ? 1f : 0f;
        float ease = 1f - (float) Math.exp(-dtEma * 18f * Math.max(0.1f, Theme.speed));
        hover += (target - hover) * (Theme.animations ? ease : 1f);
        itemHover.put(r, hover);
        float rowScale = Theme.animations ? 1f + hover * 0.006f : 1f;
        UIRender.pushScaleAt(x + w * 0.5f, y + h * 0.5f, rowScale);
        int fill = UIRender.mix(Theme.card, Theme.cardHover, hover * 0.72f);
        int edge = UIRender.mix(Theme.border, Theme.accent, hover * 0.28f);
        UIRender.roundRectBorder(x, y, w, h, cardRadius(), fill, fill, edge);
        if (hover > 0.025f) {
            int marker = UIRender.withAlpha(Theme.accent, hover * 0.48f);
            UIRender.roundRect(x + 1f, y + 4f, 1.6f * hover, Math.max(0f, h - 8f), 0.8f,
                    marker, marker, 0f);
        }

        float maxW = w - 24f - (r.control != null ? r.control.w + 12f : 0f);
        String label = fit(fr, r.label, maxW);
        if (r.desc != null) {
            UIRender.text(fr, label, x + 12f, y + 7f, Theme.textPrimary, 1f, false);
            UIRender.text(fr, fit(fr, r.desc, maxW), x + 12f, y + 21f, Theme.textSecondary, 1f, false);
        } else if (!label.isEmpty()) {
            UIRender.text(fr, label, x + 12f, y + (h - 9f) * 0.5f + 1f, Theme.textPrimary, 1f, false);
        }
        if (r.control != null) {
            r.control.draw(mx, my);
        }
        UIRender.popTransform();
    }

    private void drawScrollIndicator() {
        float ind = indicator.get();
        float maxS = scroll.max();
        if (ind <= 0.01f || maxS <= 0f) {
            return;
        }
        float track = vh - 8f;
        float thumb = Math.max(24f, track * vh / (contentHeight(currentRows()) + 4f));
        float ty = vy + 4f + (track - thumb) * (scroll.value() / maxS);
        float prev = UIRender.alphaMul;
        UIRender.alphaMul = prev * ind;
        UIRender.roundRect(vx + vw - 3f, ty, 3f, thumb, 1.5f, Theme.textSecondary, Theme.textSecondary, 0.5f);
        UIRender.alphaMul = prev;
    }

    /** Stat cards for the QoL overview. Painter, no widgets. */
    private void paintStats(float x, float y, float w, float h) {
        FontRenderer fr = fr();
        final int[] order = {S_FPS, S_MINE, S_MEM};
        final String[] labels = {"FRAME RATE", "MINING", "MEMORY"};
        float gap = 8f;
        float cardW = (w - gap * 2f) / 3f;
        for (int i = 0; i < order.length; i++) {
            float cx = x + i * (cardW + gap);
            UIRender.roundRectBorder(cx, y, cardW, h, cardRadius(), Theme.card, Theme.card, Theme.border);
            UIRender.text(fr, labels[i], cx + 10f, y + 11f, Theme.textTertiary, 0.8f, false);
            int valueCol = i == 0 || i == 1 ? Theme.accent : Theme.textPrimary;
            UIRender.text(fr, statValues[order[i]], cx + 10f, y + h - 26f, valueCol, 1.4f, false);
        }
    }

    /** Frame-time bar chart for the QoL page. Batched into one draw call. */
    private void paintGraph(float x, float y, float w, float h) {
        FontRenderer fr = fr();
        UIRender.roundRectBorder(x, y, w, h, cardRadius(), Theme.card, Theme.card, Theme.border);
        UIRender.text(fr, "FRAME TIME", x + 12f, y + 9f, Theme.textTertiary, 0.8f, false);
        String v = statValues[S_FRAME];
        UIRender.text(fr, v, x + w - 12f - fr.getStringWidth(v), y + 8f, Theme.textPrimary, 1f, false);

        float px = x + 12f;
        float pw = w - 24f;
        float py = y + 26f;
        float ph = h - 36f;
        UIRender.rect(px, py + ph * 0.5f, pw, 1f, Theme.divider);

        int n = frameHistory.length;
        float bw = pw / n;
        UIRender.beginBatch();
        for (int i = 0; i < n; i++) {
            float ms = frameHistory[(histIdx + i) % n];
            float bh = Math.max(1f, Math.min(1f, ms / 33.3f) * ph);
            int c = ms > 33.3f ? 0xFFFF9F0A : Theme.accent;
            UIRender.rect(px + i * bw, py + ph - bh, Math.max(1f, bw - 1f), bh, c);
        }
        UIRender.endBatch();
    }

    /** Empty state for a category with no modules. Painter, no widgets. */
    private void paintEmpty(float x, float y, float w, float h, int icon) {
        FontRenderer fr = fr();
        UIRender.roundRectBorder(x, y, w, h, cardRadius(), Theme.card, Theme.card, Theme.border);
        Icons.draw(icon, x + 26f, y + h * 0.5f, 22f, Theme.textTertiary);
        UIRender.text(fr, "No modules yet", x + 52f, y + h * 0.5f - 13f, Theme.textPrimary, 1f, false);
        String note = "Nothing is available in this category yet.";
        UIRender.text(fr, fit(fr, note, w - 64f), x + 52f, y + h * 0.5f + 3f, Theme.textSecondary, 1f, false);
    }

    private float cardRadius() {
        return Math.max(4f, Theme.radius - 4f);
    }

    // ------------------------------------------------------------------ input

    @Override
    protected void mouseClicked(int mx, int my, int button) throws IOException {
        if (button != 0) {
            return;
        }
        if (handleOpenDropdownClick(mx, my)) {
            return;
        }
        if (!inside(mx, my, wx, wy, ww, wh)) {
            close();
            return;
        }
        int control = WindowControls.hit(mx, my, wx + 16f, wy + 17f, 0b111);
        if (control == WindowControls.CLOSE) {
            close();
            return;
        }
        if (control == WindowControls.COLLAPSE) {
            toggleCollapsed();
            return;
        }
        if (control == WindowControls.ZOOM) {
            toggleZoom();
            return;
        }
        if (collapsed) {
            return;
        }
        if (dollVisible && inside(mx, my, vx, vy, vw, vh) && inside(mx, my, dollX, dollY, dollW, dollH)) {
            dollDragging = true;
            dollLastX = mx;
            return;
        }
        int nav = navIndexAt(mx, my);
        if (nav >= 0) {
            selectPage(nav);
            return;
        }
        if (search.contains(mx, my)) {
            search.setFocused(true);
            return;
        }
        search.setFocused(false);
        if (!inside(mx, my, vx, vy, vw, vh)) {
            return;
        }

        Row header = headerAt(mx, my);
        if (header != null) {
            pendingHeader = header;
            active = null;
            sliderEngaged = false;
            gestureActive = true;
            gesture.begin(null, mx, my, scroll.value());
            return;
        }
        Widget w = widgetAt(mx, my);
        active = w;
        sliderEngaged = false;
        gestureActive = true;
        gesture.begin(w, mx, my, scroll.value());
        if (w != null && !(w instanceof AppleSlider)) {
            w.onPress(mx, my);
        }
    }

    @Override
    protected void mouseClickMove(int mx, int my, int button, long timeSinceLastClick) {
        if (dollDragging) {
            // Horizontal drag turns the doll. About 1.2 degrees per pixel.
            HudManager.DOLL.dragBy((mx - dollLastX) * 1.2f);
            dollLastX = mx;
            return;
        }
        if (!gestureActive) {
            return;
        }
        float speed = scrollSpeed();
        int kind = gesture.move(mx, my);
        if (kind == Gesture.SLIDER) {
            if (!sliderEngaged) {
                sliderEngaged = true;
                active.onPress((int) gesture.startX, (int) gesture.startY);
            }
            active.onDrag(mx, my);
        } else if (kind == Gesture.SCROLL) {
            // The swipe cancels any press. The control is not activated on release.
            if (active != null) {
                active.onRelease(mx, my, false);
                active = null;
            }
            scroll.setImmediate(gesture.scrollAt(my, speed));
            gesture.track(my, speed);
        }
    }

    @Override
    protected void mouseReleased(int mx, int my, int button) {
        if (dollDragging) {
            dollDragging = false;
            HudManager.save();
            return;
        }
        if (active != null) {
            if (active instanceof AppleSlider && gesture.kind == Gesture.PENDING) {
                // A tap on a slider sets it where the finger lifted.
                active.onPress((int) gesture.startX, (int) gesture.startY);
            }
            boolean activate = gesture.kind == Gesture.PENDING && active.contains(mx, my);
            Widget a = active;
            active = null;
            a.onRelease(mx, my, activate);
            if (activate && a instanceof AppleDropdown && ((AppleDropdown) a).isAllowed()) {
                AppleDropdown d = (AppleDropdown) a;
                openDropdown = (openDropdown == d) ? null : d;
                if (openDropdown != null) {
                    openDropdown.onExpand();
                }
            }
        }
        if (pendingHeader != null) {
            Row header = pendingHeader;
            pendingHeader = null;
            if (gesture.kind == Gesture.PENDING && mx >= vx && mx < vx + vw
                    && my >= header.y && my < header.y + header.height) {
                toggleGroup(header.label);
            }
        }
        if (gestureActive && gesture.kind == Gesture.SCROLL) {
            scroll.fling(gesture.flingVelocity() * scrollSpeed());
        }
        gestureActive = false;
        sliderEngaged = false;
        gesture.target = null;
        gesture.kind = Gesture.PENDING;
    }

    /** Mouse wheel. 1.8.9 has no wheel callback, so read the event before the default handling. */
    @Override
    public void handleMouseInput() throws IOException {
        int wheel = Mouse.getEventDWheel();
        super.handleMouseInput();
        if (wheel != 0) {
            scroll.wheel(wheel / 120f, scrollSpeed());
        }
    }

    private float scrollSpeed() {
        return AppleSettings.effectiveScrollSpeed() / 100f;
    }

    @Override
    protected void keyTyped(char c, int code) throws IOException {
        if (collapsed && code != Keyboard.KEY_ESCAPE) {
            return;
        }
        if (search.isFocused()) {
            if (code == Keyboard.KEY_ESCAPE) {
                if (!search.isEmpty()) {
                    search.clear();
                } else {
                    search.setFocused(false);
                }
                return;
            }
            if (search.keyTyped(c, code)) {
                return;
            }
        }
        if (code == Keyboard.KEY_ESCAPE) {
            if (openDropdown != null) {
                openDropdown = null;
                return;
            }
            close();
            return;
        }
        if (isCtrlKeyDown()) {
            if (code == Keyboard.KEY_F) {
                search.setFocused(true);
                return;
            }
            if (code >= Keyboard.KEY_1 && code - Keyboard.KEY_1 < PAGE_NAMES.length) {
                selectPage(code - Keyboard.KEY_1);
            }
            return;
        }
        if (handleNavigationKey(code)) {
            return;
        }
        if (c >= 32 && c != 127) {
            search.setFocused(true);
            search.keyTyped(c, code);
        }
    }

    /** Keyboard navigation: tabs with Left and Right, the list with the scroll keys. */
    private boolean handleNavigationKey(int code) {
        float page = Math.max(40f, vh * 0.8f);
        switch (code) {
            case Keyboard.KEY_LEFT:
                selectPage(Math.max(0, pageIndex - 1));
                return true;
            case Keyboard.KEY_RIGHT:
                selectPage(Math.min(PAGE_NAMES.length - 1, pageIndex + 1));
                return true;
            case Keyboard.KEY_DOWN:
                scroll.key(ScrollState.KEY_STEP);
                return true;
            case Keyboard.KEY_UP:
                scroll.key(-ScrollState.KEY_STEP);
                return true;
            case Keyboard.KEY_NEXT:
                scroll.key(page);
                return true;
            case Keyboard.KEY_PRIOR:
                scroll.key(-page);
                return true;
            case Keyboard.KEY_HOME:
                scroll.key(-1.0e7f);
                return true;
            case Keyboard.KEY_END:
                scroll.key(1.0e7f);
                return true;
            default:
                return false;
        }
    }

    private void close() {
        Minecraft.getMinecraft().displayGuiScreen(parent);
    }

    /** Yellow: hide the body and keep the title bar. Clears any open popup and focus first. */
    private void toggleCollapsed() {
        collapsed = !collapsed;
        resetTransient();
    }

    /** Green: fill the screen, or go back to the normal size. Expands the window if it was collapsed. */
    private void toggleZoom() {
        zoomed = !zoomed;
        collapsed = false;
        resetTransient();
    }

    private void resetTransient() {
        openDropdown = null;
        active = null;
        gestureActive = false;
        sliderEngaged = false;
        dollDragging = false;
        search.setFocused(false);
    }

    private int navIndexAt(int mx, int my) {
        if (wide) {
            float x = wx + 8f;
            float w = SIDEBAR_W - 16f;
            for (int i = 0; i < PAGE_NAMES.length; i++) {
                float y = wy + TITLE_H + 10f + i * NAV_STEP;
                if (inside(mx, my, x, y, w, NAV_H)) {
                    return i;
                }
            }
            return -1;
        }
        float y = wy + TITLE_H + 6f;
        if (my < y || my >= y + TAB_H) {
            return -1;
        }
        float x0 = wx + PAD;
        float seg = (ww - PAD * 2f) / PAGE_NAMES.length;
        if (mx < x0) {
            return -1;
        }
        int i = (int) ((mx - x0) / seg);
        return (i >= 0 && i < PAGE_NAMES.length) ? i : -1;
    }

    /** The group header under the pointer inside the visible list, or null. */
    private Row headerAt(int mx, int my) {
        if (searching || !inside(mx, my, vx, vy, vw, vh)) {
            return null;
        }
        List<Row> rows = pages.get(pageIndex);
        for (int i = 0, n = rows.size(); i < n; i++) {
            Row r = rows.get(i);
            if (r.kind == Row.HEADER && my >= r.y && my < r.y + r.height && mx >= vx && mx < vx + vw) {
                return r;
            }
        }
        return null;
    }

    private Widget widgetAt(int mx, int my) {
        List<Row> rows = currentRows();
        for (int i = rows.size() - 1; i >= 0; i--) {
            Row row = rows.get(i);
            Widget c = row.control;
            if (c != null && shown(row) && c.contains(mx, my)) {
                return c;
            }
        }
        return null;
    }
}
