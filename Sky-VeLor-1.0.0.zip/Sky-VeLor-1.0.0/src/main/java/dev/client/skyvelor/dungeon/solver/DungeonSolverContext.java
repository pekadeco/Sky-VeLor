package dev.client.skyvelor.dungeon.solver;

import dev.client.skyvelor.feature.DungeonContext;

/** Shared context gates for the Better NEF dungeon features adapted to Sky VeLor. */
public final class DungeonSolverContext {
    private DungeonSolverContext() { }

    public static boolean checkEssentials() {
        return DungeonContext.inDungeon();
    }

    public static boolean checkEssentialsF7() {
        return DungeonContext.inF7OrM7();
    }
}
