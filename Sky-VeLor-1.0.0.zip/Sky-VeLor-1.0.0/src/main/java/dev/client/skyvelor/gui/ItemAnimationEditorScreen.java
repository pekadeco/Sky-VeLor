package dev.client.skyvelor.gui;

import dev.client.skyvelor.config.AppleSettings;
import dev.client.skyvelor.feature.ItemAnimation;
import dev.client.skyvelor.render.Theme;
import dev.client.skyvelor.render.UIRender;
import dev.client.skyvelor.widget.AppleButton;
import dev.client.skyvelor.widget.AppleDropdown;
import dev.client.skyvelor.widget.AppleSlider;
import dev.client.skyvelor.widget.AppleToggle;
import dev.client.skyvelor.widget.Widget;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.item.ItemStack;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Live first-person Item Animation editor. The world is deliberately left undimmed and this screen does not pause
 * gameplay, so the player's held item remains visible behind the translucent settings panel while values are changed.
 */
public final class ItemAnimationEditorScreen extends AppleScreen {

    private static final float PANEL_X = 12f;
    private static final float PANEL_Y = 12f;
    private static final float ROW_HEIGHT = 34f;
    private static final float ROW_GAP = 2f;

    private static final class Entry {
        final String label;
        final Widget widget;
        float y;

        Entry(String label, Widget widget) {
            this.label = label;
            this.widget = widget;
        }
    }

    private final GuiScreen parent;
    private final List<Entry> entries = new ArrayList<Entry>();
    private Widget active;

    private float panelW;
    private float panelH;
    private float viewX;
    private float viewY;
    private float viewW;
    private float viewH;
    private float contentHeight;
    private float maxScroll;
    private float scrollTarget;
    private float scrollCurrent;
    private long lastFrameNanos;

    public ItemAnimationEditorScreen(GuiScreen parent) {
        this.parent = parent;
        buildEntries();
    }

    private void buildEntries() {
        entries.add(new Entry("Item Animation", new AppleToggle(
                () -> AppleSettings.itemAnimationEnabled,
                value -> AppleSettings.itemAnimationEnabled = value)));

        entries.add(new Entry("Custom item scale", new AppleToggle(
                () -> AppleSettings.itemAnimationSizeOn,
                value -> AppleSettings.itemAnimationSizeOn = value)
                .gate(() -> AppleSettings.itemAnimationEnabled)));
        entries.add(new Entry("Item scale", new AppleSlider(ItemAnimation.MIN_SIZE_PERCENT,
                ItemAnimation.MAX_SIZE_PERCENT, 5, "%", 150f,
                () -> AppleSettings.itemAnimationSize,
                value -> AppleSettings.itemAnimationSize = ItemAnimation.clampSize(value))
                .gate(() -> AppleSettings.itemAnimationEnabled && AppleSettings.itemAnimationSizeOn)));

        entries.add(new Entry("Custom animation speed", new AppleToggle(
                () -> AppleSettings.itemAnimationSpeedOn,
                value -> AppleSettings.itemAnimationSpeedOn = value)
                .gate(() -> AppleSettings.itemAnimationEnabled)));
        entries.add(new Entry("Animation speed", new AppleSlider(ItemAnimation.MIN_SPEED_PERCENT,
                ItemAnimation.MAX_SPEED_PERCENT, 5, "%", 150f,
                () -> AppleSettings.itemAnimationSpeed,
                value -> AppleSettings.itemAnimationSpeed = ItemAnimation.clampSpeed(value))
                .gate(() -> AppleSettings.itemAnimationEnabled && AppleSettings.itemAnimationSpeedOn)));

        entries.add(new Entry("Position X", offsetSlider(() -> AppleSettings.itemAnimationX,
                value -> AppleSettings.itemAnimationX = ItemAnimation.clampOffset(value))));
        entries.add(new Entry("Position Y", offsetSlider(() -> AppleSettings.itemAnimationY,
                value -> AppleSettings.itemAnimationY = ItemAnimation.clampOffset(value))));
        entries.add(new Entry("Position Z", offsetSlider(() -> AppleSettings.itemAnimationZ,
                value -> AppleSettings.itemAnimationZ = ItemAnimation.clampOffset(value))));

        entries.add(new Entry("Hit / slash style", new AppleDropdown(
                AppleSettings.ITEM_ANIMATION_HIT_SLASH_STYLES, null, 142f, 24f,
                () -> AppleSettings.itemAnimationHitSlashStyle,
                value -> AppleSettings.itemAnimationHitSlashStyle = ItemAnimation.clampHitSlashStyle(value))
                .gate(() -> AppleSettings.itemAnimationEnabled)));

        entries.add(new Entry("Smooth swing", new AppleToggle(
                () -> AppleSettings.itemAnimationSmoothSwing,
                value -> AppleSettings.itemAnimationSmoothSwing = value)
                .gate(() -> AppleSettings.itemAnimationEnabled)));
        entries.add(new Entry("Swing smoothness", new AppleSlider(ItemAnimation.MIN_SMOOTHNESS_PERCENT,
                ItemAnimation.MAX_SMOOTHNESS_PERCENT, 5, "%", 150f,
                () -> AppleSettings.itemAnimationSmoothness,
                value -> AppleSettings.itemAnimationSmoothness = ItemAnimation.clampSmoothness(value))
                .gate(() -> AppleSettings.itemAnimationEnabled && AppleSettings.itemAnimationSmoothSwing)));
        entries.add(new Entry("Haste-independent swing", new AppleToggle(
                () -> AppleSettings.itemAnimationRemoveHasteEffect,
                value -> AppleSettings.itemAnimationRemoveHasteEffect = value)
                .gate(() -> AppleSettings.itemAnimationEnabled)));

        entries.add(new Entry("Preview swing", new AppleButton("Preview", 96f, 24f, true, () -> {
            if (AppleSettings.itemAnimationEnabled) {
                ItemAnimation.previewSwing();
            }
        })));
        entries.add(new Entry("Restore defaults", new AppleButton("Reset", 96f, 24f, false, () -> {
            ItemAnimation.resetToDefaults();
            AppleSettings.save();
        })));
    }

    private AppleSlider offsetSlider(java.util.function.IntSupplier getter,
                                     java.util.function.IntConsumer setter) {
        return new AppleSlider(ItemAnimation.MIN_OFFSET, ItemAnimation.MAX_OFFSET, 5, "", 150f,
                getter, setter)
                .valueLabel(value -> String.format(Locale.ROOT, "%+.2f", value / 100.0f))
                .gate(() -> AppleSettings.itemAnimationEnabled);
    }

    @Override
    public void initGui() {
        super.initGui();
        recalculateLayout();
    }

    @Override
    public void onGuiClosed() {
        AppleSettings.save();
        super.onGuiClosed();
    }

    /** Keep the game rendering so changes can be judged against the real first-person held item. */
    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    private void recalculateLayout() {
        panelW = Math.max(220f, Math.min(410f, width - 24f));
        panelH = Math.max(180f, height - 24f);
        viewX = PANEL_X + 10f;
        viewY = PANEL_Y + 51f;
        viewW = panelW - 20f;
        viewH = Math.max(45f, panelH - 62f);
        contentHeight = entries.size() * (ROW_HEIGHT + ROW_GAP) - ROW_GAP;
        maxScroll = Math.max(0f, contentHeight - viewH);
        scrollTarget = clamp(scrollTarget, 0f, maxScroll);
        scrollCurrent = clamp(scrollCurrent, 0f, maxScroll);

        for (int i = 0; i < entries.size(); i++) {
            Entry entry = entries.get(i);
            entry.y = viewY + i * (ROW_HEIGHT + ROW_GAP) - scrollCurrent;
            Widget widget = entry.widget;
            widget.x = PANEL_X + panelW - 15f - widget.w;
            widget.y = entry.y + (ROW_HEIGHT - widget.h) * 0.5f;
        }
    }

    private static float clamp(float value, float min, float max) {
        return value < min ? min : (value > max ? max : value);
    }

    private boolean entryVisible(Entry entry) {
        return entry.y + ROW_HEIGHT > viewY && entry.y < viewY + viewH;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        long now = System.nanoTime();
        float dt = lastFrameNanos == 0L ? 1f / 60f : Math.min(0.1f, (now - lastFrameNanos) / 1.0e9f);
        lastFrameNanos = now;
        if (Theme.animations) {
            float blend = 1f - (float) Math.exp(-dt * 20f * Math.max(0.1f, Theme.speed));
            scrollCurrent += (scrollTarget - scrollCurrent) * blend;
            if (Math.abs(scrollTarget - scrollCurrent) < 0.08f) scrollCurrent = scrollTarget;
        } else {
            scrollCurrent = scrollTarget;
        }
        recalculateLayout();
        for (Entry entry : entries) {
            if (entryVisible(entry)) entry.widget.update(dt);
        }

        // Intentionally leaves the game background untouched and adds no full-screen veil.
        UIRender.beginFrame();
        float radius = Math.min(Theme.radius, 12f);
        UIRender.shadow(PANEL_X, PANEL_Y, panelW, panelH, radius);
        UIRender.roundRect(PANEL_X, PANEL_Y, panelW, panelH, radius,
                0x8E152438, 0x88101B2B, 0.35f);
        UIRender.roundRectRing(PANEL_X, PANEL_Y, panelW, panelH, radius, 1f, Theme.border);
        UIRender.text(fr(), "Item Animation Editor", PANEL_X + 12f, PANEL_Y + 9f,
                Theme.textPrimary, 1f, false);
        UIRender.text(fr(), "LIVE  ·  change settings and watch your held item", PANEL_X + 12f, PANEL_Y + 26f,
                Theme.textTertiary, 0.68f, false);
        UIRender.text(fr(), "Done", PANEL_X + panelW - 43f, PANEL_Y + 10f, Theme.accent, 0.82f, false);
        UIRender.rect(PANEL_X + 1f, PANEL_Y + 45f, panelW - 2f, 1f, 0x655B7188);

        float scale = new ScaledResolution(Minecraft.getMinecraft()).getScaleFactor();
        UIRender.scissorBegin(viewX, viewY, viewW, viewH, scale);
        for (Entry entry : entries) {
            if (!entryVisible(entry)) continue;
            boolean hovered = inside(mouseX, mouseY, viewX, entry.y, viewW, ROW_HEIGHT);
            int rowFill = hovered ? 0x463A5169 : 0x28121E30;
            UIRender.roundRect(viewX, entry.y, viewW, ROW_HEIGHT, 5f,
                    rowFill, rowFill, 0.25f);
            UIRender.text(fr(), fit(fr(), entry.label, Math.max(12f, entry.widget.x - viewX - 14f)),
                    viewX + 8f, entry.y + (ROW_HEIGHT - fr().FONT_HEIGHT * 0.78f) * 0.5f,
                    Theme.textSecondary, 0.78f, false);
            entry.widget.draw(mouseX, mouseY);
        }
        if (maxScroll > 0.5f) {
            float thumbH = Math.max(22f, viewH * viewH / contentHeight);
            float travel = Math.max(1f, viewH - thumbH);
            float thumbY = viewY + travel * (scrollCurrent / maxScroll);
            float barX = viewX + viewW - 3f;
            UIRender.roundRect(barX, viewY + 2f, 2f, viewH - 4f, 1f,
                    0x403F536A, 0x403F536A, 0f);
            UIRender.roundRect(barX, thumbY, 2f, thumbH, 1f,
                    UIRender.withAlpha(Theme.accent, 0.85f), UIRender.withAlpha(Theme.accent, 0.85f), 0f);
        }
        UIRender.scissorEnd();

        if (openDropdown != null) {
            UIRender.scissorBegin(viewX, viewY, viewW, viewH, scale);
            openDropdown.drawPopup(mouseX, mouseY, viewY, viewY + viewH,
                    PANEL_X + panelW, PANEL_X);
            UIRender.scissorEnd();
        }
        drawLivePreviewLabel();
        UIRender.endFrame();
    }

    private void drawLivePreviewLabel() {
        float badgeX = width - 192f;
        if (badgeX <= PANEL_X + panelW + 8f) return;
        float badgeY = 14f;
        UIRender.roundRect(badgeX, badgeY, 178f, 43f, 8f,
                0x75111F32, 0x75111F32, 0.25f);
        UIRender.text(fr(), "LIVE ITEM PREVIEW", badgeX + 9f, badgeY + 7f,
                Theme.accent, 0.72f, false);
        Minecraft mc = Minecraft.getMinecraft();
        ItemStack stack = mc.thePlayer == null ? null : mc.thePlayer.getHeldItem();
        String itemName = stack == null ? "Hold an item to preview" : stack.getDisplayName();
        UIRender.text(fr(), fit(fr(), itemName, 160f), badgeX + 9f, badgeY + 23f,
                Theme.textPrimary, 0.82f, false);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        if (button != 0) return;
        if (handleOpenDropdownClick(mouseX, mouseY)) return;
        if (inside(mouseX, mouseY, PANEL_X + panelW - 54f, PANEL_Y, 54f, 44f)) {
            closeEditor();
            return;
        }
        if (!inside(mouseX, mouseY, viewX, viewY, viewW, viewH)) return;
        Entry selected = null;
        for (int i = entries.size() - 1; i >= 0; i--) {
            Entry entry = entries.get(i);
            if (entryVisible(entry) && entry.widget.contains(mouseX, mouseY)) {
                selected = entry;
                break;
            }
        }
        active = selected == null ? null : selected.widget;
        if (active != null) active.onPress(mouseX, mouseY);
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int button) {
        if (active == null) return;
        Widget released = active;
        active = null;
        boolean activate = released.contains(mouseX, mouseY);
        released.onRelease(mouseX, mouseY, activate);
        if (activate && released instanceof AppleDropdown) {
            AppleDropdown dropdown = (AppleDropdown) released;
            openDropdown = openDropdown == dropdown ? null : dropdown;
            if (openDropdown != null) openDropdown.onExpand();
        }
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int button, long elapsed) {
        if (active != null) active.onDrag(mouseX, mouseY);
        super.mouseClickMove(mouseX, mouseY, button, elapsed);
    }

    @Override
    public void handleMouseInput() throws IOException {
        int wheel = Mouse.getEventDWheel();
        super.handleMouseInput();
        int mouseX = Mouse.getEventX() * width / Math.max(1, Minecraft.getMinecraft().displayWidth);
        int mouseY = height - Mouse.getEventY() * height / Math.max(1, Minecraft.getMinecraft().displayHeight) - 1;
        if (wheel != 0 && openDropdown == null && inside(mouseX, mouseY, viewX, viewY, viewW, viewH)) {
            float multiplier = AppleSettings.guiScrollMultiplier();
            scrollTarget = clamp(scrollTarget - (wheel / 120f) * ROW_HEIGHT * 2.5f * multiplier,
                    0f, maxScroll);
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE) {
            if (openDropdown != null) openDropdown = null;
            else closeEditor();
            return;
        }
        super.keyTyped(typedChar, keyCode);
    }

    private void closeEditor() {
        AppleSettings.save();
        Minecraft.getMinecraft().displayGuiScreen(parent);
    }
}
