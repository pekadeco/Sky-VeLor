package dev.client.skyvelor.feature.qol;

import net.minecraft.util.IChatComponent;

/** Stores the original message on each wrapped chat row. */
public interface ChatLineAccess {
    IChatComponent skyvelor$getFullMessage();
    void skyvelor$setFullMessage(IChatComponent message);
}
