package dev.client.skyvelor.hud;

import dev.client.skyvelor.config.ConfigFiles;
import dev.client.skyvelor.feature.MiningTracker;
import dev.client.skyvelor.dungeon.DungeonProgressTracker;
import dev.client.skyvelor.feature.DungeonContext;
import dev.client.skyvelor.feature.SkyblockContext;
import dev.client.skyvelor.fishing.FishingHud;
import dev.client.skyvelor.fishing.SeaCreatureHud;
import dev.client.skyvelor.dungeon.DungeonBossHpHud;
import dev.client.skyvelor.slayer.SlayerHud;
import dev.client.skyvelor.render.UIRender;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.ScaledResolution;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

/**
 * Owns the HUD elements. Draws the enabled ones every frame, and saves and loads their settings to
 * {@code skyvelor-hud.properties} in the game directory. Older builds wrote {@code pekaclient-hud.properties};
 * that file is read once when the new one does not exist yet, and it is never written again.
 *
 * The file is read once. A corrupt file is logged and the defaults are used, so a bad save cannot stop
 * the game from starting. Save writes to a temporary file and then renames it, so an interrupted save
 * keeps the previous file.
 */
public final class HudManager {

    public static final MiningHud MINING = new MiningHud();
    public static final MiningAssistantHud MINING_ASSISTANT = new MiningAssistantHud();
    public static final InventoryHud INVENTORY = new InventoryHud();
    public static final HotbarHud HOTBAR = new HotbarHud();
    public static final PlayerDollHud DOLL = new PlayerDollHud();
    public static final StatsHud STATS = new StatsHud();
    public static final FishingHud FISHING = new FishingHud();
    public static final SeaCreatureHud SEA_HP = new SeaCreatureHud();
    public static final DungeonBossHpHud DUNGEON_BOSS_HP = new DungeonBossHpHud();
    public static final SlayerHud SLAYER = new SlayerHud();
    public static final DungeonProgressTracker DUNGEON_PROGRESS = new DungeonProgressTracker();
    public static final DungeonScoreHud DUNGEON_SCORE = new DungeonScoreHud();
    public static final DungeonSecretsHud DUNGEON_SECRETS = new DungeonSecretsHud();

    /** Every element, in draw order. */
    public static final HudElement[] ELEMENTS = {MINING, MINING_ASSISTANT, INVENTORY, HOTBAR, DOLL, STATS, FISHING, SEA_HP, DUNGEON_BOSS_HP, SLAYER, DUNGEON_SCORE, DUNGEON_SECRETS};

    public static final String FILE_NAME = "skyvelor-hud.properties";
    public static final String LEGACY_FILE_NAME = "pekaclient-hud.properties";

    private static final Logger LOG = LogManager.getLogger("SkyVeLor");
    private static boolean loaded;

    private HudManager() {
    }

    private static File dir() {
        return Minecraft.getMinecraft().mcDataDir;
    }

    /** Loads settings once. Missing or unreadable files keep the defaults. */
    public static void ensureLoaded() {
        if (!loaded) {
            load();
        }
    }

    public static void load() {
        Properties p = ConfigFiles.read(ConfigFiles.resolveRead(dir(), FILE_NAME, LEGACY_FILE_NAME));
        for (HudElement e : ELEMENTS) {
            e.load(p);
        }
        MiningTracker.setWindowSeconds(MINING.windowSeconds());
        loaded = true;
    }

    public static void save() {
        Properties p = new Properties();
        for (HudElement e : ELEMENTS) {
            e.save(p);
        }
        ConfigFiles.writeAtomic(new File(dir(), FILE_NAME), p, "Sky VeLor HUD settings");
    }

    /** Called once per client tick, before the world moves. */
    public static void tick(Minecraft mc) {
        ensureLoaded();
        MiningTracker.setWindowSeconds(MINING.windowSeconds());
        MiningTracker.tick(mc);
    }

    /** True when the in-game HUD should draw: a world is loaded, and no GUI is open except chat. */
    public static boolean visibleInGame() {
        Minecraft mc = Minecraft.getMinecraft();
        return !mc.gameSettings.hideGUI && mc.thePlayer != null
                && (mc.currentScreen == null || mc.currentScreen instanceof GuiChat);
    }

    /** Draws the enabled elements in game. */
    public static void render(ScaledResolution sr) {
        UIRender.beginFrame();
        for (HudElement e : ELEMENTS) {
            if (e.enabled && (!isSkyblockOnlyHud(e) || SkyblockContext.isInSkyblock())
                    && (!isDungeonOnlyHud(e) || DungeonContext.inDungeon())) {
                e.render(sr.getScaledWidth(), sr.getScaledHeight(), 1f);
            }
        }
        UIRender.endFrame();
    }

    private static boolean isSkyblockOnlyHud(HudElement element) {
        return element == MINING_ASSISTANT || element == STATS
                || element == FISHING || element == SEA_HP || element == DUNGEON_BOSS_HP || element == SLAYER
                || element == DUNGEON_SCORE || element == DUNGEON_SECRETS;
    }

    private static boolean isDungeonOnlyHud(HudElement element) {
        return element == DUNGEON_SCORE || element == DUNGEON_SECRETS;
    }

    /** Draws every element for the editor. Disabled elements are shown faded. */
    public static void renderEditor(ScaledResolution sr, int mx, int my) {
        int sw = sr.getScaledWidth();
        int sh = sr.getScaledHeight();
        HudElement under = null;
        for (HudElement e : ELEMENTS) {
            int x = e.leftFor(sw);
            int y = e.topFor(sh);
            if (mx >= x && mx < x + e.pixelWidth() && my >= y && my < y + e.pixelHeight()) {
                under = e;
            }
        }
        HudElement.backgroundOnHoverOnly = true;
        HudElement.hoveredInEditor = under;
        UIRender.beginFrame();
        for (HudElement e : ELEMENTS) {
            e.render(sw, sh, e.enabled ? 1f : 0.35f);
        }
        UIRender.endFrame();
        HudElement.backgroundOnHoverOnly = false;
        HudElement.hoveredInEditor = null;
    }

    public static void resetPositions() {
        for (HudElement e : ELEMENTS) {
            e.resetPosition();
        }
    }

    public static void resetAll() {
        for (HudElement e : ELEMENTS) {
            e.resetAll();
        }
    }
}
