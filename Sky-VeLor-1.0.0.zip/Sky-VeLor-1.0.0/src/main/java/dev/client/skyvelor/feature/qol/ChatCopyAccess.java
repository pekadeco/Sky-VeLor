package dev.client.skyvelor.feature.qol;

import net.minecraft.client.gui.ChatLine;

/** Access to wrapped chat rows so click-copy acts on the original full message. */
public interface ChatCopyAccess {
    ChatLine skyvelor$getChatLineAt(int mouseX, int mouseY);
    int skyvelor$getVisibleRowAt(int mouseX, int mouseY);
    int skyvelor$getMessageFirstRow(int row);
    int skyvelor$getMessageLastRow(int row);
}
