/*
 * This modified version is maintained by ii8we. Review LICENSE for upstream attribution and applicable license terms before use or redistribution. Original NotEnoughFakepixel code and third-party components remain subject to their respective copyrights and license terms.
 */
/* Adapted for Sky VeLor from code originating in NotEnoughFakepixel, through ii8we's private modifications. See LICENSE. */
package dev.client.skyvelor.dungeon.solver.terminals;
import dev.client.skyvelor.config.AppleSettings;

import dev.client.skyvelor.dungeon.solver.DungeonSolverContext;
import dev.client.skyvelor.dungeon.solver.DungeonSolverColor;
import dev.client.skyvelor.dungeon.solver.DungeonSolverRender;
import dev.client.skyvelor.dungeon.solver.DungeonSolverSound;
import dev.client.skyvelor.dungeon.solver.DungeonSolverColorsDict;
import net.minecraft.block.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Mouse;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ClickOnColorsSolver {

    private static final int SLOT_SIZE = 16;
    private static final int COLUMNS = 9;
    private static final int INNER_COLUMNS = 7;
    private static final int INNER_ROWS = 4;

    private final Set<Integer> clickedSlots = new HashSet<>();
    private long lastRecheckTime = 0;



    @SubscribeEvent(priority = EventPriority.LOW)
    public void onDrawScreenPost(GuiScreenEvent.DrawScreenEvent.Post event) {
        if (TerminalGuiLayer.isCustomTerminal(event.gui)) return;
        renderTerminalOverlay(event.gui);
    }

    @SubscribeEvent(priority = EventPriority.LOW)
    public void onTerminalGuiTopLayer(TerminalGuiTopLayerEvent event) {
        renderTerminalOverlay(event.gui);
    }

    private void renderTerminalOverlay(net.minecraft.client.gui.GuiScreen screen) {
        if (!AppleSettings.terminalColorsSolver) return;
        if (!(screen instanceof GuiChest)) return;
        if (!DungeonSolverContext.checkEssentialsF7()) return;

        GuiChest chest = (GuiChest) screen;
        Container container = chest.inventorySlots;
        if (!(container instanceof ContainerChest)) return;

        String title = ((ContainerChest) container).getLowerChestInventory().getDisplayName().getUnformattedText();
        if (!title.startsWith("Select all the")) return;

        String targetColor = title.split("the ")[1].split(" items")[0].toLowerCase();

        long currentTime = System.currentTimeMillis();
        if (currentTime - lastRecheckTime >= 1000) {
            clickedSlots.clear();
            lastRecheckTime = currentTime;
        }

        if (AppleSettings.terminalCustomColors) {
            List<Slot> correctSlots = new ArrayList<>();
            for (Slot slot : container.inventorySlots) {
                int slotId = container.inventorySlots.indexOf(slot);
                if (slot.inventory == Minecraft.getMinecraft().thePlayer.inventory || slotId == 49) continue;

                int row = slotId / COLUMNS;
                int col = slotId % COLUMNS;

                if (row < 1 || row > 4 || col < 1 || col > 7) continue;

                ItemStack item = slot.getStack();
                if (item == null || item.isItemEnchanted()) continue;

                if (isCorrectColor(item, targetColor)) {
                    correctSlots.add(slot);
                }
            }

            renderCustomGui(chest, correctSlots, targetColor);
        } else {
            handleDefaultGui(chest, targetColor);
        }
    
    }

    private void renderCustomGui(GuiChest chest, List<Slot> correctSlots, String targetColor) {
        ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
        float scale = TerminalGuiLayer.getGuiScale();
        int guiWidth = (int) (INNER_COLUMNS * SLOT_SIZE * scale);
        int guiHeight = (int) (INNER_ROWS * SLOT_SIZE * scale);
        int guiLeft = (sr.getScaledWidth() - guiWidth) / 2;
        int guiTop = (sr.getScaledHeight() - guiHeight) / 2;

        GlStateManager.pushMatrix();
        GlStateManager.translate(guiLeft, guiTop, 0);
        GlStateManager.scale(scale, scale, 1.0f);

        TerminalTheme.drawOverlay(INNER_COLUMNS * SLOT_SIZE, INNER_ROWS * SLOT_SIZE,
                capitalizeFirstLetter(targetColor));

        for (Slot slot : correctSlots) {
            if (!clickedSlots.contains(slot.slotNumber)) {
                int slotId = chest.inventorySlots.inventorySlots.indexOf(slot);
                int row = slotId / COLUMNS;
                int col = slotId % COLUMNS;

                int innerX = (col - 1) * SLOT_SIZE;
                int innerY = (row - 1) * SLOT_SIZE;

                TerminalTheme.drawTargetCell(innerX, innerY, SLOT_SIZE, SLOT_SIZE,
                        DungeonSolverColor.getColor(AppleSettings.solverCorrectColor).getRGB());
            }
        }
        GlStateManager.popMatrix();
    }

    private void handleDefaultGui(GuiChest chest, String targetColor) {
        ContainerChest container = (ContainerChest) chest.inventorySlots;
        for (Slot slot : container.inventorySlots) {
            if (slot.inventory == Minecraft.getMinecraft().thePlayer.inventory) continue;
            ItemStack item = slot.getStack();
            if (item == null) continue;

            int slotId = container.inventorySlots.indexOf(slot);
            if (slotId == 49 || item.isItemEnchanted()) {
                if (AppleSettings.terminalHideIncorrect) {
                    DungeonSolverRender.drawOnSlot(container.inventorySlots.size(), slot.xDisplayPosition,
                            slot.yDisplayPosition, 0xFF717171);
                }
                continue;
            }

            if (isCorrectColor(item, targetColor)) {
                DungeonSolverRender.drawOnSlot(container.inventorySlots.size(),
                        slot.xDisplayPosition, slot.yDisplayPosition,
                        DungeonSolverColor.getColor(AppleSettings.solverCorrectColor).getRGB());
            } else if (AppleSettings.terminalHideIncorrect) {
                DungeonSolverRender.drawOnSlot(container.inventorySlots.size(), slot.xDisplayPosition,
                        slot.yDisplayPosition, 0xFF717171);
            }
        }
    }

    @SubscribeEvent
    public void onMouseClick(GuiScreenEvent.MouseInputEvent.Pre event) {
        if (!AppleSettings.terminalPreventMissclicks && !AppleSettings.terminalCustomColors) return;
        if (!DungeonSolverContext.checkEssentialsF7()) return;
        if (!Mouse.getEventButtonState() || Mouse.getEventButton() != 0) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (!(mc.currentScreen instanceof GuiChest)) return;

        GuiChest guiChest = (GuiChest) mc.currentScreen;
        Container container = guiChest.inventorySlots;
        if (!(container instanceof ContainerChest)) return;

        String title = ((ContainerChest) container).getLowerChestInventory().getDisplayName().getUnformattedText();
        if (!title.startsWith("Select all the")) return;

        if (AppleSettings.terminalCustomColors) {
            handleCustomGuiClick(event, guiChest, title);
        } else {
            handleDefaultGuiClick(event, guiChest, title);
        }
    }

    private void handleCustomGuiClick(GuiScreenEvent.MouseInputEvent.Pre event, GuiChest guiChest, String title) {
        Minecraft mc = Minecraft.getMinecraft();
        ScaledResolution sr = new ScaledResolution(mc);
        float scale = TerminalGuiLayer.getGuiScale();

        int mouseX = (Mouse.getEventX() * sr.getScaledWidth()) / mc.displayWidth;
        int mouseY = sr.getScaledHeight() - (Mouse.getEventY() * sr.getScaledHeight()) / mc.displayHeight - 1;

        int guiWidth = (int) (INNER_COLUMNS * SLOT_SIZE * scale);
        int guiHeight = (int) (INNER_ROWS * SLOT_SIZE * scale);
        int guiLeft = (sr.getScaledWidth() - guiWidth) / 2;
        int guiTop = (sr.getScaledHeight() - guiHeight) / 2;

        if (mouseX < guiLeft || mouseX >= guiLeft + guiWidth ||
                mouseY < guiTop || mouseY >= guiTop + guiHeight) {
            event.setCanceled(true);
            return;
        }

        float relX = (mouseX - guiLeft) / scale;
        float relY = (mouseY - guiTop) / scale;

        String targetColor = title.split("the ")[1].split(" items")[0].toLowerCase();
        ContainerChest container = (ContainerChest) guiChest.inventorySlots;

        for (Slot slot : container.inventorySlots) {
            int slotId = container.inventorySlots.indexOf(slot);
            if (slot.inventory == mc.thePlayer.inventory || slotId == 49) continue;

            int row = slotId / COLUMNS;
            int col = slotId % COLUMNS;
            if (row < 1 || row > 4 || col < 1 || col > 7) continue;

            ItemStack item = slot.getStack();
            if (item == null || item.isItemEnchanted()) continue;

            if (isCorrectColor(item, targetColor)) {
                int innerX = (col - 1) * SLOT_SIZE;
                int innerY = (row - 1) * SLOT_SIZE;

                if (relX >= innerX && relX < innerX + SLOT_SIZE &&
                        relY >= innerY && relY < innerY + SLOT_SIZE) {
                    mc.playerController.windowClick(
                            container.windowId,
                            slot.slotNumber,
                            2,
                            0,
                            mc.thePlayer
                    );
                    playCompletionSound();
                    clickedSlots.add(slot.slotNumber);
                    event.setCanceled(true);
                    return;
                }
            }
        }
        event.setCanceled(true);
    }

    private void handleDefaultGuiClick(GuiScreenEvent.MouseInputEvent.Pre event, GuiChest guiChest, String title) {
        Slot hoveredSlot = guiChest.getSlotUnderMouse();
        if (hoveredSlot == null || hoveredSlot.getStack() == null
                || hoveredSlot.inventory == Minecraft.getMinecraft().thePlayer.inventory) return;
        ItemStack item = hoveredSlot.getStack();
        String targetColor;
        try {
            targetColor = title.split("the ", 2)[1].split(" items", 2)[0].toLowerCase(java.util.Locale.ROOT);
        } catch (RuntimeException ignored) {
            event.setCanceled(true);
            return;
        }
        if (item.isItemEnchanted() || !isCorrectColor(item, targetColor)) {
            event.setCanceled(true);
        } else {
            playCompletionSound();
        }
    }

    private boolean isCorrectColor(ItemStack item, String targetColor) {
        if (item.getItem() == Items.dye) {
            return targetColor.equals(DungeonSolverColorsDict.getColorFromDye(item.getMetadata()).toString());
        } else if (Block.getBlockFromItem(item.getItem()) instanceof BlockStainedGlassPane ||
                Block.getBlockFromItem(item.getItem()) instanceof BlockStainedGlass ||
                Block.getBlockFromItem(item.getItem()) instanceof BlockColored ||
                Block.getBlockFromItem(item.getItem()) instanceof BlockCarpet) {
            return targetColor.equals(DungeonSolverColorsDict.getColorFromMain(item.getMetadata()).toString());
        }
        return false;
    }

    private String capitalizeFirstLetter(String str) {
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }

    private void playCompletionSound() {
        Minecraft mc = Minecraft.getMinecraft();
        DungeonSolverSound.playSound(
                mc.thePlayer.getPosition(),
                "gui.button.press",
                1.0f,
                1.0f
        );
    }

    private static void drawRect(int left, int top, int right, int bottom, int color) {
        Gui.drawRect(left, top, right, bottom, color);
    }
}
