/*
 * This modified implementation follows the Better NEF / NotEnoughFakepixel behavior.
 * Maintained by ii8we; review LICENSE and NOTICE.md before use or redistribution.
 * Original code and third-party components remain subject to their applicable license terms.
 */

package dev.client.skyvelor.mixin;

import dev.client.skyvelor.feature.qol.ChatLineAccess;
import net.minecraft.client.gui.ChatLine;
import net.minecraft.util.IChatComponent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(ChatLine.class)
public abstract class MixinChatLine implements ChatLineAccess {
    @Unique private IChatComponent skyvelor$fullMessage;

    @Override
    public IChatComponent skyvelor$getFullMessage() {
        return skyvelor$fullMessage;
    }

    @Override
    public void skyvelor$setFullMessage(IChatComponent message) {
        this.skyvelor$fullMessage = message;
    }
}
