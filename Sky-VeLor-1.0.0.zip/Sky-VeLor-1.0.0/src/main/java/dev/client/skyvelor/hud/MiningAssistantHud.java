package dev.client.skyvelor.hud;

import dev.client.skyvelor.feature.MiningTracker;
import dev.client.skyvelor.feature.mining.MiningAbilityTracker;

import java.util.Locale;

/** Compact mining panel: current break rate, session total and status of a supported pickaxe ability. */
public final class MiningAssistantHud extends HudElement {

    public MiningAssistantHud() {
        super("miningAssistant", "Mining Assistant",
                new HudPlacement(HudPlacement.Anchor.START, 6, HudPlacement.Anchor.START, 42), false);
    }

    private String[] lines() {
        return new String[]{
                "Mining rate: " + String.format(Locale.ROOT, "%.2f", MiningTracker.rate()) + " blocks/s",
                "Session blocks: " + MiningTracker.total(),
                "Pickaxe ability: " + MiningAbilityTracker.statusText()
        };
    }

    @Override
    public float width() {
        String[] lines = lines();
        float widest = 0f;
        for (String line : lines) widest = Math.max(widest, textWidth(line));
        return 10f + widest + 10f;
    }

    @Override
    public float height() {
        return 10f + (9f * textScale() + 3f) * 3f;
    }

    @Override
    protected void drawContent() {
        float w = width();
        float h = height();
        drawPanel(w, h);
        String[] rows = lines();
        float y = 5f;
        float step = 9f * textScale() + 3f;
        for (String row : rows) {
            text(row, 8f, y, accentColor());
            y += step;
        }
    }
}
