# Sky VeLor Privacy Notice

This notice explains the optional **Dungeon Sync** feature in Sky VeLor. It describes the data used to share discovered dungeon Puzzle rooms between players. It does not claim that Cloudflare receives no network metadata.

## Dungeon Sync is optional

Dungeon Sync is **disabled by default**. To enable or disable it in Minecraft, open `/sv`, go to **Dungeon → Dungeon Sync**, and change **Enable Dungeon Sync**. The setting applies immediately. Turning it off closes the active synchronization connection and stops future Dungeon Sync traffic. Local puzzle detection and map labels continue to work without the shared service.

## What Sky VeLor sends for synchronization

When Dungeon Sync is enabled and a valid multi-player dungeon roster is available, the client sends synchronization data over a secure `wss://` connection. The Worker protocol uses:

- A temporary session fingerprint derived locally from the dungeon server ID, floor, and normalized party usernames. The raw usernames are **not** included in synchronization messages. The fingerprint is pseudonymous, not guaranteed anonymous, because someone who already knows likely party names may be able to test candidate rosters.
- Puzzle names, room-origin coordinates, and confidence values needed to share discoveries.
- A temporary connection/member identifier used to track an active WebSocket connection.

Sky VeLor does not intentionally place a player's IP address, raw Minecraft username, rank text, class badge, class level, or player level in the puzzle synchronization payload.

## IP addresses and ordinary internet connections

When a device connects directly to a website or online service, that service's network infrastructure can generally see the public source IP address used for the connection. This is normal internet behavior and is not unique to Sky VeLor. A VPN or proxy may cause the destination to see the VPN/proxy address instead, but then the intermediary handles the original connection.

Many home internet providers use **dynamic public IP addresses**. Depending on the provider, service plan, and router/network configuration, the public IP may change when the router reconnects or its lease renews. It may change from time to time, but **it is not guaranteed to change every day**, and restarting the router does not guarantee a new IP address. Some connections use a static address or carrier-grade NAT, and behavior varies by provider.

A changing IP can make long-term correlation less straightforward in some circumstances, but it is **not by itself a privacy or security guarantee**. Services may still associate visits through accounts, cookies, device/browser characteristics, timestamps, or other connection metadata. An IP address may also reveal an approximate network location; it generally does not, by itself, prove a person's exact home address or identity.

## IP addresses and Cloudflare

**Cloudflare receives the source IP address when a player connects directly to the Cloudflare Worker.** Sky VeLor cannot prevent the source IP from reaching Cloudflare's network in this direct-connection design. Encrypting the WebSocket connection protects data in transit; it does not hide the source IP from the service receiving the connection.

The project's Worker deployment configuration disables automatic invocation logs (`invocation_logs: false`) while allowing custom Worker logs to remain available for diagnostics. This reduces automatic invocation logging; it does **not** stop Cloudflare from processing connection metadata, remove historical logs by itself, or guarantee that no IP-related data exists anywhere in Cloudflare's systems. Cloudflare's own handling and retention of network metadata are governed by Cloudflare's policies and service terms.

The Worker does not need raw player usernames to route puzzle discoveries and does not intentionally write player IP addresses or raw usernames into application logs. Maintainers should not add code that logs the full request, IP-related headers, or sensitive connection metadata.

## Temporary puzzle data

The Durable Object temporarily stores accepted Puzzle labels and room coordinates while a session is active. The Worker is designed to delete the stored room state five seconds after the last WebSocket connection closes and to clear stale room state when a new first connection starts. This describes the application's puzzle-state behavior; it is not a promise about Cloudflare's provider-level network metadata retention.

## Player choice

You can always disable Dungeon Sync at any time from `/sv` → **Dungeon** → **Dungeon Sync** → **Enable Dungeon Sync**. Disabling it closes the active synchronization connection and stops future sharing; you can continue using local puzzle detection and the dungeon map without synchronization.

**Important limitation:** If you do not want Cloudflare to receive your connection IP, leave Dungeon Sync disabled. Hiding an IP from Cloudflare would require a separate intermediary service, which would itself receive the player's IP address. A dynamic IP may change over time, but that does not change the fact that Cloudflare receives the source IP used for each direct connection.
