#!/bin/sh
# Compiles and runs the pure-logic, config, text and migration tests. No game is started.
#
# Needs a JDK 8, compiled classes (build/classes/main), and either TEST_CP (the complete Forge test classpath)
# or the MC_JAR, LOG4J_JAR and GSON_JAR paths used by the legacy invocation.
# Example after `gradle build dumpTestClasspath`:
#   TEST_CP="$(cat build/test-classpath.txt)" sh tests/run-tests.sh
set -e
HERE=$(cd "$(dirname "$0")/.." && pwd)
CLASSES="${CLASSES:-$HERE/build/classes/main}"
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT
if [ -n "${TEST_CP:-}" ]; then
  CP="$CLASSES:$TEST_CP"
else
  : "${MC_JAR:?set MC_JAR to minecraft_merged-1.8.9.jar, or set TEST_CP}"
  : "${LOG4J_JAR:?set LOG4J_JAR to the log4j-api jar, or set TEST_CP}"
  : "${GSON_JAR:?set GSON_JAR to the gson jar, or set TEST_CP}"
  CP="$CLASSES:$MC_JAR:$LOG4J_JAR:$GSON_JAR"
fi
javac -nowarn -encoding UTF-8 -cp "$CP" -d "$OUT" $(find "$HERE/tests" -name '*.java')
java -cp "$OUT:$CP" dev.client.skyvelor.gui.PureLogicTests
java -cp "$OUT:$CP" dev.client.skyvelor.hud.ConfigTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.LeapTextTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.SkyblockContextPolicyTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.AutoSprintTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.inventory.InventoryLayoutPolicyTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.LeapIdentityTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.LeapClassCacheTests
java -cp "$OUT:$CP" dev.client.skyvelor.config.ConfigFilesTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.protection.ProtectedItemStoreTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.protection.ProtectedItemActionPolicyTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.inventory.SlotLockStoreTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.inventory.SlotBindingGesturePolicyTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.qol.InventorySearchMatcherTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.qol.RomanNumeralParserTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.qol.ItemRarityColorsTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.qol.TooltipScrollWindowTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.qol.ChatCopyTextPolicyTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.qol.ChatLengthPolicyTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.mining.MiningAbilityCooldownTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.mining.MiningPuzzlerRouteTests
java -cp "$OUT:$CP" dev.client.skyvelor.config.AppleSettingsTests
java -cp "$OUT:$CP" dev.client.skyvelor.render.ThemeTests
java -cp "$OUT:$CP" dev.client.skyvelor.hud.DollConfigTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.LeapClassTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.SpiritLeapTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.DungeonContextTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.MobMarkersTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.StarredMobPolicyTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.qol.ChatNoiseFilterPolicyTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.qol.EntityVisualPolicyTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.BloodMobMatcherTests
java -cp "$OUT:$CP" dev.client.skyvelor.dungeon.M7DetectionTests
java -cp "$OUT:$CP" dev.client.skyvelor.gui.LeapLayoutTests
java -cp "$OUT:$CP" dev.client.skyvelor.gui.WindowControlsTests
java -cp "$OUT:$CP" dev.client.skyvelor.gui.LeapPaletteTests
java -cp "$OUT:$CP" dev.client.skyvelor.gui.LeapPreviewDataTests
java -cp "$OUT:$CP" dev.client.skyvelor.hud.StatsTextTests
java -cp "$OUT:$CP" dev.client.skyvelor.startup.StartupTimingTests
java -cp "$OUT:$CP" dev.client.skyvelor.fishing.FishingTests
java -cp "$OUT:$CP" dev.client.skyvelor.dungeon.DungeonBossHpTests
java -cp "$OUT:$CP" dev.client.skyvelor.dungeon.DungeonScoreMathTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.ChatFilterRulesTests
java -cp "$OUT:$CP" dev.client.skyvelor.chat.ClipboardChainTests
java -cp "$OUT:$CP" dev.client.skyvelor.chat.ChatMenuInputRouterTests
java -cp "$OUT:$CP" dev.client.skyvelor.chat.ChatMessageHistoryTests
java -cp "$OUT:$CP" dev.client.skyvelor.chat.ChatInputInsertionTests
java -cp "$OUT:$CP" dev.client.skyvelor.chat.ChatPlayerNameTests
java -cp "$OUT:$CP" dev.client.skyvelor.chat.ChatShiftClickGestureTests
java -cp "$OUT:$CP" dev.client.skyvelor.chat.ChatVisibilityAuditTests
java -cp "$OUT:$CP" dev.client.skyvelor.chat.ChatCompactMessagesPolicyTests
java -cp "$OUT:$CP" dev.client.skyvelor.chat.ChatCompactMessagesTests
java -cp "$OUT:$CP" dev.client.skyvelor.chat.RomanNumeralsTests
java -cp "$OUT:$CP" dev.client.skyvelor.config.ChatQolSettingsTests
java -cp "$OUT:$CP" dev.client.skyvelor.config.FontSettingsTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.ChatInteractionModelTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.ChatTabsTests
java -cp "$OUT:$CP" dev.client.skyvelor.gui.ChatQolLayoutTests
java -cp "$OUT:$CP" dev.client.skyvelor.gui.GuiLayoutToolkitTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.FirstPersonItemTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.ItemAnimationTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.SwingEasingTests
java -cp "$OUT:$CP" dev.client.skyvelor.feature.VisualSwingStateMachineTests
java -cp "$OUT:$CP" dev.client.skyvelor.config.ItemAnimationSettingsTests
java -cp "$OUT:$CP" dev.client.skyvelor.dungeon.DragonKillTests
java -cp "$OUT:$CP" dev.client.skyvelor.slayer.SlayerTests
java -cp "$OUT:$CP" dev.client.skyvelor.widget.SearchFieldTests
java -cp "$OUT:$CP" dev.client.skyvelor.widget.WidgetInteractionTests

java -cp "$OUT:$CP" dev.client.skyvelor.dungeon.PuzzleRoomDataTests
java -cp "$OUT:$CP" dev.client.skyvelor.dungeon.sync.DungeonSyncIdentityTests
java -cp "$OUT:$CP" dev.client.skyvelor.dungeon.sync.DungeonSyncReconnectPolicyTests
java -cp "$OUT:$CP" dev.client.skyvelor.dungeon.sync.DungeonPuzzleSyncConfigTests
java -cp "$OUT:$CP" dev.client.skyvelor.dungeon.sync.DungeonSyncReminderPolicyTests
java -cp "$OUT:$CP" dev.client.skyvelor.dungeon.PuzzleRoomMemoryTests
java -cp "$OUT:$CP" dev.client.skyvelor.dungeon.DungeonMapLabelAnchorTests
java -cp "$OUT:$CP" dev.client.skyvelor.dungeon.PuzzleLabelsTests
java -cp "$OUT:$CP" dev.client.skyvelor.dungeon.DungeonMapProjectionTests
java -cp "$OUT:$CP" dev.client.skyvelor.dungeon.DungeonMapLabelLayoutTests
java -cp "$OUT:$CP" dev.client.skyvelor.dungeon.DungeonMapPlayerNameAssignmentsTests
java -cp "$OUT:$CP" dev.client.skyvelor.dungeon.DungeonMapPartyRosterTests
java -cp "$OUT:$CP" dev.client.skyvelor.dungeon.solver.DungeonSolverColorTests
java -cp "$OUT:$CP" dev.client.skyvelor.dungeon.solver.terminals.TerminalDebugTests
