package dev.client.skyvelor.dungeon;

import java.util.ArrayList;
import java.util.List;

public final class PuzzleRoomMemoryTests {
    private static int passed;
    private static int failed;

    public static void main(String[] args) {
        PuzzleRoomMemory memory = new PuzzleRoomMemory();
        List<PuzzleRoomMemory.RoomLabel> reusableSnapshot = new ArrayList<PuzzleRoomMemory.RoomLabel>();
        reusableSnapshot.addAll(memory.snapshot());
        memory.snapshotInto(reusableSnapshot);
        check("reusable snapshot starts empty", reusableSnapshot.isEmpty());
        memory.remember("Silverfish", 32, 70, 64, 0.96D);
        memory.snapshotInto(reusableSnapshot);
        check("reusable snapshot updates after a room is remembered", reusableSnapshot.size() == 1
                && "Silverfish".equals(reusableSnapshot.get(0).name));
        check("successful match is remembered", memory.size() == 1);
        memory.remember("Boulder", 64, 70, 64, 0.91D);
        check("second puzzle room is remembered", memory.size() == 2);
        check("earlier room remains after another room is added",
                "Silverfish".equals(memory.snapshot().get(0).name));
        check("first map-space anchor is stored", memory.rememberMapPosition(32, 70, 64, 41.5F, 62.0F));
        check("duplicate anchor update is rejected", !memory.rememberMapPosition(32, 70, 64, 15.0F, 20.0F));
        PuzzleRoomMemory.RoomLabel anchored = memory.snapshot().get(0);
        check("cached map-space anchor stays fixed", anchored.hasMapPosition()
                && Math.abs(anchored.mapX() - 41.5F) < 0.001F
                && Math.abs(anchored.mapY() - 62.0F) < 0.001F);
        check("live anchor stores its first valid projection",
                memory.updateMapPosition(64, 70, 64, 31.0F, 42.0F));
        PuzzleRoomMemory.RoomLabel secondRoom = memory.snapshot().get(1);
        check("live anchor is marked as positioned", secondRoom.hasMapPosition()
                && Math.abs(secondRoom.mapX() - 31.0F) < 0.001F
                && Math.abs(secondRoom.mapY() - 42.0F) < 0.001F);
        check("live anchor refresh reports subsequent updates without claiming first capture",
                !memory.updateMapPosition(64, 70, 64, 45.0F, 56.0F));
        check("explicit anchor refresh changes the cached anchor", 
                Math.abs(secondRoom.mapX() - 45.0F) < 0.001F
                        && Math.abs(secondRoom.mapY() - 56.0F) < 0.001F);
        check("stable capture rejects subsequent marker-driven overwrite",
                !memory.rememberMapPosition(64, 70, 64, 63.0F, 64.0F)
                        && Math.abs(secondRoom.mapX() - 45.0F) < 0.001F
                        && Math.abs(secondRoom.mapY() - 56.0F) < 0.001F);
        memory.remember("Silverfish", 32, 70, 64, 0.72D);
        check("same world coordinates do not create duplicates", memory.size() == 2);
        check("weaker match does not replace stronger room data",
                "Silverfish".equals(memory.snapshot().get(0).name)
                        && Math.abs(memory.snapshot().get(0).confidence - 0.96D) < 0.0001D);
        memory.remember("", 96, 70, 96, 1.0D);
        memory.remember("Fake", 96, 70, 96, 0.4D);
        check("empty or low-confidence detections are ignored", memory.size() == 2);
        memory.remember("Three Weirdos", 32, 70, 64, 0.99D);
        check("better match corrects the same coordinate", memory.size() == 2
                && "Three Weirdos".equals(memory.snapshot().get(0).name));
        PuzzleRoomMemory.RoomLabel corrected = memory.snapshot().get(0);
        check("corrected puzzle name preserves original map anchor", corrected.hasMapPosition()
                && Math.abs(corrected.mapX() - 41.5F) < 0.001F
                && Math.abs(corrected.mapY() - 62.0F) < 0.001F);
        memory.clearMapPositions();
        check("new map texture invalidates old map-space anchors", !corrected.hasMapPosition());
        check("new map texture can capture a fresh anchor",
                memory.rememberMapPosition(32, 70, 64, 52.0F, 47.0F)
                        && Math.abs(corrected.mapX() - 52.0F) < 0.001F
                        && Math.abs(corrected.mapY() - 47.0F) < 0.001F);
        memory.clear();
        memory.snapshotInto(reusableSnapshot);
        check("memory clears at dungeon end", memory.size() == 0);
        check("reusable snapshot clears old room references", reusableSnapshot.isEmpty());
        System.out.println("PuzzleRoomMemoryTests: passed " + passed + ", failed " + failed);
        if (failed > 0) System.exit(1);
    }

    private static void check(String name, boolean condition) {
        if (condition) passed++;
        else { failed++; System.out.println("FAIL: " + name); }
    }
}
