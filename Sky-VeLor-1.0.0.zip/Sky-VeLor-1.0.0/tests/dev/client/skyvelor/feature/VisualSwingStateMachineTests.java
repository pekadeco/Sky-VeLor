package dev.client.skyvelor.feature;

/** Pure visual-timeline tests: no Minecraft input, player, packet, or world object is created. */
public final class VisualSwingStateMachineTests {

    private static int passed;
    private static int failed;

    public static void main(String[] args) {
        idleNeverStartsASwing();
        realVanillaSwingPlaysOnce();
        secondRealSwingStartsAfterTheFirstFinishes();
        spamDoesNotRestartMidway();

        System.out.println();
        System.out.println("visual swing state machine: passed " + passed + ", failed " + failed);
        if (failed > 0) System.exit(1);
    }

    private static void idleNeverStartsASwing() {
        VisualSwingStateMachine swing = new VisualSwingStateMachine();
        float result = VisualSwingStateMachine.USE_VANILLA;
        // Holding a mouse button is deliberately not represented here: only vanilla's actual swing state matters.
        for (int tick = 0; tick <= 30; tick++) {
            result = swing.advance(tick, false, 1f);
        }
        check("no vanilla swing never creates a synthetic animation", result == VisualSwingStateMachine.USE_VANILLA);
        check("idle state never starts/repeats cycles", swing.getStarts() == 0L && !swing.isActive());
    }

    private static void realVanillaSwingPlaysOnce() {
        VisualSwingStateMachine swing = new VisualSwingStateMachine();
        swing.advance(0f, true, 1f);
        for (int tick = 1; tick <= 7; tick++) {
            swing.advance(tick, tick < 5, 1f);
        }
        check("one real swing starts exactly one visual cycle", swing.getStarts() == 1L);
        check("one real swing completes without held-input repetition", !swing.isActive());
    }

    private static void secondRealSwingStartsAfterTheFirstFinishes() {
        VisualSwingStateMachine swing = new VisualSwingStateMachine();
        swing.advance(0f, true, 1f);
        for (int tick = 1; tick <= 8; tick++) swing.advance(tick, false, 1f);
        swing.advance(9f, true, 1f);
        check("a separate real vanilla swing can start a new cycle", swing.getStarts() == 2L && swing.isActive());
    }

    private static void spamDoesNotRestartMidway() {
        VisualSwingStateMachine swing = new VisualSwingStateMachine();
        swing.advance(0f, true, 1f);
        swing.advance(1f, false, 1f);
        float before = swing.advance(2f, true, 1f);
        float after = swing.advance(3f, true, 1f);
        check("new swing edge does not add a midway restart", swing.getStarts() == 1L);
        check("visual progress keeps moving forward", after > before);
    }

    private static void check(String name, boolean ok) {
        if (ok) passed++;
        else { failed++; System.out.println("FAIL " + name); }
    }
}
