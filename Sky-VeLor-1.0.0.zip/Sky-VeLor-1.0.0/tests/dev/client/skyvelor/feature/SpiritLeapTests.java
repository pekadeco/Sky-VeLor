package dev.client.skyvelor.feature;

/** Checks the Spirit Leap menu decision (title or recent use) and the held-item name check. */
public final class SpiritLeapTests {

    private static int passed;
    private static int failed;

    public static void main(String[] args) {
        titleAlwaysCounts();
        fallbackNeedsEveryCondition();
        itemNames();
        System.out.println();
        System.out.println("spirit leap: passed " + passed + ", failed " + failed);
        if (failed > 0) {
            System.exit(1);
        }
    }

    private static void check(String name, boolean ok, String detail) {
        if (ok) {
            passed++;
        } else {
            failed++;
            System.out.println("FAIL " + name + " " + detail);
        }
    }

    private static void titleAlwaysCounts() {
        check("exact title in dungeon", SpiritLeap.decide(true, false, true, 0), "");
        check("title outside dungeon is not custom", !SpiritLeap.decide(true, false, false, 0), "");
    }

    private static void fallbackNeedsEveryCondition() {
        check("no title, no use", !SpiritLeap.decide(false, false, true, 3), "");
        check("recent leap use is not enough", !SpiritLeap.decide(false, true, true, 3), "");
        check("recent use and teammate heads still do not classify Bazaar", !SpiritLeap.decide(false, true, true, 1), "");
        check("title outside dungeon remains vanilla", !SpiritLeap.decide(true, true, false, 1), "");
    }

    private static void itemNames() {
        check("plain", LeapUse.isLeapItemName("Spirit Leap"), "");
        check("coloured", LeapUse.isLeapItemName("\u00a7bSpirit Leap"), "");
        check("case", LeapUse.isLeapItemName("spirit leap"), "");
        check("other item", !LeapUse.isLeapItemName("Iron Sword"), "");
        check("null", !LeapUse.isLeapItemName(null), "");
        check("partial", !LeapUse.isLeapItemName("Leap"), "");
    }
}
