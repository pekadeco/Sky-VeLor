package dev.client.lunaria.feature;

/**
 * Allocation-free visual swing timeline used only by the first-person ItemRenderer hook.
 * A timeline begins only on a real Minecraft {@code isSwingInProgress} rising edge. It never reads mouse/key
 * input and never manufactures or repeats a swing merely because a button remains down.
 */
public final class VisualSwingStateMachine {

    public static final float SWING_TICKS = 6.0F;
    /** Returned when the hook should keep vanilla's local swing value for this frame. */
    public static final float USE_VANILLA = -1.0F;

    private boolean active;
    private boolean sawVanillaSwing;
    private float startedAt;
    private float lastClock;
    private float lastRaw;
    private long starts;

    /**
     * Advances a renderer-only timeline for an actual vanilla swing transition. A held mouse button is not an
     * input to this method, so it cannot start or repeat cycles. Further swing edges while one visual cycle is
     * active do not restart it midway.
     */
    public float advance(float clockTicks, boolean vanillaSwinging, float speed) {
        if (!(speed > 0.0F) || Float.isNaN(speed) || Float.isInfinite(speed)) {
            reset();
            return USE_VANILLA;
        }
        if (clockTicks < lastClock) {
            resetTimeline();
            sawVanillaSwing = false;
        }
        lastClock = clockTicks;

        boolean vanillaStarted = vanillaSwinging && !sawVanillaSwing;
        sawVanillaSwing = vanillaSwinging;

        if (!active) {
            if (!vanillaStarted) {
                return USE_VANILLA;
            }
            begin(clockTicks);
        }

        // Match the UI range; malformed external values must not cause negative or infinite cycles.
        float visualSpeed = Math.max(0.25F, Math.min(4.0F, speed));
        float duration = SWING_TICKS / visualSpeed;
        float raw = (clockTicks - startedAt) / duration;
        if (raw >= 1.0F) {
            active = false;
            lastRaw = 1.0F;
            return 1.0F;
        }
        if (raw <= 0.0F) {
            lastRaw = 0.0F;
            return 0.0F;
        }
        // Never let a real click or a clock adjustment move the visual cycle backwards.
        if (raw < lastRaw) {
            raw = lastRaw;
        }
        lastRaw = raw;
        return raw;
    }

    public void reset() {
        resetTimeline();
        sawVanillaSwing = false;
        lastClock = 0.0F;
    }

    public boolean isActive() {
        return active;
    }

    /** Number of timeline starts, exposed only for headless state-machine verification. */
    public long getStarts() {
        return starts;
    }

    private void begin(float clockTicks) {
        active = true;
        startedAt = clockTicks;
        lastRaw = 0.0F;
        starts++;
    }

    private void resetTimeline() {
        active = false;
        startedAt = 0.0F;
        lastRaw = 0.0F;
    }
}
