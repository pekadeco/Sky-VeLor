package dev.client.lunaria;

import dev.client.lunaria.command.ClientActions;
import dev.client.lunaria.command.PriceSetCommand;
import dev.client.lunaria.command.QuickNoteCommand;
import dev.client.lunaria.command.SvCommand;
import dev.client.lunaria.config.AppleSettings;
import dev.client.lunaria.itemlockswap.ItemLockSwapSettings;
import dev.client.lunaria.itemlockswap.ItemLockSwapKeybind;
import dev.client.lunaria.itemlockswap.ItemLockSwapController;
import dev.client.lunaria.itemlockswap.ItemLockSwapOverlay;
import dev.client.lunaria.assist.dungeon.DungeonRunTracker;
import dev.client.lunaria.assist.dungeon.RoomClearAlertController;
import dev.client.lunaria.assist.visual.AspectTeleportTransitionRenderer;
import dev.client.lunaria.dungeon.DragonKillAlert;
import dev.client.lunaria.dungeon.DungeonMapOverlay;
import dev.client.lunaria.dungeon.DungeonProgressTracker;
import dev.client.lunaria.dungeon.WitherDoorHighlight;
import dev.client.lunaria.dungeon.SpiritBowTracer;
import dev.client.lunaria.dungeon.PuzzleRoomDatabase;
import dev.client.lunaria.dungeon.solver.puzzles.BoulderSolver;
import dev.client.lunaria.dungeon.solver.puzzles.CreeperSolver;
import dev.client.lunaria.dungeon.solver.puzzles.SilverFishSolver;
import dev.client.lunaria.dungeon.solver.puzzles.TeleportMazeSolver;
import dev.client.lunaria.dungeon.solver.puzzles.ThreeWeirdos;
import dev.client.lunaria.dungeon.solver.puzzles.WaterSolver;
import dev.client.lunaria.dungeon.solver.devices.FirstDeviceSolver;
import dev.client.lunaria.dungeon.solver.devices.ThirdDeviceSolver;
import dev.client.lunaria.dungeon.solver.terminals.ClickInOrderSolver;
import dev.client.lunaria.dungeon.solver.terminals.ClickOnColorsSolver;
import dev.client.lunaria.dungeon.solver.terminals.CorrectPanesSolver;
import dev.client.lunaria.dungeon.solver.terminals.HideTooltips;
import dev.client.lunaria.dungeon.solver.terminals.MazeSolver;
import dev.client.lunaria.dungeon.solver.terminals.StartingWithSolver;
import dev.client.lunaria.dungeon.solver.terminals.TerminalTracker;
import dev.client.lunaria.dungeon.solver.terminals.TerminalWaypoints;
import dev.client.lunaria.dungeon.solver.terminals.TerminalSimulatorCommand;
import dev.client.lunaria.dungeon.solver.terminals.TerminalDebug;
import dev.client.lunaria.dungeon.solver.terminals.TerminalDebugCommand;
import dev.client.lunaria.dungeon.solver.terminals.TerminalGuiLayer;
import dev.client.lunaria.dungeon.M7OverlayRenderer;
import dev.client.lunaria.fishing.FishingStats;
import dev.client.lunaria.slayer.SlayerTracker;
import dev.client.lunaria.feature.DungeonContext;
import dev.client.lunaria.feature.ChatChannelTabs;
import dev.client.lunaria.feature.SkyblockContext;
import dev.client.lunaria.feature.LeapUse;
import dev.client.lunaria.feature.SpiritLeap;
import dev.client.lunaria.feature.mining.MiningAbilityTracker;
import dev.client.lunaria.feature.mining.MiningPuzzlerSolver;
import dev.client.lunaria.feature.protection.ItemProtection;
import dev.client.lunaria.feature.AutoSprint;
import dev.client.lunaria.feature.inventory.SlotLocking;
import dev.client.lunaria.feature.inventory.ContainerOverlayRenderer;
import dev.client.lunaria.feature.qol.ChatCopy;
import dev.client.lunaria.feature.qol.InventoryQoL;
import dev.client.lunaria.feature.qol.TooltipQoL;
import dev.client.lunaria.feature.qol.RemoveIrritatingMessages;
import dev.client.lunaria.feature.qol.EntityVisualCleanup;
import dev.client.lunaria.feature.qol.EquipmentOverlay;
import dev.client.lunaria.events.PacketHandler;
import dev.client.lunaria.gui.AppleHubScreen;
import dev.client.lunaria.gui.AppleGuiButton;
import dev.client.lunaria.gui.HudEditorScreen;
import dev.client.lunaria.gui.LeapScreen;
import dev.client.lunaria.gui.LoadingScreen;
import dev.client.lunaria.hud.HudManager;
import dev.client.lunaria.render.Theme;
import dev.client.lunaria.render.MobHighlight;
import dev.client.lunaria.render.BloodMobHighlight;
import dev.client.lunaria.startup.StartupTasks;
import net.minecraft.client.Minecraft;
import net.minecraft.network.NetworkManager;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;
import io.netty.channel.ChannelPipeline;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

/**
 * Entry point for Lunaria Mod. Client-only. Adds:
 *  - a keybind (default Right Shift) that opens the hub from gameplay,
 *  - a "Lunaria Mod" button on the main menu and pause menu,
 *  - movable HUD elements (Mining BPS, inventory, hotbar, player doll and feature HUDs) with an editor,
 *  - the Spirit Leap teammate selector, which replaces only the server-opened Spirit Leap menu when enabled,
 *  - a loading screen that runs Lunaria Mod's own startup tasks,
 *  - M7 dungeon overlay, boss and dragon hitboxes, and the dragon kill alert,
 *  - fishing counters (including Common Creature total), Festival best, Sea Creature HP, nearby Yeti alerts and dungeon boss HP.
 * Most hooks use standard Forge 1.8.9 events. The device solver also observes outgoing packets through a
 * Netty handler installed from Forge's client-connection event and retried until the channel is ready. A small set of client-only Mixin hooks handles inventory clicks, camera effects, block particles, and wrapped chat-line access.
 */
@Mod(modid = LunariaMod.MODID,
        name = LunariaMod.NAME,
        version = LunariaMod.VERSION,
        acceptedMinecraftVersions = "[1.8.9]",
        clientSideOnly = true)
public class LunariaMod {

    /** The modid stays as it was. It names the asset folder and the keybind ids, so changing it would break them. */
    public static final String MODID = "lunaria";
    public static final String NAME = LunariaVersion.DISPLAY_NAME;
    public static final String VERSION = LunariaVersion.NAME;

    /** Unique-enough id for our injected menu button (vanilla ids are < 200). */
    private static final int MENU_BUTTON_ID = 0x41504C;

    /** The keybind id is kept so a binding the player already set still works. Only its category name changed. */
    public static final KeyBinding OPEN_KEY =
            new KeyBinding("key.lunaria.open", Keyboard.KEY_RSHIFT, "key.categories.lunaria");

    /**
     * Use Spirit Leap: default unbound. Pressing it while holding a Spirit Leap item sends the same right-click
     * the game sends. The server still opens its own leap menu first, and only then can the teammate picker show.
     */
    public static final KeyBinding LEAP_KEY =
            new KeyBinding("key.lunaria.leap", Keyboard.KEY_NONE, "key.categories.lunaria");
    public static final KeyBinding WARDROBE_KEY =
            new KeyBinding("key.lunaria.wardrobe", Keyboard.KEY_NONE, "key.categories.lunaria");
    public static final KeyBinding PETS_KEY =
            new KeyBinding("key.lunaria.pets", Keyboard.KEY_NONE, "key.categories.lunaria");
    public static final KeyBinding WARDROBE_SHORTCUT_KEY = WARDROBE_KEY;
    public static final KeyBinding PETS_SHORTCUT_KEY = PETS_KEY;
    /** Hold the key over a slot to lock/unlock it, or drag from one player slot to another to create a swap pair. */
    public static final KeyBinding ITEM_LOCK_SWAP_KEY =
            new KeyBinding("key.lunaria.itemLockSwap", Keyboard.KEY_L, "key.categories.lunaria");

    private boolean loadingShown;
    private volatile NetworkManager pendingPacketBridgeManager;
    private long packetBridgeWaitStartedAt;
    private boolean packetBridgeWaitNoticeShown;
    private final M7OverlayRenderer m7Overlay = new M7OverlayRenderer();
    private final BloodMobHighlight bloodMobHighlight = new BloodMobHighlight();
    private final MobHighlight mobHighlight = new MobHighlight();
    private final DungeonMapOverlay dungeonMapOverlay = new DungeonMapOverlay();
    private final WitherDoorHighlight witherDoorHighlight = new WitherDoorHighlight();
    private final SpiritBowTracer spiritBowTracer = new SpiritBowTracer();
    private final EquipmentOverlay equipmentOverlay = new EquipmentOverlay();
    private final DragonKillAlert dragonKill = new DragonKillAlert(m7Overlay);
    private final FishingStats fishingStats = new FishingStats();
    private final SlayerTracker slayerTracker = new SlayerTracker();
    private final ItemProtection itemProtection = new ItemProtection();
    private final SlotLocking slotLocking = new SlotLocking();
    private final ItemLockSwapController itemLockSwapController = new ItemLockSwapController();
    private final ItemLockSwapOverlay itemLockSwapOverlay = new ItemLockSwapOverlay();
    private final RoomClearAlertController roomClearAlertController = new RoomClearAlertController();
    private final AspectTeleportTransitionRenderer aspectTeleportTransition = new AspectTeleportTransitionRenderer();
    private final AutoSprint autoSprint = new AutoSprint();
    private final RemoveIrritatingMessages removeIrritatingMessages = new RemoveIrritatingMessages();
    private final EntityVisualCleanup entityVisualCleanup = new EntityVisualCleanup();
    private final InventoryQoL inventoryQoL = new InventoryQoL();
    private final ContainerOverlayRenderer containerOverlayRenderer =
            new ContainerOverlayRenderer(inventoryQoL, itemProtection);
    private final TooltipQoL tooltipQoL = new TooltipQoL();
    private final ChatCopy chatCopy = new ChatCopy();
    private final ChatChannelTabs chatChannelTabs = new ChatChannelTabs();
    private final MiningAbilityTracker miningAbilityTracker = new MiningAbilityTracker();
    private final MiningPuzzlerSolver miningPuzzlerSolver = new MiningPuzzlerSolver();

    private final BoulderSolver boulderSolver = new BoulderSolver();
    private final CreeperSolver creeperSolver = new CreeperSolver();
    private final SilverFishSolver silverFishSolver = new SilverFishSolver();
    private final TeleportMazeSolver teleportMazeSolver = new TeleportMazeSolver();
    private final ThreeWeirdos threeWeirdosSolver = new ThreeWeirdos();
    private final WaterSolver waterSolver = new WaterSolver();
    private final FirstDeviceSolver firstDeviceSolver = new FirstDeviceSolver();
    private final ThirdDeviceSolver thirdDeviceSolver = new ThirdDeviceSolver();
    private final ClickInOrderSolver clickInOrderSolver = new ClickInOrderSolver();
    private final ClickOnColorsSolver clickOnColorsSolver = new ClickOnColorsSolver();
    private final CorrectPanesSolver correctPanesSolver = new CorrectPanesSolver();
    private final HideTooltips hideTooltips = new HideTooltips();
    private final MazeSolver mazeSolver = new MazeSolver();
    private final StartingWithSolver startingWithSolver = new StartingWithSolver();
    private final TerminalTracker terminalTracker = new TerminalTracker();
    private final TerminalDebug terminalDebug = new TerminalDebug();
    private final TerminalGuiLayer terminalGuiLayer = new TerminalGuiLayer();
    private final TerminalWaypoints terminalWaypoints = new TerminalWaypoints();

    @EventHandler
    public void init(FMLInitializationEvent event) {
        // Settings are read here so the first screen has them. The loading screen runs the rest.
        AppleSettings.load();
        // Item Lock and Swap is the sole active slot gesture model. Turn off the legacy listener state on every
        // startup so a partially migrated/unreadable configuration can never reactivate a second click handler.
        boolean hadLegacySlotSettings = AppleSettings.slotLockingEnabled || AppleSettings.slotBindingEnabled;
        AppleSettings.slotLockingEnabled = false;
        AppleSettings.slotBindingEnabled = false;
        // Import old local locks/bindings once before saving the new settings, preserving existing user protection.
        if (ItemLockSwapSettings.needsLegacyMigration()) {
            if (SlotLocking.migrateStoredStateToItemLockSwap()) {
                AppleSettings.save();
            }
        } else if (hadLegacySlotSettings) {
            // Existing Item Lock and Swap data is authoritative; persist retirement of the old gesture settings.
            AppleSettings.save();
        }
        Theme.refresh();
        ClientRegistry.registerKeyBinding(OPEN_KEY);
        ClientRegistry.registerKeyBinding(LEAP_KEY);
        ClientRegistry.registerKeyBinding(WARDROBE_KEY);
        ClientRegistry.registerKeyBinding(PETS_KEY);
        ITEM_LOCK_SWAP_KEY.setKeyCode(ItemLockSwapKeybind.validStoredKeyCode(ItemLockSwapSettings.keyCode)
                ? ItemLockSwapSettings.keyCode : Keyboard.KEY_L);
        ClientRegistry.registerKeyBinding(ITEM_LOCK_SWAP_KEY);
        ClientRegistry.registerKeyBinding(ItemProtection.PROTECT_KEY);
        // The legacy key defaults to L too. Item Lock and Swap owns L now; unbind the superseded gesture
        // rather than leave two keybinds competing until the user explicitly rebinds it in Controls.
        if (SlotLocking.LOCK_SLOT_KEY.getKeyCode() == ITEM_LOCK_SWAP_KEY.getKeyCode()) {
            SlotLocking.LOCK_SLOT_KEY.setKeyCode(Keyboard.KEY_NONE);
        }
        ClientRegistry.registerKeyBinding(SlotLocking.LOCK_SLOT_KEY);
        KeyBinding.resetKeyBindingArrayAndHash();
        StartupTasks.add("Reading the HUD layout", HudManager::ensureLoaded);
        StartupTasks.add("Applying the theme", Theme::refresh);
        StartupTasks.add("Reading fishing counters", FishingStats::load);
        StartupTasks.add("Loading puzzle room templates", PuzzleRoomDatabase::load);
        ClientCommandHandler.instance.registerCommand(new SvCommand());
        ClientCommandHandler.instance.registerCommand(new QuickNoteCommand());
        ClientCommandHandler.instance.registerCommand(new PriceSetCommand("setprice"));
        ClientCommandHandler.instance.registerCommand(new PriceSetCommand("priceset"));
        ClientCommandHandler.instance.registerCommand(new TerminalSimulatorCommand());
        ClientCommandHandler.instance.registerCommand(new TerminalDebugCommand());
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(m7Overlay);
        MinecraftForge.EVENT_BUS.register(bloodMobHighlight);
        MinecraftForge.EVENT_BUS.register(mobHighlight);
        MinecraftForge.EVENT_BUS.register(dungeonMapOverlay);
        MinecraftForge.EVENT_BUS.register(dungeonMapOverlay.getPuzzleSyncManager());
        MinecraftForge.EVENT_BUS.register(HudManager.DUNGEON_PROGRESS);
        MinecraftForge.EVENT_BUS.register(witherDoorHighlight);
        MinecraftForge.EVENT_BUS.register(spiritBowTracer);
        MinecraftForge.EVENT_BUS.register(equipmentOverlay);
        MinecraftForge.EVENT_BUS.register(fishingStats);
        MinecraftForge.EVENT_BUS.register(slayerTracker);
        MinecraftForge.EVENT_BUS.register(itemProtection);
        MinecraftForge.EVENT_BUS.register(slotLocking);
        MinecraftForge.EVENT_BUS.register(itemLockSwapController);
        MinecraftForge.EVENT_BUS.register(itemLockSwapOverlay);
        MinecraftForge.EVENT_BUS.register(DungeonRunTracker.INSTANCE);
        DungeonRunTracker.markRegistered();
        MinecraftForge.EVENT_BUS.register(roomClearAlertController);
        MinecraftForge.EVENT_BUS.register(autoSprint);
        MinecraftForge.EVENT_BUS.register(removeIrritatingMessages);
        MinecraftForge.EVENT_BUS.register(entityVisualCleanup);
        MinecraftForge.EVENT_BUS.register(inventoryQoL);
        MinecraftForge.EVENT_BUS.register(tooltipQoL);
        MinecraftForge.EVENT_BUS.register(containerOverlayRenderer);
        MinecraftForge.EVENT_BUS.register(chatCopy);
        MinecraftForge.EVENT_BUS.register(chatChannelTabs);
        MinecraftForge.EVENT_BUS.register(miningAbilityTracker);
        MinecraftForge.EVENT_BUS.register(miningPuzzlerSolver);

        // Better NEF terminal, device and puzzle solvers adapted to this Forge 1.8.9 client.
        MinecraftForge.EVENT_BUS.register(boulderSolver);
        MinecraftForge.EVENT_BUS.register(creeperSolver);
        MinecraftForge.EVENT_BUS.register(silverFishSolver);
        MinecraftForge.EVENT_BUS.register(teleportMazeSolver);
        MinecraftForge.EVENT_BUS.register(threeWeirdosSolver);
        MinecraftForge.EVENT_BUS.register(waterSolver);
        MinecraftForge.EVENT_BUS.register(firstDeviceSolver);
        MinecraftForge.EVENT_BUS.register(thirdDeviceSolver);
        MinecraftForge.EVENT_BUS.register(clickInOrderSolver);
        MinecraftForge.EVENT_BUS.register(clickOnColorsSolver);
        MinecraftForge.EVENT_BUS.register(correctPanesSolver);
        MinecraftForge.EVENT_BUS.register(hideTooltips);
        MinecraftForge.EVENT_BUS.register(mazeSolver);
        MinecraftForge.EVENT_BUS.register(startingWithSolver);
        MinecraftForge.EVENT_BUS.register(terminalTracker);
        MinecraftForge.EVENT_BUS.register(terminalDebug);
        MinecraftForge.EVENT_BUS.register(terminalGuiLayer);
        MinecraftForge.EVENT_BUS.register(terminalWaypoints);
    }

    /**
     * Remember the active connection. Forge can fire this before packet_handler is present, so
     * installation is retried from client ticks instead of permanently giving up on that connection.
     */
    @SubscribeEvent
    public void onClientConnected(FMLNetworkEvent.ClientConnectedToServerEvent event) {
        SkyblockContext.reset();
        if (event == null || event.manager == null) return;
        pendingPacketBridgeManager = event.manager;
        packetBridgeWaitStartedAt = System.currentTimeMillis();
        packetBridgeWaitNoticeShown = false;
        installPacketBridgeIfReady();
    }

    @SubscribeEvent
    public void onClientDisconnected(FMLNetworkEvent.ClientDisconnectionFromServerEvent event) {
        if (event == null || event.manager == null || pendingPacketBridgeManager == event.manager) {
            pendingPacketBridgeManager = null;
        }
        SkyblockContext.reset();
    }

    private void installPacketBridgeIfReady() {
        NetworkManager manager = pendingPacketBridgeManager;
        if (manager == null) return;

        try {
            if (manager.channel() == null) return;
            ChannelPipeline pipeline = manager.channel().pipeline();
            if (pipeline.get("lunaria_packet_handler") != null) {
                pendingPacketBridgeManager = null;
                return;
            }
            if (pipeline.get("packet_handler") == null) {
                if (!packetBridgeWaitNoticeShown
                        && System.currentTimeMillis() - packetBridgeWaitStartedAt > 3000L) {
                    packetBridgeWaitNoticeShown = true;
                    System.err.println("[Lunaria Mod] Waiting for packet_handler before enabling device click validation.");
                }
                return;
            }
            pipeline.addBefore("packet_handler", "lunaria_packet_handler", new PacketHandler());
            pendingPacketBridgeManager = null;
            System.out.println("[Lunaria Mod] Outbound packet bridge installed.");
        } catch (RuntimeException ex) {
            // Keep pending and retry on the next tick if connection setup is still in progress.
            if (!packetBridgeWaitNoticeShown) {
                packetBridgeWaitNoticeShown = true;
                System.err.println("[Lunaria Mod] Packet bridge installation will retry: " + ex.getMessage());
            }
        }
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        installPacketBridgeIfReady();
        Minecraft mc = Minecraft.getMinecraft();
        if (event.phase == TickEvent.Phase.START) {
            SkyblockContext.tick(mc);
            if (!loadingShown && StartupTasks.hasWork()) {
                // Show the loading screen only while real startup tasks are pending. Shown once per launch.
                loadingShown = true;
                mc.displayGuiScreen(new LoadingScreen(mc.currentScreen));
            }
            // Before the world moves. Also resets mining counts on world change, respawn and disconnect.
            HudManager.tick(mc);
            DungeonContext.tick(mc);
            dragonKill.tick(System.currentTimeMillis());
            return;
        }
        if (ItemLockSwapSettings.keyCode != ITEM_LOCK_SWAP_KEY.getKeyCode()) {
            ItemLockSwapSettings.keyCode = ITEM_LOCK_SWAP_KEY.getKeyCode();
            AppleSettings.save();
        }
        aspectTeleportTransition.tick(mc);
        ClientActions.run(mc);
        if (OPEN_KEY.isPressed() && mc.currentScreen == null) {
            mc.displayGuiScreen(new AppleHubScreen(null));
        }
        while (LEAP_KEY.isPressed()) {
            if (mc.currentScreen == null && AppleSettings.leapKey && SkyblockContext.isInSkyblock()) {
                useSpiritLeap(mc);
            }
        }
        while (WARDROBE_KEY.isPressed()) {
            if (mc.currentScreen == null && mc.thePlayer != null && AppleSettings.wardrobeShortcutEnabled
                    && SkyblockContext.isInSkyblock() && isFakepixelServer(mc)) {
                mc.thePlayer.sendChatMessage("/wardrobe");
            }
        }
        while (PETS_KEY.isPressed()) {
            if (mc.currentScreen == null && mc.thePlayer != null && AppleSettings.petsShortcutEnabled
                    && SkyblockContext.isInSkyblock() && isFakepixelServer(mc)) {
                mc.thePlayer.sendChatMessage("/pets");
            }
        }
    }

    /**
     * Sends the vanilla use-item action for the held Spirit Leap. Only inside a dungeon, and only when the item in
     * the selected hotbar slot is a Spirit Leap item. The server validates the use and opens its menu.
     */
    private static void useSpiritLeap(Minecraft mc) {
        EntityPlayerSP p = mc.thePlayer;
        if (p == null || mc.playerController == null || mc.theWorld == null) {
            return;
        }
        if (!DungeonContext.inDungeon()) {
            chat(mc, "Spirit Leap can only be used inside a dungeon (Catacombs sidebar).");
            return;
        }
        ItemStack held = p.getHeldItem();
        if (held == null || !LeapUse.isLeapItemName(held.getDisplayName())) {
            chat(mc, "Hold a Spirit Leap item in your selected hotbar slot first.");
            return;
        }
        LeapUse.markUsed();
        mc.playerController.sendUseItem(p, mc.theWorld, held);
    }

    private static void chat(Minecraft mc, String text) {
        if (mc.thePlayer != null) {
            mc.thePlayer.addChatMessage(new ChatComponentText("\u00a7b[Lunaria Mod] \u00a7f" + text));
        }
    }

    public static String rebindItemLockSwapKey(int keyCode) {
        String conflict = keyConflictName(ITEM_LOCK_SWAP_KEY, keyCode);
        if (keyCode == Keyboard.KEY_NONE) {
            ItemLockSwapKeybind.clear();
        } else if (!ItemLockSwapKeybind.rebind(keyCode)) {
            return null;
        }
        ITEM_LOCK_SWAP_KEY.setKeyCode(ItemLockSwapSettings.keyCode);
        KeyBinding.resetKeyBindingArrayAndHash();
        return conflict;
    }

    public static String rebindWardrobeShortcutKey(int keyCode) {
        return rebindKey(WARDROBE_SHORTCUT_KEY, keyCode);
    }

    public static String rebindPetsShortcutKey(int keyCode) {
        return rebindKey(PETS_SHORTCUT_KEY, keyCode);
    }

    public static void resetShortcutKeysToDefaults() {
        WARDROBE_SHORTCUT_KEY.setKeyCode(Keyboard.KEY_NONE);
        PETS_SHORTCUT_KEY.setKeyCode(Keyboard.KEY_NONE);
        KeyBinding.resetKeyBindingArrayAndHash();
    }

    private static String rebindKey(KeyBinding binding, int keyCode) {
        if (binding == null || keyCode < Keyboard.KEY_NONE || keyCode > 255 || keyCode == Keyboard.KEY_ESCAPE) {
            return null;
        }
        String conflict = keyConflictName(binding, keyCode);
        binding.setKeyCode(keyCode);
        KeyBinding.resetKeyBindingArrayAndHash();
        return conflict;
    }

    private static String keyConflictName(KeyBinding target, int keyCode) {
        if (keyCode == Keyboard.KEY_NONE) return null;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null || mc.gameSettings == null || mc.gameSettings.keyBindings == null) return null;
        for (KeyBinding binding : mc.gameSettings.keyBindings) {
            if (binding != null && binding != target && binding.getKeyCode() == keyCode) {
                return binding.getKeyDescription();
            }
        }
        return null;
    }

    private static boolean isFakepixelServer(Minecraft mc) {
        if (mc == null || mc.getCurrentServerData() == null) return false;
        String address = mc.getCurrentServerData().serverIP;
        return address != null && address.toLowerCase(java.util.Locale.ROOT).contains("fakepixel");
    }

    /** A left-click on a held Spirit Leap item triggers the leap, so the server opens the menu the GUI replaces. */
    @SubscribeEvent
    public void onMouse(MouseEvent event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (event != null && event.button == 1 && event.buttonstate && mc.currentScreen == null) {
            aspectTeleportTransition.observeUse(mc);
        }
        if (event == null || event.button != 0 || !event.buttonstate) {
            return;
        }
        if (mc.currentScreen != null || mc.thePlayer == null || !DungeonContext.inDungeon()) {
            return;
        }
        ItemStack held = mc.thePlayer.getHeldItem();
        if (held != null && LeapUse.isLeapItemName(held.getDisplayName())) {
            // A left-click on a held Leap item triggers the leap: same use action as a right-click.
            // The server then opens its menu, and the Leap GUI takes it over.
            LeapUse.markUsed();
            mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, held);
        }
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event != null && event.phase == TickEvent.Phase.START) {
            aspectTeleportTransition.renderTick(Minecraft.getMinecraft());
        }
    }

    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) {
            return;
        }
        Minecraft mc = Minecraft.getMinecraft();
        // The editor draws the elements itself, so skip the in-game copy while it is open.
        if (!(mc.currentScreen instanceof HudEditorScreen) && HudManager.visibleInGame()) {
            HudManager.render(event.resolution);
        }
    }

    @SubscribeEvent
    public void onInitGui(GuiScreenEvent.InitGuiEvent.Post event) {
        if (event.gui instanceof GuiMainMenu || event.gui instanceof GuiIngameMenu) {
            // Top-right corner: does not collide with vanilla's centred column.
            event.buttonList.add(new AppleGuiButton(MENU_BUTTON_ID, event.gui.width - 92, 8, 84, 20, NAME));
        }
    }

    @SubscribeEvent
    public void onActionPerformed(GuiScreenEvent.ActionPerformedEvent.Pre event) {
        if (event.button != null && event.button.id == MENU_BUTTON_ID) {
            event.setCanceled(true);
            Minecraft.getMinecraft().displayGuiScreen(new AppleHubScreen(event.gui));
        }
    }

    /**
     * Dungeon tab, Spirit Leap. When the server opens its leap menu and the feature is on, the teammate picker
     * replaces that screen. The server's container is used unchanged, so every click is the server's own window
     * click, and the server still validates it. The menu is recognised only when its title is exactly Spirit Leap and the client is inside a dungeon,
     * matching Better NEF and preventing Bazaar chest items from opening the picker.
     */
    @SubscribeEvent
    public void onGuiOpen(GuiOpenEvent event) {
        // Earliest screen Lunaria Mod controls: the first main menu, shown only while startup work is pending.
        // The loading screen returns to that same main menu when its work is finished.
        if (event.gui instanceof GuiMainMenu && !loadingShown && StartupTasks.hasWork()) {
            loadingShown = true;
            event.gui = new LoadingScreen(event.gui);
            return;
        }
        if (!AppleSettings.leapMenu || !(event.gui instanceof GuiChest)) {
            return;
        }
        GuiChest chest = (GuiChest) event.gui;
        if (SpiritLeap.isLeapMenu(chest.inventorySlots)) {
            event.gui = new LeapScreen(chest.inventorySlots);
        }
    }
}
