package dev.client.lunaria.widget;

import dev.client.lunaria.render.Theme;
import dev.client.lunaria.render.UIRender;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;

public abstract class Widget {
    public float x;
    public float y;
    public float w;
    public float h;

    protected boolean hovered;
    protected boolean pressed;
    protected boolean enabled = true;
    protected float hoverAmount;
    protected float pressAmount;
    /** Short acknowledgement pulse after a successful activation or committed value change. */
    protected float clickPulse;
    private boolean animatedTransformPushed;
    protected float deltaTime = 1f / 60f;
    protected int lastMouseX;
    protected int lastMouseY;

    protected Widget(float width, float height) {
        this.w = Math.max(0f, width);
        this.h = Math.max(0f, height);
    }

    public final boolean contains(float px, float py) {
        return px >= x && py >= y && px < x + w && py < y + h;
    }

    public void update(float dt) {
        deltaTime = clamp(dt, 0f, 0.1f);
        lastMouseX = mouseX();
        lastMouseY = mouseY();
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.currentScreen == null || mc.displayWidth <= 0 || mc.displayHeight <= 0) {
            hovered = false;
        } else {
            hovered = contains(lastMouseX, lastMouseY);
        }

        hoverAmount = approach(hoverAmount, hovered && enabled ? 1f : 0f, deltaTime, 22f);
        pressAmount = approach(pressAmount, pressed && enabled ? 1f : 0f, deltaTime, 30f);
        clickPulse = approach(clickPulse, 0f, deltaTime, 11.5f);
        updateWidget(deltaTime);
    }

    /** Hook for controls that animate their own visual value. */
    protected void updateWidget(float dt) {
    }

    /** Begin a restrained scale response. This affects drawing only, never layout or click bounds. */
    protected final void beginAnimatedDraw(float hoverZoom, float pressShrink, float releasePop) {
        float scale = 1f;
        if (Theme.animations && enabled) {
            scale += hoverAmount * hoverZoom;
            scale -= pressAmount * pressShrink;
            scale += clickPulse * releasePop;
        }
        scale = clamp(scale, 0.94f, 1.065f);
        animatedTransformPushed = Math.abs(scale - 1f) > 0.0005f;
        if (animatedTransformPushed) {
            UIRender.pushScaleAt(x + w * 0.5f, y + h * 0.5f, scale);
        }
    }

    protected final void endAnimatedDraw() {
        if (animatedTransformPushed) {
            UIRender.popTransform();
            animatedTransformPushed = false;
        }
    }

    /** Use for immediate state changes such as choosing a dropdown option or changing a slider value. */
    protected final void acknowledgeChange() {
        if (Theme.animations && enabled) {
            clickPulse = 1f;
        }
    }

    /** Time-correct exponential easing; identical motion at low and high frame rates. */
    protected final float approach(float value, float target, float dt, float rate) {
        if (!Theme.animations || dt <= 0f) {
            return Theme.animations ? value : target;
        }
        float k = 1f - (float) Math.exp(-dt * rate * Math.max(0.1f, Theme.speed));
        float result = value + (target - value) * k;
        return Math.abs(target - result) < 0.0015f ? target : result;
    }

    public abstract void draw(int mouseX, int mouseY);

    public void onPress(int mouseX, int mouseY) {
        pressed = enabled && contains(mouseX, mouseY);
    }

    public void onDrag(int mouseX, int mouseY) {
    }

    public void onRelease(int mouseX, int mouseY, boolean activate) {
        boolean completedTap = pressed && activate && enabled && contains(mouseX, mouseY);
        pressed = false;
        if (completedTap) {
            acknowledgeChange();
        }
    }

    public void cancel() {
        pressed = false;
    }

    protected static FontRenderer font() {
        return Minecraft.getMinecraft().fontRendererObj;
    }

    protected final String fitText(String value, float maxWidth) {
        if (value == null || value.length() == 0 || maxWidth <= 0f) return "";
        FontRenderer renderer = font();
        if (renderer.getStringWidth(value) <= maxWidth) return value;
        String ellipsis = "...";
        int available = Math.max(0, (int) maxWidth - renderer.getStringWidth(ellipsis));
        return renderer.trimStringToWidth(value, available) + ellipsis;
    }

    protected final float textHeight() {
        return font().FONT_HEIGHT;
    }

    protected static float clamp(float value, float min, float max) {
        return value < min ? min : (value > max ? max : value);
    }

    private static int mouseX() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.currentScreen == null) {
            return -10000;
        }
        return org.lwjgl.input.Mouse.getX() * mc.currentScreen.width / Math.max(1, mc.displayWidth);
    }

    private static int mouseY() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.currentScreen == null) {
            return -10000;
        }
        return mc.currentScreen.height - org.lwjgl.input.Mouse.getY()
                * mc.currentScreen.height / Math.max(1, mc.displayHeight) - 1;
    }

    protected int mixAlpha(int color, float amount) {
        int alpha = color >>> 24;
        int next = Math.min(255, Math.max(0, Math.round(alpha * amount)));
        return (next << 24) | (color & 0x00FFFFFF);
    }

    protected void drawBorder(float radius, int color) {
        UIRender.roundRectRing(x, y, w, h, radius, 1f, color);
    }
}
