package dev.client.lunaria.hud;

import dev.client.lunaria.assist.dungeon.DungeonRunReadout;
import dev.client.lunaria.assist.dungeon.DungeonRunTracker;

/** Optional, movable, read-only HUD for run time, cleared percentage, and deaths; it never owns score state. */
public final class DungeonRunHud extends HudElement {
    public DungeonRunHud() {
        super("dungeonRun", "Dungeon Run", new HudPlacement(HudPlacement.Anchor.END, 8,
                HudPlacement.Anchor.START, 72), false);
    }

    @Override
    public float width() {
        DungeonRunReadout readout = DungeonRunTracker.INSTANCE.readout();
        float widest = textWidth("DUNGEON RUN");
        widest = Math.max(widest, textWidth(readout.timeLine()));
        widest = Math.max(widest, textWidth(readout.clearedLine()));
        widest = Math.max(widest, textWidth(readout.deathsLine()));
        return Math.max(112F, widest + 16F);
    }

    @Override
    public float height() {
        return 8F + 4F * (10F * textScale());
    }

    @Override
    protected void drawContent() {
        DungeonRunReadout readout = DungeonRunTracker.INSTANCE.readout();
        if (!readout.hasData() && !backgroundOnHoverOnly) return;
        drawPanel(width(), height());
        float y = 4F;
        text("DUNGEON RUN", 8F, y, accentColor());
        y += 10F * textScale();
        text(readout.timeLine(), 8F, y, accentColor());
        y += 10F * textScale();
        text(readout.clearedLine(), 8F, y, accentColor());
        y += 10F * textScale();
        text(readout.deathsLine(), 8F, y, accentColor());
    }
}
