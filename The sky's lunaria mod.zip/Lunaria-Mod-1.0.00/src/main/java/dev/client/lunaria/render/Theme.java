package dev.client.lunaria.render;

import dev.client.lunaria.config.AppleSettings;

/**
 * The one design-token authority for Lunaria Mod GUI surfaces.
 *
 * <p>The settings shell deliberately uses the original Apple-inspired glass system: a graphite gradient window,
 * translucent white cards, thin low-contrast dividers, and one interaction accent controlled by the existing Accent setting (blue by default). Existing
 * appearance values remain loadable in {@link AppleSettings}; current UI behavior keeps the shell deterministic so
 * an old configuration cannot silently fork the navigation or control hierarchy into a second design system. Keep
 * concrete GUI colours, typography, spacing, radii, shadows and dim layers here; renderers consume these semantic
 * tokens rather than introducing local hexadecimal literals.</p>
 */
public final class Theme {

    // ------------------------------------------------------------------ colour tokens

    /** Shared masks/opaque neutrals for render helpers; these are colour tokens, not ad-hoc caller literals. */
    public static final int RGB_MASK = 0x00FFFFFF;
    public static final int OPAQUE_BLACK = 0xFF000000;
    public static final int OPAQUE_WHITE = 0xFFFFFFFF;
    /** Minecraft-native textured-button text values retained for vanilla integration widgets. */
    public static final int VANILLA_BUTTON_DISABLED_TEXT = 0x00A0A0A0;
    public static final int VANILLA_BUTTON_TEXT = 0x00E0E0E0;
    public static final int VANILLA_BUTTON_HOVER_TEXT = 0x00FFFFA0;

    /** The original Apple reference uses this blue as its one positive/action accent. */
    public static final int ACCENT_BLUE = 0xFF0A84FF;
    public static final int ACCENT_BLUE_HOVER = 0xFF409CFF;
    public static final int STATUS_WARNING = 0xFFF0B45E;
    /** Semantic success is reserved for compact health/availability indicators, not a second interaction accent. */
    public static final int STATUS_SUCCESS = 0xFF5EDC87;
    public static final int STATUS_CRITICAL = 0xFFFF6B6B;
    public static final int STATUS_UNAVAILABLE = 0xFF8E8E93;

    /** Graphite glass, directly restored from the shipped Apple settings visual system. */
    public static final int SURFACE_TOP_RGB = 0x1E1E21;
    public static final int SURFACE_BOTTOM_RGB = 0x101012;
    public static final int SURFACE_CARD = 0x14FFFFFF;
    public static final int SURFACE_CARD_HOVER = 0x22FFFFFF;
    public static final int SURFACE_CONTROL = 0x26FFFFFF;
    public static final int SURFACE_CONTROL_HOVER = 0x3DFFFFFF;
    public static final int SURFACE_POPUP = 0xF22A2A2E;
    /** Dropdowns use an opaque-enough graphite popup and explicit state layers for readable one-level choices. */
    public static final int DROPDOWN_TRIGGER = 0x33FFFFFF;
    public static final int DROPDOWN_TRIGGER_HOVER = 0x52FFFFFF;
    public static final int DROPDOWN_POPUP = 0xFA24252B;
    public static final int DROPDOWN_BORDER = 0x54FFFFFF;
    public static final int DROPDOWN_ROW_HOVER = 0x24FFFFFF;
    public static final int DROPDOWN_ROW_SELECTED = 0x4A0A84FF;
    public static final int DROPDOWN_DIVIDER = 0x1FFFFFFF;
    /** Inset accordion panels stay readable even when the optional window glass is highly transparent. */
    public static final int EXPANDED_PANEL = 0xE51B1C22;
    public static final int EXPANDED_BORDER = 0x38FFFFFF;
    public static final int EXPANDED_HEADER = 0x260A84FF;
    public static final int EXPANDED_ROW_HOVER = 0x1CFFFFFF;
    public static final int EXPANDED_DIVIDER = 0x20FFFFFF;
    /** Master-off children remain editable but use muted, still-readable labels rather than a near-invisible veil. */
    public static final int DEPENDENT_TEXT_PRIMARY = 0xFFC4C4CA;
    public static final int DEPENDENT_TEXT_SECONDARY = 0xFF94949C;
    public static final float DEPENDENT_CONTROL_ALPHA = .78f;
    public static final int SURFACE_DISABLED = 0x52000000;
    public static final int BORDER = 0x1FFFFFFF;
    public static final int DIVIDER = 0x18FFFFFF;
    public static final int TRACK = 0xFF3A3A3D;
    public static final int SEGMENT_SELECTED = 0xFF5A5A5E;
    public static final int TEXT_PRIMARY = 0xFFF5F5F7;
    public static final int TEXT_SECONDARY = 0xFFA1A1A8;
    public static final int TEXT_TERTIARY = 0xFF707078;
    public static final int TEXT_DISABLED = 0xFF626269;
    public static final int CONTROL_KNOB = OPAQUE_WHITE;
    public static final int ICON_INK = TEXT_SECONDARY;
    public static final int NEUTRAL_DOT = TEXT_TERTIARY;
    public static final int NOTICE_WARNING = STATUS_WARNING;

    /** Non-interactive semantic surfaces shared by diagnostics and app-specific utility screens. */
    public static final int SHADOW = 0x40000000;
    public static final int DIM = 0x73000000;
    /** Light, transparent canvas veil for direct HUD placement; the game remains readable underneath. */
    public static final int HUD_EDITOR_DIM = 0x30000000;
    public static final int TOOLTIP = 0xF22A2A2E;
    public static final int DEBUG_THIN = 0xC8E85D5D;
    public static final int DEBUG_HOT = 0xFFFF4545;
    public static final int DEBUG_FILL = 0x35FF4545;
    public static final int LOADING_BLACK = OPAQUE_BLACK;
    public static final int LOADING_BLUE = 0xFF0B2350;
    public static final int LOADING_DEEP_BLUE = LOADING_BLUE;
    public static final int LOADING_WORDMARK = TEXT_PRIMARY;
    public static final int LOADING_SUBTITLE = 0xFF9CC3FF;
    public static final int LOADING_VERSION = LOADING_SUBTITLE;
    public static final int LOADING_STATUS = TEXT_SECONDARY;
    public static final int LOADING_DIM = TEXT_TERTIARY;
    public static final int LOADING_TRACK = 0x33FFFFFF;
    public static final int LOADING_ERROR = STATUS_CRITICAL;
    public static final int LEAP_CARD = 0xFF20242C;
    public static final int LEAP_CARD_HOVER = 0xFF2A313D;
    public static final int LEAP_BORDER = 0xFF465264;
    public static final int LEAP_BORDER_HOVER = 0xFF617189;
    public static final int LEAP_HEAD_LETTER = 0xFF2C3E5C;
    public static final int LEAP_TEXT = OPAQUE_WHITE;
    public static final int LEAP_TEXT_DIM = 0xFFE0E5EC;
    public static final int NOTE_PANEL = 0xF0171B24;
    public static final int NOTE_BORDER = 0xFF566173;
    public static final int NOTE_BOX = 0xFF11151D;
    public static final int NOTE_BOX_BORDER = 0xFF424D5E;
    public static final int NOTE_TITLE = TEXT_PRIMARY;
    public static final int NOTE_TEXT = 0xFFE7EBF2;
    public static final int NOTE_HINT = 0xFF98A3B4;
    public static final int NOTE_SAVED = ACCENT_BLUE;
    public static final int NOTE_PENDING = STATUS_WARNING;
    public static final int NOTE_CURSOR = OPAQUE_WHITE;
    public static final int NOTE_SIDEBAR = NOTE_BOX;
    public static final int NOTE_SIDEBAR_BORDER = NOTE_BOX_BORDER;
    public static final int NOTE_ROW = NOTE_HINT;
    public static final int NOTE_ROW_SELECTED = ACCENT_BLUE;
    public static final int NOTE_ROW_COUNT = 0xFF7F8998;
    /** Standalone Item Animation is intentionally opaque: game/HUD pixels never bleed through its controls. */
    public static final int ITEM_ANIMATION_PANEL = 0xFF17191F;
    public static final int ITEM_ANIMATION_PANEL_BORDER = 0xFF454953;

    // ------------------------------------------------------------------ typography, geometry and motion tokens

    public static final float TYPE_DISPLAY = 1.34f;
    public static final float TYPE_TITLE = 1.08f;
    public static final float TYPE_HEADING = .88f;
    public static final float TYPE_BODY = .72f;
    public static final float TYPE_META = .62f;
    public static final float TYPE_CAPTION = .52f;

    public static final float SPACE_4 = 4f;
    public static final float SPACE_8 = 8f;
    public static final float SPACE_12 = 12f;
    public static final float SPACE_16 = 16f;

    public static final float RADIUS_WINDOW = 12f;
    public static final float RADIUS_CARD = 7f;
    public static final float RADIUS_BUTTON = 8f;
    public static final float RADIUS_FIELD = 7f;
    public static final float RADIUS_POPUP = 7f;
    public static final float RADIUS_SMALL = 4f;
    public static final float RADIUS_PILL = 10f;
    public static final float RADIUS_THEME_BASE = 12f;
    public static final float OUTLINE = 1f;
    public static final float AA_FRINGE = 1f;
    public static final float SHADOW_OFFSET_X = 0f;
    public static final float SHADOW_OFFSET_Y = 3f;
    public static final float SHADOW_GROWTH = 2f;

    /** All GUI settle durations intentionally stay in the requested subtle 120–180 ms range. */
    public static final int MOTION_HOVER_MS = 140;
    public static final int MOTION_PRESS_MS = 120;
    public static final int MOTION_TOGGLE_MS = 150;
    public static final int MOTION_TAB_MS = 160;
    public static final int MOTION_SLIDER_MS = 150;
    public static final int MOTION_PULSE_MS = 150;

    // ------------------------------------------------------------------ resolved palette used by existing render call sites

    public static int accent = ACCENT_BLUE;
    public static int textPrimary = TEXT_PRIMARY;
    public static int textSecondary = TEXT_SECONDARY;
    public static int textTertiary = TEXT_TERTIARY;
    public static int windowTop = 0xF01E1E21;
    public static int windowBottom = 0xF0101012;
    public static int card = SURFACE_CARD;
    public static int cardHover = SURFACE_CARD_HOVER;
    public static int buttonFill = SURFACE_CONTROL;
    public static int buttonHover = SURFACE_CONTROL_HOVER;
    /** Dedicated resolved dropdown tokens keep trigger, popup, hover, and selected states coherent. */
    public static int dropdownTrigger = DROPDOWN_TRIGGER;
    public static int dropdownTriggerHover = DROPDOWN_TRIGGER_HOVER;
    public static int dropdownPopup = DROPDOWN_POPUP;
    public static int dropdownBorder = DROPDOWN_BORDER;
    public static int dropdownRowHover = DROPDOWN_ROW_HOVER;
    public static int dropdownRowSelected = DROPDOWN_ROW_SELECTED;
    public static int dropdownDivider = DROPDOWN_DIVIDER;
    /** Resolved disclosure tokens prevent transparent glass from washing out expanded feature controls. */
    public static int expandedPanel = EXPANDED_PANEL;
    public static int expandedBorder = EXPANDED_BORDER;
    public static int expandedHeader = EXPANDED_HEADER;
    public static int expandedRowHover = EXPANDED_ROW_HOVER;
    public static int expandedDivider = EXPANDED_DIVIDER;
    public static int dependentTextPrimary = DEPENDENT_TEXT_PRIMARY;
    public static int dependentTextSecondary = DEPENDENT_TEXT_SECONDARY;
    public static int border = BORDER;
    public static int divider = DIVIDER;
    public static int track = TRACK;
    public static int segSelected = SEGMENT_SELECTED;
    public static int popup = SURFACE_POPUP;
    public static int veil = DIM;

    public static int radius = (int) RADIUS_THEME_BASE;
    public static boolean animations = true;
    public static float speed = 1f;

    private Theme() {
    }

    /** Applies the current Lunaria Mod appearance preferences to both legacy screens and the modern settings shell. */
    public static void applyReferenceSettingsPalette() {
        refresh();
    }

    /** Rebuilds resolved tokens after an appearance, geometry, opacity, or motion preference changes. */
    public static void refresh() {
        int glass = Math.round(AppleSettings.effectiveGlassOpacity() * 2.55f);
        radius = AppleSettings.effectiveCornerRadius();
        animations = AppleSettings.animations;
        speed = AppleSettings.effectiveAnimSpeed() / 100f;
        accent = AppleSettings.accentColor();

        if (AppleSettings.darkMode) {
            windowTop = (glass << 24) | 0x1E1E21;
            windowBottom = (glass << 24) | 0x101012;
            card = SURFACE_CARD;
            cardHover = SURFACE_CARD_HOVER;
            buttonFill = SURFACE_CONTROL;
            buttonHover = SURFACE_CONTROL_HOVER;
            border = BORDER;
            divider = DIVIDER;
            track = TRACK;
            segSelected = SEGMENT_SELECTED;
            popup = SURFACE_POPUP;
            veil = DIM;
            textPrimary = TEXT_PRIMARY;
            textSecondary = TEXT_SECONDARY;
            textTertiary = TEXT_TERTIARY;

            dropdownTrigger = DROPDOWN_TRIGGER;
            dropdownTriggerHover = DROPDOWN_TRIGGER_HOVER;
            dropdownPopup = DROPDOWN_POPUP;
            dropdownBorder = DROPDOWN_BORDER;
            dropdownRowHover = DROPDOWN_ROW_HOVER;
            dropdownRowSelected = accentWithAlpha(0x4A);
            dropdownDivider = DROPDOWN_DIVIDER;
            expandedPanel = EXPANDED_PANEL;
            expandedBorder = EXPANDED_BORDER;
            expandedHeader = accentWithAlpha(0x26);
            expandedRowHover = EXPANDED_ROW_HOVER;
            expandedDivider = EXPANDED_DIVIDER;
            dependentTextPrimary = DEPENDENT_TEXT_PRIMARY;
            dependentTextSecondary = DEPENDENT_TEXT_SECONDARY;
        } else {
            // Preserve the existing soft-light palette; the new settings shell consumes these same shared tokens.
            int milky = Math.round(AppleSettings.effectiveGlassOpacity() * 2.04f) << 24;
            windowTop = milky | 0xF1F1F5;
            windowBottom = milky | 0xE8E8EF;
            card = 0x78E8E8EE;
            cardHover = 0xA8F2F2F6;
            buttonFill = 0xFFE5E5EA;
            buttonHover = 0xFFD8D8E0;
            border = 0x38000000;
            divider = 0x26000000;
            track = 0xFFD1D1D8;
            segSelected = 0xFFF1F1F5;
            popup = 0xF2F1F1F5;
            veil = 0x26F0F0F4;
            textPrimary = 0xFF1C1C1E;
            textSecondary = 0xFF4A4A52;
            textTertiary = 0xFF6E6E76;

            dropdownTrigger = 0xFFF8F8FB;
            dropdownTriggerHover = 0xFFE9E9F0;
            dropdownPopup = 0xFFF7F7FA;
            dropdownBorder = 0x42000000;
            dropdownRowHover = 0x18000000;
            dropdownRowSelected = accentWithAlpha(0x28);
            dropdownDivider = 0x1F000000;
            expandedPanel = 0xFFF8F8FB;
            expandedBorder = 0x36000000;
            expandedHeader = accentWithAlpha(0x22);
            expandedRowHover = 0x16000000;
            expandedDivider = 0x1E000000;
            dependentTextPrimary = 0xFF56565E;
            dependentTextSecondary = 0xFF777780;
        }
    }

    private static int accentWithAlpha(int alpha) {
        return ((alpha & 0xFF) << 24) | (accent & RGB_MASK);
    }

}
