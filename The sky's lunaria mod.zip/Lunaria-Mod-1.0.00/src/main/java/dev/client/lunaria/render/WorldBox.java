package dev.client.lunaria.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;

/** Draws boxes and lines in world space for overlays without leaving modified OpenGL state behind. */
public final class WorldBox {
    private static WorldRenderer wr;
    private static boolean open;
    private static boolean previousTexture;
    private static boolean previousLighting;
    private static boolean previousCull;
    private static boolean previousBlend;
    private static boolean previousDepth;
    private static boolean previousDepthMask;
    private static float previousLineWidth;
    private static int previousBlendSrcRgb;
    private static int previousBlendDstRgb;
    private static int previousBlendSrcAlpha;
    private static int previousBlendDstAlpha;

    private WorldBox() {
    }

    /** Starts an overlay pass. {@code viewX/Y/Z} are the camera position from the render manager. */
    public static void begin(double viewX, double viewY, double viewZ, boolean throughWalls) {
        if (open) {
            end();
        }
        previousTexture = GL11.glIsEnabled(GL11.GL_TEXTURE_2D);
        previousLighting = GL11.glIsEnabled(GL11.GL_LIGHTING);
        previousCull = GL11.glIsEnabled(GL11.GL_CULL_FACE);
        previousBlend = GL11.glIsEnabled(GL11.GL_BLEND);
        previousDepth = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
        previousDepthMask = GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK);
        previousLineWidth = GL11.glGetFloat(GL11.GL_LINE_WIDTH);
        previousBlendSrcRgb = GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB);
        previousBlendDstRgb = GL11.glGetInteger(GL14.GL_BLEND_DST_RGB);
        previousBlendSrcAlpha = GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA);
        previousBlendDstAlpha = GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA);

        GlStateManager.pushMatrix();
        GlStateManager.translate(-viewX, -viewY, -viewZ);
        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.depthMask(false);
        if (throughWalls) {
            GlStateManager.disableDepth();
        } else {
            GlStateManager.enableDepth();
        }
        GL11.glLineWidth(2.0F);
        wr = Tessellator.getInstance().getWorldRenderer();
        wr.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
        open = true;
    }

    /** Ends the pass and restores each capability to the state it had before begin(). */
    public static void end() {
        if (!open) {
            return;
        }
        try {
            Tessellator.getInstance().draw();
        } finally {
            open = false;
            GL11.glLineWidth(previousLineWidth);
            GlStateManager.tryBlendFuncSeparate(previousBlendSrcRgb, previousBlendDstRgb,
                    previousBlendSrcAlpha, previousBlendDstAlpha);
            GlStateManager.depthMask(previousDepthMask);
            setDepth(previousDepth);
            setCull(previousCull);
            setBlend(previousBlend);
            setLighting(previousLighting);
            setTexture(previousTexture);
            GlStateManager.popMatrix();
        }
    }

    /** Outline of an axis-aligned box, in world coordinates, as 12 edges. */
    public static void outline(double x0, double y0, double z0, double x1, double y1, double z1, int argb) {
        float a = ((argb >>> 24) & 0xFF) / 255f;
        float r = ((argb >> 16) & 0xFF) / 255f;
        float g = ((argb >> 8) & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;
        edge(x0, y0, z0, x1, y0, z0, r, g, b, a);
        edge(x1, y0, z0, x1, y0, z1, r, g, b, a);
        edge(x1, y0, z1, x0, y0, z1, r, g, b, a);
        edge(x0, y0, z1, x0, y0, z0, r, g, b, a);
        edge(x0, y1, z0, x1, y1, z0, r, g, b, a);
        edge(x1, y1, z0, x1, y1, z1, r, g, b, a);
        edge(x1, y1, z1, x0, y1, z1, r, g, b, a);
        edge(x0, y1, z1, x0, y1, z0, r, g, b, a);
        edge(x0, y0, z0, x0, y1, z0, r, g, b, a);
        edge(x1, y0, z0, x1, y1, z0, r, g, b, a);
        edge(x1, y0, z1, x1, y1, z1, r, g, b, a);
        edge(x0, y0, z1, x0, y1, z1, r, g, b, a);
    }

    /** One line segment in world coordinates. */
    public static void line(double x0, double y0, double z0, double x1, double y1, double z1, int argb) {
        float a = ((argb >>> 24) & 0xFF) / 255f;
        float r = ((argb >> 16) & 0xFF) / 255f;
        float g = ((argb >> 8) & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;
        edge(x0, y0, z0, x1, y1, z1, r, g, b, a);
    }

    private static void edge(double x0, double y0, double z0, double x1, double y1, double z1,
                             float r, float g, float b, float a) {
        wr.pos(x0, y0, z0).color(r, g, b, a).endVertex();
        wr.pos(x1, y1, z1).color(r, g, b, a).endVertex();
    }

    private static void setTexture(boolean enabled) {
        if (enabled) GlStateManager.enableTexture2D(); else GlStateManager.disableTexture2D();
    }

    private static void setLighting(boolean enabled) {
        if (enabled) GlStateManager.enableLighting(); else GlStateManager.disableLighting();
    }

    private static void setCull(boolean enabled) {
        if (enabled) GlStateManager.enableCull(); else GlStateManager.disableCull();
    }

    private static void setBlend(boolean enabled) {
        if (enabled) GlStateManager.enableBlend(); else GlStateManager.disableBlend();
    }

    private static void setDepth(boolean enabled) {
        if (enabled) GlStateManager.enableDepth(); else GlStateManager.disableDepth();
    }

    /** True when the game has a world and a player to draw for. */
    public static boolean ready() {
        Minecraft mc = Minecraft.getMinecraft();
        return mc.theWorld != null && mc.thePlayer != null && mc.getRenderManager() != null;
    }
}
