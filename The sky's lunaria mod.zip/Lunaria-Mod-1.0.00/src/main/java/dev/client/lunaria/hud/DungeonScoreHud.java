package dev.client.lunaria.hud;

import dev.client.lunaria.dungeon.DungeonProgressTracker;
import dev.client.lunaria.render.Theme;

/** Lunaria Mod-styled dungeon score card using Better NEF-compatible score math and target/rank thresholds. */
public final class DungeonScoreHud extends HudElement {
    public DungeonScoreHud() {
        super("dungeonScore", "Dungeon Score", new HudPlacement(HudPlacement.Anchor.END, 8,
                HudPlacement.Anchor.START, 70), false);
    }

    private String[] lines() {
        DungeonProgressTracker tracker = HudManager.DUNGEON_PROGRESS;
        int total = tracker.totalScore();
        if (total < 0) {
            return new String[]{"Floor: " + tracker.floorText(), "Total: waiting for server data", "S+ target: 300"};
        }
        String totalLine = tracker.totalScoreText();
        if (dev.client.lunaria.config.AppleSettings.dungeonScoreSimple) {
            return new String[]{"Floor: " + tracker.floorText(), totalLine, tracker.secretDisplayText()};
        }
        String skillLine = tracker.finalStageIncomplete() ? "Exploration: Not all puzzles done" : "Skill: " + value(tracker.skillScore());
        return new String[]{"Floor: " + tracker.floorText(), totalLine,
                skillLine, "Exploration: " + value(tracker.explorationScore()),
                "Speed: " + value(tracker.speedScore()), "Bonus: " + value(tracker.bonusScore()),
                tracker.secretDisplayText()};
    }

    private static String value(int value) { return value < 0 ? "--" : String.valueOf(value); }

    @Override public float width() {
        float widest = textWidth("DUNGEON SCORE");
        for (String line : lines()) widest = Math.max(widest, textWidth(line));
        return Math.max(104f, widest + 20f);
    }
    @Override public float height() { return 12f + (lines().length + 1) * (9f * textScale() + 3f); }
    @Override protected void drawContent() {
        float w = width(), h = height();
        drawPanel(w, h);
        dev.client.lunaria.render.UIRender.roundRect(8f, 5f, w - 16f, 2f, 1f,
                accentColor(), accentColor(), 1f);
        text("DUNGEON SCORE", 8f, 10f, accentColor());
        String[] lines = lines();
        float y = 10f + 9f * textScale() + 4f;
        float step = 9f * textScale() + 3f;
        for (String line : lines) {
            int lineColor = line.contains("S+") ? accentColor() : Theme.textPrimary;
            if (line.startsWith("Secrets:") && trackerSecretUnreachable(line)) lineColor = 0xFFFF6B6B;
            text(line, 8f, y, lineColor);
            y += step;
        }
    }

    private static boolean trackerSecretUnreachable(String line) {
        return line != null && line.toLowerCase(java.util.Locale.ROOT).contains("unreachable");
    }
}
