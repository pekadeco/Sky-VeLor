package dev.client.lunaria.dungeon;

import dev.client.lunaria.config.AppleSettings;
import dev.client.lunaria.feature.DungeonContext;
import dev.client.lunaria.feature.LeapText;
import dev.client.lunaria.render.GuiOverlayRenderState;
import dev.client.lunaria.render.SkinHead;
import dev.client.lunaria.dungeon.sync.DungeonPuzzleSyncManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemMap;
import net.minecraft.item.ItemStack;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.StringUtils;
import net.minecraft.util.Vec4b;
import net.minecraft.world.World;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.storage.MapData;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

import java.nio.IntBuffer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Renders the live dungeon map, player-name labels, and the matched puzzle-room name. */
public final class DungeonMapOverlay {
    private static final Pattern ICON_KEY = Pattern.compile("^icon-(\\d+)$");
    private static final Pattern SECRET_COUNT = Pattern.compile("(?i)secrets\\s*:?\\s*(\\d+)(?:\\s*/\\s*\\d+)?");
    private static final ResourceLocation MAP_ICONS = new ResourceLocation("textures/map/map_icons.png");
    private static final Map<String, Vec4b> NO_DECORATIONS = Collections.emptyMap();
    private static final IntBuffer PREVIOUS_SCISSOR = BufferUtils.createIntBuffer(16);
    private final PuzzleRoomMatcher roomMatcher = new PuzzleRoomMatcher();
    private final PuzzleRoomMemory puzzleMemory = new PuzzleRoomMemory();
    private final DungeonPuzzleSyncManager puzzleSync = new DungeonPuzzleSyncManager();
    private final List<DungeonMapLabelLayout.Rect> occupiedLabelBounds = new ArrayList<DungeonMapLabelLayout.Rect>();
    private final List<PuzzleRoomMemory.RoomLabel> renderRoomSnapshot = new ArrayList<PuzzleRoomMemory.RoomLabel>();
    private final float[] layoutProjectionScratch = new float[2];
    private Scoreboard secretsScoreboard;
    private long secretsUpdatedAt;
    private String cachedSecretsCount;
    private List<String> sortedDecorationKeys = Collections.emptyList();
    private long sortedDecorationKeysSignature;
    private int sortedDecorationKeysCount = -1;
    private MapData puzzleAnchorData;
    private World puzzleMemoryWorld;
    private World rosterWorld;
    private long rosterUpdatedAt;
    private List<String> roster = Collections.emptyList();
    private MapData assignmentData;
    private long decorationHash;
    private long rosterHash;
    private Map<String, String> assignments = Collections.emptyMap();
    /** Smooths discrete server map marker coordinates without mutating the map or player. */
    private MapData playerHeadMotionData;
    private final Map<String, DungeonMapPlayerHeadMotion> playerHeadMotions =
            new HashMap<String, DungeonMapPlayerHeadMotion>();

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        Minecraft mc = Minecraft.getMinecraft();
        puzzleSync.tick(mc);
        applySyncedPuzzles();
        if (!DungeonContext.inDungeon() || mc.theWorld == null || mc.thePlayer == null) {
            roomMatcher.reset();
            if (!puzzleSync.isVerifyingExit()) clearPuzzleMemory();
            if (!DungeonContext.inDungeon() || mc.theWorld == null) clearRoster();
            clearPlayerHeadMotions();
            return;
        }
        if (puzzleMemoryWorld != mc.theWorld) {
            // World transitions are verified by the sync manager first. Keep puzzle identities while
            // the same run is being reloaded, but recapture their pixel anchors for the new map data.
            puzzleMemoryWorld = mc.theWorld;
            puzzleAnchorData = null;
            puzzleMemory.clearMapPositions();
        }
        roomMatcher.tick(mc); // Re-checks templates every 40 client ticks (~2 seconds).
        rememberDetectedPuzzle();
        if (!AppleSettings.dungeonMap && puzzleMemory.size() > 0) {
            puzzleSync.reportMapState(mc, "Dungeon Map overlay is disabled in HUD settings", puzzleMemory.size());
        } else if (!AppleSettings.dungeonMapShowPuzzleName && puzzleMemory.size() > 0) {
            puzzleSync.reportMapState(mc, "Puzzle-name display is disabled in Dungeon Map settings", puzzleMemory.size());
        }
        if (roomMatcher.current() == null) puzzleSync.reportNoLocalPuzzleMatch();
        if (mc.theWorld != rosterWorld || System.currentTimeMillis() - rosterUpdatedAt >= 900L) refreshRoster(mc);
        advancePlayerHeadMotions();
    }

    private void rememberDetectedPuzzle() {
        PuzzleRoomMatcher.Match match = roomMatcher.current();
        if (match == null || match.confidence < 0.65D) return;
        puzzleMemory.remember(match.name, match.originX, match.originY, match.originZ, match.confidence);
        puzzleSync.onLocalPuzzleDetected(match);
        puzzleSync.publishLocalPuzzle(match);
    }

    private void clearPuzzleMemory() {
        puzzleMemory.clear();
        renderRoomSnapshot.clear();
        puzzleAnchorData = null;
        puzzleMemoryWorld = null;
    }

    @SubscribeEvent
    public void onWorldUnload(WorldEvent.Unload event) {
        roomMatcher.reset();
        clearRoster();
        clearPlayerHeadMotions();
        puzzleMemoryWorld = null;
        puzzleAnchorData = null;
        puzzleMemory.clearMapPositions();
        rotationZoomSource = null;
        secretsScoreboard = null;
        secretsUpdatedAt = 0L;
        cachedSecretsCount = null;
        sortedDecorationKeys = Collections.emptyList();
        sortedDecorationKeysSignature = 0L;
        sortedDecorationKeysCount = -1;
    }

    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL || !AppleSettings.dungeonMap || !DungeonContext.inDungeon()) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || mc.theWorld == null || mc.entityRenderer == null) return;
        ItemStack stack = mc.thePlayer.inventory.getStackInSlot(8); // hotbar slot 9
        if (stack == null || !(stack.getItem() instanceof ItemMap)) return;
        MapData data = ((ItemMap) stack.getItem()).getMapData(stack, mc.theWorld);
        if (data == null || data.colors == null || data.colors.length < 128 * 128) return;
        drawMap(mc, data, event.partialTicks);
    }

    private void drawMap(Minecraft mc, MapData data, float partialTicks) {
        ScaledResolution sr = new ScaledResolution(mc);
        // Position and size use the same geometry as the HUD editor. Unlike ordinary HUD cards,
        // the dungeon map may extend beyond the viewport when the user deliberately places it there.
        int screenW = sr.getScaledWidth();
        int screenH = sr.getScaledHeight();
        int size = AppleSettings.dungeonMapPixelSize(screenW, screenH);
        // Derive the actual GL scale from the integer widget size, exactly matching the editor.
        float scale = size / 128.0F;
        int x = AppleSettings.dungeonMapLeft(screenW, screenH, size);
        int y = AppleSettings.dungeonMapTop(screenW, screenH, size);
        Vec4b self = findSelfMarker(data);
        boolean rotate = AppleSettings.dungeonMapRotate && self != null;
        float pivotX = self == null ? 64.0F : self.func_176112_b() / 2.0F + 64.0F;
        float pivotY = self == null ? 64.0F : self.func_176113_c() / 2.0F + 64.0F;
        float angle = rotate ? 180.0F - MathHelper.wrapAngleTo180_float(mc.thePlayer.rotationYaw) : 0.0F;
        // Content zoom is independent from the HUD widget scale. In rotating mode it multiplies
        // the stable fit zoom, so turning the player never changes the selected magnification.
        float contentZoom = AppleSettings.dungeonMapZoomFactor();
        float rotateZoom = rotate ? stableRotationZoom(data, self) * contentZoom : contentZoom;
        DungeonMapProjection projection = new DungeonMapProjection(rotate, pivotX, pivotY, angle, rotateZoom);
        List<String> decorationKeys = getSortedDecorationKeys(data.mapDecorations);
        List<PlayerHead> playerHeads = AppleSettings.dungeonMapPlayerHeads
                ? collectPlayerHeads(mc, data, decorationKeys) : Collections.<PlayerHead>emptyList();
        if (!AppleSettings.dungeonMapPlayerHeads) clearPlayerHeadMotions();
        Set<String> replacedPlayerMarkerKeys = playerHeadMarkerKeys(playerHeads);
        occupiedLabelBounds.clear();

        GuiOverlayRenderState renderState = new GuiOverlayRenderState();
        GlStateManager.pushMatrix();
        try {
            GlStateManager.translate(x, y, 0.0F);
            GlStateManager.scale(scale, scale, 1.0F);
            GlStateManager.enableTexture2D();
            GlStateManager.enableAlpha();
            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);

            if (rotate) {
                // Keep pixels not covered by the native map texture transparent. An opaque fill here
                // obscures the game behind unknown map pixels and makes the entire map look black.
                // The border is drawn separately after the map, like Better NEF.
                renderRotatingMap(mc, data, self, angle, rotateZoom, x, y, scale, decorationKeys, replacedPlayerMarkerKeys);
            } else {
                renderStaticMap(mc, data, contentZoom, x, y, scale, replacedPlayerMarkerKeys);
            }

            // Text is deliberately drawn after the map transform: its anchor follows the world map,
            // but the glyphs stay level and have no opaque rectangle behind them.
            drawDiscoveredPuzzleNames(mc, data, projection);
            drawPlayerHeads(playerHeads, projection, partialTicks);
            drawPlayerNames(mc, data, projection, decorationKeys);
            drawSecretsCount(mc);
        } finally {
            GlStateManager.popMatrix();
            renderState.restore();
        }
    }

    /** Scales static-map contents around their center while keeping the HUD viewport fixed and clipped. */
    private void renderStaticMap(Minecraft mc, MapData data, float contentZoom,
                                 int screenX, int screenY, float scale, Set<String> replacedPlayerMarkerKeys) {
        ScaledResolution resolution = new ScaledResolution(mc);
        int factor = resolution.getScaleFactor();
        int scissorX = Math.round(screenX * factor);
        int scissorSize = Math.max(1, Math.round(128.0F * scale * factor));
        int scissorY = mc.displayHeight - Math.round(screenY * factor) - scissorSize;
        boolean wasScissored = GL11.glIsEnabled(GL11.GL_SCISSOR_TEST);
        PREVIOUS_SCISSOR.clear();
        GL11.glGetInteger(GL11.GL_SCISSOR_BOX, PREVIOUS_SCISSOR);
        int prevX = PREVIOUS_SCISSOR.get(0);
        int prevY = PREVIOUS_SCISSOR.get(1);
        int prevW = PREVIOUS_SCISSOR.get(2);
        int prevH = PREVIOUS_SCISSOR.get(3);

        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor(scissorX, scissorY, scissorSize, scissorSize);
        GlStateManager.pushMatrix();
        try {
            GlStateManager.translate(64.0F, 64.0F, 0.0F);
            GlStateManager.scale(contentZoom, contentZoom, 1.0F);
            GlStateManager.translate(-64.0F, -64.0F, 0.0F);
            Map<String, Vec4b> actualDecorations = data.mapDecorations;
            data.mapDecorations = withoutPlayerHeadMarkers(actualDecorations, replacedPlayerMarkerKeys);
            try {
                mc.entityRenderer.getMapItemRenderer().renderMap(data, false);
            } finally {
                data.mapDecorations = actualDecorations;
            }
        } finally {
            GlStateManager.popMatrix();
            if (wasScissored) {
                GL11.glScissor(prevX, prevY, prevW, prevH);
            } else {
                GL11.glDisable(GL11.GL_SCISSOR_TEST);
            }
        }
    }

    /** Mirrors Better NEF's map projection: rotate around the local-player decoration and clip to the map square. */
    private void renderRotatingMap(Minecraft mc, MapData data, Vec4b self, float angle, float rotateZoom,
                                   int screenX, int screenY, float scale, List<String> decorationKeys,
                                   Set<String> replacedPlayerMarkerKeys) {
        float pivotX = self.func_176112_b() / 2.0F + 64.0F;
        float pivotY = self.func_176113_c() / 2.0F + 64.0F;
        ScaledResolution resolution = new ScaledResolution(mc);
        int factor = resolution.getScaleFactor();
        int scissorX = Math.round(screenX * factor);
        int scissorSize = Math.max(1, Math.round(128.0F * scale * factor));
        int scissorY = mc.displayHeight - Math.round(screenY * factor) - scissorSize;
        boolean wasScissored = GL11.glIsEnabled(GL11.GL_SCISSOR_TEST);
        PREVIOUS_SCISSOR.clear();
        GL11.glGetInteger(GL11.GL_SCISSOR_BOX, PREVIOUS_SCISSOR);
        int prevX = PREVIOUS_SCISSOR.get(0);
        int prevY = PREVIOUS_SCISSOR.get(1);
        int prevW = PREVIOUS_SCISSOR.get(2);
        int prevH = PREVIOUS_SCISSOR.get(3);

        Map<String, Vec4b> actualDecorations = data.mapDecorations;
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor(scissorX, scissorY, scissorSize, scissorSize);
        GlStateManager.pushMatrix();
        try {
            GlStateManager.translate(64.0F, 64.0F, 0.0F);
            GlStateManager.scale(rotateZoom, rotateZoom, 1.0F);
            GlStateManager.rotate(angle, 0.0F, 0.0F, 1.0F);
            GlStateManager.translate(-pivotX, -pivotY, 0.0F);
            data.mapDecorations = NO_DECORATIONS;
            try {
                mc.entityRenderer.getMapItemRenderer().renderMap(data, false);
            } finally {
                data.mapDecorations = actualDecorations;
            }
            drawNativeMapMarkers(mc, withoutPlayerHeadMarkers(actualDecorations, replacedPlayerMarkerKeys), decorationKeys, angle);
        } finally {
            data.mapDecorations = actualDecorations;
            GlStateManager.popMatrix();
            if (wasScissored) {
                GL11.glScissor(prevX, prevY, prevW, prevH);
            } else {
                GL11.glDisable(GL11.GL_SCISSOR_TEST);
            }
        }
    }

    /** Returns the original map when no face is ready, otherwise filters only markers replaced by a loaded skin. */
    private static Map<String, Vec4b> withoutPlayerHeadMarkers(Map<String, Vec4b> decorations,
                                                                 Set<String> replacedPlayerMarkerKeys) {
        if (decorations == null || decorations.isEmpty() || replacedPlayerMarkerKeys == null
                || replacedPlayerMarkerKeys.isEmpty()) return decorations;
        Map<String, Vec4b> visible = new HashMap<String, Vec4b>();
        for (Map.Entry<String, Vec4b> entry : decorations.entrySet()) {
            if (!replacedPlayerMarkerKeys.contains(entry.getKey())) visible.put(entry.getKey(), entry.getValue());
        }
        return visible;
    }

    private static void drawNativeMapMarkers(Minecraft mc, Map<String, Vec4b> decorations,
                                             List<String> decorationKeys, float angle) {
        if (decorations == null || decorations.isEmpty() || decorationKeys.isEmpty()) return;
        mc.getTextureManager().bindTexture(MAP_ICONS);
        GlStateManager.enableTexture2D();
        GlStateManager.enableAlpha();
        GlStateManager.disableBlend();
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        int depthIndex = 0;
        for (String key : decorationKeys) {
            Vec4b marker = decorations.get(key);
            if (marker == null) continue;
            boolean local = marker.func_176110_a() == 1;
            float rotation = local ? (180.0F - angle) * 16.0F / 360.0F : marker.func_176111_d();
            drawNativeMarker(marker.func_176112_b() / 2.0F + 64.0F,
                    marker.func_176113_c() / 2.0F + 64.0F, rotation, marker.func_176110_a(), depthIndex++);
        }
    }

    private static void drawNativeMarker(float x, float y, float rotation, byte type, int index) {
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer buffer = tessellator.getWorldRenderer();
        GlStateManager.pushMatrix();
        try {
            GlStateManager.translate(x, y, -0.02F);
            GlStateManager.rotate(rotation * 360.0F / 16.0F, 0.0F, 0.0F, 1.0F);
            GlStateManager.scale(4.0F, 4.0F, 3.0F);
            GlStateManager.translate(-0.125F, 0.125F, 0.0F);
            int icon = type & 15;
            float u0 = (icon % 4) / 4.0F;
            float v0 = (icon / 4) / 4.0F;
            float u1 = (icon % 4 + 1) / 4.0F;
            float v1 = (icon / 4 + 1) / 4.0F;
            float depth = index * -0.001F;
            buffer.begin(7, DefaultVertexFormats.POSITION_TEX);
            buffer.pos(-1.0D, 1.0D, depth).tex(u0, v0).endVertex();
            buffer.pos(1.0D, 1.0D, depth).tex(u1, v0).endVertex();
            buffer.pos(1.0D, -1.0D, depth).tex(u1, v1).endVertex();
            buffer.pos(-1.0D, -1.0D, depth).tex(u0, v1).endVertex();
            tessellator.draw();
        } finally {
            GlStateManager.popMatrix();
        }
    }

    private float stableRotationZoom(MapData data, Vec4b self) {
        // Freeze the fit for one map-data instance. This prevents marker updates during a run from
        // making the map pulse in size; yaw changes never enter this calculation.
        if (data != rotationZoomSource) {
            rotationZoomSource = data;
            float pivotX = self.func_176112_b() / 2.0F + 64.0F;
            float pivotY = self.func_176113_c() / 2.0F + 64.0F;
            cachedRotationZoom = DungeonMapProjection.fitZoom(pivotX, pivotY);
        }
        return cachedRotationZoom;
    }

    /** Previously discovered names stay attached to their room coordinates until the dungeon run ends. */
    private void drawDiscoveredPuzzleNames(Minecraft mc, MapData data, DungeonMapProjection projection) {
        if (!AppleSettings.dungeonMapShowPuzzleName) {
            if (puzzleMemory.size() > 0) puzzleSync.reportMapState(mc, "Puzzle-name display is disabled", puzzleMemory.size());
            return;
        }
        if (puzzleMemory.size() == 0 || mc.thePlayer == null) return;
        Vec4b self = findSelfMarker(data);
        if (self == null) {
            puzzleSync.reportMapState(mc, "Known puzzle labels cannot be projected because the local-player map marker is missing", puzzleMemory.size());
            return;
        }
        if (puzzleAnchorData != data) {
            // A different map item has a different texture coordinate system; keep world-space room identity,
            // but recapture pixel anchors for this map texture.
            puzzleAnchorData = data;
            puzzleMemory.clearMapPositions();
        }
        float selfMapX = self.func_176112_b() / 2.0F + 64.0F;
        float selfMapY = self.func_176113_c() / 2.0F + 64.0F;
        float pixelsPerBlock = detectMapPixelsPerBlock(data);
        puzzleMemory.snapshotInto(renderRoomSnapshot);
        for (PuzzleRoomMemory.RoomLabel room : renderRoomSnapshot) {
            // Capture each room's texture-space position once per map data instance. The held map
            // updates player decorations at a different cadence than entity movement; recomputing
            // this from the live player coordinates every frame makes puzzle names slide and snap.
            // The stored map anchor then follows the exact same rotation/zoom as the map texture.
            if (!room.hasMapPosition()) {
                if (!DungeonMapLabelAnchor.projectRoomCenter(room.originX, room.originZ,
                        mc.thePlayer.posX, mc.thePlayer.posZ, selfMapX, selfMapY,
                        pixelsPerBlock, layoutProjectionScratch)) {
                    puzzleSync.reportMapState(mc, "Puzzle room has no valid map-space anchor", puzzleMemory.size());
                    continue;
                }
                // Use the world projection only to find the corresponding room. Snap the final label
                // anchor to the center of the purple room pixels in this exact map texture, so scale
                // rounding and map-marker quantization cannot leave the name off-center.
                DungeonMapLabelAnchor.snapToPurpleRoomCenter(data.colors,
                        layoutProjectionScratch[0], layoutProjectionScratch[1], layoutProjectionScratch);
                boolean captured = puzzleMemory.rememberMapPosition(room.originX, room.originY, room.originZ,
                        layoutProjectionScratch[0], layoutProjectionScratch[1]);
                if (captured) puzzleSync.reportMapAnchor(mc, room.originX, room.originY, room.originZ);
            }
            if (!room.hasMapPosition()) {
                puzzleSync.reportMapState(mc, "Puzzle room has no valid map-space anchor", puzzleMemory.size());
                continue;
            }

            PuzzleLabels.Style style = PuzzleLabels.of(room.name);
            String[] lines = PuzzleLabels.wrap(style.full);
            int maxLineWidth = 1;
            for (String line : lines) {
                maxLineWidth = Math.max(maxLineWidth, mc.fontRendererObj.getStringWidth(line));
            }
            int lineAdvance = mc.fontRendererObj.FONT_HEIGHT + 1;
            int blockHeight = lines.length * mc.fontRendererObj.FONT_HEIGHT + (lines.length - 1);
            float textScale = Math.min(0.46F, 18.0F / maxLineWidth);

            float textWidthOnMap = maxLineWidth * textScale;
            float textHeightOnMap = blockHeight * textScale;
            DungeonMapLabelLayout.Placement placement = DungeonMapLabelLayout.findCenteredProjected(
                    projection, room.mapX(), room.mapY(), textWidthOnMap, textHeightOnMap,
                    layoutProjectionScratch);
            if (placement == null) {
                puzzleSync.reportMapLabelOverlap(mc, room.name, room.originX, room.originY, room.originZ);
                continue;
            }
            occupiedLabelBounds.add(placement.bounds);
            puzzleSync.reportMapLabelRendered(mc, room.name, room.originX, room.originY, room.originZ);

            GlStateManager.pushMatrix();
            try {
                GlStateManager.translate(placement.centerX, placement.centerY, 0.0F);
                // The map anchor rotates with the map, but the two-line text stays screen-readable.
                GlStateManager.scale(textScale, textScale, 1.0F);
                float firstLineY = -blockHeight * 0.5F;
                // Keep the puzzle marker as plain, centered text with no backing plate or side accent.
                for (int lineIndex = 0; lineIndex < lines.length; lineIndex++) {
                    String line = lines[lineIndex];
                    int lineWidth = mc.fontRendererObj.getStringWidth(line);
                    mc.fontRendererObj.drawStringWithShadow(line,
                            -lineWidth * 0.5F, firstLineY + lineIndex * lineAdvance, style.color);
                }
            } finally {
                GlStateManager.popMatrix();
            }
        }
    }

    /** Collects only resolved player markers with a loaded tab-list skin; every other marker remains vanilla. */
    private List<PlayerHead> collectPlayerHeads(Minecraft mc, MapData data, List<String> decorationKeys) {
        if (playerHeadMotionData != data) {
            clearPlayerHeadMotions();
            playerHeadMotionData = data;
        }
        Map<String, String> names = mappedNames(mc, data, decorationKeys);
        if (names.isEmpty() || data.mapDecorations == null || data.mapDecorations.isEmpty()) {
            playerHeadMotions.clear();
            return Collections.emptyList();
        }
        List<PlayerHead> heads = new ArrayList<PlayerHead>();
        Set<String> activeIdentities = new HashSet<String>();
        for (String key : decorationKeys) {
            Vec4b marker = data.mapDecorations.get(key);
            if (!isPlayerMarker(marker)) continue;
            String name = names.get(key);
            ResourceLocation skin = loadedSkin(mc, name);
            if (skin == null) continue;
            String identity = key + "|" + name.toLowerCase(Locale.ROOT);
            DungeonMapPlayerHeadMotion motion = playerHeadMotions.get(identity);
            if (motion == null) {
                motion = new DungeonMapPlayerHeadMotion();
                playerHeadMotions.put(identity, motion);
            }
            motion.update(marker.func_176112_b() / 2.0F + 64.0F, marker.func_176113_c() / 2.0F + 64.0F);
            activeIdentities.add(identity);
            heads.add(new PlayerHead(key, skin, motion));
        }
        for (Iterator<Map.Entry<String, DungeonMapPlayerHeadMotion>> it = playerHeadMotions.entrySet().iterator();
             it.hasNext();) {
            if (!activeIdentities.contains(it.next().getKey())) it.remove();
        }
        return heads;
    }

    private static ResourceLocation loadedSkin(Minecraft mc, String name) {
        if (mc == null || mc.getNetHandler() == null || name == null || name.length() == 0) return null;
        NetworkPlayerInfo info = mc.getNetHandler().getPlayerInfo(name);
        if (info == null) return null;
        ResourceLocation requested = info.getLocationSkin();
        return info.hasLocationSkin() ? requested : null;
    }

    private static boolean isPlayerMarker(Vec4b marker) {
        if (marker == null) return false;
        int type = marker.func_176110_a();
        return type == 0 || type == 1 || type == 3;
    }

    private static Set<String> playerHeadMarkerKeys(List<PlayerHead> heads) {
        if (heads == null || heads.isEmpty()) return Collections.emptySet();
        Set<String> keys = new HashSet<String>();
        for (PlayerHead head : heads) keys.add(head.markerKey);
        return keys;
    }

    /** Faces use the same map projection/zoom as player names; only their native map marker is hidden. */
    private static void drawPlayerHeads(List<PlayerHead> heads, DungeonMapProjection projection, float partialTicks) {
        if (heads == null || heads.isEmpty() || projection == null) return;
        final float size = 8.0F;
        final float half = size * 0.5F;
        float[] point = new float[2];
        for (PlayerHead head : heads) {
            projection.project(head.motion.x(partialTicks), head.motion.y(partialTicks), point);
            float centerX = DungeonMapPlayerHeadMotion.clampCenter(point[0], size);
            float centerY = DungeonMapPlayerHeadMotion.clampCenter(point[1], size);
            SkinHead.draw(head.skin, centerX - half, centerY - half, size, 1.0F);
        }
    }

    private void advancePlayerHeadMotions() {
        for (DungeonMapPlayerHeadMotion motion : playerHeadMotions.values()) motion.advanceTick();
    }

    private void clearPlayerHeadMotions() {
        playerHeadMotionData = null;
        playerHeadMotions.clear();
    }

    private static final class PlayerHead {
        final String markerKey;
        final ResourceLocation skin;
        final DungeonMapPlayerHeadMotion motion;

        PlayerHead(String markerKey, ResourceLocation skin, DungeonMapPlayerHeadMotion motion) {
            this.markerKey = markerKey;
            this.skin = skin;
            this.motion = motion;
        }
    }

    private void drawPlayerNames(Minecraft mc, MapData data, DungeonMapProjection projection,
                                 List<String> decorationKeys) {
        if (!AppleSettings.dungeonMapShowPlayerNames || data.mapDecorations == null || data.mapDecorations.isEmpty()) return;
        Map<String, String> names = mappedNames(mc, data, decorationKeys);
        float[] point = new float[2];
        for (String key : decorationKeys) {
            Vec4b marker = data.mapDecorations.get(key);
            String name = names.get(key);
            if (marker == null || name == null) continue;
            int type = marker.func_176110_a();
            if (type != 0 && type != 1 && type != 3) continue;
            name = StringUtils.stripControlCodes(name);
            if (name == null || name.isEmpty()) continue;
            float rawX = marker.func_176112_b() / 2.0F + 64.0F;
            float rawY = marker.func_176113_c() / 2.0F + 64.0F;
            projection.project(rawX, rawY, point);
            int width = mc.fontRendererObj.getStringWidth(name);
            float textScale = Math.min(0.55F, 36.0F / Math.max(1, width));
            float renderedWidth = width * textScale;
            float renderedHeight = mc.fontRendererObj.FONT_HEIGHT * textScale;
            // Use one fixed offset from every marker. Collision-based candidate switching made
            // names jump between sides as the rotating map changed label overlaps from frame to frame.
            DungeonMapLabelLayout.Placement placement = DungeonMapLabelLayout.findStableScreen(
                    point[0], point[1], renderedWidth, renderedHeight);
            if (placement == null) continue;
            GlStateManager.pushMatrix();
            try {
                GlStateManager.translate(placement.centerX - renderedWidth * 0.5F,
                        placement.centerY - renderedHeight * 0.5F, 0.0F);
                GlStateManager.scale(textScale, textScale, 1.0F);
                mc.fontRendererObj.drawStringWithShadow(name, 0.0F, 0.0F, 0xFFFFFFFF);
            } finally {
                GlStateManager.popMatrix();
            }
        }
    }

    private static Vec4b findSelfMarker(MapData data) {
        if (data.mapDecorations == null) return null;
        for (Vec4b marker : data.mapDecorations.values()) {
            if (marker != null && marker.func_176110_a() == 1) return marker;
        }
        return null;
    }

    private static MapData mapScaleSource;
    private static long mapScaleCheckedAt;
    private static float cachedPixelsPerBlock = 20.0F / 32.0F;
    // Freeze zoom per map instance so movement/marker refreshes do not pulse the map's scale.
    private MapData rotationZoomSource;
    private float cachedRotationZoom = 0.66F;

    private static float detectMapPixelsPerBlock(MapData data) {
        long now = System.currentTimeMillis();
        if (data == mapScaleSource && now - mapScaleCheckedAt < 2000L) return cachedPixelsPerBlock;
        mapScaleSource = data;
        mapScaleCheckedAt = now;
        int longest = 0;
        for (int y = 0; y < 128; y++) {
            int run = 0;
            for (int x = 0; x < 128; x++) {
                if ((data.colors[y * 128 + x] & 0xFF) == 30) {
                    run++;
                    if (run > longest) longest = run;
                } else run = 0;
            }
        }
        cachedPixelsPerBlock = longest >= 18 ? 22.0F / 32.0F : 20.0F / 32.0F;
        return cachedPixelsPerBlock;
    }

    private void applySyncedPuzzles() {
        if (!DungeonContext.inDungeon() || !puzzleSync.isSessionActive()) {
            int dropped = 0;
            while (puzzleSync.pollSharedPuzzle() != null) dropped++;
            if (dropped > 0) puzzleSync.reportMapState(Minecraft.getMinecraft(),
                    "Discarded " + dropped + " queued remote puzzle event(s) because the local dungeon session is not active", puzzleMemory.size());
            return;
        }
        DungeonPuzzleSyncManager.SharedPuzzle shared;
        while ((shared = puzzleSync.pollSharedPuzzle()) != null) {
            boolean newRoom = !puzzleMemory.containsRoomAt(shared.x, shared.y, shared.z);
            puzzleMemory.remember(shared.name, shared.x, shared.y, shared.z, shared.confidence);
            puzzleSync.onSharedPuzzleApplied(Minecraft.getMinecraft(), shared, newRoom);
        }
        if (puzzleSync.consumeReplayRequest()) {
            for (PuzzleRoomMemory.RoomLabel room : puzzleMemory.snapshot()) puzzleSync.publishRememberedPuzzle(room);
        }
    }

    @SubscribeEvent
    public void onSyncStartMessage(ClientChatReceivedEvent event) {
        if (event == null || event.message == null) return;
        String text = StringUtils.stripControlCodes(event.message.getUnformattedText());
        if (dev.client.lunaria.dungeon.sync.DungeonSyncIdentity.isDungeonStartMessage(event.type, text)) {
            roomMatcher.reset();
            clearPuzzleMemory();
            Minecraft mc = Minecraft.getMinecraft();
            puzzleMemoryWorld = mc == null ? null : mc.theWorld;
        }
    }

    public DungeonPuzzleSyncManager getPuzzleSyncManager() { return puzzleSync; }

    private Map<String, String> mappedNames(Minecraft mc, MapData data, List<String> icons) {
        // Marker positions change as players move. They must not invalidate name assignments: doing so
        // repeatedly made labels jump between players and appear to flicker.
        long hash = 1469598103934665603L;
        for (String key : icons) {
            Vec4b marker = data.mapDecorations.get(key);
            hash = (hash ^ (key == null ? 0 : key.hashCode())) * 1099511628211L;
            hash = (hash ^ (marker == null ? -1 : marker.func_176110_a())) * 1099511628211L;
        }
        long currentRosterHash = rosterSignature(roster);
        if (assignmentData == data && decorationHash == hash && rosterHash == currentRosterHash) return assignments;

        Map<String, String> previousAssignments = assignmentData == data ? assignments : Collections.<String, String>emptyMap();
        assignmentData = data;
        decorationHash = hash;
        rosterHash = currentRosterHash;
        Map<String, String> out = new HashMap<String, String>();
        if (mc.getNetHandler() == null || mc.thePlayer == null || mc.theWorld == null) {
            assignments = out;
            return out;
        }

        List<String> names = roster;
        Vec4b self = findSelfMarker(data);
        List<Integer> candidateIndexes = new ArrayList<Integer>();
        List<String> candidateKeys = new ArrayList<String>();
        for (int i = 0; i < icons.size(); i++) {
            String key = icons.get(i);
            Vec4b marker = data.mapDecorations.get(key);
            if (marker != null && (marker.func_176110_a() == 0 || marker.func_176110_a() == 1 || marker.func_176110_a() == 3)) {
                candidateIndexes.add(i);
                candidateKeys.add(key);
            }
        }

        Set<String> used = new HashSet<String>();
        String selfName = mc.thePlayer.getName();
        String selfKey = null;
        if (self != null) {
            for (int idx : candidateIndexes) {
                if (data.mapDecorations.get(icons.get(idx)) == self) {
                    selfKey = icons.get(idx);
                    break;
                }
            }
            if (selfKey != null) {
                out.put(selfKey, selfName);
                used.add(selfName.toLowerCase(Locale.ROOT));
            }
        }

        // Reuse existing key-to-name pairs when the roster or marker set changes. Keys that remain
        // stable keep their labels even when a refresh changes marker positions or iteration order.
        for (String key : candidateKeys) {
            if (key.equals(selfKey)) continue;
            String oldName = previousAssignments.get(key);
            if (oldName == null || !containsIgnoreCase(names, oldName)) continue;
            String normalized = oldName.toLowerCase(Locale.ROOT);
            if (used.add(normalized)) out.put(key, oldName);
        }

        if (self != null) {
            double selfX = self.func_176112_b() / 2.0D + 64.0D;
            double selfZ = self.func_176113_c() / 2.0D + 64.0D;
            List<String> remainingNames = new ArrayList<String>();
            for (String name : names) if (name != null && !used.contains(name.toLowerCase(Locale.ROOT))) remainingNames.add(name);
            List<Integer> remainingIndexes = new ArrayList<Integer>();
            for (int idx : candidateIndexes) if (!out.containsKey(icons.get(idx))) remainingIndexes.add(idx);

            // Use live entity coordinates when available. Remote players may not be loaded as entities
            // on the client, so this pass is only an improvement and never a requirement for a label.
            for (String name : remainingNames) {
                EntityPlayer entity = mc.theWorld.getPlayerEntityByName(name);
                if (entity == null || entity == mc.thePlayer) continue;
                int bestIdx = -1;
                double bestDistance = Double.MAX_VALUE;
                for (double pxPerBlock : new double[]{20.0D / 32.0D, 22.0D / 32.0D}) {
                    double tx = selfX + (entity.posX - mc.thePlayer.posX) * pxPerBlock;
                    double tz = selfZ + (entity.posZ - mc.thePlayer.posZ) * pxPerBlock;
                    for (int idx : remainingIndexes) {
                        Vec4b marker = data.mapDecorations.get(icons.get(idx));
                        if (marker == null) continue;
                        double dx = marker.func_176112_b() / 2.0D + 64.0D - tx;
                        double dz = marker.func_176113_c() / 2.0D + 64.0D - tz;
                        double distance = Math.sqrt(dx * dx + dz * dz);
                        if (distance < bestDistance) { bestDistance = distance; bestIdx = idx; }
                    }
                }
                if (bestIdx >= 0 && bestDistance <= 4.0D) {
                    String key = icons.get(bestIdx);
                    if (used.add(name.toLowerCase(Locale.ROOT))) {
                        out.put(key, name);
                        remainingIndexes.remove(Integer.valueOf(bestIdx));
                    }
                }
            }
        }

        // Always fill remaining player markers from the party roster, even when the roster and marker
        // counts differ. The old equal-count requirement silently dropped remote players whenever the
        // tab list contained extra entries or a remote entity was not loaded locally.
        assignments = DungeonMapPlayerNameAssignments.fillUnassigned(candidateKeys, names, out);
        return assignments;
    }

    private static long rosterSignature(List<String> names) {
        long hash = 1469598103934665603L;
        for (String name : names) {
            hash = (hash ^ (name == null ? 0 : name.toLowerCase(Locale.ROOT).hashCode())) * 1099511628211L;
        }
        return hash;
    }

    private List<String> getSortedDecorationKeys(Map<String, Vec4b> decorations) {
        if (decorations == null || decorations.isEmpty()) {
            sortedDecorationKeys = Collections.emptyList();
            sortedDecorationKeysSignature = 0L;
            sortedDecorationKeysCount = 0;
            return sortedDecorationKeys;
        }
        long signature = 1469598103934665603L;
        for (Map.Entry<String, Vec4b> entry : decorations.entrySet()) {
            signature = (signature ^ (entry.getKey() == null ? 0 : entry.getKey().hashCode())) * 1099511628211L;
            Vec4b marker = entry.getValue();
            signature = (signature ^ (marker == null ? -1 : marker.func_176110_a())) * 1099511628211L;
        }
        if (decorations.size() == sortedDecorationKeysCount && signature == sortedDecorationKeysSignature) {
            return sortedDecorationKeys;
        }
        List<String> keys = new ArrayList<String>(decorations.keySet());
        Collections.sort(keys, new Comparator<String>() {
            @Override public int compare(String a, String b) {
                int ai = keyIndex(a), bi = keyIndex(b);
                if (ai != bi) return ai < bi ? -1 : 1;
                if (a == null) return b == null ? 0 : 1;
                if (b == null) return -1;
                return a.compareTo(b);
            }
        });
        sortedDecorationKeys = Collections.unmodifiableList(keys);
        sortedDecorationKeysSignature = signature;
        sortedDecorationKeysCount = decorations.size();
        return sortedDecorationKeys;
    }

    private static int keyIndex(String key) {
        Matcher m = ICON_KEY.matcher(key == null ? "" : key);
        if (!m.matches()) return Integer.MAX_VALUE;
        try { return Integer.parseInt(m.group(1)); } catch (NumberFormatException e) { return Integer.MAX_VALUE; }
    }

    private void refreshRoster(Minecraft mc) {
        rosterWorld = mc.theWorld; rosterUpdatedAt = System.currentTimeMillis();
        if (mc.getNetHandler() == null) { updateRoster(Collections.<String>emptyList()); return; }
        List<NetworkPlayerInfo> info = new ArrayList<NetworkPlayerInfo>(mc.getNetHandler().getPlayerInfoMap());
        Collections.sort(info, new Comparator<NetworkPlayerInfo>() {
            @Override public int compare(NetworkPlayerInfo a, NetworkPlayerInfo b) {
                if (a == b) return 0; if (a == null) return 1; if (b == null) return -1;
                boolean ap = a.getGameType() != WorldSettings.GameType.SPECTATOR;
                boolean bp = b.getGameType() != WorldSettings.GameType.SPECTATOR;
                if (ap != bp) return ap ? -1 : 1;
                String at = a.getPlayerTeam() == null ? "" : a.getPlayerTeam().getRegisteredName();
                String bt = b.getPlayerTeam() == null ? "" : b.getPlayerTeam().getRegisteredName();
                int c = at.compareToIgnoreCase(bt); if (c != 0) return c;
                return a.getGameProfile().getName().compareToIgnoreCase(b.getGameProfile().getName());
            }
        });
        List<String> known = new ArrayList<String>();
        for (NetworkPlayerInfo player : info) {
            if (player != null && player.getGameProfile() != null) known.add(player.getGameProfile().getName());
        }
        List<String> sidebar = sidebarLines(mc.theWorld.getScoreboard());
        List<String> orderedParty = DungeonMapPartyRoster.build(sidebar, known, mc.thePlayer.getName());
        updateRoster(orderedParty);
    }

    private void updateRoster(List<String> nextRoster) {
        if (sameRosterMembers(roster, nextRoster)) return;
        roster = Collections.unmodifiableList(new ArrayList<String>(nextRoster));
        // mappedNames() observes the changed roster signature and rebuilds only once.
    }

    private static boolean sameRosterMembers(List<String> current, List<String> next) {
        if (current.size() != next.size()) return false;
        Set<String> currentNames = new HashSet<String>();
        for (String name : current) if (name != null) currentNames.add(name.toLowerCase(Locale.ROOT));
        for (String name : next) {
            if (name == null || !currentNames.remove(name.toLowerCase(Locale.ROOT))) return false;
        }
        return currentNames.isEmpty();
    }

    private static List<String> sidebarLines(Scoreboard board) {
        List<String> lines = new ArrayList<String>();
        if (board == null) return lines;
        ScoreObjective objective = board.getObjectiveInDisplaySlot(1);
        if (objective == null) return lines;
        Collection<Score> scores = board.getSortedScores(objective);
        if (scores == null) return lines;
        for (Score score : scores) {
            if (score == null || score.getPlayerName() == null || score.getPlayerName().startsWith("#")) continue;
            String line = ScorePlayerTeam.formatPlayerName(board.getPlayersTeam(score.getPlayerName()), score.getPlayerName());
            lines.add(StringUtils.stripControlCodes(line));
        }
        return lines;
    }

    private static boolean containsIgnoreCase(List<String> values, String needle) {
        for (String value : values) if (value != null && needle != null && value.equalsIgnoreCase(needle)) return true;
        return false;
    }

    private void drawSecretsCount(Minecraft mc) {
        Scoreboard scoreboard = mc.theWorld.getScoreboard();
        long now = System.currentTimeMillis();
        if (scoreboard != secretsScoreboard || now - secretsUpdatedAt >= 300L) {
            secretsScoreboard = scoreboard;
            secretsUpdatedAt = now;
            cachedSecretsCount = currentSecrets(scoreboard);
        }
        if (cachedSecretsCount == null) return;
        String text = "Secrets: " + cachedSecretsCount;
        mc.fontRendererObj.drawStringWithShadow(text, 3.0F, 116.0F, 0xFFFFFFFF);
    }

    static String currentSecrets(Scoreboard scoreboard) {
        for (String line : sidebarLines(scoreboard)) {
            Matcher matcher = SECRET_COUNT.matcher(LeapText.strip(line));
            if (matcher.find()) return matcher.group(1);
        }
        return null;
    }

    private void clearRoster() {
        rosterWorld = null; rosterUpdatedAt = 0L; roster = Collections.emptyList();
        assignmentData = null; decorationHash = 0L; rosterHash = 0L; assignments = Collections.emptyMap();
    }
}
