package dev.client.lunaria.notes;

import net.minecraft.client.Minecraft;

import java.io.File;

/** One shared quick-note store for the session. The pages live in lunaria-notes.txt in the game folder. */
public final class QuickNotes {

    public static final String FILE_NAME = "lunaria-notes.txt";
    private static QuickNoteStore store;

    private QuickNotes() {
    }

    public static synchronized QuickNoteStore store() {
        if (store == null) {
            store = new QuickNoteStore(new File(Minecraft.getMinecraft().mcDataDir, FILE_NAME));
        }
        return store;
    }
}
