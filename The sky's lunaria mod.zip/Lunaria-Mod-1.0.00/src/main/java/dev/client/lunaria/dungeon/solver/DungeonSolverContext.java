package dev.client.lunaria.dungeon.solver;

import dev.client.lunaria.feature.DungeonContext;

/** Shared context gates for the Better NEF dungeon features adapted to Lunaria Mod. */
public final class DungeonSolverContext {
    private DungeonSolverContext() { }

    public static boolean checkEssentials() {
        return DungeonContext.inDungeon();
    }

    public static boolean checkEssentialsF7() {
        return DungeonContext.inF7OrM7();
    }
}
