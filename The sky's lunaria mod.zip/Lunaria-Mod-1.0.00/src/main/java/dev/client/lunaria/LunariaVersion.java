package dev.client.lunaria;

/**
 * The single source of truth for the Lunaria Mod version and name.
 *
 * build.gradle reads NAME from this file, so the jar name, mcmod.info, the GUI title and the
 * version label always match. Change it only when preparing a new release, never on every game
 * launch or build. Current release: 1.0.0.
 *
 * The Java package and mod id use the Lunaria namespace {@code dev.client.lunaria}. Existing asset
 * paths, keybinding ids and mod-specific files resolve under that namespace. The displayed client
 * name and release metadata use Lunaria Mod.
 */
public final class LunariaVersion {

    /** The version string shown in the GUI and written to mcmod.info. */
    public static final String NAME = "1.0.0";

    /** The client's display name. */
    public static final String DISPLAY_NAME = "Lunaria Mod";

    private LunariaVersion() {
    }
}
