#!/bin/sh
# Compiles and runs the pure-logic, config, text and migration tests. No game is started.
#
# Needs a JDK 8, compiled classes (build/classes/main), and either TEST_CP (the complete Forge test classpath)
# or the MC_JAR, LOG4J_JAR and GSON_JAR paths used by the legacy invocation.
# Example after `gradle build dumpTestClasspath`:
#   TEST_CP="$(cat build/test-classpath.txt)" sh tests/run-tests.sh
set -e
HERE=$(cd "$(dirname "$0")/.." && pwd)
CLASSES="${CLASSES:-$HERE/build/classes/main}"
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT
if [ -n "${TEST_CP:-}" ]; then
  CP="$CLASSES:$TEST_CP"
else
  : "${MC_JAR:?set MC_JAR to minecraft_merged-1.8.9.jar, or set TEST_CP}"
  : "${LOG4J_JAR:?set LOG4J_JAR to the log4j-api jar, or set TEST_CP}"
  : "${GSON_JAR:?set GSON_JAR to the gson jar, or set TEST_CP}"
  CP="$CLASSES:$MC_JAR:$LOG4J_JAR:$GSON_JAR"
fi
javac -nowarn -encoding UTF-8 -cp "$CP" -d "$OUT" $(find "$HERE/tests" -name '*.java')
java -cp "$OUT:$CP" dev.client.lunaria.gui.PureLogicTests
java -cp "$OUT:$CP" dev.client.lunaria.hud.ConfigTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.LeapTextTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.SkyblockContextPolicyTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.AutoSprintTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.inventory.InventoryLayoutPolicyTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.LeapIdentityTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.LeapClassCacheTests
java -cp "$OUT:$CP" dev.client.lunaria.config.ConfigFilesTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.protection.ProtectedItemStoreTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.protection.ProtectedItemActionPolicyTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.inventory.SlotLockStoreTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.inventory.SlotBindingGesturePolicyTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.qol.InventorySearchMatcherTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.qol.RomanNumeralParserTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.qol.ItemRarityColorsTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.qol.TooltipScrollWindowTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.qol.ChatCopyTextPolicyTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.qol.ChatLengthPolicyTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.mining.MiningAbilityCooldownTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.mining.MiningPuzzlerRouteTests
java -cp "$OUT:$CP" dev.client.lunaria.config.AppleSettingsTests
java -cp "$OUT:$CP" dev.client.lunaria.render.ThemeTests
java -cp "$OUT:$CP" dev.client.lunaria.hud.DollConfigTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.LeapClassTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.SpiritLeapTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.DungeonContextTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.MobMarkersTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.StarredMobPolicyTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.qol.ChatNoiseFilterPolicyTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.qol.EntityVisualPolicyTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.BloodMobMatcherTests
java -cp "$OUT:$CP" dev.client.lunaria.dungeon.M7DetectionTests
java -cp "$OUT:$CP" dev.client.lunaria.gui.LeapLayoutTests
java -cp "$OUT:$CP" dev.client.lunaria.gui.WindowControlsTests
java -cp "$OUT:$CP" dev.client.lunaria.gui.LeapPaletteTests
java -cp "$OUT:$CP" dev.client.lunaria.gui.LeapPreviewDataTests
java -cp "$OUT:$CP" dev.client.lunaria.hud.StatsTextTests
java -cp "$OUT:$CP" dev.client.lunaria.startup.StartupTimingTests
java -cp "$OUT:$CP" dev.client.lunaria.fishing.FishingTests
java -cp "$OUT:$CP" dev.client.lunaria.dungeon.DungeonBossHpTests
java -cp "$OUT:$CP" dev.client.lunaria.dungeon.DungeonScoreMathTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.ChatFilterRulesTests
java -cp "$OUT:$CP" dev.client.lunaria.chat.ClipboardChainTests
java -cp "$OUT:$CP" dev.client.lunaria.chat.ChatMenuInputRouterTests
java -cp "$OUT:$CP" dev.client.lunaria.chat.ChatMessageHistoryTests
java -cp "$OUT:$CP" dev.client.lunaria.chat.ChatInputInsertionTests
java -cp "$OUT:$CP" dev.client.lunaria.chat.ChatPlayerNameTests
java -cp "$OUT:$CP" dev.client.lunaria.chat.ChatShiftClickGestureTests
java -cp "$OUT:$CP" dev.client.lunaria.chat.ChatVisibilityAuditTests
java -cp "$OUT:$CP" dev.client.lunaria.chat.ChatCompactMessagesPolicyTests
java -cp "$OUT:$CP" dev.client.lunaria.chat.ChatCompactMessagesTests
java -cp "$OUT:$CP" dev.client.lunaria.chat.RomanNumeralsTests
java -cp "$OUT:$CP" dev.client.lunaria.config.ChatQolSettingsTests
java -cp "$OUT:$CP" dev.client.lunaria.config.FontSettingsTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.ChatInteractionModelTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.ChatTabsTests
java -cp "$OUT:$CP" dev.client.lunaria.gui.ChatQolLayoutTests
java -cp "$OUT:$CP" dev.client.lunaria.gui.GuiLayoutToolkitTests
java -cp "$OUT:$CP" dev.client.lunaria.gui.ReferenceSettingsCatalogTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.FirstPersonItemTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.ItemAnimationTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.SwingEasingTests
java -cp "$OUT:$CP" dev.client.lunaria.feature.VisualSwingStateMachineTests
java -cp "$OUT:$CP" dev.client.lunaria.itemlockswap.ItemLockSwapSettingsTests
java -cp "$OUT:$CP" dev.client.lunaria.itemlockswap.ItemLockSwapLineGeometryTests
java -cp "$OUT:$CP" dev.client.lunaria.itemlockswap.ItemLockSwapSwapPolicyTests
java -cp "$OUT:$CP" dev.client.lunaria.itemlockswap.ItemLockSwapInputStateTests
java -cp "$OUT:$CP" dev.client.lunaria.itemlockswap.ItemLockSwapSlotMapperTests
java -cp "$OUT:$CP" dev.client.lunaria.itemlockswap.ItemLockSwapTransformerTests
java -cp "$OUT:$CP" dev.client.lunaria.itemlockswap.ItemLockSwapProtectionPolicyTests
java -cp "$OUT:$CP" dev.client.lunaria.assist.visual.AspectTeleportCameraPathTests
java -cp "$OUT:$CP" dev.client.lunaria.assist.visual.AspectTeleportTransitionPolicyTests
java -cp "$OUT:$CP" dev.client.lunaria.assist.visual.AspectTeleportTransitionObservationTests
java -cp "$OUT:$CP" dev.client.lunaria.assist.visual.AspectTeleportCameraTransformerTests
java -cp "$OUT:$CP" dev.client.lunaria.assist.dungeon.DungeonRunReadoutTests
java -cp "$OUT:$CP" dev.client.lunaria.assist.dungeon.RoomClearAlertPolicyTests
java -cp "$OUT:$CP" dev.client.lunaria.dungeon.DungeonMapPlayerHeadMotionTests
java -cp "$OUT:$CP" dev.client.lunaria.config.ItemAnimationSettingsTests
java -cp "$OUT:$CP" dev.client.lunaria.dungeon.DragonKillTests
java -cp "$OUT:$CP" dev.client.lunaria.slayer.SlayerTests
java -cp "$OUT:$CP" dev.client.lunaria.widget.SearchFieldTests
java -cp "$OUT:$CP" dev.client.lunaria.widget.WidgetInteractionTests

java -cp "$OUT:$CP" dev.client.lunaria.dungeon.PuzzleRoomDataTests
java -cp "$OUT:$CP" dev.client.lunaria.dungeon.sync.DungeonSyncIdentityTests
java -cp "$OUT:$CP" dev.client.lunaria.dungeon.sync.DungeonSyncReconnectPolicyTests
java -cp "$OUT:$CP" dev.client.lunaria.dungeon.sync.DungeonPuzzleSyncConfigTests
java -cp "$OUT:$CP" dev.client.lunaria.dungeon.sync.DungeonSyncReminderPolicyTests
java -cp "$OUT:$CP" dev.client.lunaria.dungeon.PuzzleRoomMemoryTests
java -cp "$OUT:$CP" dev.client.lunaria.dungeon.DungeonMapLabelAnchorTests
java -cp "$OUT:$CP" dev.client.lunaria.dungeon.PuzzleLabelsTests
java -cp "$OUT:$CP" dev.client.lunaria.dungeon.DungeonMapProjectionTests
java -cp "$OUT:$CP" dev.client.lunaria.dungeon.DungeonMapLabelLayoutTests
java -cp "$OUT:$CP" dev.client.lunaria.dungeon.DungeonMapPlayerNameAssignmentsTests
java -cp "$OUT:$CP" dev.client.lunaria.dungeon.DungeonMapPartyRosterTests
java -cp "$OUT:$CP" dev.client.lunaria.dungeon.solver.DungeonSolverColorTests
java -cp "$OUT:$CP" dev.client.lunaria.dungeon.solver.terminals.TerminalDebugTests
