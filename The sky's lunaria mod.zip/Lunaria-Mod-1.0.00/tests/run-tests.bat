@echo off
setlocal EnableExtensions
set "ROOT=%~dp0.."
set "CLASSES=%ROOT%\build\classes\main"
set "CP_FILE=%ROOT%\build\test-classpath.txt"
set "OUT=%TEMP%\lunaria-tests-%RANDOM%-%RANDOM%"

if not exist "%CLASSES%" (
    echo Main classes not found. Run gradlew.bat build dumpTestClasspath first.
    exit /b 1
)
if not exist "%CP_FILE%" (
    echo Test classpath not found. Run gradlew.bat build dumpTestClasspath first.
    exit /b 1
)
set /p "TEST_CP="<"%CP_FILE%"
if not defined TEST_CP (
    echo Test classpath is empty: %CP_FILE%
    exit /b 1
)
mkdir "%OUT%" || exit /b 1

for /r "%ROOT%\tests" %%F in (*.java) do echo "%%F" >> "%OUT%\sources.txt"
javac -nowarn -encoding UTF-8 -cp "%CLASSES%;%TEST_CP%" -d "%OUT%" @"%OUT%\sources.txt"
if errorlevel 1 goto fail

set "CP=%OUT%;%CLASSES%;%TEST_CP%"
call :run dev.client.lunaria.gui.PureLogicTests || goto fail
call :run dev.client.lunaria.hud.ConfigTests || goto fail
call :run dev.client.lunaria.feature.LeapTextTests || goto fail
call :run dev.client.lunaria.feature.SkyblockContextPolicyTests || goto fail
call :run dev.client.lunaria.feature.AutoSprintTests || goto fail
call :run dev.client.lunaria.feature.inventory.InventoryLayoutPolicyTests || goto fail
call :run dev.client.lunaria.feature.LeapIdentityTests || goto fail
call :run dev.client.lunaria.feature.LeapClassCacheTests || goto fail
call :run dev.client.lunaria.config.ConfigFilesTests || goto fail
call :run dev.client.lunaria.feature.protection.ProtectedItemStoreTests || goto fail
call :run dev.client.lunaria.feature.protection.ProtectedItemActionPolicyTests || goto fail
call :run dev.client.lunaria.feature.inventory.SlotLockStoreTests || goto fail
call :run dev.client.lunaria.feature.inventory.SlotBindingGesturePolicyTests || goto fail
call :run dev.client.lunaria.feature.qol.InventorySearchMatcherTests || goto fail
call :run dev.client.lunaria.feature.qol.RomanNumeralParserTests || goto fail
call :run dev.client.lunaria.feature.qol.ItemRarityColorsTests || goto fail
call :run dev.client.lunaria.feature.qol.TooltipScrollWindowTests || goto fail
call :run dev.client.lunaria.feature.qol.ChatCopyTextPolicyTests || goto fail
call :run dev.client.lunaria.feature.qol.ChatLengthPolicyTests || goto fail
call :run dev.client.lunaria.feature.mining.MiningAbilityCooldownTests || goto fail
call :run dev.client.lunaria.feature.mining.MiningPuzzlerRouteTests || goto fail
call :run dev.client.lunaria.config.AppleSettingsTests || goto fail
call :run dev.client.lunaria.render.ThemeTests || goto fail
call :run dev.client.lunaria.hud.DollConfigTests || goto fail
call :run dev.client.lunaria.feature.LeapClassTests || goto fail
call :run dev.client.lunaria.feature.SpiritLeapTests || goto fail
call :run dev.client.lunaria.feature.DungeonContextTests || goto fail
call :run dev.client.lunaria.feature.MobMarkersTests || goto fail
call :run dev.client.lunaria.feature.StarredMobPolicyTests || goto fail
call :run dev.client.lunaria.feature.qol.ChatNoiseFilterPolicyTests || goto fail
call :run dev.client.lunaria.feature.qol.EntityVisualPolicyTests || goto fail
call :run dev.client.lunaria.feature.BloodMobMatcherTests || goto fail
call :run dev.client.lunaria.dungeon.M7DetectionTests || goto fail
call :run dev.client.lunaria.gui.LeapLayoutTests || goto fail
call :run dev.client.lunaria.gui.WindowControlsTests || goto fail
call :run dev.client.lunaria.gui.LeapPaletteTests || goto fail
call :run dev.client.lunaria.gui.LeapPreviewDataTests || goto fail
call :run dev.client.lunaria.hud.StatsTextTests || goto fail
call :run dev.client.lunaria.startup.StartupTimingTests || goto fail
call :run dev.client.lunaria.fishing.FishingTests || goto fail
call :run dev.client.lunaria.dungeon.DungeonBossHpTests || goto fail
call :run dev.client.lunaria.dungeon.DungeonScoreMathTests || goto fail
call :run dev.client.lunaria.feature.ChatFilterRulesTests || goto fail
call :run dev.client.lunaria.chat.ClipboardChainTests || goto fail
call :run dev.client.lunaria.chat.ChatMenuInputRouterTests || goto fail
call :run dev.client.lunaria.chat.ChatMessageHistoryTests || goto fail
call :run dev.client.lunaria.chat.ChatInputInsertionTests || goto fail
call :run dev.client.lunaria.chat.ChatPlayerNameTests || goto fail
call :run dev.client.lunaria.chat.ChatShiftClickGestureTests || goto fail
call :run dev.client.lunaria.chat.ChatVisibilityAuditTests || goto fail
call :run dev.client.lunaria.chat.ChatCompactMessagesPolicyTests || goto fail
call :run dev.client.lunaria.chat.ChatCompactMessagesTests || goto fail
call :run dev.client.lunaria.chat.RomanNumeralsTests || goto fail
call :run dev.client.lunaria.config.ChatQolSettingsTests || goto fail
call :run dev.client.lunaria.config.FontSettingsTests || goto fail
call :run dev.client.lunaria.feature.ChatInteractionModelTests || goto fail
call :run dev.client.lunaria.feature.ChatTabsTests || goto fail
call :run dev.client.lunaria.gui.ChatQolLayoutTests || goto fail
call :run dev.client.lunaria.gui.GuiLayoutToolkitTests || goto fail
call :run dev.client.lunaria.gui.ReferenceSettingsCatalogTests || goto fail
call :run dev.client.lunaria.feature.FirstPersonItemTests || goto fail
call :run dev.client.lunaria.feature.ItemAnimationTests || goto fail
call :run dev.client.lunaria.feature.SwingEasingTests || goto fail
call :run dev.client.lunaria.feature.VisualSwingStateMachineTests || goto fail
call :run dev.client.lunaria.itemlockswap.ItemLockSwapSettingsTests || goto fail
call :run dev.client.lunaria.itemlockswap.ItemLockSwapLineGeometryTests || goto fail
call :run dev.client.lunaria.itemlockswap.ItemLockSwapSwapPolicyTests || goto fail
call :run dev.client.lunaria.itemlockswap.ItemLockSwapInputStateTests || goto fail
call :run dev.client.lunaria.itemlockswap.ItemLockSwapSlotMapperTests || goto fail
call :run dev.client.lunaria.itemlockswap.ItemLockSwapTransformerTests || goto fail
call :run dev.client.lunaria.itemlockswap.ItemLockSwapProtectionPolicyTests || goto fail
call :run dev.client.lunaria.assist.visual.AspectTeleportCameraPathTests || goto fail
call :run dev.client.lunaria.assist.visual.AspectTeleportTransitionPolicyTests || goto fail
call :run dev.client.lunaria.assist.visual.AspectTeleportTransitionObservationTests || goto fail
call :run dev.client.lunaria.assist.visual.AspectTeleportCameraTransformerTests || goto fail
call :run dev.client.lunaria.assist.dungeon.DungeonRunReadoutTests || goto fail
call :run dev.client.lunaria.assist.dungeon.RoomClearAlertPolicyTests || goto fail
call :run dev.client.lunaria.dungeon.DungeonMapPlayerHeadMotionTests || goto fail
call :run dev.client.lunaria.config.ItemAnimationSettingsTests || goto fail
call :run dev.client.lunaria.dungeon.DragonKillTests || goto fail
call :run dev.client.lunaria.dungeon.PuzzleRoomDataTests || goto fail
call :run dev.client.lunaria.dungeon.sync.DungeonSyncIdentityTests || goto fail
call :run dev.client.lunaria.dungeon.sync.DungeonSyncReconnectPolicyTests || goto fail
call :run dev.client.lunaria.dungeon.sync.DungeonPuzzleSyncConfigTests || goto fail
call :run dev.client.lunaria.dungeon.PuzzleRoomMemoryTests || goto fail
call :run dev.client.lunaria.dungeon.DungeonMapLabelAnchorTests || goto fail
call :run dev.client.lunaria.dungeon.PuzzleLabelsTests || goto fail
call :run dev.client.lunaria.dungeon.DungeonMapProjectionTests || goto fail
call :run dev.client.lunaria.dungeon.DungeonMapLabelLayoutTests || goto fail
call :run dev.client.lunaria.dungeon.DungeonMapPlayerNameAssignmentsTests || goto fail
call :run dev.client.lunaria.dungeon.DungeonMapPartyRosterTests || goto fail
call :run dev.client.lunaria.dungeon.solver.DungeonSolverColorTests || goto fail
call :run dev.client.lunaria.dungeon.solver.terminals.TerminalDebugTests || goto fail
call :run dev.client.lunaria.slayer.SlayerTests || goto fail
call :run dev.client.lunaria.widget.SearchFieldTests || goto fail
call :run dev.client.lunaria.widget.WidgetInteractionTests || goto fail

echo All Lunaria Mod tests passed.
rmdir /s /q "%OUT%"
exit /b 0

:run
 echo === %~1 ===
 java -cp "%CP%" %~1
 if errorlevel 1 exit /b 1
 exit /b 0

:fail
 echo Tests failed. Temporary output kept at "%OUT%" for diagnosis.
 exit /b 1
