package dev.client.lunaria.assist.dungeon;

/** Regression tests for the conservative room-clear alert policy. */
public final class RoomClearAlertPolicyTests {
    public static void main(String[] args) {
        chatClearRequiresDungeonAndRecognizedText();
        repeatedRoomAndCrossSignalAreDeduplicated();
        progressRequiresPlausibleIncrease();
        specialRoomsAndFinalClearAreExcluded();
        System.out.println("RoomClearAlertPolicyTests passed");
    }

    private static void chatClearRequiresDungeonAndRecognizedText() {
        RoomClearAlertPolicy policy = new RoomClearAlertPolicy();
        check(!policy.shouldAlert(false, "Room Cleared!", "1:1", 1000L), "outside dungeon");
        check(!policy.shouldAlert(true, "Nice run!", "1:1", 1001L), "unrelated chat");
        check(policy.shouldAlert(true, "Room Cleared!", "1:1", 1002L), "valid room clear");
    }

    private static void repeatedRoomAndCrossSignalAreDeduplicated() {
        RoomClearAlertPolicy policy = new RoomClearAlertPolicy();
        check(policy.shouldAlert(true, "Room Cleared!", "1:1", 2000L), "first room clear");
        check(!policy.shouldAlert(true, "Room Cleared!", "1:1", 3500L), "same room repeated");
        check(!policy.shouldAlertClearedProgress(true, 10, 15, "1:2", 2500L), "chat/sidebar duplicate");
    }

    private static void progressRequiresPlausibleIncrease() {
        RoomClearAlertPolicy policy = new RoomClearAlertPolicy();
        check(!policy.shouldAlertClearedProgress(true, -1, 5, "2:1", 1000L), "unknown baseline");
        check(!policy.shouldAlertClearedProgress(true, 10, 10, "2:1", 2000L), "no increase");
        check(!policy.shouldAlertClearedProgress(true, 10, 40, "2:1", 3000L), "implausible jump");
        check(policy.shouldAlertClearedProgress(true, 10, 15, "2:1", 4000L), "plausible increase");
        check(!policy.shouldAlertClearedProgress(true, 15, 20, "2:1", 6000L), "same room progress");
    }

    private static void specialRoomsAndFinalClearAreExcluded() {
        RoomClearAlertPolicy policy = new RoomClearAlertPolicy();
        check(!policy.shouldAlert(true, "Blood Room Cleared!", "3:1", 1000L), "blood room");
        check(!policy.shouldAlert(true, "Fairy Room Cleared!", "3:2", 3000L), "fairy room");
        check(!policy.shouldAlert(true, "Entrance Room Cleared!", "3:3", 5000L), "entrance room");
        check(!policy.shouldAlert(true, "Dungeon Cleared!", "3:4", 7000L), "final dungeon clear");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
