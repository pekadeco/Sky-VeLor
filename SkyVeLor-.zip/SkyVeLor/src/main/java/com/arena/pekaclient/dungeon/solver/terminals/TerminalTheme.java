package com.arena.pekaclient.dungeon.solver.terminals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.FontRenderer;

final class TerminalTheme {
    private static final int FRAME = 0xFF101722;
    private static final int PANEL = 0xE9162231;
    private static final int HEADER = 0xFF172638;
    private static final int ACCENT = 0xFF53E0C1;
    private static final int BORDER = 0xFF30485D;
    private static final int TEXT = 0xFFF1F6FC;
    private static final int SLOT = 0xFF1D3042;
    private static final int SLOT_BORDER = 0xFF38566B;

    private TerminalTheme() {
    }

    static void drawOverlay(int width, int height, String title) {
        Gui.drawRect(-3, -15, width + 3, height + 3, FRAME);
        Gui.drawRect(-2, -14, width + 2, height + 2, PANEL);
        Gui.drawRect(-2, -14, width + 2, 0, HEADER);
        Gui.drawRect(-2, -14, 0, height + 2, ACCENT);
        Gui.drawRect(0, -14, width + 2, -13, BORDER);
        drawBrandTitle(title, 3, -10);
    }

    static void drawWindow(int width, int height, String title) {
        Gui.drawRect(-1, -1, width + 1, height + 1, FRAME);
        Gui.drawRect(0, 0, width, height, PANEL);
        Gui.drawRect(0, 0, width, 18, HEADER);
        Gui.drawRect(0, 0, 2, height, ACCENT);
        Gui.drawRect(2, 17, width, 18, BORDER);
        drawBrandTitle(title, 7, 5);
    }

    static void drawSlot(int x, int y, int width, int height) {
        Gui.drawRect(x, y, x + width, y + height, SLOT_BORDER);
        Gui.drawRect(x + 1, y + 1, x + width - 1, y + height - 1, SLOT);
    }

    private static void drawBrandTitle(String title, int x, int y) {
        FontRenderer font = Minecraft.getMinecraft().fontRendererObj;
        font.drawString("SV", x, y, ACCENT, false);
        font.drawString(title, x + 17, y, TEXT, false);
    }
}
