package com.arena.pekaclient.dungeon.solver;

import com.arena.pekaclient.feature.DungeonContext;

/** Shared context gates for the Better NEF dungeon features adapted to Sky VeLor. */
public final class DungeonSolverContext {
    private DungeonSolverContext() { }

    public static boolean checkEssentials() {
        return DungeonContext.inDungeon();
    }

    public static boolean checkEssentialsF7() {
        return DungeonContext.inF7OrM7();
    }
}
