/*
 * This modified version is maintained by ii8we. Review LICENSE and THIRD_PARTY_NOTICES/Better-NEF-NOTICE.md before use or redistribution. Original code and third-party components remain subject to their respective copyrights and license terms.
 */
/* Adapted for Sky VeLor from better-nef-1.2.4-v34. See THIRD_PARTY_NOTICES for license and attribution. */
package com.arena.pekaclient.dungeon.solver.devices;

import com.arena.pekaclient.config.AppleSettings;
import com.arena.pekaclient.dungeon.solver.DungeonSolverColor;
import com.arena.pekaclient.dungeon.solver.DungeonSolverContext;
import com.arena.pekaclient.dungeon.solver.DungeonSolverRender;
import com.arena.pekaclient.events.PacketWriteEvent;
import net.minecraft.block.Block;
import net.minecraft.block.BlockButton;
import net.minecraft.block.BlockButtonStone;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.awt.*;
import java.util.Objects;

public class FirstDeviceSolver {

    private BlockPos[] positionsToSolve;
    private int[] positionsIndexSolved = new int[]{-1, -1, -1, -1, -1};
    private boolean startMemorising = false;
    private boolean resolving = false;
    private int positionInRound = 0;
    private int round = 1;

    @SubscribeEvent
    public void onRenderLast(RenderWorldLastEvent event) {
        if (!AppleSettings.solverFirstDevice) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null || mc.thePlayer == null) return;

        if (startMemorising) {
            if (positionsToSolve == null || round < 1 || round > positionsIndexSolved.length) {
                reset();
                return;
            }
            for (int i = 0; i < positionsToSolve.length; i++) {
                Block targetBlock = mc.theWorld.getBlockState(positionsToSolve[i]).getBlock();
                if (targetBlock == Blocks.sea_lantern
                        && positionsIndexSolved[round - 1] == -1
                        && !checkIfAdded(positionsIndexSolved, i)) {
                    positionsIndexSolved[round - 1] = i;
                    resolving = true;
                    startMemorising = false;
                }
            }
        }

        if (resolving) {
            if (positionsToSolve == null || round < 1 || round > positionsIndexSolved.length) {
                reset();
                return;
            }
            for (int i = 0; i < round; i++) {
                int solvedIndex = positionsIndexSolved[i];
                if (solvedIndex < 0 || solvedIndex >= positionsToSolve.length) {
                    reset();
                    return;
                }
                Color baseColor = DungeonSolverColor.getColor(AppleSettings.solverAlternativeColor);
                if (i == positionInRound) {
                    DungeonSolverRender.highlightBlock(positionsToSolve[solvedIndex],
                            DungeonSolverColor.getColor(AppleSettings.solverCorrectColor), false, true, event.partialTicks);
                } else if (i == positionInRound + 1) {
                    DungeonSolverRender.highlightBlock(positionsToSolve[solvedIndex],
                            DungeonSolverColor.getColor(AppleSettings.solverAlternativeColor), false, true, event.partialTicks);
                } else if (i == positionInRound + 2) {
                    DungeonSolverRender.highlightBlock(positionsToSolve[solvedIndex], new Color(
                            baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), 150),
                            false, true, event.partialTicks);
                }
            }
        }
    }

    /** Handles ordinary right-click interactions, as in Better NEF. */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent event) {
        if (!AppleSettings.solverFirstDevice || !DungeonSolverContext.checkEssentialsF7()) return;
        if (Minecraft.getMinecraft().thePlayer == null || Minecraft.getMinecraft().theWorld == null) return;
        if (Minecraft.getMinecraft().thePlayer != event.entityPlayer) return;
        if (event.action != PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK) return;

        if (handleButtonClick(event.pos)) {
            event.setCanceled(true);
        }
    }

    /**
     * First Device also sends C07 START_DESTROY_BLOCK packets for left-clicks. Observing only
     * PlayerInteractEvent misses this input path, which is why the original solver appeared inert
     * when interacting with the device in the same way Better NEF supports.
     */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public void onDiggingPacket(PacketWriteEvent event) {
        if (!AppleSettings.solverFirstDevice || !DungeonSolverContext.checkEssentialsF7()) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || mc.theWorld == null || event == null || event.packet == null) return;
        Packet packet = event.packet;
        if (!(packet instanceof C07PacketPlayerDigging)) return;

        C07PacketPlayerDigging digging = (C07PacketPlayerDigging) packet;
        if (digging.getStatus() != C07PacketPlayerDigging.Action.START_DESTROY_BLOCK) return;

        if (handleButtonClick(digging.getPosition())) {
            event.setCanceled(true);
        }
    }

    /**
     * @return true when the attempted sequence press must be cancelled.
     */
    private boolean handleButtonClick(BlockPos buttonPos) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null || buttonPos == null) return false;

        net.minecraft.block.state.IBlockState buttonState = mc.theWorld.getBlockState(buttonPos);
        if (!(buttonState.getBlock() instanceof BlockButtonStone)) return false;

        EnumFacing facing = buttonState.getValue(BlockButton.FACING);
        BlockPos underButton = getBlockUnderButton(buttonPos, facing);
        if (underButton == null) return false;

        Block underlyingBlock = mc.theWorld.getBlockState(underButton).getBlock();
        if (Objects.equals(underlyingBlock.getUnlocalizedName(), Blocks.obsidian.getUnlocalizedName())) {
            if (!resolving) return false;

            if (positionsToSolve == null || positionInRound < 0 || positionInRound >= positionsIndexSolved.length) {
                return true;
            }
            int solvedIndex = positionsIndexSolved[positionInRound];
            if (solvedIndex < 0 || solvedIndex >= positionsToSolve.length
                    || !underButton.equals(positionsToSolve[solvedIndex])) {
                return true;
            }

            positionInRound++;
            if (positionInRound == round) {
                positionInRound = 0;
                round++;
                startMemorising = true;
                resolving = false;
            }
            if (round == 6) {
                reset();
            }
        } else if (Objects.equals(underlyingBlock.getUnlocalizedName(), Blocks.emerald_block.getUnlocalizedName())) {
            if (!startMemorising) {
                BlockPos[] surrounding = getSurroundingBlocks(underButton, facing);
                reset();
                positionsToSolve = surrounding;
                startMemorising = true;
            }
        }
        return false;
    }

    @SubscribeEvent
    public void onWorldUnload(WorldEvent.Unload event) {
        reset();
        positionsToSolve = null;
    }

    private static BlockPos getBlockUnderButton(BlockPos pos, EnumFacing facing) {
        if (pos == null || facing == null) return null;
        switch (facing) {
            case NORTH:
                return new BlockPos(pos.getX(), pos.getY(), pos.getZ() + 1);
            case EAST:
                return new BlockPos(pos.getX() - 1, pos.getY(), pos.getZ());
            case SOUTH:
                return new BlockPos(pos.getX(), pos.getY(), pos.getZ() - 1);
            case WEST:
                return new BlockPos(pos.getX() + 1, pos.getY(), pos.getZ());
            default:
                return null;
        }
    }

    public static BlockPos[] getSurroundingBlocks(BlockPos startPos, EnumFacing enumFacing) {
        BlockPos[] surroundingBlocks = new BlockPos[16];
        int index = 0;
        for (int yOffset = -1; yOffset <= 2; yOffset++) {
            for (int hOffset = 1; hOffset <= 4; hOffset++) {
                int dx = 0;
                int dz = 0;
                int dy = yOffset;
                switch (enumFacing) {
                    case NORTH:
                        dx = -hOffset;
                        break;
                    case SOUTH:
                        dx = hOffset;
                        break;
                    case WEST:
                        dz = hOffset;
                        break;
                    case EAST:
                        dz = -hOffset;
                        break;
                    default:
                        break;
                }
                surroundingBlocks[index++] = new BlockPos(startPos.getX() + dx,
                        startPos.getY() + dy, startPos.getZ() + dz);
            }
        }
        return surroundingBlocks;
    }

    private boolean checkIfAdded(int[] array, int index) {
        for (int value : array) {
            if (value == index) return true;
        }
        return false;
    }

    private void reset() {
        positionsIndexSolved = new int[]{-1, -1, -1, -1, -1};
        startMemorising = false;
        resolving = false;
        positionInRound = 0;
        round = 1;
    }
}
