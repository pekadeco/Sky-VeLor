package com.arena.pekaclient.config;

import java.util.Properties;

/** Checks fresh-install performance defaults and explicit saved choices. */
public final class AppleSettingsTests {

    private static int passed;
    private static int failed;

    public static void main(String[] args) {
        check("fresh adaptive quality defaults off", !AppleSettings.adaptive);
        check("fresh Performance Boost Beta defaults on", AppleSettings.experimentalPerformance);
        check("fresh panel opacity is slightly transparent", AppleSettings.DEFAULT_GLASS_OPACITY == 88);
        check("dungeon map enabled by default", AppleSettings.dungeonMap);
        check("dungeon map rotation follows Better NEF by default", AppleSettings.dungeonMapRotate);
        check("player labels enabled by default", AppleSettings.dungeonMapShowPlayerNames);
        check("puzzle labels enabled by default", AppleSettings.dungeonMapShowPuzzleName);
        check("dungeon map scale defaults to 100%", AppleSettings.dungeonMapScale == 100);
        check("dungeon map scale is enabled by default", AppleSettings.dungeonMapScaleOn);
        check("dungeon map content zoom defaults to 100%", AppleSettings.dungeonMapZoom == 100);
        check("map content zoom supports down to 50%", AppleSettings.DUNGEON_MAP_ZOOM_MIN == 50);
        check("map content zoom supports up to 200%", AppleSettings.DUNGEON_MAP_ZOOM_MAX == 200);
        check("map content zoom factor is 1.0 at 100%", Math.abs(AppleSettings.dungeonMapZoomFactor() - 1.0F) < 0.001F);
        AppleSettings.dungeonMapZoom = 999;
        check("map content zoom clamps to 200%", AppleSettings.effectiveDungeonMapZoom() == 200);
        AppleSettings.dungeonMapZoom = 20;
        check("map content zoom clamps to 50%", AppleSettings.effectiveDungeonMapZoom() == 50);
        AppleSettings.dungeonMapZoom = 100;
        check("map scale supports down to 70%", AppleSettings.DUNGEON_MAP_SCALE_MIN == 70);
        check("map scale supports up to 250%", AppleSettings.DUNGEON_MAP_SCALE_MAX == 250);
        check("map scale default remains within the expanded range", AppleSettings.dungeonMapScale >= AppleSettings.DUNGEON_MAP_SCALE_MIN
                && AppleSettings.dungeonMapScale <= AppleSettings.DUNGEON_MAP_SCALE_MAX);
        check("map scale factor uses 100% on a large viewport",
                Math.abs(AppleSettings.dungeonMapScaleFactor(1920, 1080) - 1.0F) < 0.001F);
        check("map size at 100% is 128 GUI pixels", AppleSettings.dungeonMapPixelSize(1920, 1080) == 128);
        AppleSettings.dungeonMapScaleOn = true;
        AppleSettings.dungeonMapScale = 250;
        check("map size expands to 250% when viewport permits", AppleSettings.dungeonMapPixelSize(1920, 1080) == 320);
        check("map size remains viewport-fitted on a short screen", AppleSettings.dungeonMapPixelSize(854, 200) == 200);
        AppleSettings.dungeonMapScaleOn = false;
        check("disabled map scale uses native 100% geometry", AppleSettings.dungeonMapPixelSize(1920, 1080) == 128);
        check("effective map scale is native size while scale is disabled", AppleSettings.effectiveDungeonMapScale() == 100);
        AppleSettings.dungeonMapScaleOn = true;
        AppleSettings.dungeonMapScale = 100;
        check("dungeon map starts near the upper-left", AppleSettings.dungeonMapXPercent == 2 && AppleSettings.dungeonMapYPercent == 2);
        AppleSettings.setDungeonMapPosition(400, 300, 128, -140, 350, false, 0);
        check("map placement can be moved left of the viewport", AppleSettings.dungeonMapLeft(400, 300, 128) == -140);
        check("map placement can be moved below the viewport", AppleSettings.dungeonMapTop(400, 300, 128) == 350);
        AppleSettings.resetDungeonMapPosition();

        AppleSettings.adaptive = AppleSettings.DEFAULT_ADAPTIVE_QUALITY;
        AppleSettings.experimentalPerformance = AppleSettings.DEFAULT_PERFORMANCE_BOOST_BETA;
        AppleSettings.loadPerformanceSettings(new Properties());
        check("empty fresh config keeps adaptive disabled", !AppleSettings.adaptive);
        check("empty fresh config keeps Performance Boost Beta enabled",
                AppleSettings.experimentalPerformance);

        Properties saved = new Properties();
        saved.setProperty("dungeonMapRotate", "false");
        check("static-map config value parses false", !AppleSettings.readBool(saved, "dungeonMapRotate", true));
        saved.setProperty("dungeonMapScaleOn", "false");
        check("disabled map scale config value parses false",
                !AppleSettings.readBool(saved, "dungeonMapScaleOn", true));
        saved.setProperty("dungeonMapZoom", "165");
        check("saved map content zoom is read as an integer", AppleSettings.readInt(saved, "dungeonMapZoom", 100,
                AppleSettings.DUNGEON_MAP_ZOOM_MIN, AppleSettings.DUNGEON_MAP_ZOOM_MAX) == 165);
        saved.setProperty("adaptive", "true");
        saved.setProperty("experimentalPerformance", "false");
        AppleSettings.loadPerformanceSettings(saved);
        check("saved adaptive choice is preserved", AppleSettings.adaptive);
        check("saved Performance Boost Beta choice is preserved", !AppleSettings.experimentalPerformance);

        AppleSettings.loadPerformanceSettings(new Properties());
        check("missing keys do not overwrite effective adaptive choice", AppleSettings.adaptive);
        check("missing keys do not overwrite effective performance choice",
                !AppleSettings.experimentalPerformance);

        System.out.println();
        System.out.println("apple settings: passed " + passed + ", failed " + failed);
        if (failed > 0) {
            System.exit(1);
        }
    }

    private static void check(String name, boolean ok) {
        if (ok) {
            passed++;
        } else {
            failed++;
            System.out.println("FAIL " + name);
        }
    }
}
