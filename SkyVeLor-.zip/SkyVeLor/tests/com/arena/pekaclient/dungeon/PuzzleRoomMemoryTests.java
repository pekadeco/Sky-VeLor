package com.arena.pekaclient.dungeon;

public final class PuzzleRoomMemoryTests {
    private static int passed;
    private static int failed;

    public static void main(String[] args) {
        PuzzleRoomMemory memory = new PuzzleRoomMemory();
        memory.remember("Silverfish", 32, 70, 64, 0.96D);
        check("successful match is remembered", memory.size() == 1);
        memory.remember("Boulder", 64, 70, 64, 0.91D);
        check("second puzzle room is remembered", memory.size() == 2);
        check("earlier room remains after another room is added",
                "Silverfish".equals(memory.snapshot().get(0).name));
        memory.remember("Silverfish", 32, 70, 64, 0.72D);
        check("same world coordinates do not create duplicates", memory.size() == 2);
        check("weaker match does not replace stronger room data",
                "Silverfish".equals(memory.snapshot().get(0).name)
                        && Math.abs(memory.snapshot().get(0).confidence - 0.96D) < 0.0001D);
        memory.remember("", 96, 70, 96, 1.0D);
        memory.remember("Fake", 96, 70, 96, 0.4D);
        check("empty or low-confidence detections are ignored", memory.size() == 2);
        memory.remember("Three Weirdos", 32, 70, 64, 0.99D);
        check("better match corrects the same coordinate", memory.size() == 2
                && "Three Weirdos".equals(memory.snapshot().get(0).name));
        memory.clear();
        check("memory clears at dungeon end", memory.size() == 0);
        System.out.println("PuzzleRoomMemoryTests: passed " + passed + ", failed " + failed);
        if (failed > 0) System.exit(1);
    }

    private static void check(String name, boolean condition) {
        if (condition) passed++;
        else { failed++; System.out.println("FAIL: " + name); }
    }
}
