# Sky VeLor — Beta-0.10.6v

Sky VeLor is a client-side Forge mod for Minecraft 1.8.9. It provides a configurable HUD, a settings hub, dungeon utilities, Spirit Leap helpers, fishing and Slayer trackers, and quick notes.

## Features

- Settings hub and movable HUD editor with dark and light themes.
- Smooth, frame-rate-independent UI motion: soft hover and press feedback, animated toggles and sliders, a sliding segmented selector, a gently appearing dropdown, and responsive search-field focus.
- Rounded animated buttons in the main/pause menu and Quick Note screen, with distinct primary, secondary and destructive styles.
- Spirit Leap teammate picker, class labels, player heads and isolated preview.
- Dungeon minimap with automatically rotating live map, teammate names, puzzle-room labels and a numeric Secrets counter; Floor VII overlays and dragon alerts.
- Fishing and Slayer trackers, plus quick notes and client commands.
- Dungeon terminal GUI variants and solvers, device helpers, six puzzle solvers, Goldor phase tracker, waypoints, and a local `/termsim` practice screen.

## Requirements

- Minecraft 1.8.9 with Forge `11.15.1.2318`.
- JDK 8 for compiling and Java 8 for the legacy Forge runtime.
- Internet access on the first build so Gradle and ForgeGradle can download their dependencies.

This project intentionally retains the ForgeGradle 2.1 / Gradle 2.14.1 toolchain used by Forge 1.8.9. Newer JDKs and Gradle releases are not drop-in replacements for this legacy build.

## Build on Windows

Open Command Prompt in this folder and make sure `JAVA_HOME` points to a JDK 8 installation. Then run:

```bat
gradlew.bat clean build dumpTestClasspath
```

To run the standalone tests in Command Prompt:

```bat
tests\run-tests.bat
```

## Build on Linux or Git Bash

With JDK 8 selected, run:

```sh
./gradlew clean build dumpTestClasspath
TEST_CP="$(cat build/test-classpath.txt)" sh tests/run-tests.sh
```

The mod JAR is written to `build/libs/`. The source package keeps any older generated outputs under `previous-build-artifacts/` only as a backup; do not install a JAR from that folder. Build a fresh JAR with the command above. The active `build/` output and `.gradle/` cache are generated locally.

## Installation

1. Start Minecraft 1.8.9 with Forge `11.15.1.2318` once.
2. Put `SkyVeLor-1.8.9-Beta-0.10.6v.jar` in the Minecraft `mods` folder.
3. Launch the Forge profile.

## Compatibility and testing limits

The project targets desktop Java 8. Android/Pojav compatibility is not verified. Automated tests cover logic, settings and configuration; they do not launch Minecraft or verify live-server behavior. Test rendering and gameplay in Minecraft 1.8.9 before publishing a release.

## License and credits

Both `LICENSE` and `LICENSE.txt` are retained from the supplied source archive. They contain different license texts (MIT and LGPL v3), so they must not be treated as interchangeable. Preserve upstream notices and verify the applicable license for each reused component before redistributing. Parts of the project were ported from RNG Carried Bald; existing attribution should remain with the relevant code.


## Dungeon map and puzzle-room labels

The Dungeon page includes a client-side overlay for the live map item in hotbar slot 9. Rotation defaults to the Better NEF-style player-centered projection (including the same yaw-angle rule, map-square clipping, and manually redrawn map decorations). Turn **Rotate map** off to use the server map in static north-up mode. Player names are anchored to their transformed map marker positions but remain horizontal and have no rectangle background. The Secrets readout displays the current count only (for example, `Secrets: 36`) when that number is available in the scoreboard.

Puzzle labels are recognized from the bundled user-provided `rooms.json` selected-block templates and rendered in green directly above each matched purple room tile, with no black label background. Successful detections are remembered by fixed room world coordinates (`originX`, `originY`, `originZ`) for the rest of that dungeon run, so the name stays visible after the player leaves the room. That memory is cleared when the run/world ends to prevent labels from a previous run leaking into a new dungeon. The matcher checks every 40 client ticks (about 2 seconds at 20 TPS) until a high-confidence match is stable. Only rooms represented in `rooms.json` can be labeled.

The map options are on **Sky VeLor → HUD → Dungeon Map**. **Scale** changes the whole HUD widget size (70–250%, capped to the viewport); the separate **Map zoom** control magnifies or shrinks the map contents (50–200%) without moving or resizing the HUD frame. Above 100% intentionally crops map edges. **Edit map** opens the HUD editor, where you can move the map, adjust the same zoom, and reset its position, size, or zoom. Rotation mode, zoom, size, position, player-name labels, and puzzle labels persist in the existing settings file.

## Dungeon terminals, devices and puzzle solvers

The Dungeon settings page exposes independent options for the Better NEF-derived features. Terminal handling includes **Starts With**, **Click in Order**, **Select Colors**, **Correct Panes**, and **Terminal Maze**, with optional custom layouts, scaling, safer-click handling, incorrect-choice hiding and tooltip suppression. Supporting features include the Goldor phase tracker, editable terminal/device waypoints, and the local `/termsim` practice GUI (it does not send a server command).

Available puzzle helpers are **Three Weirdos**, **Creeper Beams**, **Boulder**, **Silverfish**, **Water Board**, and **Teleport Maze**. Device support includes the **First Device** and **Third Device** from Better NEF v34. That source archive does not contain a separate Second Device solver, so Sky VeLor does not claim to implement one. See `THIRD_PARTY_NOTICES/Better-NEF-NOTICE.md` and the adjacent license file for attribution and license terms.

`check` runs a source-level integration gate for the required solver classes, Forge event registrations, settings controls and attribution. The standalone test runners also include a regression test for solver highlight-colour parsing. These checks do not replace testing all terminal states and puzzle rooms in a live Minecraft 1.8.9 client.
