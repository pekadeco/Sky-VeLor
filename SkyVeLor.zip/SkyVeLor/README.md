# Sky VeLor — Beta-0.10.6v

Sky VeLor is a client-side Forge mod for Minecraft 1.8.9. It provides a configurable HUD, a settings hub, dungeon utilities, Spirit Leap helpers, fishing and Slayer trackers, and quick notes.

## Features

- Settings hub and movable HUD editor with dark and light themes.
- Smooth, frame-rate-independent UI motion: soft hover and press feedback, animated toggles and sliders, a sliding segmented selector, a gently appearing dropdown, and responsive search-field focus.
- Rounded animated buttons in the main/pause menu and Quick Note screen, with distinct primary, secondary and destructive styles.
- Spirit Leap teammate picker, class labels, player heads and isolated preview.
- Dungeon minimap with automatically rotating live map, teammate names, puzzle-room labels and a numeric Secrets counter; optional Cloudflare-based Puzzle discovery sync; Floor VII boss/dragon overlays, dragon alerts, and optional blood-room miniboss highlights.
- Mining foundations: Mining BPS, a movable mining-session panel, optional Fakepixel pickaxe ability alerts, and the Dwarven Mines Puzzler target marker.
- Fishing and Slayer trackers, plus quick notes and client commands.
- Item Protection for uniquely identified SkyBlock items: configurable keybind, persistent local UUID list, protected-item indicators, and guarded drop/trade/sell actions.
- Optional Slot Locking and inventory-to-hotbar bindings with a persistent local slot map and lock/binding indicators.
- Dungeon terminal GUI variants and solvers, device helpers, six puzzle solvers, Goldor phase tracker, waypoints, and a local `/termsim` practice screen.

## Requirements

- Minecraft 1.8.9 with Forge `11.15.1.2318`.
- JDK 8 for compiling and Java 8 for the legacy Forge runtime.
- Internet access on the first build so Gradle and ForgeGradle can download their dependencies.

This project intentionally retains the ForgeGradle 2.1 / Gradle 2.14.1 toolchain used by Forge 1.8.9. Newer JDKs and Gradle releases are not drop-in replacements for this legacy build.

## Build on Windows

Open Command Prompt in this folder and make sure `JAVA_HOME` points to a JDK 8 installation. Then run:

```bat
gradlew.bat clean build dumpTestClasspath
```

To run the standalone tests in Command Prompt:

```bat
tests\run-tests.bat
```

## Build on Linux or Git Bash

With JDK 8 selected, run:

```sh
./gradlew clean build dumpTestClasspath
TEST_CP="$(cat build/test-classpath.txt)" sh tests/run-tests.sh
```

The mod JAR is written to `build/libs/`. The source package keeps any older generated outputs under `previous-build-artifacts/` only as a backup; do not install a JAR from that folder. Build a fresh JAR with the command above. The active `build/` output and `.gradle/` cache are generated locally.


## Mining foundations

The `/sv` hub has a **Mining** tab (renamed from the former Farming tab without changing existing settings keys). Mining BPS continues to count client-visible block breaks and resets when the world/player session changes. The optional **Mining Assistant** HUD shows the rolling rate, session count, and the status of a supported pickaxe ability; it is movable and styled through the HUD editor.

The opt-in **Pickaxe ability ready alert** tracks only recognized Fakepixel system-chat activation messages for Pickobulus (nominal 60 seconds) and Mining Speed Boost (nominal 120 seconds). Cooldown reductions or server-side rule changes can make a local nominal countdown differ from the real cooldown, so treat the alert as a reminder rather than authoritative server state. Unknown abilities are not assigned a guessed cooldown.

The opt-in **Dwarven Mines Puzzler direction helper** parses a valid `[NPC] Puzzler` direction clue and outlines the resulting target block. It is limited to Fakepixel, clears its target when the world changes, and only renders near the expected puzzle coordinates. The powder, drill-fuel, and commission values are intentionally not displayed yet because Sky VeLor does not have a verified parser for the current Fakepixel data layouts.

The mining ability notifier and Puzzler helper are off by default. Open `/sv` → **Mining** to enable them. Pure-logic tests cover cooldown parsing, rounding, unknown ability handling, Puzzler route directions, malformed clues, and bounded input length. Those tests do not replace validation in a live Forge 1.8.9 session.

## Inventory and Chat QoL

- Chat copy follows the Better NEF gesture: hold **Shift** and left-click a visible chat message to copy the entire wrapped message; hold **Ctrl** too to include formatting codes. A subtle highlight and copy icon are shown while Shift is held.
- **No hurt camera** disables the damage camera shake/roll (enabled by default, like Better NEF).
- **Hide block breaking particles** hides both block-hit and block-destroy particles (off by default).


Client-side helpers are available from `/sv` under **Inventory & Chat QoL**. Default states are noted for each option:

- **Inventory search and filter** adds a search box to the player inventory and chest screens. It follows Minecraft's actual GUI coordinates, including the potion-panel offset, so highlights remain aligned when status effects are visible. It searches item names and lore, dims non-matching stacks, and outlines matches; it never disables or intercepts item clicks.
- **Hide potion effects in inventory** optionally hides only the effects panel on the player inventory screen and recenters the inventory. Potion effects remain active in gameplay.
- **Auto sprint** starts sprinting while moving forward when the usual food/flight, use-item, collision, riding, sneaking and blindness restrictions permit it. It is off by default.
- **Roman numerals in tooltips** converts unambiguous Roman numeral levels such as `VI` to `6` while preserving formatting codes.
- **Scrollable item tooltips** is enabled by default like Better NEF and limits long tooltips to a compact window. Scroll the mouse wheel while the tooltip is visible to move through the lore; the wheel is consumed while scrolling so the hotbar selection does not change.
- **Item rarity highlight** draws an optional static, rarity-colored 16×16 slot gradient. The tint is intentionally more visible, strongest around the lower-middle and fading toward the top; it does not animate or add a border or external glow. The item, stack count, durability bar and enchantment glint render normally above it.
- **Copy chat text** is enabled by default like Better NEF. In an open chat screen, hold Shift and left-click a visible message to copy the full wrapped message; hold Ctrl too to include formatting codes. A copy icon and highlight appear while Shift is held, with no confirmation message added to chat.
- **No hurt camera** is enabled by default and disables the damage camera shake/roll.
- **Hide block breaking particles** is off by default; enabling it hides block-hit and block-destroy particles.
- **Wardrobe / Pets shortcuts** can be enabled and bound in `Options → Controls → Sky VeLor`. They send `/wardrobe` or `/pets` only when the connected server address contains `fakepixel`.

The search and rarity visuals operate only on supported inventory/chest screens. A small client-only Mixin hook draws the rarity tint before vanilla draws the slot item, avoiding duplicate item rendering. It does not change server-side inventory data.

## Item Protection

Item Protection is enabled by default. Open an inventory, place the cursor over a SkyBlock item and press **Protect Item** (configure its initially unbound key under **Options → Controls → Sky VeLor**). Outside an inventory, the same key protects or unprotects the currently held item. The feature requires the item's `ExtraAttributes.uuid` (or `ExtraAttributes.UUID`) to be a valid UUID; ordinary items without that identity cannot be protected safely. Protected items are marked with a gold star drawn over the item but below its tooltip in standard inventory and chest screens. Dragging a protected cursor stack outside the container is blocked on both mouse release and the outgoing container-click packet.

The protected UUID list is stored locally in `config/skyvelor/protected-items.txt`. It is readable and versioned, and updates are written atomically. `/sv protect` shows status; `/sv protect on`, `/sv protect off`, and `/sv protect toggle` control the feature. The master switch and notifications are also in **/sv → QoL → Item Protection**. If the store becomes unreadable or a save fails, protection switches to a fail-closed state for known destructive actions rather than treating the list as empty; repair the reported file before relying on the feature again.

Protection blocks known item drops and interactions in recognized trade, sell, salvage and auction-confirmation menus. It is a client-side safety layer, not a server guarantee: unrecognized custom interfaces, server-side menu bugs, items without a stable UUID, or actions taken while protection is disabled cannot be fully covered. Check the held item and destination before confirming any valuable transaction.

## Slot Locking and Binding

Slot Locking is off by default. Enable it in **/sv → QoL → Slot Locking / Binding** or with `/sv slots on`. Open the player inventory or a chest, hover a player-inventory slot, and tap **Lock Slot** (default **L**, configurable under **Options → Controls → Sky VeLor**) to lock or unlock it. The Better NEF-style gold lock icon marks a locked slot at 50% overlay opacity, and the blue binding icon marks a slot binding at 70% overlay opacity. The icons and search/rarity overlays render above slot items but below the active tooltip; their OpenGL state is restored after drawing. Locked player-inventory slots reject ordinary clicks and known drop, hotbar-swap, shift-click, drag-target and collect-all paths that would move items out of or into the slot. If the slot-lock settings file cannot be read, the feature restricts risky operations; `/sv slots off` disables the guard if access needs to be recovered while the file is repaired.

With **Enable slot binding** on, hold **Lock Slot** over a main-inventory or armor slot, then move the cursor onto a hotbar slot while still holding the key, matching Better NEF's drag gesture. The hotbar slots highlight and a link preview follows the cursor. A successful binding automatically protects both connected slots like Slot Locking and replaces any previous source paired to that hotbar slot. Release the key after each completed pair, then hold it again over the next source to create another pair; the release fallback prevents a missed GUI key-up event from leaving the gesture stuck. A short tap still toggles a regular slot lock. Multiple independent source/target pairs are supported at once. Right-click either the bound source slot or its paired hotbar slot to swap them. The real `GuiContainer` click is intercepted before vanilla treats a bound/locked slot as a cursor pickup, drop or ordinary move; only the validated right-click on the corresponding pair performs the special swap. Hover either bound endpoint to show a cyan link line between the slots, matching Better NEF without permanently drawing lines across the inventory. Each hotbar slot can have one bound inventory/armor partner, and several independent pairs can exist at the same time. Routine lock, unlock, bind, unbind and blocked-slot notices are silent in chat; storage errors may still be reported. Bindings and locks are stored locally in `config/skyvelor/slot-locks.properties` with atomic updates. `/sv slots` shows status; `/sv slots on`, `/sv slots off`, and `/sv slots toggle` control slot locking without deleting saved bindings.

Slot Locking is a client-side safeguard, not a server guarantee. It uses Forge GUI events, outgoing packet checks, and a narrowly scoped client-only Mixin for the actual slot-click interception. Custom interfaces or actions that bypass these hooks may not be covered. Test it with a non-valuable item and never rely on a client-side lock as the only protection for irreplaceable items.


## Installation

1. Start Minecraft 1.8.9 with Forge `11.15.1.2318` once.
2. Put `SkyVeLor-1.8.9-Beta-0.10.6v.jar` in the Minecraft `mods` folder.
3. Launch the Forge profile.

## Compatibility and testing limits

The project targets desktop Java 8. Android/Pojav compatibility is not verified. Automated tests cover logic, settings and configuration; they do not launch Minecraft or verify live-server behavior. Test rendering and gameplay in Minecraft 1.8.9 before publishing a release.

## Developers

Sky VeLor is developed by **ii8we**, **whiteshadow**, and **pekadeco**.

## License and credits

The root `LICENSE` is the sole license and attribution file. It contains the Sky VeLor developer credits, the NotEnoughFakepixel upstream attribution, and the unmodified GNU Lesser General Public License v3.0-or-later text used for code derived from that project. No separate notice directory or duplicate license file is required. Gradle refuses to configure the project if `LICENSE` is missing or its required license/attribution content is incomplete.

Sky VeLor is a separate project; this notice does not claim ownership of the original NotEnoughFakepixel authors' code. Parts of the project were also ported from RNG Carried Bald, so preserve its applicable attribution and license notices for the relevant components.
## Privacy

Read [privacy.md](privacy.md) for the Dungeon Sync data disclosure, IP-address limitations, log configuration, temporary puzzle-data behavior, and how to opt out at any time.

## Optional dungeon Puzzle sync

Puzzle discovery can be synchronized between teammates without Party Chat or `[code]` messages. The exact `Dungeon starts in 1 second.` line starts setup whether Fakepixel delivers it as ordinary chat or system text. Each client waits for three matching snapshots. The server ID is read from the Tab List (including its header/footer), the floor from the scoreboard, and the party roster is selected from valid profile usernames using the declared `Party (2)`–`Party (5)` size, visible player rows, and class-marker evidence when Fakepixel's custom Tab List contains synthetic entries. The local player must be present, and the selected roster must match the declared party size; solo, unknown-size, conflicting, incomplete, or oversized rosters are rejected rather than guessed. Each client sorts and hashes the names locally together with server ID and floor; only the derived 64-character SHA-256 session ID is sent to Cloudflare, not the raw names. This works with offline-mode accounts when the server exposes the same account usernames to all party members. Puzzle labels and room-origin coordinates are synchronized only during the temporary session.

The mod ships with the project's Worker endpoint, so players do not need to copy or send the same URL to one another. Synchronization is **off by default**. To enable it, open the in-game Sky VeLor settings (`/sv`), go to **Dungeon → Dungeon Sync**, and switch on **Enable Dungeon Sync**. The toggle is also searchable by `sync`, `dungeon`, `enable` or `data`. The change saves and applies immediately; no restart or manual config editing is required. The same toggle turns it off and closes the current sync connection. Read [CLOUDFLARE-DUNGEON-SYNC.md](CLOUDFLARE-DUNGEON-SYNC.md) before enabling it. The current dungeon instance ID and floor are combined with the valid player profile usernames in the current Tab List to derive a temporary session fingerprint locally. Raw player names are not uploaded; the Worker receives the fingerprint and puzzle-room discoveries, while Cloudflare also processes normal connection metadata, including IP addresses. The fingerprint is pseudonymous, not guaranteed anonymous. Stable-mode roster validation requires a declared `Party (2)` through `Party (5)` and an exact, consistent set of party profile names. Solo `Party (1)` sessions are rejected; the sync connection is only opened for a real multi-player roster.

## Dungeon map and puzzle-room labels

The Dungeon page includes a client-side overlay for the live map item in hotbar slot 9. Rotation defaults to the Better NEF-style player-centered projection (including the same yaw-angle rule, map-square clipping, and manually redrawn map decorations). Turn **Rotate map** off to use the server map in static north-up mode. Player names are anchored to their transformed map marker positions but remain horizontal and have no rectangle background. The Secrets readout displays the current count only (for example, `Secrets: 36`) when that number is available in the scoreboard.

Puzzle labels are recognized from the bundled user-provided `rooms.json` selected-block templates and anchored at the center of each matched purple room tile. Multi-word names wrap over two lines (for example, `Water` above `Board`) and use a compact translucent dark plate plus each puzzle's accent color to remain readable over map details. Successful detections are remembered by fixed room world coordinates (`originX`, `originY`, `originZ`) for the rest of that dungeon run, so the name stays visible after the player leaves the room. That memory is cleared when the run/world ends to prevent labels from a previous run leaking into a new dungeon. The matcher checks every 40 client ticks (about 2 seconds at 20 TPS) until a high-confidence match is stable. Only rooms represented in `rooms.json` can be labeled.

The map options are on **Sky VeLor → HUD → Dungeon Map**. **Scale** changes the whole HUD widget size (70–250%, capped to the viewport); the separate **Map zoom** control magnifies or shrinks the map contents (50–200%) without moving or resizing the HUD frame. Above 100% intentionally crops map edges. **Edit map** opens the HUD editor, where you can move the map, adjust the same zoom, and reset its position, size, or zoom. Rotation mode, zoom, size, position, player-name labels, and puzzle labels persist in the existing settings file.

## Dungeon combat highlights

The Dungeon page has an opt-in **Blood-room miniboss highlight** for Fakepixel Catacombs. It highlights the known Angry Archaeologist, Lost Adventurer, Frozen Adventurer, Diamond Guy, Shadow Assassin and King Midas mobs with configurable box colour. It is disabled by default and only runs when both the Fakepixel server check and the Catacombs scoreboard check pass. A separate **Level-tag mob highlights** option outlines dungeon mobs whose name tags begin with a recognised `[LvNN]` tag or contain the elite-star marker. The existing Floor VII/M7 boss and dragon overlays remain separately controlled.

## Dungeon terminals, devices and puzzle solvers

The Dungeon settings page exposes independent options for the Better NEF-derived features. Terminal handling includes **Starts With**, **Click in Order**, **Select Colors**, **Correct Panes**, and **Terminal Maze**, with optional custom layouts, scaling, safer-click handling, incorrect-choice hiding and tooltip suppression. Supporting features include the Goldor phase tracker, editable terminal/device waypoints, and the local `/termsim` practice GUI (it does not send a server command).

For troubleshooting, run `/termdebug on`, reproduce the terminal GUI issue, then run `/termdebug dump`. The bounded diagnostic log is written to `config/skyvelor/terminal-debug.log` inside the Minecraft game directory. It records GUI titles/state, solver settings, relevant inventory slot contents, canceled GUI draw/click events, and mouse coordinates. Use `/termdebug off` to stop recording, `/termdebug status` to check state, and `/termdebug clear` to clear the in-memory buffer. Debug recording is off by default and does not send data to the server.

Available puzzle helpers are **Three Weirdos**, **Creeper Beams**, **Boulder**, **Silverfish**, **Water Board**, and **Teleport Maze**. Device support includes the **First Device** and **Third Device** adapted through ii8we’s private modifications of code originating in the original NotEnoughFakepixel project. The inspected source did not contain a separate Second Device solver, so Sky VeLor does not claim to implement one. See the root `LICENSE` file for upstream attribution and applicable license terms.

`check` runs a source-level integration gate for the required solver classes, Forge event registrations, settings controls and attribution. The standalone test runners also include a regression test for solver highlight-colour parsing. These checks do not replace testing all terminal states and puzzle rooms in a live Minecraft 1.8.9 client.


### Dungeon Sync Debug

Open `/sv` → **Dungeon → Dungeon Sync** and enable **Dungeon Sync Debug** only when troubleshooting. It is **off by default**. When enabled, it reports roster selection, server connection, Worker acceptance/rejection, remote puzzle receipt, local map memory, and puzzle-label rendering. Diagnostics keep raw player usernames and the session fingerprint local and out of network messages. The setting saves immediately and can be turned off again from the same GUI. The Cloudflare Worker must be updated to support server-side acknowledgements and member counts.

## Attribution and notices

Sky VeLor includes adaptations of portions of NotEnoughFakepixel-related open-source work. Read [`notice.md`](notice.md) for upstream attribution and the root [`LICENSE`](LICENSE) for the applicable NotEnoughFakepixel LGPL and Skytils AGPL license texts and their scope. The notice is supplementary and does not replace the license terms.


## SkyBlock-only features

SkyBlock-specific behavior is enabled only while the live scoreboard sidebar title identifies `SKYBLOCK`. The mod checks the sidebar title rather than relying on the server address alone, because the same server can expose multiple game modes. The context is refreshed on client ticks and reset on disconnect.

This gate covers slot locking/binding, protected-item actions and markers, rarity highlighting, dungeon map/solver features, M7 overlays, Slayer and fishing tracking, Fakepixel mining alerts/Puzzler highlighting, SkyBlock-only HUD panels, and Roman-numeral tooltip conversion. General client QoL (such as inventory search, chat copying, scrollable tooltips, key configuration, and the HUD editor) remains available outside SkyBlock. Saved locks, bindings, and protected-item records are retained when leaving SkyBlock; their restrictions are simply inactive until SkyBlock is detected again.

### Dungeon puzzle labels

Puzzle names are centered on the detected 32×32 room center. Their map-space anchors are refreshed from the current player coordinates and map marker every render frame, preventing a stale first marker sample from leaving a label stranded far from its room. World X increases to the right and world Z increases downward in map space.


### Additional features

- **Dungeon Boss HP HUD:** optional draggable HUD for Maxor, Storm, Goldor, Necron and the five Master Mode VII dragons. Health parsing uses boss-bar/sidebar/entity sources with safeguards against vanilla-scaled HP; enable it from `/sv` → Dungeon or configure it in the HUD editor.
- **Chat channel tabs:** All, Party, Guild, PM and Co-op tabs above the chat input. Chat history is retained and tab filtering rebuilds only visible chat rows. Skytils attribution and the applicable AGPL license text are included in the root `LICENSE` and summarized in `notice.md`.
- **Fishing counter expansion:** individual rare/legendary creature rows, a combined **CC** total for non-legendary catches, a total row, and the pre-existing Festival count/best.
- **Sea Creature HP improvements:** more robust nameplate extraction for Fakepixel scoreboard-composed labels, short detection grace to avoid HUD flicker, and Yeti appearance alerts (with the existing Jawbus chat alert retained).
- **Slayer tracker retention:** rare drops and quantities are written to a separate local history file and survive game restarts until cleared. The HUD can show all stored drops or use its row-limit switch. The Slayer HUD border can be toggled from `/sv` → Slayer.
- **Optional Chatting animation controls:** settings are exposed for compatible externally installed Chatting builds. This source ZIP does not bundle Chatting's runtime, mixins or launch tweaker.
