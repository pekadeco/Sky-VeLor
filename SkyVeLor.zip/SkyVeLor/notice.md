# Sky VeLor Notice

Sky VeLor is an independent, community-developed Forge 1.8.9 client mod maintained by **ii8we, whiteshadow, and pekadeco**. It is not an official release of, and is not endorsed by, the upstream projects listed below.

## NotEnoughFakepixel-origin portions

- **Project:** NotEnoughFakepixel
- **Repository:** https://github.com/im2pb/NotEnoughFakepixel
- **License:** GNU Lesser General Public License v3.0 or later (**LGPL-3.0-or-later**) for applicable upstream-derived portions.
- Some dungeon solver, terminal, device, and related implementation in Sky VeLor was adapted through ii8we's private modifications of code originating in NotEnoughFakepixel-related work. Original copyright and license notices in reused source remain applicable.

## Skytils-derived Chat Channel Tabs

- **Project:** SkytilsMod
- **Repository:** https://github.com/Skytils/SkytilsMod
- **Reference commit:** `276c07edf0f1e64956424016f438a5059c63a863`
- **Copyright:** Copyright (C) 2020-2023 Skytils contributors
- **License:** GNU Affero General Public License v3 or later (**AGPL-3.0-or-later**) for the Skytils-derived Chat Channel Tabs portion, including the linking exception supplied with that license.

The Chat Channel Tabs feature is an independent Java/Forge integration based on the upstream ChatTabs implementation and channel conventions. The applicable license texts and their scopes are collected in the root [`LICENSE`](LICENSE) file. This `notice.md` is a concise attribution notice; it does not replace or modify those license terms.

## Scope and responsibility

Sky VeLor's own original additions and assets should be distinguished from upstream-derived portions. Each applicable upstream license governs the portions covered by it. Sky VeLor does not claim ownership of upstream contributors' work, and upstream projects and contributors are not responsible for Sky VeLor or its modifications.
