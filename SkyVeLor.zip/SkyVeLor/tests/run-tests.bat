@echo off
setlocal EnableExtensions
set "ROOT=%~dp0.."
set "CLASSES=%ROOT%\build\classes\main"
set "CP_FILE=%ROOT%\build\test-classpath.txt"
set "OUT=%TEMP%\skyvelor-tests-%RANDOM%-%RANDOM%"

if not exist "%CLASSES%" (
    echo Main classes not found. Run gradlew.bat build dumpTestClasspath first.
    exit /b 1
)
if not exist "%CP_FILE%" (
    echo Test classpath not found. Run gradlew.bat build dumpTestClasspath first.
    exit /b 1
)
set /p "TEST_CP="<"%CP_FILE%"
if not defined TEST_CP (
    echo Test classpath is empty: %CP_FILE%
    exit /b 1
)
mkdir "%OUT%" || exit /b 1

for /r "%ROOT%\tests" %%F in (*.java) do echo "%%F" >> "%OUT%\sources.txt"
javac -nowarn -encoding UTF-8 -cp "%CLASSES%;%TEST_CP%" -d "%OUT%" @"%OUT%\sources.txt"
if errorlevel 1 goto fail

set "CP=%OUT%;%CLASSES%;%TEST_CP%"
call :run dev.client.skyvelor.gui.PureLogicTests || goto fail
call :run dev.client.skyvelor.hud.ConfigTests || goto fail
call :run dev.client.skyvelor.feature.LeapTextTests || goto fail
call :run dev.client.skyvelor.feature.SkyblockContextPolicyTests || goto fail
call :run dev.client.skyvelor.feature.AutoSprintTests || goto fail
call :run dev.client.skyvelor.feature.inventory.InventoryLayoutPolicyTests || goto fail
call :run dev.client.skyvelor.feature.LeapIdentityTests || goto fail
call :run dev.client.skyvelor.feature.LeapClassCacheTests || goto fail
call :run dev.client.skyvelor.config.ConfigFilesTests || goto fail
call :run dev.client.skyvelor.feature.protection.ProtectedItemStoreTests || goto fail
call :run dev.client.skyvelor.feature.protection.ProtectedItemActionPolicyTests || goto fail
call :run dev.client.skyvelor.feature.inventory.SlotLockStoreTests || goto fail
call :run dev.client.skyvelor.feature.inventory.SlotBindingGesturePolicyTests || goto fail
call :run dev.client.skyvelor.feature.qol.InventorySearchMatcherTests || goto fail
call :run dev.client.skyvelor.feature.qol.RomanNumeralParserTests || goto fail
call :run dev.client.skyvelor.feature.qol.ItemRarityColorsTests || goto fail
call :run dev.client.skyvelor.feature.qol.TooltipScrollWindowTests || goto fail
call :run dev.client.skyvelor.feature.qol.ChatCopyTextPolicyTests || goto fail
call :run dev.client.skyvelor.feature.mining.MiningAbilityCooldownTests || goto fail
call :run dev.client.skyvelor.feature.mining.MiningPuzzlerRouteTests || goto fail
call :run dev.client.skyvelor.config.AppleSettingsTests || goto fail
call :run dev.client.skyvelor.render.ThemeTests || goto fail
call :run dev.client.skyvelor.hud.DollConfigTests || goto fail
call :run dev.client.skyvelor.feature.LeapClassTests || goto fail
call :run dev.client.skyvelor.feature.SpiritLeapTests || goto fail
call :run dev.client.skyvelor.feature.DungeonContextTests || goto fail
call :run dev.client.skyvelor.feature.MobMarkersTests || goto fail
call :run dev.client.skyvelor.feature.BloodMobMatcherTests || goto fail
call :run dev.client.skyvelor.dungeon.M7DetectionTests || goto fail
call :run dev.client.skyvelor.gui.LeapLayoutTests || goto fail
call :run dev.client.skyvelor.gui.WindowControlsTests || goto fail
call :run dev.client.skyvelor.gui.LeapPaletteTests || goto fail
call :run dev.client.skyvelor.gui.LeapPreviewDataTests || goto fail
call :run dev.client.skyvelor.hud.StatsTextTests || goto fail
call :run dev.client.skyvelor.startup.StartupTimingTests || goto fail
call :run dev.client.skyvelor.fishing.FishingTests || goto fail
call :run dev.client.skyvelor.dungeon.DungeonBossHpTests || goto fail
call :run dev.client.skyvelor.feature.ChatFilterRulesTests || goto fail
call :run dev.client.skyvelor.dungeon.DragonKillTests || goto fail
call :run dev.client.skyvelor.dungeon.PuzzleRoomDataTests || goto fail
call :run dev.client.skyvelor.dungeon.sync.DungeonSyncIdentityTests || goto fail
call :run dev.client.skyvelor.dungeon.sync.DungeonSyncReconnectPolicyTests || goto fail
call :run dev.client.skyvelor.dungeon.sync.DungeonPuzzleSyncConfigTests || goto fail
call :run dev.client.skyvelor.dungeon.PuzzleRoomMemoryTests || goto fail
call :run dev.client.skyvelor.dungeon.DungeonMapLabelAnchorTests || goto fail
call :run dev.client.skyvelor.dungeon.PuzzleLabelsTests || goto fail
call :run dev.client.skyvelor.dungeon.DungeonMapProjectionTests || goto fail
call :run dev.client.skyvelor.dungeon.DungeonMapLabelLayoutTests || goto fail
call :run dev.client.skyvelor.dungeon.DungeonMapPlayerNameAssignmentsTests || goto fail
call :run dev.client.skyvelor.dungeon.DungeonMapPartyRosterTests || goto fail
call :run dev.client.skyvelor.dungeon.solver.DungeonSolverColorTests || goto fail
call :run dev.client.skyvelor.dungeon.solver.terminals.TerminalDebugTests || goto fail
call :run dev.client.skyvelor.slayer.SlayerTests || goto fail
call :run dev.client.skyvelor.widget.SearchFieldTests || goto fail
call :run dev.client.skyvelor.widget.WidgetInteractionTests || goto fail

echo All Sky VeLor tests passed.
rmdir /s /q "%OUT%"
exit /b 0

:run
 echo === %~1 ===
 java -cp "%CP%" %~1
 if errorlevel 1 exit /b 1
 exit /b 0

:fail
 echo Tests failed. Temporary output kept at "%OUT%" for diagnosis.
 exit /b 1
