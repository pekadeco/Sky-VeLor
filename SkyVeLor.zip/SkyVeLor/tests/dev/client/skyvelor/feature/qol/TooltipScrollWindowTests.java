package dev.client.skyvelor.feature.qol;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class TooltipScrollWindowTests {
    private static int passed;
    private static int failed;

    public static void main(String[] args) {
        List<String> shortTip = Arrays.asList("Sword", "Damage", "Legendary");
        check("short tooltips are unchanged", TooltipScrollWindow.window(shortTip, 2, 12).equals(shortTip));
        List<String> longTip = new ArrayList<String>();
        for (int i = 0; i < 30; i++) longTip.add(i == 0 ? "Sword" : "Line " + i);
        List<String> top = TooltipScrollWindow.window(longTip, 0, 12);
        check("top keeps title first", "Sword".equals(top.get(0)));
        check("top window indicates additional lines", top.get(top.size() - 1).contains("more"));
        check("window respects requested height", top.size() <= 12);
        List<String> middle = TooltipScrollWindow.window(longTip, 5, 12);
        check("middle window indicates lines above", middle.get(1).contains("More above"));
        check("middle window remains bounded", middle.size() <= 12);
        List<String> end = TooltipScrollWindow.window(longTip, 999, 12);
        check("offset clamps to final window", end.size() <= 12 && end.get(0).equals("Sword"));
        check("max offset reaches final source line", TooltipScrollWindow.maxOffset(longTip) == 20
                && end.contains("Line 29"));
        check("null source yields empty window", TooltipScrollWindow.window(null, 0, 12).isEmpty());
        check("zero visible lines yields empty window", TooltipScrollWindow.window(longTip, 0, 0).isEmpty());
        check("negative visible lines yields empty window", TooltipScrollWindow.window(longTip, 0, -1).isEmpty());
        System.out.println("tooltip scroll window: passed " + passed + ", failed " + failed);
        if (failed > 0) System.exit(1);
    }

    private static void check(String name, boolean ok) {
        if (ok) passed++;
        else { failed++; System.out.println("FAIL " + name); }
    }
}
