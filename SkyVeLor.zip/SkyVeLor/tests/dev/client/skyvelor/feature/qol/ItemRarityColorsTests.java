package dev.client.skyvelor.feature.qol;

import java.util.Arrays;
import java.util.Collections;

public final class ItemRarityColorsTests {
    private static int passed;
    private static int failed;

    public static void main(String[] args) {
        check("recognizes formatted legendary line", ItemRarityColors.colorForLoreLines(Arrays.asList("§7Some lore", "§6§lLEGENDARY")) == 0xFFFFAA00);
        check("recognizes decorated very special", ItemRarityColors.colorForLoreLines(Arrays.asList("✪✪ VERY SPECIAL")) == 0xFFFF5555);
        check("recognizes uncommon line", ItemRarityColors.colorForLoreLines(Arrays.asList("§aUNCOMMON")) == 0xFF55FF55);
        check("rarity keyword anywhere in lore is recognized", ItemRarityColors.colorForLoreLines(Arrays.asList("This is very rare indeed")) == 0xFF5555FF);
        check("rare helmet rarity line is recognized", ItemRarityColors.colorForLoreLines(Arrays.asList("RARE HELMET")) == 0xFF5555FF);
        check("mythic helmet rarity line is recognized", ItemRarityColors.colorForLoreLines(Arrays.asList("MYTHIC HELMET")) == 0xFFFF55FF);
        check("epic helmet rarity line is recognized", ItemRarityColors.colorForLoreLines(Arrays.asList("§5EPIC HELMET")) == 0xFFAA00AA);
        check("rare helmet display name is recognized", ItemRarityColors.colorForItem("RARE HELMET", Collections.<String>emptyList()) == 0xFF5555FF);
        check("mythic helmet display name is recognized", ItemRarityColors.colorForItem("MYTHIC HELMET", Collections.<String>emptyList()) == 0xFFFF55FF);
        check("formatted rare helmet display name is recognized", ItemRarityColors.colorForItem("§9§lRARE HELMET", Collections.<String>emptyList()) == 0xFF5555FF);
        check("rarity substring in display name is accepted", ItemRarityColors.colorForItem("RAREFIED HELMET", Collections.<String>emptyList()) == 0xFF5555FF);
        check("rarity substring in lore line is accepted", ItemRarityColors.colorForLoreLines(Arrays.asList("RAREFIED HELMET")) == 0xFF5555FF);
        check("rarity later in item name is recognized", ItemRarityColors.colorForItem("HELMET OF RARE POWER", Collections.<String>emptyList()) == 0xFF5555FF);
        check("dedicated lore rarity line has priority over display name", ItemRarityColors.colorForItem("RARE HELMET", Arrays.asList("§5EPIC")) == 0xFFAA00AA);
        check("recombobulated item with embedded legendary rarity is recognized", ItemRarityColors.colorForLoreLines(Arrays.asList("§7Recombobulated to §6LEGENDARY!")) == 0xFFFFAA00);
        check("spaced rarity letters are recognized", ItemRarityColors.colorForLoreLines(Arrays.asList("§dM Y T H I C HELMET")) == 0xFFFF55FF);
        check("rare is found through punctuation and formatting", ItemRarityColors.colorForItem("§9✦ R.A.R.E ✦ Helmet", Collections.<String>emptyList()) == 0xFF5555FF);
        check("uncommon takes precedence over common substring", ItemRarityColors.colorForLoreLines(Arrays.asList("UNCOMMON")) == 0xFF55FF55);
        check("very special is not reduced to special", ItemRarityColors.colorForLoreLines(Arrays.asList("VERY SPECIAL")) == 0xFFFF5555);
        check("empty lore returns no border", ItemRarityColors.colorForLoreLines(Collections.<String>emptyList()) == 0);
        check("null lore returns no border", ItemRarityColors.colorForLoreLines(null) == 0);
        check("static highlight alpha is low at top", ItemRarityColors.highlightAlphaForRow(0) > 0
                && ItemRarityColors.highlightAlphaForRow(0) < 16);
        check("highlight is strongest near lower middle", ItemRarityColors.highlightAlphaForRow(11)
                > ItemRarityColors.highlightAlphaForRow(0));
        check("gradient fades before the bottom edge", ItemRarityColors.highlightAlphaForRow(11)
                > ItemRarityColors.highlightAlphaForRow(15));
        check("rarity highlight is visibly stronger", ItemRarityColors.highlightAlphaForRow(11) >= 96);
        check("highlight alpha is bounded", ItemRarityColors.highlightAlphaForRow(11) <= 120);
        check("highlight rejects rows outside slot", ItemRarityColors.highlightAlphaForRow(16) == 0);
        check("negative row has no alpha", ItemRarityColors.highlightAlphaForRow(-1) == 0);
        System.out.println("item rarity colors: passed " + passed + ", failed " + failed);
        if (failed > 0) System.exit(1);
    }

    private static void check(String name, boolean ok) {
        if (ok) passed++;
        else { failed++; System.out.println("FAIL " + name); }
    }
}
