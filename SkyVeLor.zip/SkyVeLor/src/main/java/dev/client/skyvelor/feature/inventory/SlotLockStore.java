package dev.client.skyvelor.feature.inventory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Local, versioned persistence for player-inventory slot locks and inventory-to-hotbar bindings. */
public final class SlotLockStore {
    public static final int SLOT_COUNT = 40;
    public static final int HOTBAR_SIZE = 9;
    public static final int MAIN_INVENTORY_START = 9;
    public static final int MAIN_INVENTORY_END = 35;

    private static final Logger LOGGER = Logger.getLogger("SkyVeLor");
    private static final String VERSION = "1";

    private final boolean[] locked = new boolean[SLOT_COUNT];
    private final int[] boundTo = new int[SLOT_COUNT];
    private File file;
    private boolean loaded;
    private boolean failed;
    private String failureReason = "";

    public SlotLockStore() {
        Arrays.fill(boundTo, -1);
    }

    public synchronized void load(File target) {
        if (loaded) return;
        if (target == null) {
            fail("Slot-lock settings path is unavailable.");
            loaded = true;
            return;
        }
        file = target;
        File parent = file.getParentFile();
        if (parent != null && !parent.isDirectory() && !parent.mkdirs() && !parent.isDirectory()) {
            fail("Could not create the slot-lock settings folder.");
            loaded = true;
            return;
        }

        File temp = new File(file.getPath() + ".tmp");
        if (temp.isFile()) {
            Properties recovery = readStrict(temp);
            if (recovery != null) {
                apply(recovery);
                try {
                    try {
                        Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING,
                                StandardCopyOption.ATOMIC_MOVE);
                    } catch (AtomicMoveNotSupportedException unsupported) {
                        Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
                    }
                    loaded = true;
                    return;
                } catch (IOException | SecurityException ex) {
                    LOGGER.log(Level.WARNING, "Could not promote recovered slot-lock settings " + temp, ex);
                }
                fail("Could not recover the slot-lock settings. Inventory actions involving player slots are restricted until repair.");
                loaded = true;
                return;
            }
            if (file.isFile()) {
                Properties main = readStrict(file);
                if (main != null) apply(main);
            }
            fail("The slot-lock recovery file is malformed. The source files were preserved; risky inventory actions are restricted.");
            loaded = true;
            return;
        }

        if (file.isFile()) {
            Properties values = readStrict(file);
            if (values == null) {
                fail("The slot-lock settings file is malformed or unreadable. Risky inventory actions are restricted.");
            } else {
                apply(values);
            }
        }
        loaded = true;
    }

    /**
     * A binding is stored on both endpoints, as in Better NEF. Each endpoint is automatically
     * protected while the pair exists; the relation itself is the persisted source of that lock.
     */
    public synchronized boolean isLocked(int index) {
        ensureLoaded();
        if (!isValidIndex(index)) return false;
        if (locked[index] || boundTo[index] >= 0) return true;
        // Keep legacy one-way settings safe until they are normalized by load().
        if (isHotbarIndex(index)) {
            for (int source = MAIN_INVENTORY_START; source < SLOT_COUNT; source++) {
                if (boundTo[source] == index) return true;
            }
        }
        return false;
    }

    /** Returns only a user-created lock, excluding the automatic lock implied by a binding. */
    public synchronized boolean isExplicitlyLocked(int index) {
        ensureLoaded();
        return isValidIndex(index) && locked[index];
    }

    public synchronized int getBoundTo(int index) {
        ensureLoaded();
        return isValidIndex(index) ? boundTo[index] : -1;
    }

    public synchronized int getSourceForHotbar(int hotbarIndex) {
        ensureLoaded();
        if (!isHotbarIndex(hotbarIndex)) return -1;
        int reciprocalSource = boundTo[hotbarIndex];
        if (isBindableSourceIndex(reciprocalSource) && boundTo[reciprocalSource] == hotbarIndex) {
            return reciprocalSource;
        }
        // Fallback supports an older one-way binding still present in memory.
        for (int index = MAIN_INVENTORY_START; index < SLOT_COUNT; index++) {
            if (boundTo[index] == hotbarIndex) return index;
        }
        return -1;
    }

    public synchronized int lockedCount() {
        ensureLoaded();
        int count = 0;
        for (int index = 0; index < SLOT_COUNT; index++) {
            if (isLocked(index)) count++;
        }
        return count;
    }

    public synchronized int bindingCount() {
        ensureLoaded();
        int count = 0;
        for (int index = MAIN_INVENTORY_START; index < SLOT_COUNT; index++) {
            if (boundTo[index] >= 0) count++;
        }
        return count;
    }

    public synchronized boolean hasFailed() {
        ensureLoaded();
        return failed;
    }

    public synchronized String getFailureReason() {
        ensureLoaded();
        return failureReason;
    }

    public synchronized ChangeResult toggleLock(int index) {
        ensureLoaded();
        if (!isValidIndex(index)) return ChangeResult.INVALID_SLOT;
        if (failed) return ChangeResult.STORAGE_UNAVAILABLE;
        boolean[] oldLocked = locked.clone();
        int[] oldBindings = boundTo.clone();
        locked[index] = !locked[index];
        if (locked[index]) {
            clearBindingAt(index);
            if (isHotbarIndex(index)) clearBindingsToHotbar(index);
        }
        if (!saveCurrent()) return rollback(oldLocked, oldBindings);
        return locked[index] ? ChangeResult.LOCKED : ChangeResult.UNLOCKED;
    }

    public synchronized ChangeResult bind(int inventoryIndex, int hotbarIndex) {
        ensureLoaded();
        if (!isBindableSourceIndex(inventoryIndex) || hotbarIndex < 0 || hotbarIndex >= HOTBAR_SIZE) {
            return ChangeResult.INVALID_BINDING;
        }
        if (failed) return ChangeResult.STORAGE_UNAVAILABLE;
        if (locked[inventoryIndex] || locked[hotbarIndex]) return ChangeResult.LOCKED_SLOT;

        boolean[] oldLocked = locked.clone();
        int[] oldBindings = boundTo.clone();
        int current = boundTo[inventoryIndex];
        if (current == hotbarIndex) {
            clearBindingAt(inventoryIndex);
            ChangeResult result = saveCurrent() ? ChangeResult.UNBOUND : rollback(oldLocked, oldBindings);
            return result == ChangeResult.UNBOUND ? ChangeResult.UNBOUND : result;
        }
        clearBindingAt(inventoryIndex);
        clearBindingsToHotbar(hotbarIndex);
        boundTo[inventoryIndex] = hotbarIndex;
        boundTo[hotbarIndex] = inventoryIndex;
        if (!saveCurrent()) return rollback(oldLocked, oldBindings);
        return ChangeResult.BOUND;
    }

    /** Completes a hold-to-bind gesture after the source was toggled by the key-down event. */
    public synchronized ChangeResult bindFromLockGesture(int inventoryIndex, int hotbarIndex) {
        ensureLoaded();
        if (!isBindableSourceIndex(inventoryIndex) || hotbarIndex < 0 || hotbarIndex >= HOTBAR_SIZE) {
            return ChangeResult.INVALID_BINDING;
        }
        if (failed) return ChangeResult.STORAGE_UNAVAILABLE;
        if (locked[hotbarIndex]) return ChangeResult.LOCKED_SLOT;

        boolean[] oldLocked = locked.clone();
        int[] oldBindings = boundTo.clone();
        // Better NEF stores the relationship on both slots. Binding-derived protection is
        // independent from explicit lock flags, so the special bound swap remains available.
        clearBindingAt(inventoryIndex);
        clearBindingsToHotbar(hotbarIndex);
        locked[inventoryIndex] = false;
        boundTo[inventoryIndex] = hotbarIndex;
        boundTo[hotbarIndex] = inventoryIndex;
        if (!saveCurrent()) return rollback(oldLocked, oldBindings);
        return ChangeResult.BOUND;
    }

    public synchronized boolean clearAll() {
        ensureLoaded();
        if (failed) return false;
        boolean[] oldLocked = locked.clone();
        int[] oldBindings = boundTo.clone();
        Arrays.fill(locked, false);
        Arrays.fill(boundTo, -1);
        if (saveCurrent()) return true;
        System.arraycopy(oldLocked, 0, locked, 0, SLOT_COUNT);
        System.arraycopy(oldBindings, 0, boundTo, 0, SLOT_COUNT);
        fail("Could not save cleared slot-lock settings. Previous settings were restored in memory.");
        return false;
    }

    private ChangeResult rollback(boolean[] oldLocked, int[] oldBindings) {
        System.arraycopy(oldLocked, 0, locked, 0, SLOT_COUNT);
        System.arraycopy(oldBindings, 0, boundTo, 0, SLOT_COUNT);
        fail("Could not save slot-lock settings. Changes were rolled back; inventory actions are restricted until repair.");
        return ChangeResult.STORAGE_ERROR;
    }

    /** Clears the pair touching any endpoint, including legacy one-way entries. */
    private void clearBindingAt(int index) {
        if (!isValidIndex(index)) return;
        int partner = boundTo[index];
        boundTo[index] = -1;
        if (isHotbarIndex(index)) {
            if (isBindableSourceIndex(partner) && boundTo[partner] == index) boundTo[partner] = -1;
            for (int source = MAIN_INVENTORY_START; source < SLOT_COUNT; source++) {
                if (boundTo[source] == index) boundTo[source] = -1;
            }
        } else {
            if (isHotbarIndex(partner) && boundTo[partner] == index) boundTo[partner] = -1;
            for (int hotbar = 0; hotbar < HOTBAR_SIZE; hotbar++) {
                if (boundTo[hotbar] == index) boundTo[hotbar] = -1;
            }
        }
    }

    private void clearBindingsToHotbar(int hotbarIndex) {
        if (!isHotbarIndex(hotbarIndex)) return;
        int reciprocalSource = boundTo[hotbarIndex];
        if (isBindableSourceIndex(reciprocalSource) && boundTo[reciprocalSource] == hotbarIndex) {
            boundTo[reciprocalSource] = -1;
        }
        boundTo[hotbarIndex] = -1;
        for (int index = MAIN_INVENTORY_START; index < SLOT_COUNT; index++) {
            if (boundTo[index] == hotbarIndex) boundTo[index] = -1;
        }
    }

    private Properties readStrict(File source) {
        Properties values = new Properties();
        try (java.io.InputStream in = Files.newInputStream(source.toPath())) {
            values.load(in);
        } catch (IOException | IllegalArgumentException | SecurityException ex) {
            LOGGER.log(Level.WARNING, "Could not read slot-lock settings " + source, ex);
            return null;
        }
        if (!VERSION.equals(values.getProperty("version"))) return null;
        for (String key : values.stringPropertyNames()) {
            String value = values.getProperty(key);
            if ("version".equals(key)) continue;
            if (key.startsWith("locked.")) {
                int index = parseIndex(key.substring("locked.".length()));
                if (!isValidIndex(index) || !("true".equals(value) || "false".equals(value))) return null;
            } else if (key.startsWith("bound.")) {
                int index = parseIndex(key.substring("bound.".length()));
                int target = parseIndex(value);
                if (!isValidIndex(index) || (target != -1 && !isValidBindingEndpoint(index, target))) return null;
            } else {
                return null;
            }
        }
        boolean[] proposedLocked = new boolean[SLOT_COUNT];
        int[] proposedBindings = new int[SLOT_COUNT];
        Arrays.fill(proposedBindings, -1);
        for (String key : values.stringPropertyNames()) {
            if (key.startsWith("locked.")) proposedLocked[parseIndex(key.substring(7))] = Boolean.parseBoolean(values.getProperty(key));
            if (key.startsWith("bound.")) proposedBindings[parseIndex(key.substring(6))] = parseIndex(values.getProperty(key));
        }
        // Validate one-to-one relationships while accepting the old format where only the
        // inventory/armor source stored its hotbar target. apply() normalizes both formats.
        for (int target = 0; target < HOTBAR_SIZE; target++) {
            int owner = -1;
            for (int sourceIndex = MAIN_INVENTORY_START; sourceIndex < SLOT_COUNT; sourceIndex++) {
                if (proposedBindings[sourceIndex] == target) {
                    if (owner >= 0 && owner != sourceIndex) return null;
                    owner = sourceIndex;
                }
            }
            int reverse = proposedBindings[target];
            if (reverse >= 0) {
                if (!isBindableSourceIndex(reverse)) return null;
                if (owner >= 0 && owner != reverse) return null;
                owner = reverse;
                int forward = proposedBindings[reverse];
                if (forward != -1 && forward != target) return null;
            }
            if (owner >= 0 && (proposedLocked[owner] || proposedLocked[target])) return null;
        }
        // Reject a source that tries to point at an invalid/non-hotbar partner. Also rejects
        // duplicate or conflicting reciprocal data before the existing settings are replaced.
        for (int sourceIndex = MAIN_INVENTORY_START; sourceIndex < SLOT_COUNT; sourceIndex++) {
            int target = proposedBindings[sourceIndex];
            if (target >= 0) {
                if (!isHotbarIndex(target)) return null;
                int reverse = proposedBindings[target];
                if (reverse != -1 && reverse != sourceIndex) return null;
            }
        }
        return values;
    }

    private static boolean isValidBindingEndpoint(int index, int target) {
        if (isBindableSourceIndex(index)) return isHotbarIndex(target);
        if (isHotbarIndex(index)) return isBindableSourceIndex(target);
        return false;
    }

    private void apply(Properties values) {
        Arrays.fill(locked, false);
        Arrays.fill(boundTo, -1);
        for (String key : values.stringPropertyNames()) {
            if (key.startsWith("locked.")) locked[parseIndex(key.substring(7))] = Boolean.parseBoolean(values.getProperty(key));
            if (key.startsWith("bound.")) boundTo[parseIndex(key.substring(6))] = parseIndex(values.getProperty(key));
        }
        int[] storedBindings = boundTo.clone();
        Arrays.fill(boundTo, -1);
        for (int target = 0; target < HOTBAR_SIZE; target++) {
            int sourceIndex = -1;
            for (int candidate = MAIN_INVENTORY_START; candidate < SLOT_COUNT; candidate++) {
                if (storedBindings[candidate] == target) {
                    sourceIndex = candidate;
                    break;
                }
            }
            if (sourceIndex < 0 && isBindableSourceIndex(storedBindings[target])) {
                sourceIndex = storedBindings[target];
            }
            if (sourceIndex >= 0) {
                boundTo[sourceIndex] = target;
                boundTo[target] = sourceIndex;
            }
        }
    }

    private boolean saveCurrent() {
        if (file == null) return false;
        File parent = file.getParentFile();
        if (parent != null && !parent.isDirectory() && !parent.mkdirs() && !parent.isDirectory()) return false;
        File temp = new File(file.getPath() + ".tmp");
        try (FileOutputStream stream = new FileOutputStream(temp);
             Writer writer = new OutputStreamWriter(stream, StandardCharsets.UTF_8)) {
            writer.write("# Sky VeLor slot locks and bindings");
            writer.write(System.lineSeparator());
            writer.write("version=" + VERSION);
            writer.write(System.lineSeparator());
            for (int i = 0; i < SLOT_COUNT; i++) {
                if (locked[i]) {
                    writer.write("locked." + i + "=true");
                    writer.write(System.lineSeparator());
                }
                if (boundTo[i] >= 0) {
                    writer.write("bound." + i + "=" + boundTo[i]);
                    writer.write(System.lineSeparator());
                }
            }
            writer.flush();
            stream.getFD().sync();
        } catch (IOException | SecurityException ex) {
            LOGGER.log(Level.WARNING, "Could not write slot-lock temp file " + temp, ex);
            return false;
        }
        try {
            try {
                Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException unsupported) {
                Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException | SecurityException ex) {
            LOGGER.log(Level.WARNING, "Could not replace slot-lock file " + file, ex);
            return false;
        }
    }

    private void ensureLoaded() {
        if (!loaded) load(new File(new File(System.getProperty("user.dir", "."), "config"), "skyvelor/slot-locks.properties"));
    }

    private static boolean isValidIndex(int index) {
        return index >= 0 && index < SLOT_COUNT;
    }

    private static boolean isMainInventoryIndex(int index) {
        return index >= MAIN_INVENTORY_START && index <= MAIN_INVENTORY_END;
    }

    private static boolean isBindableSourceIndex(int index) {
        return index >= MAIN_INVENTORY_START && index < SLOT_COUNT;
    }

    private static boolean isHotbarIndex(int index) {
        return index >= 0 && index < HOTBAR_SIZE;
    }

    private static int parseIndex(String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException ignored) {
            return Integer.MIN_VALUE;
        }
    }

    private void fail(String reason) {
        failed = true;
        failureReason = reason == null ? "Slot-lock storage failed." : reason;
        LOGGER.warning("[Sky VeLor] " + failureReason);
    }

    public enum ChangeResult {
        LOCKED,
        UNLOCKED,
        BOUND,
        UNBOUND,
        LOCKED_SLOT,
        INVALID_SLOT,
        INVALID_BINDING,
        STORAGE_ERROR,
        STORAGE_UNAVAILABLE
    }
}
