package dev.client.skyvelor.feature;

import dev.client.skyvelor.config.AppleSettings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ChatLine;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.util.IChatComponent;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Skytils-style chat tabs for Minecraft 1.8.9.
 *
 * The complete vanilla chatLines list remains untouched. Only drawnChatLines is rebuilt for the
 * selected tab, so switching back to All immediately restores messages received while another tab
 * was selected. This mirrors the important behaviour of Skytils' chat-tab renderer without clearing
 * chat history or maintaining a second, incomplete copy of it.
 *
 * Behaviour and channel formats are based on Skytils' open-source ChatTabs feature. This is an
 * independent Java port for Sky VeLor's Forge-only build; see the root LICENSE and notice.md for attribution and license scope.
 */
public final class ChatChannelTabs {

    private static final String[] LABELS = {"ALL", "PARTY", "GUILD", "PM", "CO-OP"};
    private static final int[] BUTTON_WIDTHS = {38, 54, 54, 34, 52};
    private static final int FIRST_BUTTON_ID = 0x5356430;
    private static final int BUTTON_H = 18;
    private static final int BUTTON_GAP = 2;

    private static final Field CHAT_LINES;
    private static final Field DRAWN_LINES;
    private static final Method SET_CHAT_LINE;

    static {
        Field chatLines = null;
        Field drawnLines = null;
        Method setChatLine = null;
        try {
            chatLines = ReflectionHelper.findField(GuiNewChat.class, "chatLines", "field_146252_h");
            drawnLines = ReflectionHelper.findField(GuiNewChat.class, "drawnChatLines", "field_146253_i");
            setChatLine = ReflectionHelper.findMethod(GuiNewChat.class, null,
                    new String[]{"setChatLine", "func_146237_a"},
                    IChatComponent.class, int.class, int.class, boolean.class);
        } catch (RuntimeException ignored) {
            // Kept null: the feature fails open rather than breaking chat on an unusual client.
        }
        CHAT_LINES = chatLines;
        DRAWN_LINES = drawnLines;
        SET_CHAT_LINE = setChatLine;
    }

    private boolean pendingRefresh;
    private final List<GuiButton> tabButtons = new ArrayList<GuiButton>();

    @SubscribeEvent
    public void onChat(ClientChatReceivedEvent event) {
        if (event.type != 2 && AppleSettings.chatFilterMode != ChatFilterRules.ALL) {
            // Vanilla adds the line after this event returns. Rebuild at the end of the tick.
            pendingRefresh = true;
        }
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !pendingRefresh) {
            return;
        }
        pendingRefresh = false;
        refreshForSelectedTab();
    }

    @SubscribeEvent
    public void onInitGui(GuiScreenEvent.InitGuiEvent.Post event) {
        if (!(event.gui instanceof GuiChat)) {
            return;
        }
        // Re-apply the animation-only profile before the first chat frame. This guarantees that
        // Chatting's copy/delete/search buttons stay absent even if its external config was changed.
        ChattingAnimationBridge.apply();
        int y = buttonY(event.gui.height);
        int x = 2;
        tabButtons.clear();
        for (int i = 0; i < LABELS.length; i++) {
            GuiButton button = new ChatTabButton(FIRST_BUTTON_ID + i,
                    x, y, BUTTON_WIDTHS[i], BUTTON_H, LABELS[i]);
            tabButtons.add(button);
            event.buttonList.add(button);
            x += BUTTON_WIDTHS[i] + BUTTON_GAP;
        }
        if (AppleSettings.chatFilterMode != ChatFilterRules.ALL) {
            refreshForSelectedTab();
        }
    }

    @SubscribeEvent
    public void onDraw(GuiScreenEvent.DrawScreenEvent.Pre event) {
        if (!(event.gui instanceof GuiChat)) {
            return;
        }
        int y = buttonY(event.gui.height);
        for (GuiButton button : tabButtons) {
            int tab = button.id - FIRST_BUTTON_ID;
            if (tab >= 0 && tab < LABELS.length) {
                button.yPosition = y;
                button.enabled = tab != AppleSettings.chatFilterMode;
            }
        }
    }

    @SubscribeEvent
    public void onButton(GuiScreenEvent.ActionPerformedEvent.Pre event) {
        if (!(event.gui instanceof GuiChat) || event.button == null) {
            return;
        }
        int tab = event.button.id - FIRST_BUTTON_ID;
        if (tab < 0 || tab >= LABELS.length) {
            return;
        }
        AppleSettings.chatFilterMode = tab;
        AppleSettings.save();
        refreshForSelectedTab();
        event.setCanceled(true);
    }

    /** Keep the tab strip directly above the chat input, matching the full-label reference layout. */
    private static int buttonY(int screenHeight) {
        return screenHeight - BUTTON_H - 16;
    }

    /**
     * Compact, texture-free chat tab matching the reference: square dark cells, subtle separators,
     * and a cyan top edge/text for the selected channel.
     */
    private static final class ChatTabButton extends GuiButton {
        ChatTabButton(int id, int x, int y, int width, int height, String label) {
            super(id, x, y, width, height, label);
        }

        @Override
        public void drawButton(Minecraft mc, int mouseX, int mouseY) {
            if (!visible) {
                return;
            }
            hovered = mouseX >= xPosition && mouseY >= yPosition
                    && mouseX < xPosition + width && mouseY < yPosition + height;
            boolean selected = !enabled;
            int background = selected ? 0xDC1C292D : hovered ? 0xDC292A30 : 0xC8141418;
            int border = selected ? 0xFF4ED8D1 : 0xA04A4A50;
            int text = selected ? 0xFF76F4ED : hovered ? 0xFFFFFFFF : 0xFFE2E2E2;

            drawRect(xPosition, yPosition, xPosition + width, yPosition + height, background);
            drawRect(xPosition, yPosition, xPosition + width, yPosition + 1, border);
            drawRect(xPosition, yPosition + height - 1, xPosition + width, yPosition + height,
                    0xB008080A);
            drawRect(xPosition + width - 1, yPosition, xPosition + width, yPosition + height,
                    0xA03A3A40);
            drawCenteredString(mc.fontRendererObj, displayString,
                    xPosition + width / 2, yPosition + (height - 8) / 2, text);
        }
    }

    /** Rebuilds only the rendered lines; vanilla's complete history remains available for other tabs. */
    private static void refreshForSelectedTab() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.ingameGUI == null || CHAT_LINES == null || DRAWN_LINES == null || SET_CHAT_LINE == null) {
            return;
        }
        GuiNewChat chat = mc.ingameGUI.getChatGUI();
        try {
            List<ChatLine> complete = new ArrayList<ChatLine>(chatLines(chat));
            drawnLines(chat).clear();
            Collections.reverse(complete);
            for (ChatLine line : complete) {
                if (line == null || line.getChatComponent() == null) {
                    continue;
                }
                IChatComponent component = line.getChatComponent();
                if (ChatFilterRules.visible(AppleSettings.chatFilterMode, component.getFormattedText())) {
                    // ID 0 is intentional: vanilla deletes matching IDs from both drawnChatLines
                    // and chatLines before drawing. Reusing a non-zero historical ID would silently
                    // erase that message from the retained full chat history when switching tabs.
                    SET_CHAT_LINE.invoke(chat, component, 0, line.getUpdatedCounter(), true);
                }
            }
            chat.resetScroll();
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            // Fail open. Chat remains usable even if another coremod changes GuiNewChat internals.
        }
    }

    @SuppressWarnings("unchecked")
    private static List<ChatLine> chatLines(GuiNewChat chat) {
        try {
            return (List<ChatLine>) CHAT_LINES.get(chat);
        } catch (IllegalAccessException e) {
            throw new IllegalStateException(e);
        }
    }

    @SuppressWarnings("unchecked")
    private static List<ChatLine> drawnLines(GuiNewChat chat) {
        try {
            return (List<ChatLine>) DRAWN_LINES.get(chat);
        } catch (IllegalAccessException e) {
            throw new IllegalStateException(e);
        }
    }
}
