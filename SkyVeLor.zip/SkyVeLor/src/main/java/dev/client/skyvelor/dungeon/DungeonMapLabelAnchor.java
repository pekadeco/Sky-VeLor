package dev.client.skyvelor.dungeon;

/** Projects a 32x32 dungeon room center from world coordinates into the live map texture. */
final class DungeonMapLabelAnchor {
    private static final float ROOM_SIZE = 32.0F;
    private static final float ROOM_CENTER = ROOM_SIZE * 0.5F;

    private DungeonMapLabelAnchor() { }

    /**
     * Projects a room center relative to a local-player marker sample.
     * Positive world X moves right on the map; positive world Z moves down.
     * The resulting texture-space anchor should be captured once per map-data instance: map-marker
     * updates arrive in quantized steps, so recomputing from live player movement every frame makes
     * a room label slide and snap even though its room tile is fixed on the map.
     */
    static boolean projectRoomCenter(int originX, int originZ, double playerWorldX, double playerWorldZ,
                                     float playerMapX, float playerMapY, float pixelsPerBlock, float[] output) {
        if (output == null || output.length < 2 || !finite(playerWorldX) || !finite(playerWorldZ)
                || !finite(playerMapX) || !finite(playerMapY) || !finite(pixelsPerBlock)
                || pixelsPerBlock <= 0.0F) {
            return false;
        }

        float roomCenterX = originX + ROOM_CENTER;
        float roomCenterZ = originZ + ROOM_CENTER;
        double mapX = playerMapX + (roomCenterX - playerWorldX) * pixelsPerBlock;
        double mapY = playerMapY + (roomCenterZ - playerWorldZ) * pixelsPerBlock;
        if (!finite(mapX) || !finite(mapY) || Math.abs(mapX) > 4096.0D || Math.abs(mapY) > 4096.0D) {
            return false;
        }
        output[0] = (float) mapX;
        output[1] = (float) mapY;
        return true;
    }

    private static boolean finite(double value) {
        return !Double.isNaN(value) && !Double.isInfinite(value);
    }
}
