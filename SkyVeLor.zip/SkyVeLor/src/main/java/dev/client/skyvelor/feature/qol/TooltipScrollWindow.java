package dev.client.skyvelor.feature.qol;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Pure windowing logic for long item tooltips. The first (item-name) line remains pinned. */
public final class TooltipScrollWindow {
    private static final int BODY_LINES = 9;

    private TooltipScrollWindow() {
    }

    public static int maxOffset(List<String> lines) {
        if (lines == null || lines.size() <= BODY_LINES + 1) return 0;
        return Math.max(0, lines.size() - BODY_LINES - 1);
    }

    public static List<String> window(List<String> source, int requestedOffset, int maxVisibleLines) {
        if (source == null || source.isEmpty() || maxVisibleLines <= 0) return Collections.emptyList();
        if (source.size() <= maxVisibleLines) return new ArrayList<String>(source);
        if (maxVisibleLines < 4) {
            return new ArrayList<String>(source.subList(0, Math.min(source.size(), maxVisibleLines)));
        }

        int bodyCapacity = Math.max(1, Math.min(BODY_LINES, maxVisibleLines - 3));
        int offset = Math.max(0, Math.min(requestedOffset, source.size() - 1 - bodyCapacity));
        int start = Math.min(source.size() - 1, 1 + offset);
        int end = Math.min(source.size(), start + bodyCapacity);

        List<String> result = new ArrayList<String>(maxVisibleLines);
        result.add(source.get(0));
        if (offset > 0) result.add("\u00a78\u2191 More above");
        for (int i = start; i < end; i++) result.add(source.get(i));
        if (end < source.size()) result.add("\u00a78\u2193 " + (source.size() - end) + " more");
        return result;
    }
}
