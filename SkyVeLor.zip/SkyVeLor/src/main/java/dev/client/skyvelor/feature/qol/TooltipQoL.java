package dev.client.skyvelor.feature.qol;

import dev.client.skyvelor.config.AppleSettings;
import dev.client.skyvelor.feature.SkyblockContext;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Mouse;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** Optional tooltip-only text conversion and a small fixed-height scrolling window for long lore. */
public final class TooltipQoL {
    private static final int MAX_VISIBLE_LINES = 12;
    private List<String> lastFullTooltip;
    private int scrollOffset;
    private boolean tooltipSeenThisFrame;

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onItemTooltip(ItemTooltipEvent event) {
        if (event == null || event.toolTip == null || event.toolTip.isEmpty()) return;
        if (AppleSettings.romanNumeralsInTooltips && SkyblockContext.isInSkyblock()) {
            for (int i = 0; i < event.toolTip.size(); i++) {
                String line = event.toolTip.get(i);
                if (line != null) event.toolTip.set(i, RomanNumeralParser.replaceInString(line));
            }
        }
        if (!AppleSettings.scrollableTooltipsEnabled) {
            lastFullTooltip = null;
            scrollOffset = 0;
            return;
        }

        tooltipSeenThisFrame = true;
        List<String> full = new ArrayList<String>(event.toolTip);
        if (!Objects.equals(full, lastFullTooltip)) {
            scrollOffset = 0;
            lastFullTooltip = full;
        }
        List<String> visible = TooltipScrollWindow.window(full, scrollOffset, MAX_VISIBLE_LINES);
        event.toolTip.clear();
        event.toolTip.addAll(visible);
    }

    @SubscribeEvent
    public void onMouseWheel(MouseEvent event) {
        if (!AppleSettings.scrollableTooltipsEnabled || lastFullTooltip == null || event == null) return;
        int wheel = Mouse.getEventDWheel();
        if (wheel == 0) return;
        int maxOffset = TooltipScrollWindow.maxOffset(lastFullTooltip);
        if (maxOffset <= 0) return;
        // Consume the wheel while a long tooltip is active so it cannot also change the hotbar selection.
        event.setCanceled(true);
        if (wheel > 0) scrollOffset = Math.max(0, scrollOffset - 1);
        else scrollOffset = Math.min(maxOffset, scrollOffset + 1);
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase == TickEvent.Phase.START) {
            tooltipSeenThisFrame = false;
        } else if (!tooltipSeenThisFrame) {
            lastFullTooltip = null;
            scrollOffset = 0;
        }
    }
}
