package dev.client.skyvelor;

/**
 * The single source of truth for the Sky VeLor version and name.
 *
 * build.gradle reads NAME from this file, so the jar name, mcmod.info, the GUI title and the
 * version label always match. Change it only when preparing a new release, never on every game
 * launch or build. Current release: Beta-0.10.6v.
 *
 * The Java package uses the Sky VeLor namespace {@code dev.client.skyvelor}. The legacy mod id
 * remains {@code pekaclient} so existing asset paths, keybinding ids and mod-specific files continue
 * to resolve without a separate migration. The displayed client name and release metadata use Sky VeLor.
 */
public final class PekaVersion {

    /** The version string shown in the GUI and written to mcmod.info. */
    public static final String NAME = "Beta-0.10.6v";

    /** The client's display name. */
    public static final String DISPLAY_NAME = "Sky VeLor";

    private PekaVersion() {
    }
}
