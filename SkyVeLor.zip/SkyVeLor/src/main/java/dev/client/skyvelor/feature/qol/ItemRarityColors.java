package dev.client.skyvelor.feature.qol;

import java.util.List;
import java.util.Locale;

/** Deterministic rarity palette and static 16x16 slot-gradient opacity. */
public final class ItemRarityColors {
    private ItemRarityColors() {
    }

    public static int colorForLoreLines(List<String> lore) {
        if (lore == null || lore.isEmpty()) return 0;
        // The item's actual rarity is normally near the bottom of SkyBlock lore.
        // Check from the bottom and accept the rarity anywhere in the line.
        for (int i = lore.size() - 1; i >= 0; i--) {
            String rarity = findRarity(lore.get(i));
            if (rarity != null) return colorForRarity(rarity);
        }
        return 0;
    }

    /**
     * Detects rarity words in any part of the display name or lore. This intentionally ignores
     * whitespace, punctuation and Minecraft formatting codes so upgraded/recombobulated items
     * are not missed merely because their rarity text is decorated or embedded in a longer line.
     */
    public static int colorForItem(String displayName, List<String> lore) {
        int loreColor = colorForLoreLines(lore);
        if (loreColor != 0) return loreColor;
        String rarity = findRarity(displayName);
        return rarity == null ? 0 : colorForRarity(rarity);
    }

    private static String findRarity(String text) {
        if (text == null || text.isEmpty()) return null;
        String normalized = normalizeLine(text);
        StringBuilder compact = new StringBuilder(normalized.length());
        for (int i = 0; i < normalized.length(); i++) {
            char c = normalized.charAt(i);
            if (c >= 'A' && c <= 'Z') compact.append(c);
        }
        String value = compact.toString();
        String[] rarities = {"VERYSPECIAL", "UNCOMMON", "LEGENDARY", "SUPREME", "DIVINE",
                "MYTHIC", "EPIC", "RARE", "COMMON", "SPECIAL"};
        for (String rarity : rarities) {
            if (value.contains(rarity)) return rarity.equals("VERYSPECIAL") ? "VERY SPECIAL" : rarity;
        }
        return null;
    }

    private static int colorForRarity(String rarity) {
        switch (rarity) {
            case "COMMON": return 0xFFAAAAAA;
            case "UNCOMMON": return 0xFF55FF55;
            case "RARE": return 0xFF5555FF;
            case "EPIC": return 0xFFAA00AA;
            case "LEGENDARY": return 0xFFFFAA00;
            case "MYTHIC": return 0xFFFF55FF;
            case "DIVINE": return 0xFF55FFFF;
            case "SUPREME": return 0xFFAA0000;
            case "SPECIAL": return 0xFFFF5555;
            case "VERY SPECIAL": return 0xFFFF5555;
            default: return 0;
        }
    }

    private static String normalizeLine(String line) {
        return InventorySearchMatcher.normalize(line).toUpperCase(Locale.ROOT).trim();
    }

    /**
     * Returns a fixed opacity for one row of the 16x16 slot background.
     * The tint is almost transparent at the top and strongest in the lower-middle;
     * no time value is used, so the shape never animates.
     */
    public static int highlightAlphaForRow(int row) {
        if (row < 0 || row >= 16) return 0;
        float position = row / 15.0F;
        float lowerGradient = position * position;
        float distance = Math.abs(row - 11.0F);
        float lowerMiddlePlume = Math.max(0.0F, 1.0F - distance / 5.5F);
        // A more visible fixed tint: roughly 4% opacity at the top and about 43% at its peak.
        float opacity = 0.04F + lowerGradient * 0.16F + lowerMiddlePlume * 0.30F;
        return Math.min(120, Math.max(0, Math.round(opacity * 255.0F)));
    }

}
