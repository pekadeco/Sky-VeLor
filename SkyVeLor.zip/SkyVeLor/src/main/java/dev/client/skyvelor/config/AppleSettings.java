package dev.client.skyvelor.config;

import dev.client.skyvelor.dungeon.M7Settings;
import dev.client.skyvelor.hud.HudPlacement;
import net.minecraft.client.Minecraft;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

/**
 * Sky VeLor client settings, saved to .minecraft/skyvelor.properties.
 *
 * Older builds used pekaclient.properties. That file is read once when the new file does not exist yet
 * (see {@link ConfigFiles}), and it is never written again.
 * Plain static fields keep reads allocation-free on the render path.
 */
public final class AppleSettings {

    private static final Logger LOG = LogManager.getLogger("SkyVeLor");
    public static final String FILE_NAME = "skyvelor.properties";
    public static final String LEGACY_FILE_NAME = "pekaclient.properties";

    public static final String[] ACCENT_NAMES = {"Blue", "Purple", "Pink", "Green", "Orange", "Teal"};
    public static final int[] ACCENT_COLORS = {
            0xFF0A84FF, 0xFFBF5AF2, 0xFFFF375F, 0xFF30D158, 0xFFFF9F0A, 0xFF64D2FF
    };
    public static final String[] CURVE_NAMES = {"Smooth", "Balanced", "Fast"};
    /** Arc subdivisions per 90 degrees for each curve quality. */
    public static final int[] CURVE_SEGMENTS = {8, 4, 2};

    public static int accent = 0;
    public static boolean darkMode = true;
    public static int cornerRadius = 12;      // 4..18
    /** Switches for the global sliders. Off uses the default value below. */
    public static boolean cornerRadiusOn = true;
    public static boolean glassOpacityOn = true;
    public static boolean animSpeedOn = true;
    public static boolean scrollSpeedOn = true;
    public static final int DEFAULT_CORNER_RADIUS = 12;
    /** A slightly more transparent fresh-install panel setting; saved user values are not reset. */
    public static final int DEFAULT_GLASS_OPACITY = 88;
    public static final int DEFAULT_ANIM_SPEED = 100;
    public static final boolean DEFAULT_ADAPTIVE_QUALITY = false;
    public static final boolean DEFAULT_PERFORMANCE_BOOST_BETA = true;
    public static final int DEFAULT_SCROLL_SPEED = 100;

    /** Corner radius in use: the slider value when its switch is on, otherwise the default. */
    public static int effectiveCornerRadius() {
        return cornerRadiusOn ? cornerRadius : DEFAULT_CORNER_RADIUS;
    }

    public static int effectiveGlassOpacity() {
        return glassOpacityOn ? glassOpacity : DEFAULT_GLASS_OPACITY;
    }

    public static int effectiveAnimSpeed() {
        return animSpeedOn ? animSpeed : DEFAULT_ANIM_SPEED;
    }

    public static int effectiveScrollSpeed() {
        return scrollSpeedOn ? scrollSpeed : DEFAULT_SCROLL_SPEED;
    }
    /** Panel opacity in percent (60..100). Higher is more solid, lower shows more of the game. */
    public static int glassOpacity = DEFAULT_GLASS_OPACITY;
    public static boolean animations = true;
    public static int animSpeed = 100;        // 40..200 (%)
    public static int curveQuality = 1;       // 0 smooth, 1 balanced, 2 fast
    public static boolean shadows = true;
    public static boolean adaptive = DEFAULT_ADAPTIVE_QUALITY; // auto-lower detail when FPS drops
    public static int scrollSpeed = 100;      // 50..300 (%), wheel and swipe speed (keys are fixed)
    /** Dungeon tab: replace the server's Spirit Leap menu with the teammate selector. On by default. */
    public static boolean leapMenu = true;
    /** Dungeon tab: optional outline of mobs carrying a level tag or elite-star marker. */
    public static boolean mobHighlights = false;
    /** Highlights recognized blood-room minibosses on Fakepixel. Disabled by default. */
    public static boolean bloodMobHighlight = false;
    public static String bloodMobHighlightColor = "0:255:0:255:0";
    /** Displays the live server dungeon map in the HUD. */
    public static boolean dungeonMap = true;
    /** Rotates the dungeon map around the local player marker, like Better NEF. */
    public static boolean dungeonMapRotate = true;
    /** Displays resolved usernames beside their map markers without a key hold. */
    public static boolean dungeonMapShowPlayerNames = true;
    /** Detects and centers the matched puzzle-room label on its purple map tile. */
    public static boolean dungeonMapShowPuzzleName = true;
    public static final int DUNGEON_MAP_SCALE_MIN = 70;
    public static final int DUNGEON_MAP_SCALE_MAX = 250;
    /** HUD widget size as a percentage of the native 128-pixel map. */
    public static int dungeonMapScale = 100;
    /** Matches the common HUD "Use scale" switch. Disabled means the native 100% widget size. */
    public static boolean dungeonMapScaleOn = true;
    public static final int DUNGEON_MAP_ZOOM_MIN = 50;
    public static final int DUNGEON_MAP_ZOOM_MAX = 200;
    /** Contents zoom, separate from the on-screen widget size. 100% keeps the previous behavior. */
    public static int dungeonMapZoom = 100;
    /** Legacy horizontal percentage used only when migrating older settings files. */
    public static int dungeonMapXPercent = 2;
    /** Legacy vertical percentage used only when migrating older settings files. */
    public static int dungeonMapYPercent = 2;
    /**
     * The map shares the HUD editor's anchored positioning model, but remains intentionally unclamped
     * so it can be placed partly or completely beyond the viewport. Percent values above are retained
     * only to migrate older configuration files.
     */
    public static final HudPlacement dungeonMapPlacement = new HudPlacement(
            HudPlacement.Anchor.START, 12, HudPlacement.Anchor.START, 12);
    private static boolean dungeonMapPlacementInitialized = true;
    /**
     * Performance Boost Beta. Enabled on a fresh install. Selects lower-cost Sky VeLor GUI/HUD work:
     * fewer curve segments and no shadows in the hub and editor, slower HUD scans, and cached HUD text.
     * It never touches entity rendering, world rendering or JVM flags.
     */
    public static boolean experimentalPerformance = DEFAULT_PERFORMANCE_BOOST_BETA;
    public static boolean slayerTracker = true;        // track Slayer drops from chat
    public static boolean slayerBossTimer = true;      // boss spawn to quest complete timer
    public static boolean slayerPricing = true;        // profit and /setprice
    public static boolean svCommand = true;            // /sv opens the hub
    public static boolean qnCommand = true;            // /qn opens quick notes
    public static boolean leapKey = true;              // Spirit Leap key works when bound
    public static boolean fishingCounter = true;       // count legendary catches
    public static boolean fishingFestival = true;      // Festival Great White count and best
    public static boolean fishingJawbusAlert = true;   // title when Lord Jawbus arrives
    /** Protect uniquely identified SkyBlock items against accidental drops and risky menu actions. */
    public static boolean itemProtectionEnabled = true;
    /** Show chat notifications when item protection blocks an action or cannot save its data. */
    public static boolean itemProtectionNotifications = true;
    /** Slot locking is opt-in so existing inventory behavior never changes on a fresh install. */
    public static boolean slotLockingEnabled = false;
    /** Optional quick-swap bindings from main inventory slots to hotbar slots. */
    public static boolean slotBindingEnabled = true;
    /** Show chat notifications when a locked slot prevents an inventory action. */
    public static boolean slotLockNotifications = true;
    /** Opt-in search overlay for player inventory and container screens. */
    public static boolean inventorySearchEnabled = false;
    /** Hide the potion-effect panel only while the player inventory screen is open. */
    public static boolean hideInventoryPotionEffects = false;
    /** Automatically sprint while moving forward when vanilla sprint conditions permit it. */
    public static boolean autoSprintEnabled = false;
    /** Convert clear Roman-numeral level tokens in item tooltips. */
    public static boolean romanNumeralsInTooltips = false;
    /** Allow scrolling through long item tooltip lore with the mouse wheel. */
    public static boolean scrollableTooltipsEnabled = true;
    /** Draw a static rarity-colored 16x16 slot tint, strongest near the lower-middle and faded toward the top. */
    public static boolean itemRarityBordersEnabled = false;
    /** Shift + left-click a visible chat line to copy it; Ctrl also includes formatting codes. */
    public static boolean chatCopyEnabled = true;
    /** Chat tab selected on open: 0 All, 1 Party, 2 Guild, 3 PM, 4 Co-op. */
    public static int chatFilterMode = 0;
    /** Optional Chatting 2.0.6 animation bridge; no third-party runtime is bundled. */
    public static boolean chatMessageAnimation = true;
    public static int chatMessageSpeed = 50;
    public static boolean chatBackgroundAnimation = true;
    public static int chatBackgroundDuration = 400;
    public static boolean chatScrollAnimation = true;
    public static int chatScrollDuration = 150;
    public static boolean chatRemoveScrollBar = true;
    /** Disable the vanilla camera roll/shake when the player takes damage. Mirrors Better NEF's QoL option. */
    public static boolean noHurtCamEnabled = true;
    /** Hide block-hit and block-destroy particles. Disabled by default to preserve vanilla visuals. */
    public static boolean hideBlockBreakingParticles = false;
    /** Optional /wardrobe shortcut, limited to servers whose address contains fakepixel. */
    public static boolean wardrobeShortcutEnabled = false;
    /** Optional /pets shortcut, limited to servers whose address contains fakepixel. */
    public static boolean petsShortcutEnabled = false;
    /** Mining ability readiness notifications are opt-in and are tracked only on Fakepixel. */
    public static boolean miningAbilityNotifier = false;
    /** Optional Dwarven Mines Puzzler direction solver, limited to Fakepixel. */
    public static boolean miningPuzzlerSolver = false;

    // Dungeon puzzle and terminal helpers adapted from NotEnoughFakepixel-origin code (see LICENSE).
    public static boolean solverThreeWeirdos = true;
    public static boolean solverCreeper = true;
    public static boolean solverBoulder = true;
    public static boolean solverSilverfish = true;
    public static boolean solverWater = true;
    public static boolean solverTeleportMaze = true;

    public static boolean terminalTracker = true;
    public static float terminalTrackerScale = 1.0f;
    public static String terminalTrackerColor = "0:255:0:100:255";
    public static int terminalTrackerX = 10;
    public static int terminalTrackerY = 10;
    public static boolean terminalCustomClickIn = true;
    public static boolean terminalCustomColors = true;
    public static boolean terminalCustomMaze = true;
    public static boolean terminalCustomStartsWith = true;
    public static boolean terminalCustomPanes = true;
    public static float terminalGuiScale = 3.0f;
    public static boolean terminalStartsWithSolver = true;
    public static boolean terminalColorsSolver = true;
    public static boolean terminalClickInOrderSolver = true;
    public static boolean terminalMazeSolver = true;
    public static boolean terminalCorrectPanesSolver = true;
    public static boolean terminalHideIncorrect = true;
    public static boolean terminalPreventMissclicks = true;
    public static boolean terminalHideTooltips = true;
    public static boolean solverFirstDevice = true;
    public static boolean solverThirdDevice = true;
    public static String solverCorrectColor = "0:255:0:255:0";
    public static String solverAlternativeColor = "0:255:255:255:0";
    public static boolean terminalWaypoints = true;

    private AppleSettings() {
    }

    public static int accentColor() {
        return ACCENT_COLORS[Math.max(0, Math.min(ACCENT_COLORS.length - 1, accent))];
    }

    public static void load() {
        Properties p = ConfigFiles.read(readFile());
        accent = readInt(p, "accent", accent, 0, ACCENT_COLORS.length - 1);
        darkMode = readBool(p, "darkMode", darkMode);
        cornerRadius = readInt(p, "cornerRadius", cornerRadius, 4, 18);
        cornerRadiusOn = readBool(p, "cornerRadiusOn", cornerRadiusOn);
        glassOpacityOn = readBool(p, "glassOpacityOn", glassOpacityOn);
        animSpeedOn = readBool(p, "animSpeedOn", animSpeedOn);
        scrollSpeedOn = readBool(p, "scrollSpeedOn", scrollSpeedOn);
        glassOpacity = readInt(p, "glassOpacity", glassOpacity, 60, 100);
        animations = readBool(p, "animations", animations);
        animSpeed = readInt(p, "animSpeed", animSpeed, 40, 200);
        curveQuality = readInt(p, "curveQuality", curveQuality, 0, 2);
        shadows = readBool(p, "shadows", shadows);
        loadPerformanceSettings(p);
        scrollSpeed = readInt(p, "scrollSpeed", scrollSpeed, 50, 300);
        leapMenu = readBool(p, "leapMenu", leapMenu);
        mobHighlights = readBool(p, "mobHighlights", mobHighlights);
        bloodMobHighlight = readBool(p, "dungeon.bloodMobHighlight", bloodMobHighlight);
        bloodMobHighlightColor = readColor(p.getProperty("dungeon.bloodMobHighlightColor"), bloodMobHighlightColor);
        dungeonMap = readBool(p, "dungeonMap", dungeonMap);
        dungeonMapRotate = readBool(p, "dungeonMapRotate", dungeonMapRotate);
        dungeonMapShowPlayerNames = readBool(p, "dungeonMapShowPlayerNames", dungeonMapShowPlayerNames);
        dungeonMapShowPuzzleName = readBool(p, "dungeonMapShowPuzzleName", dungeonMapShowPuzzleName);
        dungeonMapScale = readInt(p, "dungeonMapScale", dungeonMapScale, DUNGEON_MAP_SCALE_MIN, DUNGEON_MAP_SCALE_MAX);
        dungeonMapScaleOn = readBool(p, "dungeonMapScaleOn", dungeonMapScaleOn);
        dungeonMapZoom = readInt(p, "dungeonMapZoom", dungeonMapZoom, DUNGEON_MAP_ZOOM_MIN, DUNGEON_MAP_ZOOM_MAX);
        dungeonMapXPercent = readInt(p, "dungeonMapXPercent", dungeonMapXPercent, 0, 100);
        dungeonMapYPercent = readInt(p, "dungeonMapYPercent", dungeonMapYPercent, 0, 100);
        if (p.containsKey("dungeonMapAx") && p.containsKey("dungeonMapOx")
                && p.containsKey("dungeonMapAy") && p.containsKey("dungeonMapOy")) {
            dungeonMapPlacement.reset(
                    readAnchor(p, "dungeonMapAx", HudPlacement.Anchor.START),
                    readInt(p, "dungeonMapOx", 12, -HudPlacement.MAX_OFFSET, HudPlacement.MAX_OFFSET),
                    readAnchor(p, "dungeonMapAy", HudPlacement.Anchor.START),
                    readInt(p, "dungeonMapOy", 12, -HudPlacement.MAX_OFFSET, HudPlacement.MAX_OFFSET));
            dungeonMapPlacementInitialized = true;
        } else {
            // Old versions stored a percent of the free screen width/height. Convert lazily when
            // the current scaled viewport and map size are known, so loading settings never needs GL.
            dungeonMapPlacement.reset(HudPlacement.Anchor.START, 12, HudPlacement.Anchor.START, 12);
            dungeonMapPlacementInitialized = false;
        }
        leapKey = readBool(p, "leapKey", leapKey);
        svCommand = readBool(p, "cmd.sv", svCommand);
        slayerTracker = readBool(p, "slayer.tracker", slayerTracker);
        slayerBossTimer = readBool(p, "slayer.bossTimer", slayerBossTimer);
        slayerPricing = readBool(p, "slayer.pricing", slayerPricing);
        qnCommand = readBool(p, "cmd.qn", qnCommand);
        fishingCounter = readBool(p, "fishing.counter", fishingCounter);
        fishingFestival = readBool(p, "fishing.festival", fishingFestival);
        fishingJawbusAlert = readBool(p, "fishing.jawbusAlert", fishingJawbusAlert);
        itemProtectionEnabled = readBool(p, "itemProtection.enabled", itemProtectionEnabled);
        itemProtectionNotifications = readBool(p, "itemProtection.notifications", itemProtectionNotifications);
        slotLockingEnabled = readBool(p, "slotLocking.enabled", slotLockingEnabled);
        slotBindingEnabled = readBool(p, "slotLocking.binding", slotBindingEnabled);
        slotLockNotifications = readBool(p, "slotLocking.notifications", slotLockNotifications);
        inventorySearchEnabled = readBool(p, "qol.inventorySearch", inventorySearchEnabled);
        hideInventoryPotionEffects = readBool(p, "qol.hideInventoryPotionEffects", hideInventoryPotionEffects);
        autoSprintEnabled = readBool(p, "movement.autoSprint", autoSprintEnabled);
        romanNumeralsInTooltips = readBool(p, "qol.romanNumerals", romanNumeralsInTooltips);
        scrollableTooltipsEnabled = readBool(p, "qol.scrollableTooltips", scrollableTooltipsEnabled);
        itemRarityBordersEnabled = readBool(p, "qol.itemRarityBorders", itemRarityBordersEnabled);
        chatCopyEnabled = readBool(p, "qol.chatCopy", chatCopyEnabled);
        chatFilterMode = readChatTabMode(p);
        chatMessageAnimation = readBool(p, "chat.animation.messages", chatMessageAnimation);
        chatMessageSpeed = readInt(p, "chat.animation.messageSpeed", chatMessageSpeed, 0, 100);
        chatBackgroundAnimation = readBool(p, "chat.animation.background", chatBackgroundAnimation);
        chatBackgroundDuration = readInt(p, "chat.animation.backgroundDuration", chatBackgroundDuration, 50, 1000);
        chatScrollAnimation = readBool(p, "chat.animation.scrolling", chatScrollAnimation);
        chatScrollDuration = readInt(p, "chat.animation.scrollDuration", chatScrollDuration, 0, 1000);
        chatRemoveScrollBar = readBool(p, "chat.animation.removeScrollBar", chatRemoveScrollBar);
        noHurtCamEnabled = readBool(p, "qol.noHurtCam", noHurtCamEnabled);
        hideBlockBreakingParticles = readBool(p, "qol.hideBlockBreakingParticles", hideBlockBreakingParticles);
        wardrobeShortcutEnabled = readBool(p, "qol.wardrobeShortcut", wardrobeShortcutEnabled);
        petsShortcutEnabled = readBool(p, "qol.petsShortcut", petsShortcutEnabled);
        miningAbilityNotifier = readBool(p, "mining.abilityNotifier", miningAbilityNotifier);
        miningPuzzlerSolver = readBool(p, "mining.puzzlerSolver", miningPuzzlerSolver);

        solverThreeWeirdos = readBool(p, "dungeon.solver.threeWeirdos", solverThreeWeirdos);
        solverCreeper = readBool(p, "dungeon.solver.creeper", solverCreeper);
        solverBoulder = readBool(p, "dungeon.solver.boulder", solverBoulder);
        solverSilverfish = readBool(p, "dungeon.solver.silverfish", solverSilverfish);
        solverWater = readBool(p, "dungeon.solver.water", solverWater);
        solverTeleportMaze = readBool(p, "dungeon.solver.teleportMaze", solverTeleportMaze);
        terminalTracker = readBool(p, "dungeon.terminal.tracker", terminalTracker);
        terminalTrackerScale = readFloat(p, "dungeon.terminal.trackerScale", terminalTrackerScale, 0.5f, 3.0f);
        terminalTrackerColor = readColor(p.getProperty("dungeon.terminal.trackerColor"), terminalTrackerColor);
        terminalTrackerX = readInt(p, "dungeon.terminal.trackerX", terminalTrackerX, -1000, 4000);
        terminalTrackerY = readInt(p, "dungeon.terminal.trackerY", terminalTrackerY, -1000, 4000);
        terminalCustomClickIn = readBool(p, "dungeon.terminal.customClickIn", terminalCustomClickIn);
        terminalCustomColors = readBool(p, "dungeon.terminal.customColors", terminalCustomColors);
        terminalCustomMaze = readBool(p, "dungeon.terminal.customMaze", terminalCustomMaze);
        terminalCustomStartsWith = readBool(p, "dungeon.terminal.customStartsWith", terminalCustomStartsWith);
        terminalCustomPanes = readBool(p, "dungeon.terminal.customPanes", terminalCustomPanes);
        terminalGuiScale = readFloat(p, "dungeon.terminal.guiScale", terminalGuiScale, 1.0f, 5.0f);
        terminalStartsWithSolver = readBool(p, "dungeon.terminal.startsWith", terminalStartsWithSolver);
        terminalColorsSolver = readBool(p, "dungeon.terminal.colors", terminalColorsSolver);
        terminalClickInOrderSolver = readBool(p, "dungeon.terminal.clickInOrder", terminalClickInOrderSolver);
        terminalMazeSolver = readBool(p, "dungeon.terminal.maze", terminalMazeSolver);
        terminalCorrectPanesSolver = readBool(p, "dungeon.terminal.correctPanes", terminalCorrectPanesSolver);
        terminalHideIncorrect = readBool(p, "dungeon.terminal.hideIncorrect", terminalHideIncorrect);
        terminalPreventMissclicks = readBool(p, "dungeon.terminal.preventMissclicks", terminalPreventMissclicks);
        terminalHideTooltips = readBool(p, "dungeon.terminal.hideTooltips", terminalHideTooltips);
        solverFirstDevice = readBool(p, "dungeon.device.first", solverFirstDevice);
        solverThirdDevice = readBool(p, "dungeon.device.third", solverThirdDevice);
        solverCorrectColor = readColor(p.getProperty("dungeon.solver.correctColor"), solverCorrectColor);
        solverAlternativeColor = readColor(p.getProperty("dungeon.solver.alternativeColor"), solverAlternativeColor);
        terminalWaypoints = readBool(p, "dungeon.terminal.waypoints", terminalWaypoints);
        M7Settings.load(p);
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("accent", Integer.toString(accent));
        p.setProperty("darkMode", Boolean.toString(darkMode));
        p.setProperty("cornerRadius", Integer.toString(cornerRadius));
        p.setProperty("cornerRadiusOn", Boolean.toString(cornerRadiusOn));
        p.setProperty("glassOpacityOn", Boolean.toString(glassOpacityOn));
        p.setProperty("animSpeedOn", Boolean.toString(animSpeedOn));
        p.setProperty("scrollSpeedOn", Boolean.toString(scrollSpeedOn));
        p.setProperty("glassOpacity", Integer.toString(glassOpacity));
        p.setProperty("animations", Boolean.toString(animations));
        p.setProperty("animSpeed", Integer.toString(animSpeed));
        p.setProperty("curveQuality", Integer.toString(curveQuality));
        p.setProperty("shadows", Boolean.toString(shadows));
        p.setProperty("adaptive", Boolean.toString(adaptive));
        p.setProperty("scrollSpeed", Integer.toString(scrollSpeed));
        p.setProperty("leapMenu", Boolean.toString(leapMenu));
        p.setProperty("mobHighlights", Boolean.toString(mobHighlights));
        p.setProperty("dungeon.bloodMobHighlight", Boolean.toString(bloodMobHighlight));
        p.setProperty("dungeon.bloodMobHighlightColor", bloodMobHighlightColor);
        p.setProperty("dungeonMap", Boolean.toString(dungeonMap));
        p.setProperty("dungeonMapRotate", Boolean.toString(dungeonMapRotate));
        p.setProperty("dungeonMapShowPlayerNames", Boolean.toString(dungeonMapShowPlayerNames));
        p.setProperty("dungeonMapShowPuzzleName", Boolean.toString(dungeonMapShowPuzzleName));
        p.setProperty("dungeonMapScale", Integer.toString(dungeonMapScale));
        p.setProperty("dungeonMapScaleOn", Boolean.toString(dungeonMapScaleOn));
        p.setProperty("dungeonMapZoom", Integer.toString(dungeonMapZoom));
        p.setProperty("dungeonMapXPercent", Integer.toString(dungeonMapXPercent));
        p.setProperty("dungeonMapYPercent", Integer.toString(dungeonMapYPercent));
        if (dungeonMapPlacementInitialized) {
            p.setProperty("dungeonMapAx", dungeonMapPlacement.anchorX.name());
            p.setProperty("dungeonMapOx", Integer.toString(dungeonMapPlacement.offsetX));
            p.setProperty("dungeonMapAy", dungeonMapPlacement.anchorY.name());
            p.setProperty("dungeonMapOy", Integer.toString(dungeonMapPlacement.offsetY));
        }
        p.setProperty("experimentalPerformance", Boolean.toString(experimentalPerformance));
        p.setProperty("leapKey", Boolean.toString(leapKey));
        p.setProperty("cmd.sv", Boolean.toString(svCommand));
        p.setProperty("slayer.tracker", Boolean.toString(slayerTracker));
        p.setProperty("slayer.bossTimer", Boolean.toString(slayerBossTimer));
        p.setProperty("slayer.pricing", Boolean.toString(slayerPricing));
        p.setProperty("cmd.qn", Boolean.toString(qnCommand));
        p.setProperty("fishing.counter", Boolean.toString(fishingCounter));
        p.setProperty("fishing.festival", Boolean.toString(fishingFestival));
        p.setProperty("fishing.jawbusAlert", Boolean.toString(fishingJawbusAlert));
        p.setProperty("itemProtection.enabled", Boolean.toString(itemProtectionEnabled));
        p.setProperty("itemProtection.notifications", Boolean.toString(itemProtectionNotifications));
        p.setProperty("slotLocking.enabled", Boolean.toString(slotLockingEnabled));
        p.setProperty("slotLocking.binding", Boolean.toString(slotBindingEnabled));
        p.setProperty("slotLocking.notifications", Boolean.toString(slotLockNotifications));
        p.setProperty("qol.inventorySearch", Boolean.toString(inventorySearchEnabled));
        p.setProperty("qol.hideInventoryPotionEffects", Boolean.toString(hideInventoryPotionEffects));
        p.setProperty("movement.autoSprint", Boolean.toString(autoSprintEnabled));
        p.setProperty("qol.romanNumerals", Boolean.toString(romanNumeralsInTooltips));
        p.setProperty("qol.scrollableTooltips", Boolean.toString(scrollableTooltipsEnabled));
        p.setProperty("qol.itemRarityBorders", Boolean.toString(itemRarityBordersEnabled));
        p.setProperty("qol.chatCopy", Boolean.toString(chatCopyEnabled));
        p.setProperty("chat.tabMode", Integer.toString(chatFilterMode));
        p.setProperty("chat.animation.messages", Boolean.toString(chatMessageAnimation));
        p.setProperty("chat.animation.messageSpeed", Integer.toString(chatMessageSpeed));
        p.setProperty("chat.animation.background", Boolean.toString(chatBackgroundAnimation));
        p.setProperty("chat.animation.backgroundDuration", Integer.toString(chatBackgroundDuration));
        p.setProperty("chat.animation.scrolling", Boolean.toString(chatScrollAnimation));
        p.setProperty("chat.animation.scrollDuration", Integer.toString(chatScrollDuration));
        p.setProperty("chat.animation.removeScrollBar", Boolean.toString(chatRemoveScrollBar));
        p.setProperty("qol.noHurtCam", Boolean.toString(noHurtCamEnabled));
        p.setProperty("qol.hideBlockBreakingParticles", Boolean.toString(hideBlockBreakingParticles));
        p.setProperty("qol.wardrobeShortcut", Boolean.toString(wardrobeShortcutEnabled));
        p.setProperty("qol.petsShortcut", Boolean.toString(petsShortcutEnabled));
        p.setProperty("mining.abilityNotifier", Boolean.toString(miningAbilityNotifier));
        p.setProperty("mining.puzzlerSolver", Boolean.toString(miningPuzzlerSolver));

        p.setProperty("dungeon.solver.threeWeirdos", Boolean.toString(solverThreeWeirdos));
        p.setProperty("dungeon.solver.creeper", Boolean.toString(solverCreeper));
        p.setProperty("dungeon.solver.boulder", Boolean.toString(solverBoulder));
        p.setProperty("dungeon.solver.silverfish", Boolean.toString(solverSilverfish));
        p.setProperty("dungeon.solver.water", Boolean.toString(solverWater));
        p.setProperty("dungeon.solver.teleportMaze", Boolean.toString(solverTeleportMaze));
        p.setProperty("dungeon.terminal.tracker", Boolean.toString(terminalTracker));
        p.setProperty("dungeon.terminal.trackerScale", Float.toString(terminalTrackerScale));
        p.setProperty("dungeon.terminal.trackerColor", terminalTrackerColor);
        p.setProperty("dungeon.terminal.trackerX", Integer.toString(terminalTrackerX));
        p.setProperty("dungeon.terminal.trackerY", Integer.toString(terminalTrackerY));
        p.setProperty("dungeon.terminal.customClickIn", Boolean.toString(terminalCustomClickIn));
        p.setProperty("dungeon.terminal.customColors", Boolean.toString(terminalCustomColors));
        p.setProperty("dungeon.terminal.customMaze", Boolean.toString(terminalCustomMaze));
        p.setProperty("dungeon.terminal.customStartsWith", Boolean.toString(terminalCustomStartsWith));
        p.setProperty("dungeon.terminal.customPanes", Boolean.toString(terminalCustomPanes));
        p.setProperty("dungeon.terminal.guiScale", Float.toString(terminalGuiScale));
        p.setProperty("dungeon.terminal.startsWith", Boolean.toString(terminalStartsWithSolver));
        p.setProperty("dungeon.terminal.colors", Boolean.toString(terminalColorsSolver));
        p.setProperty("dungeon.terminal.clickInOrder", Boolean.toString(terminalClickInOrderSolver));
        p.setProperty("dungeon.terminal.maze", Boolean.toString(terminalMazeSolver));
        p.setProperty("dungeon.terminal.correctPanes", Boolean.toString(terminalCorrectPanesSolver));
        p.setProperty("dungeon.terminal.hideIncorrect", Boolean.toString(terminalHideIncorrect));
        p.setProperty("dungeon.terminal.preventMissclicks", Boolean.toString(terminalPreventMissclicks));
        p.setProperty("dungeon.terminal.hideTooltips", Boolean.toString(terminalHideTooltips));
        p.setProperty("dungeon.device.first", Boolean.toString(solverFirstDevice));
        p.setProperty("dungeon.device.third", Boolean.toString(solverThirdDevice));
        p.setProperty("dungeon.solver.correctColor", solverCorrectColor);
        p.setProperty("dungeon.solver.alternativeColor", solverAlternativeColor);
        p.setProperty("dungeon.terminal.waypoints", Boolean.toString(terminalWaypoints));
        M7Settings.save(p);
        ConfigFiles.writeAtomic(new File(dir(), FILE_NAME), p, "Sky VeLor settings");
    }

    /** Scale value in use, matching the common HUD element scale toggle. */
    public static int effectiveDungeonMapScale() {
        return dungeonMapScaleOn ? Math.max(DUNGEON_MAP_SCALE_MIN,
                Math.min(DUNGEON_MAP_SCALE_MAX, dungeonMapScale)) : 100;
    }

    /** Content magnification, independent from the map's HUD widget size. */
    public static int effectiveDungeonMapZoom() {
        return Math.max(DUNGEON_MAP_ZOOM_MIN, Math.min(DUNGEON_MAP_ZOOM_MAX, dungeonMapZoom));
    }

    public static float dungeonMapZoomFactor() {
        return effectiveDungeonMapZoom() / 100.0F;
    }

    /** Scale factor shared by the live overlay and the HUD editor. */
    public static float dungeonMapScaleFactor(int screenW, int screenH) {
        float requested = effectiveDungeonMapScale() / 100.0F;
        float fit = Math.min(screenW, screenH) / 128.0F;
        return Math.min(requested, Math.max(0.10F, fit));
    }

    /** Effective square size in scaled GUI pixels, shared by the live overlay and HUD editor. */
    public static int dungeonMapPixelSize(int screenW, int screenH) {
        return Math.max(1, Math.round(128.0F * dungeonMapScaleFactor(screenW, screenH)));
    }

    /** Resolves legacy percentage coordinates once the viewport dimensions are known. */
    public static void ensureDungeonMapPlacement(int screenW, int screenH, int size) {
        if (dungeonMapPlacementInitialized) return;
        int maxX = Math.max(0, screenW - size);
        int maxY = Math.max(0, screenH - size);
        int x = Math.round(maxX * clampPercent(dungeonMapXPercent) / 100.0F);
        int y = Math.round(maxY * clampPercent(dungeonMapYPercent) / 100.0F);
        dungeonMapPlacement.reset(HudPlacement.Anchor.START, x, HudPlacement.Anchor.START, y);
        dungeonMapPlacementInitialized = true;
    }

    public static int dungeonMapLeft(int screenW, int screenH, int size) {
        ensureDungeonMapPlacement(screenW, screenH, size);
        return dungeonMapPlacement.leftUnclamped(screenW, size);
    }

    public static int dungeonMapTop(int screenW, int screenH, int size) {
        ensureDungeonMapPlacement(screenW, screenH, size);
        return dungeonMapPlacement.topUnclamped(screenH, size);
    }

    public static int setDungeonMapPosition(int screenW, int screenH, int size,
                                            int left, int top, boolean snap, int threshold) {
        ensureDungeonMapPlacement(screenW, screenH, size);
        int guides = dungeonMapPlacement.setFromAbsoluteUnclamped(
                screenW, screenH, size, size, left, top, snap, threshold);
        dungeonMapPlacementInitialized = true;
        return guides;
    }

    public static int setDungeonMapLeft(int screenW, int screenH, int size,
                                        int left, boolean snap, int threshold) {
        ensureDungeonMapPlacement(screenW, screenH, size);
        int guides = dungeonMapPlacement.setLeftFromAbsoluteUnclamped(screenW, size, left, snap, threshold);
        dungeonMapPlacementInitialized = true;
        return guides;
    }

    public static int setDungeonMapTop(int screenW, int screenH, int size,
                                       int top, boolean snap, int threshold) {
        ensureDungeonMapPlacement(screenW, screenH, size);
        int guides = dungeonMapPlacement.setTopFromAbsoluteUnclamped(screenH, size, top, snap, threshold);
        dungeonMapPlacementInitialized = true;
        return guides;
    }

    public static void resetDungeonMapPosition() {
        dungeonMapPlacement.reset(HudPlacement.Anchor.START, 12, HudPlacement.Anchor.START, 12);
        dungeonMapPlacementInitialized = true;
        dungeonMapXPercent = 2;
        dungeonMapYPercent = 2;
    }

    private static int clampPercent(int value) {
        return Math.max(0, Math.min(100, value));
    }

    static int readChatTabMode(Properties p) {
        if (p != null && p.containsKey("chat.tabMode")) {
            return readInt(p, "chat.tabMode", 0, 0, 4);
        }
        int legacy = readInt(p == null ? new Properties() : p, "chat.filterMode", 0, 0, 2);
        return legacy == 2 ? 4 : legacy;
    }

    private static HudPlacement.Anchor readAnchor(Properties p, String key, HudPlacement.Anchor def) {
        try {
            return HudPlacement.Anchor.valueOf(p.getProperty(key, def.name()).trim().toUpperCase(java.util.Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            return def;
        }
    }

    private static File dir() {
        return Minecraft.getMinecraft().mcDataDir;
    }

    private static File readFile() {
        return ConfigFiles.resolveRead(dir(), FILE_NAME, LEGACY_FILE_NAME);
    }

    private static int readInt(Properties p, String key, int def, int min, int max) {
        try {
            int v = Integer.parseInt(p.getProperty(key, Integer.toString(def)).trim());
            return Math.max(min, Math.min(max, v));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    /** Loads the two performance defaults while honoring explicit values saved by the user. */
    static void loadPerformanceSettings(Properties p) {
        adaptive = readBool(p, "adaptive", adaptive);
        experimentalPerformance = readBool(p, "experimentalPerformance", experimentalPerformance);
    }

    private static float readFloat(Properties p, String key, float def, float min, float max) {
        try {
            float v = Float.parseFloat(p.getProperty(key, Float.toString(def)).trim());
            if (Float.isNaN(v) || Float.isInfinite(v)) return def;
            return Math.max(min, Math.min(max, v));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static String readColor(String value, String def) {
        if (value == null) return def;
        String[] parts = value.trim().split(":");
        if (parts.length != 5) return def;
        try {
            int alpha = Integer.parseInt(parts[1]);
            int red = Integer.parseInt(parts[2]);
            int green = Integer.parseInt(parts[3]);
            int blue = Integer.parseInt(parts[4]);
            if (alpha < 0 || alpha > 255 || red < 0 || red > 255 || green < 0 || green > 255 || blue < 0 || blue > 255) return def;
            Integer.parseInt(parts[0]);
            return value.trim();
        } catch (NumberFormatException ignored) {
            return def;
        }
    }

    static boolean readBool(Properties p, String key, boolean def) {
        return Boolean.parseBoolean(p.getProperty(key, Boolean.toString(def)));
    }
}
