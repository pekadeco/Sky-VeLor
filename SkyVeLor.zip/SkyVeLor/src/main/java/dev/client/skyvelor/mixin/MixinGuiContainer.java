package dev.client.skyvelor.mixin;

import dev.client.skyvelor.feature.inventory.SlotLocking;
import dev.client.skyvelor.feature.qol.InventoryQoL;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Small, client-only hooks for the two slot operations that Forge 1.8.9 does not expose as GUI events. */
@Mixin(GuiContainer.class)
public abstract class MixinGuiContainer {
    @Inject(
            method = "handleMouseClick",
            at = @At("HEAD"),
            cancellable = true,
            require = 1
    )
    private void skyvelor$activateSlotBinding(Slot slot, int slotId, int clickedButton, int clickType,
                                              CallbackInfo callback) {
        if (SlotLocking.handleBoundSlotClick((GuiContainer) (Object) this, slot, clickedButton, clickType)) {
            callback.cancel();
        }
    }

    @Inject(
            method = "drawSlot",
            at = @At("HEAD"),
            require = 1
    )
    private void skyvelor$drawStaticRarityBackground(Slot slot, CallbackInfo callback) {
        if (slot == null) return;
        ItemStack stack = slot.getStack();
        if (stack == null) return;

        // GuiContainer.drawScreen has already translated the matrix by guiLeft/guiTop
        // before calling drawSlot. Slot positions are therefore local coordinates here;
        // adding guiLeft/guiTop again would shift the tint away from the item slot.
        InventoryQoL.drawRarityHighlight(stack, slot.xDisplayPosition, slot.yDisplayPosition);
    }
}
