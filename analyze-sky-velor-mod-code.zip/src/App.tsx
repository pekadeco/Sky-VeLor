import { useEffect, useState } from "react";
import {
  ARTIFACT,
  DEFAULT_PLANNED,
  FINDINGS,
  QA_CHECKS,
  RELEASE_CHECKS,
  REPO,
  VERDICT,
  type FindingStatus,
} from "./data/audit";
import type { PageId, SharedAuditProps } from "./types";
import { useStoredState, downloadText } from "./utils/storage";
import { Icon, PixelCube, type IconName } from "./components/Icons";
import { Button, MeterBar, StatusBadge } from "./components/Ui";
import { Overview } from "./pages/Overview";
import { GuiRevamp } from "./pages/GuiRevamp";
import { Findings } from "./pages/Findings";
import { Modules } from "./pages/Modules";
import { Release } from "./pages/Release";
import { FixPlan } from "./pages/FixPlan";
import { Method } from "./pages/Method";
import { cn } from "./utils/cn";

const NAV: { label: string; items: { id: PageId; label: string; icon: IconName }[] }[] = [
  {
    label: "Workspace",
    items: [
      { id: "overview", label: "Overview", icon: "overview" },
      { id: "gui", label: "GUI revamp", icon: "modules" },
      { id: "findings", label: "Findings", icon: "findings" },
      { id: "modules", label: "Modules", icon: "modules" },
    ],
  },
  {
    label: "Release",
    items: [
      { id: "release", label: "Release check", icon: "release" },
      { id: "plan", label: "Fix plan", icon: "plan" },
    ],
  },
  {
    label: "Reference",
    items: [{ id: "method", label: "Method", icon: "method" }],
  },
];

const PAGE_TITLES: Record<PageId, string> = {
  overview: "Overview",
  gui: "GUI revamp",
  findings: "Findings",
  modules: "Modules",
  release: "Release check",
  plan: "Fix plan",
  method: "Method",
};

function defaultPlan(): Record<string, boolean> {
  return DEFAULT_PLANNED.reduce<Record<string, boolean>>((record, id) => {
    record[id] = true;
    return record;
  }, {});
}

function postureFor(criticalOpen: number, highOpen: number, qaDone: number) {
  if (criticalOpen > 0) return { label: "Private canary only", tone: "#f2b35c" };
  if (highOpen > 0) return { label: "Not broadly ready", tone: "#f2b35c" };
  if (qaDone < QA_CHECKS.length) return { label: "Validation incomplete", tone: "#75baff" };
  return { label: "Release candidate", tone: "#64e08d" };
}

function SidebarContent({
  page,
  navigate,
  readiness,
  qaDone,
  openCount,
  planCount,
  posture,
  exportReport,
  resetAll,
  onClose,
}: {
  page: PageId;
  navigate: (page: PageId) => void;
  readiness: number;
  qaDone: number;
  openCount: number;
  planCount: number;
  posture: { label: string; tone: string };
  exportReport: () => void;
  resetAll: () => void;
  onClose: () => void;
}) {
  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex items-center gap-3 border-b border-line-soft px-5 pb-5 pt-5">
        <div className="relative shrink-0 drop-shadow-[0_7px_14px_rgba(0,0,0,.55)]">
          <PixelCube size={39} />
        </div>
        <div className="min-w-0">
          <div className="pixel-title text-[14px] leading-none text-ink">SKY VELOR</div>
          <div className="mt-1.5 flex items-center gap-1.5 font-mono text-[8px] uppercase tracking-[0.17em] text-faint">
            <span className="h-1 w-1 rounded-full bg-accent" />
            release audit
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="focus-ring ml-auto flex h-7 w-7 items-center justify-center rounded-md border border-line text-faint lg:hidden"
          aria-label="Close navigation"
        >
          <Icon name="close" size={13} />
        </button>
      </div>

      <div className="px-3 pt-3">
        <div className="rounded-lg border border-line-soft bg-[#0a100d] px-2.5 py-2">
          <div className="flex items-center justify-between gap-2">
            <span className="flex min-w-0 items-center gap-1.5 font-mono text-[9px] text-muted">
              <Icon name="git" size={11} className="shrink-0 text-accent/70" />
              <span className="truncate">{REPO.branch}</span>
            </span>
            <span className="rounded border border-line px-1 py-0.5 font-mono text-[8px] uppercase text-faint">head</span>
          </div>
          <div className="mt-1 flex items-center justify-between font-mono text-[8px] text-faint">
            <span>{REPO.branchHead} · {REPO.numericVersion}</span>
            <span className="text-accent/70">verified</span>
          </div>
        </div>
      </div>

      <nav className="scroll-slim min-h-0 flex-1 overflow-y-auto px-3 py-4" aria-label="Audit sections">
        {NAV.map((group) => (
          <div key={group.label} className="mb-4 last:mb-0">
            <div className="mb-1.5 px-2 mono-label text-[8px] text-faint/80">{group.label}</div>
            <div className="space-y-0.5">
              {group.items.map((item) => {
                const active = page === item.id;
                const badge =
                  item.id === "findings" ? openCount : item.id === "plan" ? planCount : null;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      navigate(item.id);
                      onClose();
                    }}
                    className={cn(
                      "focus-ring group flex w-full items-center gap-2.5 rounded-lg border px-2.5 py-2 text-left transition-all",
                      active
                        ? "border-accent/20 bg-[linear-gradient(90deg,rgba(100,224,141,.13),rgba(100,224,141,.025))] text-ink"
                        : "border-transparent text-muted hover:bg-white/[0.03] hover:text-ink",
                    )}
                    aria-current={active ? "page" : undefined}
                  >
                    <span className={cn("flex h-6 w-6 items-center justify-center rounded-md border", active ? "border-accent/30 bg-accent/10 text-accent" : "border-line-soft bg-[#0a100d] text-faint group-hover:text-muted")}>
                      <Icon name={item.icon} size={13} />
                    </span>
                    <span className="flex-1 text-[11.5px] font-medium">{item.label}</span>
                    {badge !== null && (
                      <span
                        className={cn(
                          "min-w-[18px] rounded px-1 py-0.5 text-center font-mono text-[8px]",
                          active ? "bg-accent/15 text-accent" : "bg-[#101a14] text-faint",
                        )}
                      >
                        {badge}
                      </span>
                    )}
                    {active && <span className="h-1.5 w-1.5 rounded-full bg-accent shadow-[0_0_8px_rgba(100,224,141,.65)]" />}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      <div className="border-t border-line-soft p-3">
        <div className="rounded-xl border border-line bg-[#0a100d] p-3">
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="mono-label text-[8px] text-faint">Release posture</div>
              <div className="mt-1 text-[10px] font-medium" style={{ color: posture.tone }}>{posture.label}</div>
            </div>
            <div className="font-display text-xl font-semibold leading-none text-ink">
              {readiness}
              <span className="text-[9px] font-normal text-faint">/100</span>
            </div>
          </div>
          <div className="mt-2.5"><MeterBar value={readiness} height={4} tone={readiness < 60 ? "danger" : readiness < 80 ? "ember" : "accent"} /></div>
          <div className="mt-2 flex items-center justify-between font-mono text-[8px] text-faint">
            <span>QA {qaDone}/{QA_CHECKS.length}</span>
            <span>{Math.max(0, QA_CHECKS.length - qaDone)} checks left</span>
          </div>
        </div>
        <div className="mt-2 grid grid-cols-2 gap-1.5">
          <Button size="sm" variant="secondary" icon="download" onClick={exportReport} className="w-full">
            Export
          </Button>
          <a
            href={REPO.url}
            target="_blank"
            rel="noreferrer"
            className="focus-ring inline-flex items-center justify-center gap-1.5 rounded-lg border border-line bg-panel-2/80 px-2 py-1.5 text-[11px] font-medium text-muted transition-colors hover:border-[#355443] hover:text-ink"
          >
            <Icon name="git" size={13} /> Repo
          </a>
        </div>
        <button
          type="button"
          onClick={resetAll}
          className="focus-ring mt-2 flex w-full items-center justify-center gap-1.5 rounded-md py-1.5 font-mono text-[8px] uppercase tracking-wider text-faint transition-colors hover:text-muted"
        >
          <Icon name="refresh" size={10} /> reset workspace state
        </button>
      </div>
    </div>
  );
}

export default function App() {
  const [page, setPage] = useState<PageId>("gui");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [statuses, setStatuses] = useStoredState<Record<string, FindingStatus>>("skyvelor.audit.statuses.v1", {});
  const [planned, setPlanned] = useStoredState<Record<string, boolean>>("skyvelor.audit.plan.v1", defaultPlan());
  const [qa, setQa] = useStoredState<Record<string, boolean>>("skyvelor.audit.qa.v1", {});
  const [toast, setToast] = useState<{ id: number; message: string } | null>(null);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [page]);

  useEffect(() => {
    if (mobileOpen) {
      const previous = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      return () => {
        document.body.style.overflow = previous;
      };
    }
    return undefined;
  }, [mobileOpen]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 2800);
    return () => window.clearTimeout(timer);
  }, [toast]);

  function showToast(message: string) {
    setToast({ id: Date.now(), message });
  }

  function navigate(next: PageId) {
    setPage(next);
    setMobileOpen(false);
  }

  function setStatus(id: string, status: FindingStatus) {
    setStatuses((current) => ({ ...current, [id]: status }));
  }

  function togglePlanned(id: string) {
    setPlanned((current) => ({ ...current, [id]: !current[id] }));
  }

  function toggleQa(id: string) {
    setQa((current) => ({ ...current, [id]: !current[id] }));
  }

  const fixed = FINDINGS.filter((finding) => statuses[finding.id] === "fixed").length;
  const criticalOpen = FINDINGS.filter(
    (finding) => finding.severity === "critical" && (statuses[finding.id] ?? "open") !== "fixed",
  ).length;
  const highOpen = FINDINGS.filter(
    (finding) => finding.severity === "high" && (statuses[finding.id] ?? "open") !== "fixed",
  ).length;
  const qaDone = QA_CHECKS.filter((check) => qa[check.id]).length;
  const highFixed = FINDINGS.filter((finding) => finding.severity === "high" && statuses[finding.id] === "fixed").length;
  const mediumFixed = FINDINGS.filter((finding) => finding.severity === "medium" && statuses[finding.id] === "fixed").length;
  const readiness = Math.min(
    97,
    58 + (2 - criticalOpen) * 6 + highFixed * 3 + mediumFixed + Math.round((qaDone / QA_CHECKS.length) * 14),
  );
  const posture = postureFor(criticalOpen, highOpen, qaDone);
  const openCount = FINDINGS.length - fixed;
  const planCount = FINDINGS.filter((finding) => planned[finding.id]).length;

  function exportReport() {
    const now = new Date().toISOString();
    const criticals = FINDINGS.filter((finding) => finding.severity === "critical").length;
    const statusOf = (id: string) => (statuses[id] ?? "open").toUpperCase();
    const lines = [
      `# Sky VeLor ${REPO.version} — release audit`,
      "",
      `Audit date: ${REPO.auditDate} (snapshot)  `,
      `Generated: ${now}  `,
      `Branch: ${REPO.branch}  `,
      `Source commit: ${REPO.sourceCommit}  `,
      `Branch head: ${REPO.branchHead}  `,
      "",
      `## Verdict`,
      "",
      `**${VERDICT.label}** — audit readiness ${readiness}/100. ${VERDICT.summary}`,
      "",
      `- Critical findings: ${criticals}`,
      `- Open findings: ${openCount}/16`,
      `- Fix queue: ${planCount} items`,
      `- In-game QA: ${qaDone}/${QA_CHECKS.length} verified`,
      "",
      `## Artifact`,
      "",
      `- JAR: ${ARTIFACT.jar}`,
      `- Size: ${ARTIFACT.sizeBytes} bytes`,
      `- SHA-256: \`${ARTIFACT.sha256}\``,
      `- Classes: ${ARTIFACT.classes} / entries: ${ARTIFACT.entries}`,
      `- Source ZIP: ${ARTIFACT.sourceZip}`,
      `- Source SHA-256: \`${ARTIFACT.sourceSha256}\``,
      "",
      `## Findings`,
      "",
      ...FINDINGS.map(
        (finding) =>
          `### [${finding.severity.toUpperCase()}] ${finding.id} — ${finding.title}\n` +
          `Status: **${statusOf(finding.id)}** · Area: ${finding.area} · Evidence: \`${finding.file}:${finding.lines}\`\n\n` +
          `${finding.summary}\n\n` +
          `Impact: ${finding.impact}\n\n` +
          `Fix:\n${finding.fix.map((step) => `- ${step}`).join("\n")}\n\n` +
          `Verify:\n${finding.verification.map((step) => `- ${step}`).join("\n")}`,
      ),
      "",
      `## Release checks`,
      "",
      ...RELEASE_CHECKS.map((check) => `- [${check.status.toUpperCase()}] ${check.label} — ${check.detail}`),
      "",
      `## In-game QA checklist`,
      "",
      ...QA_CHECKS.map((check) => `- [${qa[check.id] ? "x" : " "}] **${check.group}** · ${check.label} — ${check.detail}`),
      "",
      `## Method limit`,
      "",
      `This is a static source and artifact review. No Minecraft client, Forge runtime or Gradle test run was launched. Runtime effects still require a clean 1.8.9 Forge pass.`,
      "",
    ];
    downloadText("skyvelor-beta-0.10.8.9-audit.md", lines.join("\n"));
    showToast("Audit report downloaded");
  }

  function resetAll() {
    setStatuses({});
    setPlanned(defaultPlan());
    setQa({});
    showToast("Workspace reset to the initial audit state");
  }

  const shared: SharedAuditProps = {
    statuses,
    setStatus,
    planned,
    togglePlanned,
    qa,
    toggleQa,
    readiness,
    navigate,
    showToast,
    exportReport,
    resetAll,
  };

  return (
    <div className="app-shell min-h-screen">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[264px] border-r border-line-soft bg-[#090e0b]/95 lg:block">
        <SidebarContent
          page={page}
          navigate={navigate}
          readiness={readiness}
          qaDone={qaDone}
          openCount={openCount}
          planCount={planCount}
          posture={posture}
          exportReport={exportReport}
          resetAll={resetAll}
          onClose={() => setMobileOpen(false)}
        />
      </aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="drawer-scrim absolute inset-0 animate-fade-in" onClick={() => setMobileOpen(false)} />
          <aside className="animate-slide-in relative h-full w-[86%] max-w-[310px] border-r border-line bg-[#090e0b] shadow-2xl">
            <SidebarContent
              page={page}
              navigate={navigate}
              readiness={readiness}
              qaDone={qaDone}
              openCount={openCount}
              planCount={planCount}
              posture={posture}
              exportReport={exportReport}
              resetAll={resetAll}
              onClose={() => setMobileOpen(false)}
            />
          </aside>
        </div>
      )}

      <div className="lg:pl-[264px]">
        <header className="sticky top-0 z-30 border-b border-line-soft bg-[#080b0a]/85 backdrop-blur-xl">
          <div className="mx-auto flex h-14 max-w-[1480px] items-center gap-3 px-4 sm:px-6 lg:px-8">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              className="focus-ring flex h-8 w-8 items-center justify-center rounded-lg border border-line bg-panel text-muted lg:hidden"
              aria-label="Open navigation"
            >
              <Icon name="menu" size={15} />
            </button>
            <div className="hidden items-center gap-2 font-mono text-[10px] text-faint sm:flex">
              <span className="text-muted">{REPO.owner}</span>
              <span>/</span>
              <span className="text-muted">{REPO.name}</span>
              <span>/</span>
              <span className="text-accent/85">beta-{REPO.numericVersion}</span>
            </div>
            <div className="flex items-center gap-2 sm:hidden">
              <PixelCube size={23} />
              <span className="pixel-title text-[10px] text-ink">SKY VELOR</span>
            </div>
            <div className="ml-auto flex items-center gap-2">
              <span className="hidden items-center gap-1.5 rounded-md border border-accent/20 bg-accent/[0.06] px-2 py-1 font-mono text-[8px] uppercase tracking-[0.11em] text-accent md:inline-flex">
                <span className="h-1.5 w-1.5 rounded-full bg-accent" />
                jar verified
              </span>
              <span className="hidden font-mono text-[9px] text-faint xl:block">
                {REPO.branchHead} · {REPO.auditDate}
              </span>
              <span className="mx-1 hidden h-5 w-px bg-line xl:block" />
              <Button size="sm" variant="ghost" icon="download" onClick={exportReport}>
                <span className="hidden sm:inline">Export audit</span>
              </Button>
              <a
                href={REPO.url}
                target="_blank"
                rel="noreferrer"
                className="focus-ring flex h-8 w-8 items-center justify-center rounded-lg border border-line bg-panel text-muted transition-colors hover:border-[#355443] hover:text-ink"
                aria-label="Open repository on GitHub"
              >
                <Icon name="git" size={14} />
              </a>
            </div>
          </div>
        </header>

        <main className="mx-auto w-full max-w-[1480px] px-4 py-5 sm:px-6 lg:px-8 lg:py-6">
          <div className="mb-3 flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.13em] text-faint">
            <span>audit</span>
            <Icon name="chevron" size={9} />
            <span className="text-muted">{PAGE_TITLES[page]}</span>
            <span className="ml-auto hidden items-center gap-1.5 sm:flex">
              <StatusBadge status={criticalOpen > 0 ? "open" : "fixed"} />
              <span className="text-faint">{fixed}/{FINDINGS.length} fixed</span>
            </span>
          </div>

          {page === "overview" && <Overview {...shared} />}
          {page === "gui" && <GuiRevamp {...shared} />}
          {page === "findings" && <Findings {...shared} />}
          {page === "modules" && <Modules {...shared} />}
          {page === "release" && <Release {...shared} />}
          {page === "plan" && <FixPlan {...shared} />}
          {page === "method" && <Method {...shared} />}

          <footer className="mt-8 border-t border-line-soft pt-5">
            <div className="flex flex-col gap-3 text-[9px] leading-relaxed text-faint sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                <span className="inline-flex items-center gap-1.5 font-mono">
                  <PixelCube size={15} />
                  Sky VeLor audit
                </span>
                <span>{REPO.version}</span>
                <span>·</span>
                <span>static source review</span>
                <span>·</span>
                <span>not an official project page</span>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <span>Unaffiliated with Mojang, Hypixel or Fakepixel.</span>
                <a href={REPO.branchUrl} target="_blank" rel="noreferrer" className="focus-ring inline-flex items-center gap-1 rounded text-accent/70 hover:text-accent">
                  Source <Icon name="external" size={10} />
                </a>
              </div>
            </div>
          </footer>
        </main>
      </div>

      {toast && (
        <div className="fixed bottom-4 left-1/2 z-[100] w-[calc(100%-2rem)] max-w-sm -translate-x-1/2 animate-fade-up sm:left-auto sm:right-5 sm:w-auto sm:translate-x-0">
          <div className="flex items-center gap-2.5 rounded-xl border border-accent/25 bg-[#0c1510]/95 px-3.5 py-2.5 shadow-2xl backdrop-blur-md">
            <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded border border-accent/30 bg-accent/10 text-accent">
              <Icon name="check" size={11} />
            </span>
            <span className="text-[11px] text-[#d6e5db]">{toast.message}</span>
          </div>
        </div>
      )}
    </div>
  );
}
