import { useEffect, useState, type CSSProperties, type ReactNode } from "react";
import { cn } from "../utils/cn";
import { Icon, type IconName } from "./Icons";
import { SEVERITY_META, STATUS_META, type FindingStatus, type Severity } from "../data/audit";

export function SeverityBadge({
  severity,
  compact = false,
}: {
  severity: Severity;
  compact?: boolean;
}) {
  const meta = SEVERITY_META[severity];
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 rounded-md border font-mono font-medium uppercase tracking-[0.12em]",
        compact ? "px-1.5 py-1 text-[9px]" : "px-2 py-1 text-[10px]",
      )}
      style={{ color: meta.color, backgroundColor: meta.bg, borderColor: meta.border }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: meta.color }} />
      {meta.label}
    </span>
  );
}

export function StatusBadge({ status }: { status: FindingStatus }) {
  const meta = STATUS_META[status];
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-md border border-line bg-panel-2/70 px-2 py-1 font-mono text-[10px] uppercase tracking-[0.08em]"
      style={{ color: meta.color }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: meta.dot }} />
      {meta.label}
    </span>
  );
}

export function Tag({ children, color }: { children: ReactNode; color?: string }) {
  return (
    <span
      className="inline-flex items-center rounded border border-line-soft bg-[#0b110e] px-1.5 py-1 font-mono text-[9px] uppercase tracking-[0.1em] text-faint"
      style={color ? { color, borderColor: `${color}33` } : undefined}
    >
      {children}
    </span>
  );
}

export function Button({
  children,
  onClick,
  variant = "primary",
  size = "md",
  icon,
  iconRight,
  className,
  type = "button",
  disabled,
  title,
}: {
  children?: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "ghost" | "danger";
  size?: "sm" | "md";
  icon?: IconName;
  iconRight?: IconName;
  className?: string;
  type?: "button" | "submit";
  disabled?: boolean;
  title?: string;
}) {
  const variants: Record<string, string> = {
    primary:
      "border-accent/45 bg-accent/15 text-accent-soft hover:bg-accent/22 hover:border-accent/65 shadow-[0_0_22px_-14px_rgba(100,224,141,.8)]",
    secondary: "border-line bg-panel-2/80 text-ink hover:border-[#355443] hover:bg-panel-3",
    ghost: "border-transparent bg-transparent text-muted hover:bg-white/[0.035] hover:text-ink",
    danger: "border-danger/30 bg-danger/10 text-[#ffb3ad] hover:bg-danger/15",
  };
  return (
    <button
      type={type}
      title={title}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "focus-ring inline-flex shrink-0 items-center justify-center gap-2 rounded-lg border font-medium transition-all duration-150 disabled:cursor-not-allowed disabled:opacity-45",
        size === "sm" ? "px-2.5 py-1.5 text-[11px]" : "px-3.5 py-2 text-xs",
        variants[variant],
        className,
      )}
    >
      {icon && <Icon name={icon} size={size === "sm" ? 13 : 15} />}
      {children}
      {iconRight && <Icon name={iconRight} size={size === "sm" ? 13 : 15} />}
    </button>
  );
}

export function MeterBar({
  value,
  tone = "accent",
  height = 6,
  label,
}: {
  value: number;
  tone?: "accent" | "ember" | "danger" | "info";
  height?: number;
  label?: string;
}) {
  const colors: Record<string, string> = {
    accent: "#64e08d",
    ember: "#f2b35c",
    danger: "#ff7a70",
    info: "#75baff",
  };
  const color = colors[tone];
  return (
    <div
      className="w-full overflow-hidden rounded-full bg-[#07100a] inner-ring"
      style={{ height }}
      role="progressbar"
      aria-valuenow={value}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={label}
    >
      <div
        className="h-full rounded-full transition-[width] duration-500 ease-out"
        style={{
          width: `${Math.max(0, Math.min(100, value))}%`,
          background: `linear-gradient(90deg, ${color}99, ${color})`,
          boxShadow: `0 0 12px ${color}55`,
        }}
      />
    </div>
  );
}

export function ScoreRing({
  value,
  size = 132,
  stroke = 8,
  caption,
}: {
  value: number;
  size?: number;
  stroke?: number;
  caption?: string;
}) {
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (value / 100) * circumference;
  const color = value >= 85 ? "#64e08d" : value >= 65 ? "#f2b35c" : "#ff7a70";
  return (
    <div className="relative inline-flex shrink-0 items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} stroke="rgba(105,152,124,.14)" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 700ms cubic-bezier(.22,1,.36,1), stroke 300ms ease", filter: `drop-shadow(0 0 6px ${color}55)` }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-3xl font-semibold leading-none tracking-tight text-ink">{value}</span>
        <span className="mt-1 font-mono text-[9px] uppercase tracking-[0.14em] text-faint">{caption ?? "audit score"}</span>
      </div>
    </div>
  );
}

export function CopyButton({
  text,
  label = "Copy",
  onCopied,
  className,
  iconOnly = false,
}: {
  text: string;
  label?: string;
  onCopied?: (message: string) => void;
  className?: string;
  iconOnly?: boolean;
}) {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!copied) return;
    const timer = window.setTimeout(() => setCopied(false), 1700);
    return () => window.clearTimeout(timer);
  }, [copied]);

  async function copy() {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      onCopied?.(`${label} copied to clipboard`);
    } catch {
      onCopied?.("Clipboard unavailable in this browser");
    }
  }

  return (
    <button
      type="button"
      onClick={copy}
      className={cn(
        "focus-ring inline-flex items-center gap-1.5 rounded-md border border-line bg-panel-2/70 px-2 py-1.5 font-mono text-[10px] text-muted transition-colors hover:border-[#355443] hover:text-ink",
        className,
      )}
      title={`Copy ${label.toLowerCase()}`}
    >
      <Icon name={copied ? "check" : "copy"} size={12} />
      {!iconOnly && (copied ? "Copied" : label)}
    </button>
  );
}

export function SectionLabel({
  children,
  icon,
  trailing,
  className,
}: {
  children: ReactNode;
  icon?: IconName;
  trailing?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("mb-3 flex items-center justify-between gap-3", className)}>
      <div className="flex items-center gap-2">
        {icon && <Icon name={icon} size={13} className="text-accent/80" />}
        <span className="mono-label text-[#8fa497]">{children}</span>
      </div>
      {trailing}
    </div>
  );
}

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow: string;
  title: string;
  description: ReactNode;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col gap-4 border-b border-line-soft pb-6 lg:flex-row lg:items-end lg:justify-between">
      <div className="min-w-0">
        <div className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-accent/80">
          <span className="inline-block h-1.5 w-1.5 rounded-full bg-accent animate-pulse-dot" />
          {eyebrow}
        </div>
        <h1 className="font-display text-[28px] font-semibold leading-tight tracking-[-0.03em] text-ink sm:text-[34px]">{title}</h1>
        <div className="mt-2 max-w-3xl text-[13px] leading-relaxed text-muted">{description}</div>
      </div>
      {actions && <div className="flex shrink-0 flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export function EmptyState({ icon = "eye", title, detail }: { icon?: IconName; title: string; detail: string }) {
  return (
    <div className="panel flex flex-col items-center justify-center px-6 py-14 text-center">
      <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl border border-line bg-panel-2 text-faint">
        <Icon name={icon} size={20} />
      </div>
      <div className="text-sm font-medium text-ink">{title}</div>
      <div className="mt-1 max-w-sm text-xs leading-relaxed text-faint">{detail}</div>
    </div>
  );
}

export function KeyValue({
  label,
  value,
  mono = true,
  className,
}: {
  label: string;
  value: ReactNode;
  mono?: boolean;
  className?: string;
}) {
  return (
    <div className={cn("flex items-start justify-between gap-4 py-2.5", className)}>
      <span className="text-[11px] text-faint">{label}</span>
      <span className={cn("min-w-0 break-all text-right text-[11px] text-ink", mono && "font-mono")}>{value}</span>
    </div>
  );
}

export function Callout({
  tone = "info",
  initials,
  title,
  children,
  className,
}: {
  tone?: "info" | "warn" | "success" | "danger";
  initials?: string;
  title?: string;
  children: ReactNode;
  className?: string;
}) {
  const tones = {
    info: { color: "#75baff", border: "rgba(117,186,255,.24)", bg: "rgba(117,186,255,.06)" },
    warn: { color: "#f2b35c", border: "rgba(242,179,92,.26)", bg: "rgba(242,179,92,.06)" },
    success: { color: "#64e08d", border: "rgba(100,224,141,.24)", bg: "rgba(100,224,141,.06)" },
    danger: { color: "#ff7a70", border: "rgba(255,122,112,.26)", bg: "rgba(255,122,112,.06)" },
  }[tone];
  return (
    <div className={cn("rounded-xl border px-4 py-3.5", className)} style={{ borderColor: tones.border, background: tones.bg }}>
      <div className="flex items-start gap-3">
        {initials && (
          <span
            className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded border font-mono text-[9px]"
            style={{ color: tones.color, borderColor: tones.border }}
          >
            {initials}
          </span>
        )}
        <div className="min-w-0">
          {title && <div className="mb-1 text-xs font-semibold" style={{ color: tones.color }}>{title}</div>}
          <div className="text-[11px] leading-relaxed text-muted">{children}</div>
        </div>
      </div>
    </div>
  );
}

export function Sparkline({ values, color = "#64e08d", height = 34 }: { values: number[]; color?: string; height?: number }) {
  const max = Math.max(...values, 1);
  const min = Math.min(...values, 0);
  const points = values
    .map((v, i) => {
      const x = (i / (values.length - 1)) * 100;
      const y = height - 4 - ((v - min) / (max - min || 1)) * (height - 8);
      return `${x},${y}`;
    })
    .join(" ");
  return (
    <svg width="100%" height={height} viewBox={`0 0 100 ${height}`} preserveAspectRatio="none" aria-hidden="true">
      <polyline points={points} fill="none" stroke={color} strokeWidth="1.4" vectorEffect="non-scaling-stroke" opacity=".75" />
    </svg>
  );
}

export function ProgressChip({ label, value, tone = "accent" }: { label: string; value: number; tone?: "accent" | "ember" | "danger" | "info" }) {
  return (
    <div className="flex items-center gap-2.5">
      <span className="w-24 truncate text-[10px] text-faint">{label}</span>
      <div className="flex-1">
        <MeterBar value={value} tone={tone} height={4} />
      </div>
      <span className="w-7 text-right font-mono text-[10px] text-muted">{value}</span>
    </div>
  );
}

export function PanelStyle(style?: CSSProperties) {
  return style;
}
