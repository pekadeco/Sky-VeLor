import type { SVGProps } from "react";

export type IconName =
  | "overview"
  | "findings"
  | "modules"
  | "release"
  | "plan"
  | "method"
  | "search"
  | "close"
  | "chevron"
  | "arrow"
  | "external"
  | "git"
  | "copy"
  | "check"
  | "download"
  | "alert"
  | "shield"
  | "wrench"
  | "code"
  | "file"
  | "clock"
  | "menu"
  | "filter"
  | "lock"
  | "spark"
  | "info"
  | "refresh"
  | "server"
  | "gauge"
  | "layers"
  | "eye";

interface IconProps extends SVGProps<SVGSVGElement> {
  name: IconName;
  size?: number;
}

export function Icon({ name, size = 18, ...rest }: IconProps) {
  const common = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.7,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true,
  };

  switch (name) {
    case "overview":
      return (
        <svg {...common} {...rest}>
          <rect x="3" y="3" width="7" height="7" rx="1.5" />
          <rect x="14" y="3" width="7" height="7" rx="1.5" />
          <rect x="3" y="14" width="7" height="7" rx="1.5" />
          <rect x="14" y="14" width="7" height="7" rx="1.5" />
        </svg>
      );
    case "findings":
      return (
        <svg {...common} {...rest}>
          <path d="M8 3.8v-1a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v1" />
          <rect x="4.5" y="4" width="15" height="17" rx="3" />
          <path d="M8 9h8M8 13h5" />
          <path d="m15.5 16 1.5 1.5 2.5-2.6" />
        </svg>
      );
    case "modules":
      return (
        <svg {...common} {...rest}>
          <path d="M12 2.8 21 8l-9 5.2L3 8l9-5.2Z" />
          <path d="m3 12 9 5.2 9-5.2" />
          <path d="m3 16 9 5.2 9-5.2" />
        </svg>
      );
    case "release":
      return (
        <svg {...common} {...rest}>
          <path d="M21 8.5v7L12 21l-9-5.5v-7L12 3l9 5.5Z" />
          <path d="m3.4 8.3 8.6 5 8.6-5" />
          <path d="M12 21v-7.7" />
        </svg>
      );
    case "plan":
      return (
        <svg {...common} {...rest}>
          <path d="M9 5h11M9 12h11M9 19h11" />
          <path d="m3.5 4.5 1.3 1.3L7 3.6M3.5 11.5l1.3 1.3L7 10.6M3.5 18.5l1.3 1.3L7 17.6" />
        </svg>
      );
    case "method":
      return (
        <svg {...common} {...rest}>
          <rect x="2.5" y="4" width="19" height="16" rx="2.5" />
          <path d="m7 9 2.4 2.4L7 13.8M12 14h5" />
        </svg>
      );
    case "search":
      return (
        <svg {...common} {...rest}>
          <circle cx="11" cy="11" r="6.7" />
          <path d="m16 16 4.2 4.2" />
        </svg>
      );
    case "close":
      return (
        <svg {...common} {...rest}>
          <path d="M6 6l12 12M18 6 6 18" />
        </svg>
      );
    case "chevron":
      return (
        <svg {...common} {...rest}>
          <path d="m9 5 7 7-7 7" />
        </svg>
      );
    case "arrow":
      return (
        <svg {...common} {...rest}>
          <path d="M4 12h16M14 6l6 6-6 6" />
        </svg>
      );
    case "external":
      return (
        <svg {...common} {...rest}>
          <path d="M13 4h7v7M20 4l-8.5 8.5" />
          <path d="M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5" />
        </svg>
      );
    case "git":
      return (
        <svg {...common} {...rest}>
          <circle cx="6" cy="5" r="2" />
          <circle cx="18" cy="6" r="2" />
          <circle cx="6" cy="19" r="2" />
          <path d="M6 7v10M18 8v2a3 3 0 0 1-3 3H9a3 3 0 0 0-3 3v1" />
        </svg>
      );
    case "copy":
      return (
        <svg {...common} {...rest}>
          <rect x="8" y="8" width="12" height="12" rx="2" />
          <path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3" />
        </svg>
      );
    case "check":
      return (
        <svg {...common} {...rest}>
          <path d="m4.5 12.5 5 5L20 6.8" />
        </svg>
      );
    case "download":
      return (
        <svg {...common} {...rest}>
          <path d="M12 3v12M7 10.5l5 5 5-5" />
          <path d="M4 20h16" />
        </svg>
      );
    case "alert":
      return (
        <svg {...common} {...rest}>
          <path d="M12 3 2.8 20h18.4L12 3Z" />
          <path d="M12 9v5M12 17.2v.1" />
        </svg>
      );
    case "shield":
      return (
        <svg {...common} {...rest}>
          <path d="M12 2.8 20 6v6.2c0 4.6-3.4 7.6-8 9-4.6-1.4-8-4.4-8-9V6l8-3.2Z" />
          <path d="m8.6 11.8 2.2 2.2 4.6-4.7" />
        </svg>
      );
    case "wrench":
      return (
        <svg {...common} {...rest}>
          <path d="M14.6 6.1a5 5 0 0 0-6.7 6.4l-4.3 4.3a2.1 2.1 0 0 0 3 3l4.3-4.3a5 5 0 0 0 6.4-6.7l-3 3-2.7-.9-.9-2.7 3-3Z" />
        </svg>
      );
    case "code":
      return (
        <svg {...common} {...rest}>
          <path d="m8 6-6 6 6 6M16 6l6 6-6 6" />
        </svg>
      );
    case "file":
      return (
        <svg {...common} {...rest}>
          <path d="M13 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V9l-6-6Z" />
          <path d="M13 3v6h6" />
        </svg>
      );
    case "clock":
      return (
        <svg {...common} {...rest}>
          <circle cx="12" cy="12" r="8.7" />
          <path d="M12 7v5.4l3.5 2" />
        </svg>
      );
    case "menu":
      return (
        <svg {...common} {...rest}>
          <path d="M4 6.5h16M4 12h16M4 17.5h16" />
        </svg>
      );
    case "filter":
      return (
        <svg {...common} {...rest}>
          <path d="M3 5h18l-7 8.2V20l-4-2.4v-4.4L3 5Z" />
        </svg>
      );
    case "lock":
      return (
        <svg {...common} {...rest}>
          <rect x="4.5" y="10" width="15" height="11" rx="2.2" />
          <path d="M8 10V7.2a4 4 0 0 1 8 0V10M12 14.5v2.5" />
        </svg>
      );
    case "spark":
      return (
        <svg {...common} {...rest}>
          <path d="m12 2 1.8 6.2L20 10l-6.2 1.8L12 18l-1.8-6.2L4 10l6.2-1.8L12 2Z" />
          <path d="m19 16 .7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7L19 16Z" />
        </svg>
      );
    case "info":
      return (
        <svg {...common} {...rest}>
          <circle cx="12" cy="12" r="9" />
          <path d="M12 10.7V17M12 7.4v.1" />
        </svg>
      );
    case "refresh":
      return (
        <svg {...common} {...rest}>
          <path d="M20 11a8 8 0 1 0-.7 4.6" />
          <path d="M20 4v7h-7" />
        </svg>
      );
    case "server":
      return (
        <svg {...common} {...rest}>
          <rect x="3" y="4" width="18" height="6" rx="1.5" />
          <rect x="3" y="14" width="18" height="6" rx="1.5" />
          <path d="M7 7h.1M7 17h.1M12 7h5M12 17h5" />
        </svg>
      );
    case "gauge":
      return (
        <svg {...common} {...rest}>
          <path d="M4 18a9 9 0 1 1 16 0" />
          <path d="m12 14 4-4M6.5 18h11" />
        </svg>
      );
    case "layers":
      return (
        <svg {...common} {...rest}>
          <path d="m12 3 9 5-9 5-9-5 9-5Z" />
          <path d="m3 12 9 5 9-5M3 16l9 5 9-5" />
        </svg>
      );
    case "eye":
      return (
        <svg {...common} {...rest}>
          <path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z" />
          <circle cx="12" cy="12" r="2.5" />
        </svg>
      );
    default:
      return null;
  }
}

export function PixelCube({ size = 40 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true">
      <path d="M24 3 45 14 24 25 3 14Z" fill="#69e08d" />
      <path d="M24 7 39 14.8 24 22.6 9 14.8Z" fill="#85efa3" opacity="0.52" />
      <path d="M4.2 16.4 23 25.8v17.6L4.2 34Z" fill="#6d4b30" />
      <path d="M44.2 16.4 25 25.8v17.6L44.2 34Z" fill="#533921" />
      <path d="M4.2 16.4 23 25.8l4-2-18.8-9.4-4 2Z" fill="#91efaa" />
      <path d="M25 25.8 44.2 16.4l4 2-19.2 9.4-4-2Z" fill="#66d185" />
      <path d="M24 3 45 14v5.5L24 30 3 19.5V14L24 3Z" fill="none" stroke="#0a140d" strokeOpacity=".35" />
      <path d="M9 15.5h3v2H9zM17 18h2v2h-2zM31 17.5h3v2h-3zM36 15.8h2v2h-2z" fill="#0a2b15" opacity=".35" />
      <path d="M24 30v20L3 39V19.5L24 30Z" fill="none" stroke="#0a140d" strokeOpacity=".4" />
      <path d="M24 30v20l21-11V19.5L24 30Z" fill="none" stroke="#0a140d" strokeOpacity=".4" />
      <path d="M10 28h3v2h-3zM14 33h2v2h-2zM34 29h2v2h-2zM30 34h3v2h-3z" fill="#241508" opacity=".5" />
    </svg>
  );
}
