import type { FindingStatus } from "./data/audit";

export type PageId = "overview" | "gui" | "findings" | "modules" | "release" | "plan" | "method";

export interface SharedAuditProps {
  statuses: Record<string, FindingStatus>;
  setStatus: (id: string, status: FindingStatus) => void;
  planned: Record<string, boolean>;
  togglePlanned: (id: string) => void;
  qa: Record<string, boolean>;
  toggleQa: (id: string) => void;
  readiness: number;
  navigate: (page: PageId) => void;
  showToast: (message: string) => void;
  exportReport: () => void;
  resetAll: () => void;
}
