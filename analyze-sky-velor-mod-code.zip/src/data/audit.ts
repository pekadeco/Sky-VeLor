export type Severity = "critical" | "high" | "medium" | "low";
export type FindingStatus = "open" | "planned" | "fixed" | "accepted";
export type Phase = 1 | 2 | 3;

export type Area =
  | "Release"
  | "Runtime"
  | "Dungeon"
  | "Config"
  | "Network"
  | "Code health"
  | "Docs"
  | "CI";

export interface Finding {
  id: string;
  title: string;
  severity: Severity;
  area: Area;
  component: string;
  file: string;
  lines: string;
  phase: Phase;
  effort: "S" | "M" | "L";
  confidence: "High" | "Medium";
  summary: string;
  evidence: string;
  code: string;
  impact: string;
  fix: string[];
  verification: string[];
  tags: string[];
}

export interface AuditModule {
  id: string;
  name: string;
  packages: string[];
  files: number;
  loc: number;
  suites: number;
  risk: Severity;
  summary: string;
  signal: string;
  tags: string[];
}

export interface QaCheck {
  id: string;
  group: "Launch" | "Surface" | "Dungeon" | "Config" | "Safety" | "Soak";
  label: string;
  detail: string;
}

export const REPO = {
  owner: "pekadeco",
  name: "Sky-VeLor",
  branch: "arena/9b99b4ab-sky-velor",
  branchHead: "80b8b1a",
  sourceCommit: "c80c65b",
  auditDate: "23 Oct 2026",
  version: "Beta-0.10.8.9v",
  numericVersion: "0.10.8.9",
  mc: "1.8.9",
  forge: "11.15.1.2318",
  modid: "pekaclient",
  url: "https://github.com/pekadeco/Sky-VeLor",
  branchUrl: "https://github.com/pekadeco/Sky-VeLor/tree/arena/9b99b4ab-sky-velor",
};

export const ARTIFACT = {
  jar: "SkyVeLor-1.8.9-Beta-0.10.8.9v.jar",
  sizeBytes: 882396,
  sha256: "67d459ad88a481bb48b080c4c6136c3ee2915b1c670cae6c2a064f719104a361",
  sourceZip: "SkyVeLor-1.8.9-Beta-0.10.8.9v-source.zip",
  sourceSizeBytes: 749321,
  sourceSha256: "dfaaf584eb26029ea03c2d76b984d23dfa62854c9bd9840c4e5b342d9f0f2b5c",
  classes: 397,
  entries: 436,
  javaFiles: 202,
  loc: 34449,
  testSuites: 65,
  assertions: 1175,
  hubRows: 34,
  coremod: "com.arena.pekaclient.render.itemanimation.ItemAnimationLoadingPlugin",
  builtAt: "2026-10-23T11:31:25Z",
};

export const FINDINGS: Finding[] = [
  {
    id: "SV-001",
    title: "The release is structurally verified, but nobody has launched it",
    severity: "critical",
    area: "Release",
    component: "Release gate",
    file: "CHANGELOG.md",
    lines: "11 · README.md:27",
    phase: 1,
    effort: "M",
    confidence: "High",
    summary:
      "Beta-0.10.8.9v ships with an explicit 'NOT tested in-game' disclaimer. The 1,175 headless checks and the JAR verifier prove packaging and pure logic, not Forge startup, rendering, input or network behaviour.",
    evidence:
      "The 0.10.8.9 changelog ends with 'NOT tested in-game.' The README repeats it. The audit verified the JAR's metadata, class inventory and hash, but no Minecraft process was started.",
    code: "## Beta-0.10.8.9v — 2026-10-23\n- ...\n- **NOT tested in-game.**\n\n// README.md:27\n// ... this release was **NOT tested in-game**.",
    impact:
      "A startup failure, a disabled coremod hook or a broken GUI can reach users while every automated check stays green. This project has already shipped a no-op JAR once after a compile failure, so packaging checks alone are not enough.",
    fix: [
      "Treat this build as a private canary. Publish it as a pre-release, not a stable download.",
      "Run a clean Forge 1.8.9 instance smoke pass before every public tag; record the result in BUILD-VERIFICATION.md.",
      "Add a repeatable CI launch probe that boots the dev client headlessly far enough to assert FML load and coremod transformation.",
      "Keep the current JAR/hash verifier, but make the in-game checklist a required release gate alongside it.",
    ],
    verification: [
      "A clean instance reaches the main menu with no log errors.",
      "The hub opens and all 34 rows render at 100%, 150% and 200% GUI scale.",
      "`/velor selftest` reports every hook state, not 'unknown'.",
    ],
    tags: ["release-gate", "qa", "canary"],
  },
  {
    id: "SV-002",
    title: "Left-clicking while holding a Spirit Leap sends a use action",
    severity: "critical",
    area: "Runtime",
    component: "Spirit Leap",
    file: "PekaClientMod.java",
    lines: "335–356",
    phase: 1,
    effort: "S",
    confidence: "High",
    summary:
      "A global mouse handler intercepts every left-click in a dungeon and calls sendUseItem when the held item name contains 'spirit leap'. The path has no feature toggle and does not cancel the normal attack.",
    evidence:
      "onMouse() checks button 0, currentScreen == null and DungeonContext.inDungeon(), then calls LeapUse.markUsed() and mc.playerController.sendUseItem(...) whenever the held display name matches. The explicit LEAP_KEY is a separate, default-unbound path.",
    code: "if (held != null && LeapUse.isLeapItemName(held.getDisplayName())) {\n    LeapUse.markUsed();\n    mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, held);\n}",
    impact:
      "Players can trigger a leap accidentally while attacking, mining or trying to open a menu. That wastes a consumable, teleports the party member unexpectedly and can wipe a run. It is also a hidden interaction the user never opted into.",
    fix: [
      "Delete the left-click route. Interaction should remain vanilla.",
      "Make the Spirit Leap selector require the explicit LEAP_KEY plus `AppleSettings.leapKey`.",
      "Add a short chat confirmation and a 500 ms debounce so a held key cannot double-use.",
      "Cover the policy with a pure-logic test: wrong button, no item, not in dungeon and feature disabled all return false.",
    ],
    verification: [
      "Holding a Spirit Leap and left-clicking a mob never opens the picker.",
      "The configured leap key is the only way the mod initiates a leap.",
      "The vanilla right-click use path still opens the server menu.",
    ],
    tags: ["input", "spirit-leap", "least-surprise"],
  },
  {
    id: "SV-003",
    title: "Automation is still shipped, even though it defaults to off",
    severity: "high",
    area: "Release",
    component: "Terminal Assist + Auto Sprint",
    file: "DungeonTerminalAssistController.java",
    lines: "96–110",
    phase: 1,
    effort: "S",
    confidence: "High",
    summary:
      "The mod can automatically call windowClick on a parsed terminal target and can programmatically hold the sprint key. Default-off flags reduce exposure, but the capability is a server-rule and account-safety problem for a public client.",
    evidence:
      "terminalAutoClick is gated by terminal hints, F7/M7 detection, a changed container fingerprint and a cooldown, but the call is still a real client click. AutoSprint writes KeyBinding.setKeyBindState directly. README:27 acknowledges these need user review.",
    code: "if (!TerminalAssistPolicy.allowAutoClick(true, AssistSettings.terminalAutoClick, ...)) return;\n...\nmc.playerController.windowClick(context.container.windowId, target.slotNumber, 0, 0, mc.thePlayer);",
    impact:
      "Fakepixel and Hypixel treat macros and automated clicks as cheating. A user who enables a visible setting can be banned, and the author inherits the support burden. Guard rails do not change the server rule.",
    fix: [
      "Remove terminal auto-click from public builds. Keep the passive highlight and optional wrong-click block.",
      "If automation must exist, isolate it in a private developer build, behind a typed consent screen and an unmistakable warning.",
      "Keep Auto Sprint opt-in, but document that it holds the normal key and no custom packets are sent.",
      "State the server-rule stance in the README, mod menu and each setting's tooltip.",
    ],
    verification: [
      "The public JAR has no reachable auto-click code path.",
      "A fresh config has all gameplay assists off.",
      "The hub cannot enable automation without the warning screen.",
    ],
    tags: ["automation", "bannable", "defaults"],
  },
  {
    id: "SV-004",
    title: "Terminal Assist never clears its cached container",
    severity: "high",
    area: "Dungeon",
    component: "Terminal Assist cache",
    file: "DungeonTerminalAssistController.java",
    lines: "36–41, 133–145",
    phase: 1,
    effort: "S",
    confidence: "High",
    summary:
      "cachedContainer, cachedFingerprint, cached Context, lastAutoFingerprint and lastAutoSlot live for the controller's lifetime. There is no GuiOpen, disconnect or world-unload reset.",
    evidence:
      "The controller is a single instance registered on the Forge bus. context() caches by object identity and fingerprint. The auto-click suppression compares against lastAutoFingerprint/lastAutoSlot, which are never reset when the screen closes or the chest changes.",
    code: "private ContainerChest cachedContainer;\nprivate int lastAutoFingerprint = Integer.MIN_VALUE;\nprivate int lastAutoSlot = -1;\n\nif (container == cachedContainer && fingerprint == cachedFingerprint && cached != null) return cached;",
    impact:
      "After leaving a dungeon, the mod still retains a container and its lower inventory. On a later terminal with an identical title and item layout, the stale suppression can skip a valid click. Highlights can also be computed from a cache that no longer belongs to the current session.",
    fix: [
      "Reset all five fields in a `GuiOpenEvent` handler when the new screen is not the same container, and on `WorldEvent.Unload` / client disconnect.",
      "Key the cache by container identity + windowId + world identity instead of identity alone.",
      "Clear lastAutoFingerprint/lastAutoSlot on every terminal exit and after a failed parse.",
      "Add a regression test around cache invalidation, not just the parser.",
    ],
    verification: [
      "Open a chest, close it, reopen it: a fresh parse occurs.",
      "Change worlds and run `/velor selftest`: status is idle, not a stale terminal.",
      "A 30-minute dungeon soak shows no container retention in a heap dump.",
    ],
    tags: ["cache", "lifecycle", "memory"],
  },
  {
    id: "SV-005",
    title: "Controls rebinds can revert after the next launch",
    severity: "high",
    area: "Config",
    component: "Item Lock keybind",
    file: "PekaClientMod.java",
    lines: "161–164, 227–230",
    phase: 1,
    effort: "S",
    confidence: "High",
    summary:
      "The client tick mirrors the live KeyBinding code into ItemLockSwapSettings, but never persists it. On startup the config value overwrites the KeyBinding again.",
    evidence:
      "init() calls ITEM_LOCK_SWAP_KEY.setKeyCode(ItemLockSwapSettings.keyCode). onClientTick mirrors KeyBinding -> settings in memory. `AppleSettings.save()` is called by GUI interactions and the lock gesture, not on shutdown. A rebind followed by a quit is lost.",
    code: "// init(): config wins\nITEM_LOCK_SWAP_KEY.setKeyCode(ItemLockSwapSettings.keyCode);\n\n// tick: memory only\nif (ItemLockSwapSettings.keyCode != ITEM_LOCK_SWAP_KEY.getKeyCode()) {\n    ItemLockSwapSettings.keyCode = ITEM_LOCK_SWAP_KEY.getKeyCode();\n}",
    impact:
      "A user changes the key in Options → Controls, restarts, and the old key returns. Worse, the two sources can disagree during the session, making the gesture appear unreliable.",
    fix: [
      "Choose one source of truth. Prefer Minecraft's keybind store for key codes.",
      "Persist a deferred config save when the tick detects a real change (debounced, e.g. 500 ms).",
      "Remove the startup overwrite unless the config file is explicitly imported.",
      "Add a test for load → rebind → save → restart symmetry.",
    ],
    verification: [
      "Rebind L to K in Controls, quit, relaunch: K is still bound.",
      "The feature accepts K in an inventory and the L key no longer locks.",
      "No duplicate save on every tick.",
    ],
    tags: ["keybinds", "persistence", "controls"],
  },
  {
    id: "SV-006",
    title: "Four ASM transformers have no runtime integration test",
    severity: "high",
    area: "Runtime",
    component: "Coremod hooks",
    file: "ItemAnimationTransformer.java",
    lines: "14–75",
    phase: 2,
    effort: "M",
    confidence: "High",
    summary:
      "Item Animation, block particles, visual assists and Item Lock/Swap all patch 1.8.9 bytecode. Tests inspect transformer source/signatures, while the verifier checks SRG mapping in the JAR; neither executes a transformed class against the real renderer.",
    evidence:
      "The transformer selects methods by MCP/SRG/notch names and descriptors and hooks with COMPUTE_MAXS only. The headless suites cannot construct ItemRenderer or exercise the callback ordering with OptiFine, another coremod, or a changed deobfuscation environment.",
    code: "ClassWriter writer = new ClassWriter(reader, ClassWriter.COMPUTE_MAXS);\n...\nif (!renderMatrixInjected || !renderCleanupInjected) {\n    ItemAnimationHookStatus.fail(\"balanced render matrix hooks ...\");\n}",
    impact:
      "A hook can fail closed (feature silently missing) or fail badly (crash / broken hand rendering). The user-facing symptom is hard to attribute, and the release has no compatibility matrix.",
    fix: [
      "Add a Gradle `runClient` smoke profile that asserts every hook status at startup and exits non-zero on FAILED.",
      "Test with and without OptiFine on a locked, documented mod list; record the matrix.",
      "Use COMPUTE_FRAMES or a checked writer if stack-map frames are needed by modified classes.",
      "Expose one consolidated hook report in the hub, not just chat, and copy it to the clipboard for support.",
    ],
    verification: [
      "A dev client logs ACTIVE for every transformer before joining a world.",
      "The same smoke run passes with OptiFine installed.",
      "`/velor itemdebug` reports ACTIVE and a changing frame count.",
    ],
    tags: ["coremod", "asm", "compatibility"],
  },
  {
    id: "SV-007",
    title: "Dungeon Sync points at a personal workers.dev endpoint",
    severity: "high",
    area: "Network",
    component: "Dungeon Sync",
    file: "AssistSettings.java",
    lines: "14",
    phase: 1,
    effort: "S",
    confidence: "High",
    summary:
      "The durable default is a Cloudflare Workers subdomain owned by an individual. The feature is off by default and hashes names, but enabling it trusts a private service whose source and retention policy are not in the repo.",
    evidence:
      "DEFAULT_SYNC_ENDPOINT = wss://skyvelor-dungeon-sync.bombadzalge.workers.dev/ws. docs/DUNGEON_SYNC.md describes the transport and what leaves the client, but not who operates the worker, logging, retention or a takedown/privacy contact.",
    code: "public static final String DEFAULT_SYNC_ENDPOINT =\n    \"wss://skyvelor-dungeon-sync.bombadzalge.workers.dev/ws\";",
    impact:
      "A personal dependency can disappear or change without review. Users cannot assess data handling. Even hashed session IDs plus coordinates are third-party telemetry, and the feature sits next to dungeon automation in a mod that already carries ban risk.",
    fix: [
      "Remove the hard-coded third-party endpoint. Require an explicit user-provided URL and show the exact data payload before connecting.",
      "If the feature stays official, publish the worker source, retention policy and a project-owned domain.",
      "Rename it to make clear it sends data off-device, and never initialize a socket until enabled.",
      "Add an offline mode / disable switch that clears queued data immediately.",
    ],
    verification: [
      "A fresh config makes zero DNS or socket calls.",
      "Enabling requires a visible consent screen listing fields sent.",
      "Disabling or changing worlds closes the socket and clears the inbound queue.",
    ],
    tags: ["privacy", "network", "third-party"],
  },
  {
    id: "SV-008",
    title: "No Hurt Cam fallback mutates player.hurtTime every tick",
    severity: "medium",
    area: "Runtime",
    component: "Visual Assist",
    file: "VisualAssistHooks.java",
    lines: "27–34",
    phase: 2,
    effort: "S",
    confidence: "High",
    summary:
      "If the narrow camera transformer is unavailable, the fallback zeros EntityPlayerSP.hurtTime while enabled. That is an entity/gameplay field, not a camera-only value, and it is written from the client tick loop.",
    evidence:
      "zeroFallbackVisualTilt() calls player.hurtTime = 0 whenever the feature is on and the hook is inactive. Vanilla uses hurtTime for the local hurt flash/animation; other mods may read it too.",
    code: "public static void zeroFallbackVisualTilt(Minecraft mc) {\n    if (!shouldUseVisualFallback(AssistSettings.noHurtCamera, ...)) return;\n    ...\n    if (player.hurtTime > 0) player.hurtTime = 0;\n}",
    impact:
      "Damage feedback can disappear, other visual mods can behave incorrectly, and the code contradicts the 'visual-only, damage untouched' claim. A stale fallback can mask a broken hook instead of reporting it.",
    fix: [
      "Delete the field mutation. If the camera hook is unavailable, leave vanilla behaviour and mark the feature FAILED.",
      "Keep the render-only suppression inside the verified transformer path.",
      "Show the failure in `/velor selftest` and the General settings status.",
    ],
    verification: [
      "Disabling the core hook leaves the hurt camera unchanged.",
      "A damage test still plays the hurt flash.",
      "Selftest reports FAILED rather than silently forcing the fallback.",
    ],
    tags: ["rendering", "visual-assist", "side-effects"],
  },
  {
    id: "SV-009",
    title: "Config writes are synchronous and failures are discarded",
    severity: "medium",
    area: "Config",
    component: "AppleSettings",
    file: "AppleSettings.java",
    lines: "440–511",
    phase: 2,
    effort: "M",
    confidence: "High",
    summary:
      "The atomic writer is good, but AppleSettings.save() ignores its boolean result and can be invoked from GUI interaction paths. Users get no signal when the disk rejects a write.",
    evidence:
      "ConfigFiles.writeAtomic returns false on a null target, mkdir failure, write failure or move failure. The only call in AppleSettings discards the return value. Some saves happen while handling settings controls and inventory gestures.",
    code: "ConfigFiles.writeAtomic(\n    new File(dir(), FILE_NAME), p, \"Sky VeLor settings\");\n// return value unused everywhere",
    impact:
      "A read-only .minecraft folder, full disk or antivirus lock silently loses settings. Repeated synchronous saves can also produce small hitches on slow disks.",
    fix: [
      "Capture the write result and surface a non-blocking warning with the target path and error class.",
      "Debounce saves from toggles/sliders; keep an explicit flush on screen close, world unload and client stop.",
      "Move disk I/O to one daemon writer thread with an atomic replace and a bounded queue.",
      "Add a test that a failed write leaves the in-memory state intact and reports failure.",
    ],
    verification: [
      "A read-only config directory produces a visible, copyable warning.",
      "Spam-clicking a slider does not write for every click.",
      "Quitting after a change flushes the latest state at least once.",
    ],
    tags: ["persistence", "io", "reliability"],
  },
  {
    id: "SV-010",
    title: "Dungeon detection is one substring: 'catacombs'",
    severity: "medium",
    area: "Dungeon",
    component: "DungeonContext",
    file: "DungeonContext.java",
    lines: "122–166",
    phase: 2,
    effort: "M",
    confidence: "High",
    summary:
      "Any visible sidebar line or title containing 'catacombs' makes inDungeon() true. There is no server identity, objective-name or layout fingerprint beyond that string.",
    evidence:
      "isCatacombsLine() strips colour and checks line.contains(\"catacombs\"). evaluateSidebar() accepts a title or any line. The result gates terminal overlays, Spirit Leap replacement and dungeon sync.",
    code: "public static boolean isCatacombsLine(String rawLine) {\n    if (rawLine == null) return false;\n    String line = LeapText.strip(rawLine).toLowerCase(Locale.ROOT);\n    return line.contains(\"catacombs\");\n}",
    impact:
      "Another server, a quest scoreboard or a mod that displays lore can enable dungeon-only behaviour. Because Fakepixel exposes no API, a layout change can also disable every dungeon feature without a clear error.",
    fix: [
      "Require a multi-signal fingerprint: server host allow-list + objective title + at least two known stat lines (floor, class, health).",
      "Make the signal fail closed and expose the matched signal in `/velor dungeon` diagnostics.",
      "Centralize sidebar parsing behind a versioned adapter with captured fixtures, so one server update is one change.",
      "Distinguish 'not in dungeon' from 'unknown layout' in the UI.",
    ],
    verification: [
      "A custom scoreboard containing 'catacombs' does not enable dungeon features.",
      "Changing the sidebar order does not break detection when the fingerprint still matches.",
      "`/velor selftest` shows which signals matched.",
    ],
    tags: ["parsing", "no-api", "false-positive"],
  },
  {
    id: "SV-011",
    title: "Runtime-heavy modules have no executed tests",
    severity: "medium",
    area: "Code health",
    component: "Test strategy",
    file: "tests/run-tests.sh",
    lines: "1–80",
    phase: 2,
    effort: "M",
    confidence: "High",
    summary:
      "The 65 suites cover pure policies, config, chat models and transformer source inspection. Dungeon Sync, inventory assist, mining assist, movement assist, command handling and real GUI/render input have zero executed tests.",
    evidence:
      "The test tree contains no suites under assist/sync, assist/inventory, assist/mining, assist/movement or command. Render/itemanimation has no test class of its own. The runner never starts a Minecraft client.",
    code: "# 65 suite invocations; all are pure JVM main() programs\njava -cp \"$OUT:$CP\" com.arena.pekaclient.itemlockswap.ItemLockSwapProtectionPolicyTests\njava -cp \"$OUT:$CP\" com.arena.pekaclient.gui.ReleaseClaimsTests\n# no assist.sync / assist.inventory / launch harness",
    impact:
      "The features with the most failure modes — sockets, reflection, screen replacement, input hooks — are exactly the least proven. Regressions are found by users, often through crashes.",
    fix: [
      "Add a loopback WebSocket integration suite for the handshake, masked frames, fragmentation limits, close and reconnect.",
      "Create a tiny GuiScreen input harness that can exercise click/key routing without a full render.",
      "Add golden ASM tests that load the patched class in an isolated classloader and invoke a stub.",
      "Publish a coverage map so every package has an owner and at least one smoke path.",
    ],
    verification: [
      "CI fails if an assist package has no test.",
      "The sync client passes localhost handshake, reject, truncation and reconnect cases.",
      "Transformer tests verify injected bytecode, not only transformer source text.",
    ],
    tags: ["tests", "coverage", "integration"],
  },
  {
    id: "SV-012",
    title: "Licensing story and release docs do not match the archive",
    severity: "medium",
    area: "Docs",
    component: "Distribution",
    file: "README.md",
    lines: "156–158",
    phase: 2,
    effort: "S",
    confidence: "High",
    summary:
      "The distribution mixes MIT, LGPL-derived files and AGPL/GPL third-party components. The README names only two license files, neither an SPDX story nor a complete notice manifest. Docs also omit two shipped Hub rows.",
    evidence:
      "The source archive has LICENSE (MIT) and a Better NEF LGPL notice but no LICENSE.txt promised by the README. The JAR carries LICENSE-SKYTILS-AGPL-3.0.txt, LICENSE-CHATTING-GPL-3.0.txt and THIRD_PARTY_NOTICES-CHAT.txt, but the Better NEF notice is source-only. docs/FEATURE-SETTINGS-EDITOR.md tables 32 Hub rows; the model now has 34 with no-hurt-cam and auto-sprint.",
    code: "// README.md:158\nBoth LICENSE and LICENSE.txt are retained... (MIT and LGPL v3)\n\n// Source root: LICENSE (MIT), THIRD_PARTY_NOTICES/Better-NEF...; no LICENSE.txt\n// JAR META-INF:\n//   LICENSE-SKYTILS-AGPL-3.0.txt\n//   LICENSE-CHATTING-GPL-3.0.txt\n//   THIRD_PARTY_NOTICES-CHAT.txt\n// FeatureSettingsUiModel: 34 rows; docs table: 32",
    impact:
      "Downstream pack authors cannot tell what outbound terms apply. AGPL, GPL and LGPL components impose obligations that a single MIT LICENSE does not express. Stale docs erode trust in the release notes and in every other claim.",
    fix: [
      "Produce one license manifest: outbound LICENSE, per-component SPDX identifiers and required source/notice obligations.",
      "Make README, GitHub metadata, source ZIP, delivery ZIP and JAR agree; remove the missing LICENSE.txt claim.",
      "Ship the Better NEF LGPL notice in the same surfaces as the AGPL/GPL notices, or remove the derived files.",
      "Regenerate the feature table from FeatureSettingsUiModel (or add a test that compares them).",
    ],
    verification: [
      "`unzip -l` shows the notices in JAR and delivery ZIP.",
      "README and archive list the same license files.",
      "The docs table row count equals the 34 model rows.",
    ],
    tags: ["license", "docs", "distribution"],
  },
  {
    id: "SV-013",
    title: "The GUI is a 9.4k-LOC surface with two God screens",
    severity: "low",
    area: "Code health",
    component: "Settings UI",
    file: "gui/HudEditorScreen.java",
    lines: "1–1664",
    phase: 3,
    effort: "L",
    confidence: "High",
    summary:
      "The gui package is 38 files and 9,395 LOC. HudEditorScreen is 1,664 lines, AppleHubScreen 1,223, ChatChannelTabs 1,138 and LeapScreen 995. The release rewrote editors again.",
    evidence:
      "These files hold layout, state, input, rendering and persistence. The changelog for 0.10.8.9 rewrites the editors while the same release is untested in-game.",
    code: "gui/                     38 files   9,395 LOC   15 test suites\nHudEditorScreen.java            1,664 LOC\nAppleHubScreen.java             1,223 LOC\nChatChannelTabs.java            1,138 LOC\nLeapScreen.java                   995 LOC",
    impact:
      "Every settings change risks a layout regression at a new GUI scale, and debugging input/state coupling is slow. Large render methods also make performance work harder.",
    fix: [
      "Extract pure layout models and route tables; keep draw methods thin.",
      "Split HudEditorScreen into selection, inspector, render and persistence collaborators.",
      "Add screenshot golden tests at 100/150/200% scale (or at least deterministic geometry assertions).",
      "Freeze new settings features for 0.10.9 and spend the cycle on reliability.",
    ],
    verification: [
      "No GUI class exceeds an agreed line/cyclomatic threshold.",
      "A geometry test covers every hub row and editor pane at all scales.",
      "Manual UI pass fits on one page of the QA checklist.",
    ],
    tags: ["maintainability", "gui", "scope"],
  },
  {
    id: "SV-014",
    title: "Fakepixel gating is a substring check on the typed server address",
    severity: "low",
    area: "Runtime",
    component: "Wardrobe / Pets shortcuts",
    file: "ShortcutController.java",
    lines: "24–31",
    phase: 3,
    effort: "S",
    confidence: "High",
    summary:
      "Shortcuts are enabled when serverIP contains 'fakepixel'. Numeric IPs or proxies disable them; any unrelated host with that substring enables them.",
    evidence:
      "isFakepixel() lowercases the current ServerData.serverIP and checks indexOf(\"fakepixel\") >= 0. The server IP is whatever the user typed, including aliases and port strings.",
    code: "return data != null && data.serverIP != null\n    && data.serverIP.toLowerCase(Locale.ROOT).indexOf(\"fakepixel\") >= 0;",
    impact:
      "A user behind a proxy loses the shortcuts, while a mistyped or malicious address that includes the token could receive /wardrobe or /pets. The check is weak least-privilege.",
    fix: [
      "Normalize host (strip port, lowercase, punycode) and compare against an explicit allow-list.",
      "Allow a manual override in settings with a clear 'send this command only on the current server' consent.",
      "Never send a command automatically; keep every action on a key press.",
    ],
    verification: [
      "Numeric and proxied addresses can be enabled explicitly.",
      "`fakepixel.evil.example` does not pass.",
      "No shortcut fires on a server mismatch.",
    ],
    tags: ["server-gate", "least-privilege", "input"],
  },
  {
    id: "SV-015",
    title: "84 catch blocks, five printlns and no support-grade error journal",
    severity: "low",
    area: "Code health",
    component: "Observability",
    file: "src/main/java",
    lines: "84 × catch",
    phase: 2,
    effort: "M",
    confidence: "High",
    summary:
      "Many failures are intentionally fail-closed, but diagnostics are scattered across chat, log4j and System.out. There is no single rate-limited error journal or support bundle.",
    evidence:
      "Static scan: 84 catch blocks, 31 synchronized blocks, 5 System.out calls, comments like 'fail closed'. `/velor selftest` reports hook status but not the last render/parse/save errors or a versioned support report.",
    code: "84 catch (...) blocks\n31 synchronized\n5 System.out.println\n0 global error-rate counters",
    impact:
      "When a user reports 'the HUD is gone', the author has to reconstruct the hook state from chat. Silent catches can hide real bugs until they become widespread.",
    fix: [
      "Introduce one namespaced logger and a ring buffer of the last ~50 warnings with subsystem tags.",
      "Add `/velor report` to copy version, artifact hash, hook status, last warnings and relevant config to the clipboard.",
      "Rate-limit repeated failures and distinguish intentional fallback from unexpected errors.",
      "Never include player names or server IDs in the report.",
    ],
    verification: [
      "Every new catch either handles and recovers or logs with a subsystem tag.",
      "A copyable report includes no personal data.",
      "Support can identify whether a feature is OFF, FAILED or unsupported from one message.",
    ],
    tags: ["observability", "support", "logging"],
  },
  {
    id: "SV-016",
    title: "CI has write permission and commits release artifacts to the branch",
    severity: "low",
    area: "CI",
    component: "Build workflow",
    file: ".github/workflows/build.yml",
    lines: "12–14, 229–262",
    phase: 2,
    effort: "M",
    confidence: "High",
    summary:
      "The workflow runs on push, pull_request and workflow_dispatch with contents: write, then copies the JAR, delivery ZIP and source ZIP back into dist/ on the branch.",
    evidence:
      "Top-level permissions grant write access to every job. The publish step commits to the branch and release tags are created from workflow context. The branch head is a bot publish commit (80b8b1a), not the source commit.",
    code: "permissions:\n  contents: write\n...\ncp -v \"build/libs/$JAR_NAME\" \"dist/$JAR_NAME\"\ncp -v \"build/delivery/$ZIP_NAME\" \"dist/$ZIP_NAME\"",
    impact:
      "A compromised build dependency or same-repo PR has a write-capable token. Auto-commits make branch heads mutable and artifact provenance harder to reason about. The audit had to distinguish the publish commit from source commit c80c65b.",
    fix: [
      "Split read-only build/test and write-only publish jobs; gate publish behind an environment and review.",
      "Publish artifacts (GitHub Artifacts/Release) instead of committing binaries to the branch.",
      "Pin actions by SHA, restrict workflow inputs and require signed tags for releases.",
      "Attach a checksum + provenance attestation and make the JAR verification independent of branch writes.",
    ],
    verification: [
      "Build jobs have contents: read.",
      "A source commit produces an immutable artifact with checksum and provenance.",
      "Publishing requires explicit approval and cannot mutate source files.",
    ],
    tags: ["supply-chain", "ci", "provenance"],
  },
  {
    id: "SV-017",
    title: "The settings Hub asks for 34 equal-weight decisions on one screen",
    severity: "medium",
    area: "Code health",
    component: "Settings Hub",
    file: "gui/FeatureSettingsUiModel.java",
    lines: "84–190",
    phase: 3,
    effort: "M",
    confidence: "High",
    summary:
      "Seven top-level tabs and 34 flat rows present diagnostics, presets, network features and everyday comfort with the same visual weight. The player has to learn the implementation to find the setting they want.",
    evidence:
      "FeatureSettingsUiModel registers 34 visible Hub features across 7 categories, including five diagnostics/commands surfaces and several advanced assists. Beta-0.10.8.9 changed presentation twice but kept the same equal-weight inventory.",
    code: "// FeatureSettingsUiModel — 34 features / 7 tabs\nGeneral, Quality of Life, HUD, Farming, Dungeon, Slayer, Fishing\n// Simple rows and one-level dropdowns all render at the same hierarchy.",
    impact:
      "First-run configuration is confusing, unsafe options (automation, network) sit beside harmless ones, and support questions become 'where is X?' rather than 'does X work?'. A crowded screen also makes every layout regression more likely.",
    fix: [
      "Adopt the GUI revamp concept: Home plus Gameplay, Dungeon, Visuals, System.",
      "Group the 34 routes into 17 outcome-focused cards, with presets on Home.",
      "Put advanced/diagnostic controls behind one explicit Advanced switch.",
      "Keep every config key, range and default unchanged; prove 34/34 route parity before deleting the old Hub.",
    ],
    verification: [
      "A new user can configure a first session from Home in under a minute.",
      "No diagnostic or network control appears in the default view.",
      "The parity test resolves all 34 legacy option IDs to exactly one reachable route.",
      "GUI scale 1–3 has no clipped labels or overlapping hitboxes.",
    ],
    tags: ["gui", "information-architecture", "settings"],
  },
];

export const DEFAULT_PLANNED = [
  "SV-001",
  "SV-002",
  "SV-003",
  "SV-004",
  "SV-005",
  "SV-006",
  "SV-007",
  "SV-012",
  "SV-017",
];

export const PHASES: Record<
  Phase,
  { title: string; eyebrow: string; description: string; done: string }
> = {
  1: {
    eyebrow: "Before any public build",
    title: "Stabilize",
    description: "Remove the unsafe interaction path, prove the client starts, and make the release honest about what it is.",
    done: "Clean launch + safety review + no critical findings.",
  },
  2: {
    eyebrow: "Before a wider release",
    title: "Verify",
    description: "Close runtime test gaps, fix persistence and lifecycle edges, and reconcile distribution documentation.",
    done: "Runtime smoke coverage + docs/license match + no high findings.",
  },
  3: {
    eyebrow: "Polish and maintenance",
    title: "Harden",
    description: "Reduce the GUI blast radius, strengthen server detection, and make user support possible without guesswork.",
    done: "Maintainability budget + observability + a full QA pass.",
  },
};

export const SEVERITY_ORDER: Record<Severity, number> = {
  critical: 0,
  high: 1,
  medium: 2,
  low: 3,
};

export const SEVERITY_META: Record<
  Severity,
  { label: string; color: string; bg: string; border: string }
> = {
  critical: {
    label: "Critical",
    color: "#ff8a81",
    bg: "rgba(255, 122, 112, 0.1)",
    border: "rgba(255, 122, 112, 0.32)",
  },
  high: {
    label: "High",
    color: "#f2b35c",
    bg: "rgba(242, 179, 92, 0.1)",
    border: "rgba(242, 179, 92, 0.3)",
  },
  medium: {
    label: "Medium",
    color: "#75baff",
    bg: "rgba(117, 186, 255, 0.1)",
    border: "rgba(117, 186, 255, 0.28)",
  },
  low: {
    label: "Low",
    color: "#a9bdae",
    bg: "rgba(169, 189, 174, 0.08)",
    border: "rgba(169, 189, 174, 0.22)",
  },
};

export const STATUS_META: Record<FindingStatus, { label: string; color: string; dot: string }> = {
  open: { label: "Open", color: "#ffb3ad", dot: "#ff7a70" },
  planned: { label: "In plan", color: "#f2d09b", dot: "#f2b35c" },
  fixed: { label: "Fixed", color: "#9ff0bb", dot: "#64e08d" },
  accepted: { label: "Accepted risk", color: "#a9bdae", dot: "#7b8f82" },
};

export const MODULES: AuditModule[] = [
  {
    id: "gui",
    name: "GUI & screens",
    packages: ["gui", "widget", "notes"],
    files: 50,
    loc: 11522,
    suites: 18,
    risk: "high",
    summary: "Hub, HUD editor, feature editors, leap picker, chat editor and quick notes. The largest and most frequently rewritten surface.",
    signal: "1,664 LOC in HudEditorScreen alone. Heavy layout + input + persistence coupling.",
    tags: ["swing", "layout", "input"],
  },
  {
    id: "feature",
    name: "Feature logic & trackers",
    packages: ["feature", "fishing", "slayer"],
    files: 31,
    loc: 5433,
    suites: 15,
    risk: "medium",
    summary: "Spirit Leap policy, item animation model, dungeon context, fishing, slayer and shared feature policies.",
    signal: "Good pure-policy test coverage. Server-facing assumptions still need live fixtures.",
    tags: ["trackers", "parsing", "policy"],
  },
  {
    id: "dungeon-core",
    name: "Dungeon core",
    packages: ["dungeon", "dungeonesp"],
    files: 20,
    loc: 4580,
    suites: 4,
    risk: "high",
    summary: "Map rooms, puzzle labels, floor overlays, boss/dragon alerts and cached entity/door ESP.",
    signal: "Cached scanning is the right direction; only four suites back a very large render/parsing surface.",
    tags: ["esp", "map", "rooms"],
  },
  {
    id: "dungeon-assist",
    name: "Dungeon assist",
    packages: ["assist/dungeon", "assist/mining"],
    files: 9,
    loc: 1126,
    suites: 1,
    risk: "critical",
    summary: "Boss HP parsing, terminal highlight/block/auto-click, waypoints and the mining assistant.",
    signal: "Highest account-risk surface. One parser test and no runtime input test.",
    tags: ["terminal", "automation", "boss-hp"],
  },
  {
    id: "dungeon-sync",
    name: "Dungeon Sync",
    packages: ["assist/sync"],
    files: 7,
    loc: 975,
    suites: 0,
    risk: "medium",
    summary: "Custom Java 8 TLS WebSocket transport, session identity, protocol allow-lists and map integration.",
    signal: "Solid defensive coding, but no socket test and a personal default endpoint.",
    tags: ["wss", "privacy", "threading"],
  },
  {
    id: "itemlock",
    name: "Item Lock & Swap",
    packages: ["itemlockswap"],
    files: 17,
    loc: 2181,
    suites: 7,
    risk: "high",
    summary: "17-class input/overlay/protection stack with a window-click ASM guard, paired slots and persistent bindings.",
    signal: "Best-tested assist module. The remaining risk is keybind/config divergence and fail-closed UX.",
    tags: ["asm", "inventory", "gesture"],
  },
  {
    id: "hud",
    name: "HUD & telemetry",
    packages: ["hud", "startup"],
    files: 15,
    loc: 1857,
    suites: 5,
    risk: "medium",
    summary: "Movable HUD elements, player doll, inventory HUD, config and startup task runner.",
    signal: "Telemetry was retired/restored across patch releases; config migration needs a stable contract.",
    tags: ["hud", "metrics", "startup"],
  },
  {
    id: "chat",
    name: "Chat QoL",
    packages: ["chat"],
    files: 14,
    loc: 1027,
    suites: 6,
    risk: "medium",
    summary: "Captured history, rounded chat surface, context menu, tabs, clipboard chain and visibility audit.",
    signal: "Well-factored compared with the GUI package. Chat rendering still relies on vanilla bridge behaviour.",
    tags: ["chat", "clipboard", "tabs"],
  },
  {
    id: "config",
    name: "Settings & migration",
    packages: ["config"],
    files: 6,
    loc: 1841,
    suites: 5,
    risk: "high",
    summary: "AppleSettings, AssistSettings, ChatQolSettings, ESP settings, UI preferences and atomic file IO.",
    signal: "Atomic writes and legacy keys are a strength. Save result and source-of-truth rules are not finished.",
    tags: ["properties", "migration", "io"],
  },
  {
    id: "core",
    name: "Core lifecycle",
    packages: ["PekaClientMod", "PekaVersion", "assist", "command"],
    files: 8,
    loc: 881,
    suites: 0,
    risk: "medium",
    summary: "Mod entry point, keybindings, event bus wiring, version contract, client commands and mouse handling.",
    signal: "Responsible for the highest-impact finding in the audit: the left-click use action.",
    tags: ["entrypoint", "events", "keybinds"],
  },
  {
    id: "render",
    name: "Render & bytecode hooks",
    packages: ["render", "render/itemanimation", "render/blockparticles"],
    files: 14,
    loc: 2069,
    suites: 2,
    risk: "critical",
    summary: "Theme, UI render helpers, item animation ASM hooks and block particle transformation.",
    signal: "No real class-loader integration test. Compatibility is the top unknown for 1.8.9 clients.",
    tags: ["asm", "coremod", "optifine"],
  },
  {
    id: "assists",
    name: "Inventory & visual assists",
    packages: ["assist/inventory", "assist/visual", "assist/movement"],
    files: 11,
    loc: 957,
    suites: 1,
    risk: "medium",
    summary: "Inventory search, tooltip scroll, rarity tint, potion panel, hurt camera and auto-sprint key state.",
    signal: "Reflection and vanilla field access need a multi-client compatibility pass.",
    tags: ["reflection", "tooltip", "sprint"],
  },
];

export const READINESS = [
  { label: "Runtime confidence", value: 30, note: "No launch or in-game test" },
  { label: "Input & server safety", value: 46, note: "One unsafe route, automation present" },
  { label: "Config & recovery", value: 74, note: "Atomic IO, save result ignored" },
  { label: "Test depth", value: 66, note: "Strong policy, weak runtime coverage" },
  { label: "Parse resilience", value: 52, note: "Catacombs substring gate" },
  { label: "Release hygiene", value: 82, note: "Verified JAR and source ZIP" },
  { label: "Docs & licensing", value: 42, note: "Contradictory license and stale table" },
];

export const CHANGES = [
  {
    title: "Settings presentation rebuilt",
    detail: "Focused editors now use a scrollable pane and scissored Live Preview. This is explicitly presentation-only.",
    tag: "UI",
  },
  {
    title: "Telemetry moved to General",
    detail: "Cached FPS, tab-list ping and Java heap are read-only GUI cards. Retired HUD keys are ignored.",
    tag: "HUD",
  },
  {
    title: "Hub category contract",
    detail: "Still General, Quality of Life, HUD, Farming, Dungeon, Slayer, Fishing. 34 flat rows/focused routes.",
    tag: "UI",
  },
  {
    title: "Reproducible source delivery",
    detail: "A rooted git-archive source ZIP with a verifier, alongside the JAR and delivery ZIP.",
    tag: "Release",
  },
  {
    title: "Cleanup regression suite",
    detail: "ReleaseClaimsTests rechecks retired fonts, sidebar, hotbar and item-protection surfaces.",
    tag: "Tests",
  },
  {
    title: "Version contract",
    detail: "Beta-0.10.8.9v in source and JAR, numeric 0.10.8.9 in generated mcmod.info.",
    tag: "Release",
  },
];

export const STRENGTHS = [
  "Atomic config replacement with legacy-name migration and corrupt-entry salvage.",
  "Fail-closed GUI interception: unknown or ambiguous dungeon state leaves vanilla alone.",
  "Risky gameplay assists are opt-in; no custom movement packets are sent.",
  "Version has one source of truth and the build fails on drift.",
  "CI publishes SHA-256 hashes; the verifier checks mapping, metadata and inventory.",
  "No custom font subsystem or final-field renderer replacement remains.",
  "1,175 headless assertions, zero TODO/FIXME markers in main source.",
  "Thoughtful comments explain why hooks exist and what they deliberately avoid.",
];

export const QA_CHECKS: QaCheck[] = [
  {
    id: "qa-clean-launch",
    group: "Launch",
    label: "Clean Forge launch",
    detail: "Fresh 1.8.9 + Forge 11.15.1.2318 instance, only Sky VeLor installed. No error log; main menu renders.",
  },
  {
    id: "qa-coremods",
    group: "Launch",
    label: "All hooks report ACTIVE",
    detail: "`/velor selftest` shows Item Animation, block particles, Item Lock guard and visual hooks as ACTIVE, not FAILED.",
  },
  {
    id: "qa-hub",
    group: "Surface",
    label: "Hub and keybinds",
    detail: "RS opens the hub; /sv and pause-menu button work; all tabs and 34 rows are reachable at 3 GUI scales.",
  },
  {
    id: "qa-hud",
    group: "Surface",
    label: "HUD editor round-trip",
    detail: "Select, move, scale and toggle every HUD; quit and relaunch; positions and visibility persist.",
  },
  {
    id: "qa-item-animation",
    group: "Surface",
    label: "Item Animation + OptiFine",
    detail: "Multiple swords/tools/blocks, offsets and speed; `/velor itemdebug` ACTIVE; test with OptiFine if supported.",
  },
  {
    id: "qa-chat",
    group: "Surface",
    label: "Chat QoL limits",
    detail: "History order, scroll, context menu, clipboard, tabs, All/Party/Reply filters and chat close/open.",
  },
  {
    id: "qa-skyblock",
    group: "Dungeon",
    label: "Join Fakepixel SkyBlock",
    detail: "Sidebar parse works and no dungeon features activate on the hub island / private island.",
  },
  {
    id: "qa-dungeon",
    group: "Dungeon",
    label: "F7/M7 detection + map",
    detail: "Enter Catacombs, confirm floor detection, map rooms, puzzle labels and no false positives on entry.",
  },
  {
    id: "qa-terminal",
    group: "Dungeon",
    label: "Terminal overlays",
    detail: "With auto-click off, highlights only. Close/reopen a chest, change worlds, and verify no stale cache.",
  },
  {
    id: "qa-leap",
    group: "Safety",
    label: "Spirit Leap no-hijack",
    detail: "Left-clicking with a leap item never uses it. Only the explicit key opens/replaces the leap menu.",
  },
  {
    id: "qa-itemlock",
    group: "Safety",
    label: "Item Lock + keybind restart",
    detail: "Pair/unpair, hotbar/armor moves, Q and Ctrl+Q drops, cooldown; rebind in Controls; quit and relaunch.",
  },
  {
    id: "qa-sync",
    group: "Safety",
    label: "Dungeon Sync consent and lifecycle",
    detail: "Off by default: zero socket creation. Enable, read the payload notice, change world, disable; queue clears.",
  },
  {
    id: "qa-soak",
    group: "Soak",
    label: "30-minute dungeon soak",
    detail: "Reconnect, respawn, lobby → dungeon → lobby. Watch FPS, heap, retained containers and chat log errors.",
  },
  {
    id: "qa-uninstall",
    group: "Soak",
    label: "Uninstall / rollback",
    detail: "Remove the JAR and confirm no crash, no leftover world edits, and config remains readable by the previous build.",
  },
];

export const RELEASE_CHECKS: {
  label: string;
  status: "pass" | "warn" | "fail" | "manual";
  detail: string;
}[] = [
  {
    label: "Version contract",
    status: "pass",
    detail: "PekaVersion.NAME, build.gradle guard and JAR name all read Beta-0.10.8.9v.",
  },
  {
    label: "Forge metadata",
    status: "pass",
    detail: "mcmod.info resolves 0.10.8.9 with mcversion 1.8.9, modid pekaclient, clientSideOnly=true.",
  },
  {
    label: "Coremod registration",
    status: "pass",
    detail: "JAR manifest declares ItemAnimationLoadingPlugin and FMLCorePluginContainsFMLMod=true.",
  },
  {
    label: "Artifact structure",
    status: "pass",
    detail: "397 classes, 436 entries, dungeon rooms asset present, no nested JAR.",
  },
  {
    label: "Source delivery",
    status: "pass",
    detail: "Curated source ZIP exists with verifier; source SHA recorded by this audit.",
  },
  {
    label: "Headless tests",
    status: "warn",
    detail: "65 suites and 1,175 checks are present. This audit did not execute them (no Forge test classpath).",
  },
  {
    label: "In-game smoke pass",
    status: "fail",
    detail: "Not performed. Release notes explicitly say NOT tested in-game.",
  },
  {
    label: "License consistency",
    status: "fail",
    detail: "README names two license files; source has MIT + LGPL notice, JAR carries AGPL/GPL notices. No unified manifest.",
  },
  {
    label: "Artifact provenance",
    status: "warn",
    detail: "Built by CI at c80c65b and republished as bot commit 80b8b1a. Hash available, signature status not published.",
  },
  {
    label: "Server-rule review",
    status: "fail",
    detail: "Auto-click and sprint automation remain reachable; no policy warning in the download.",
  },
];

export const CLAIMS = [
  {
    claim: "The JAR is the real mod, not a ForgeGradle intermediate",
    verdict: "verified" as const,
    detail: "397 classes, mod metadata and coremod manifest match the source. 882,396 bytes, SHA-256 ends in 4a361.",
  },
  {
    claim: "Fakepixel/Hypixel-facing features are only QoL",
    verdict: "partial" as const,
    detail: "Most features are visual. Terminal auto-click and automated sprint are gameplay automation, even if opt-in.",
  },
  {
    claim: "Safe by default",
    verdict: "partial" as const,
    detail: "New assists default off, but the Spirit Leap left-click path has no toggle and is reachable in a dungeon.",
  },
  {
    claim: "Config migration is safe",
    verdict: "verified" as const,
    detail: "Atomic replacement plus legacy file fallback are implemented. The save result is still not surfaced to users.",
  },
  {
    claim: "Dungeon Sync protects identity",
    verdict: "partial" as const,
    detail: "Names are hashed locally and inbound data is allow-listed. The default worker is privately operated and undocumented.",
  },
  {
    claim: "License and notices are complete",
    verdict: "contradicted" as const,
    detail: "README names two license files and omits AGPL/GPL components. The Better NEF LGPL notice is source-only while other notices are JAR-only.",
  },
  {
    claim: "This release is ready for users",
    verdict: "contradicted" as const,
    detail: "The authors themselves state it was not tested in-game. Treat it as a private canary.",
  },
];

export const LARGEST_FILES = [
  { name: "HudEditorScreen.java", loc: 1664, group: "gui" },
  { name: "AppleHubScreen.java", loc: 1223, group: "gui" },
  { name: "ChatChannelTabs.java", loc: 1138, group: "feature" },
  { name: "LeapScreen.java", loc: 995, group: "gui" },
  { name: "M7OverlayRenderer.java", loc: 836, group: "dungeon" },
  { name: "QuickNoteScreen.java", loc: 759, group: "notes" },
  { name: "DungeonMapOverlay.java", loc: 692, group: "dungeon" },
  { name: "AppleSettings.java", loc: 674, group: "config" },
  { name: "ChatEditorScreen.java", loc: 671, group: "gui" },
  { name: "FeatureSettingsEditorScreen.java", loc: 575, group: "gui" },
];

export const METHOD = [
  {
    step: "01",
    title: "Acquire the actual revision",
    detail: "Downloaded the branch source ZIP and the published JAR from dist/ for Beta-0.10.8.9v.",
  },
  {
    step: "02",
    title: "Verify the artifact",
    detail: "Inspected MANIFEST.MF, mcmod.info, entries, class inventory and computed SHA-256 for JAR and source.",
  },
  {
    step: "03",
    title: "Read the risky paths",
    detail: "Traced mouse/keyboard hooks, ASM transformers, terminal automation, config persistence, scoreboard parsing and WSS transport.",
  },
  {
    step: "04",
    title: "Map the tests",
    detail: "Counted 202 source files, 34,449 LOC, 65 test suites and 1,175 headless checks. Mapped zero-coverage assist packages.",
  },
  {
    step: "05",
    title: "Cross-check the claims",
    detail: "Compared README, CHANGELOG, feature docs and license files against code and archive contents.",
  },
  {
    step: "06",
    title: "Separate proof from inference",
    detail: "No Minecraft client was launched. Findings marked High confidence describe what the code does; runtime impact still needs a game pass.",
  },
];

export const VERDICT = {
  label: "Conditional — private canary only",
  short: "Not ready for a public release",
  summary:
    "Beta-0.10.8.9 is a well-documented, structurally verified build with unusually careful failure handling. It is not in-game validated, and two behaviours should be removed before users touch it: the left-click leap and reachable terminal automation.",
};

export function formatBytes(value: number): string {
  return `${(value / 1024).toFixed(1)} KiB`;
}

export function shortHash(value: string): string {
  return `${value.slice(0, 10)}…${value.slice(-6)}`;
}

export const FILTER_AREAS: Area[] = [
  "Release",
  "Runtime",
  "Dungeon",
  "Config",
  "Network",
  "Code health",
  "Docs",
  "CI",
];
