import type { IconName } from "../components/Icons";

export type GuiTabId = "home" | "gameplay" | "dungeon" | "visuals" | "system";
export type SettingControl = "switch" | "slider" | "action" | "choice" | "info";

export interface GuiSetting {
  id: string;
  label: string;
  description: string;
  control?: SettingControl;
  value?: boolean;
  number?: number;
  min?: number;
  max?: number;
  step?: number;
  suffix?: string;
  advanced?: boolean;
  badge?: string;
  actionLabel?: string;
  options?: string[];
  children?: GuiSetting[];
  notice?: string;
}

export interface GuiCard {
  id: string;
  title: string;
  subtitle: string;
  icon: IconName;
  settings: GuiSetting[];
  advanced?: boolean;
  notice?: { tone: "info" | "warn" | "success"; text: string };
}

export interface GuiTab {
  id: GuiTabId;
  label: string;
  icon: IconName;
  caption: string;
  cards: GuiCard[];
}

export const GUI_TABS: GuiTab[] = [
  {
    id: "home",
    label: "Home",
    icon: "overview",
    caption: "Presets and the handful of switches you touch most.",
    cards: [],
  },
  {
    id: "gameplay",
    label: "Gameplay",
    icon: "spark",
    caption: "Comfort, inventory, chat and skill trackers — the everyday surface.",
    cards: [
      {
        id: "comfort",
        title: "Comfort",
        subtitle: "Tiny adjustments that remove friction without changing how the game plays.",
        icon: "spark",
        settings: [
          {
            id: "no-block-particles",
            label: "Quiet block particles",
            description: "Hide only the digging and crack particles when a block breaks.",
            value: false,
          },
          {
            id: "disable-hotbar-scrolling",
            label: "Lock hotbar to keys",
            description: "Ignore the mouse wheel while playing so your selected slot never jumps.",
            value: false,
          },
          {
            id: "no-hurt-cam",
            label: "Steady camera on damage",
            description: "Remove the local camera tilt when you take a hit. Damage and knockback are untouched.",
            value: false,
          },
          {
            id: "auto-sprint",
            label: "Sprint while holding forward",
            description: "Holds the normal sprint key only while vanilla conditions allow it. No extra packets.",
            value: false,
            advanced: true,
          },
        ],
      },
      {
        id: "inventory",
        title: "Inventory",
        subtitle: "Searching and protecting items. Position locks survive relogs.",
        icon: "lock",
        settings: [
          {
            id: "item-lock-swap",
            label: "Item Lock and Swap",
            description: "Lock a player-inventory position, or pair two slots for a safe swap.",
            value: true,
            actionLabel: "Open details",
            children: [
              {
                id: "item-lock-icons",
                label: "Show lock badges",
                description: "Draw a small padlock on locked positions.",
                value: true,
              },
              {
                id: "item-lock-hotbar",
                label: "Badges on the hotbar",
                description: "Keep lock badges visible while the inventory is closed.",
                value: true,
              },
              {
                id: "item-swap-lines",
                label: "Swap connection lines",
                description: "Draw a quiet line between paired slots.",
                value: true,
              },
            ],
          },
          {
            id: "inventory-assist",
            label: "Inventory Assist",
            description: "One local search field and a few cosmetic tooltip upgrades.",
            value: false,
            actionLabel: "Open details",
            children: [
              {
                id: "inventory-search",
                label: "Search and filter",
                description: "Dim slots that do not match the local query.",
                value: false,
              },
              {
                id: "hide-potions",
                label: "Hide potion panel",
                description: "Keep the inventory layout clean when effects are active.",
                value: false,
              },
              {
                id: "roman-numerals",
                label: "Roman tooltip levels",
                description: "Render common enchanted-book levels as Roman numerals.",
                value: false,
              },
              {
                id: "tooltip-scroll",
                label: "Scrollable tooltips",
                description: "Scroll long item lore instead of letting it run off screen.",
                value: false,
              },
              {
                id: "rarity-highlight",
                label: "Rarity highlights",
                description: "A subtle tint on item slots based on rarity.",
                value: false,
              },
            ],
          },
        ],
      },
      {
        id: "chat",
        title: "Chat",
        subtitle: "Readable messages, attached filters and one captured message menu.",
        icon: "method",
        settings: [
          {
            id: "chat-qol",
            label: "Chat QoL",
            description: "Rounded surface, smooth scrolling and an attached All / Party / Reply filter row.",
            value: false,
            actionLabel: "Open chat settings",
            children: [
              {
                id: "chat-tabs",
                label: "Filter tabs",
                description: "Keep channel tabs attached to the open chat instead of a second window.",
                value: false,
              },
              {
                id: "chat-smooth",
                label: "Smooth message motion",
                description: "Fade and slide new messages in without moving old ones.",
                value: false,
              },
              {
                id: "chat-hover",
                label: "Highlight hovered line",
                description: "A calm background on the message under the pointer.",
                value: false,
              },
            ],
          },
        ],
      },
      {
        id: "skills",
        title: "Skills",
        subtitle: "Mining, Slayer and fishing trackers, off until you enable them.",
        icon: "gauge",
        settings: [
          {
            id: "mining-bps",
            label: "Mining speed",
            description: "A compact blocks-per-second readout while mining.",
            value: true,
          },
          {
            id: "mining-assistant-settings",
            label: "Mining assistant",
            description: "Pickaxe-ready alert and a read-only route marker.",
            value: false,
            actionLabel: "Open details",
            children: [
              {
                id: "mining-ability-alert",
                label: "Pickaxe ready alert",
                description: "A local sound and text cue when the ability is charged.",
                value: false,
              },
              {
                id: "mining-puzzler",
                label: "Puzzler route marker",
                description: "Show the suggested direction in Dwarven Mines. Never clicks or walks for you.",
                value: false,
              },
              {
                id: "mining-assistant-hud",
                label: "Mining assistant HUD",
                description: "Add the assistant readout to the movable HUD layer.",
                value: false,
              },
            ],
          },
          {
            id: "slayer-tracker",
            label: "Slayer tracker",
            description: "Local boss timer and your selected tier, without a chat parser.",
            value: false,
            actionLabel: "Open details",
            children: [
              {
                id: "slayer-hud",
                label: "Slayer HUD",
                description: "Show the active quest and timer on the HUD.",
                value: false,
              },
              {
                id: "slayer-boss-timer",
                label: "Boss timer",
                description: "Track spawn and kill time for each attempt.",
                value: true,
              },
              {
                id: "slayer-pricing",
                label: "Estimated item value",
                description: "Use your saved local prices; nothing is fetched.",
                value: false,
                advanced: true,
              },
            ],
          },
          {
            id: "fishing-hud",
            label: "Fishing tracker",
            description: "Catch counters, sea-creature health and the Jawbus alert in one place.",
            value: false,
            actionLabel: "Open details",
            children: [
              {
                id: "catch-counter",
                label: "Catch counter",
                description: "Count every rarity locally, including festival catches.",
                value: true,
              },
              {
                id: "sea-creature-hp",
                label: "Sea creature health",
                description: "Show health for your current catch only.",
                value: false,
              },
              {
                id: "lord-jawbus",
                label: "Lord Jawbus alert",
                description: "A quiet banner and sound cue when Jawbus spawns.",
                value: true,
              },
              {
                id: "nearby-encounters",
                label: "Nearby encounters",
                description: "Show players fishing around you. Useful, but busy.",
                value: false,
                advanced: true,
              },
            ],
          },
        ],
      },
      {
        id: "shortcuts",
        title: "Shortcuts",
        subtitle: "Optional command keys. Nothing is bound on a fresh install.",
        icon: "plan",
        advanced: true,
        settings: [
          {
            id: "movement-shortcuts",
            label: "Wardrobe and Pets",
            description: "Send /wardrobe or /pets only on a server you explicitly allow.",
            value: false,
            children: [
              {
                id: "wardrobe-shortcut",
                label: "Wardrobe shortcut",
                description: "Unbound. Choose a key in Controls.",
                value: false,
              },
              {
                id: "pets-shortcut",
                label: "Pets shortcut",
                description: "Unbound. Choose a key in Controls.",
                value: false,
              },
            ],
          },
        ],
      },
    ],
  },
  {
    id: "dungeon",
    label: "Dungeon",
    icon: "server",
    caption: "Everything that should only be alive inside Catacombs.",
    cards: [
      {
        id: "run-tools",
        title: "Run tools",
        subtitle: "The four utilities you want on a hotkey, not buried in a menu.",
        icon: "wrench",
        settings: [
          {
            id: "dungeon-map",
            label: "Dungeon map",
            description: "Room shapes, puzzle labels and party heads on a cached map.",
            value: true,
            actionLabel: "Open map settings",
            children: [
              {
                id: "dungeon-map-rotate",
                label: "Rotate to facing",
                description: "Keep the current room pointing up.",
                value: true,
              },
              {
                id: "dungeon-map-player-names",
                label: "Player names",
                description: "Show names next to party heads.",
                value: true,
              },
            ],
          },
          {
            id: "terminal-assist",
            label: "Terminal helper",
            description: "Outline the next parsed terminal slot. Passive by default.",
            value: false,
            actionLabel: "Open details",
            badge: "passive",
            children: [
              {
                id: "terminal-hints",
                label: "Highlight the next slot",
                description: "Only verified F7/M7 layouts are outlined. Unknown layouts stay vanilla.",
                value: false,
              },
              {
                id: "terminal-hide-wrong",
                label: "Dim known wrong slots",
                description: "Useful for learning, off if you prefer a clean chest.",
                value: false,
              },
              {
                id: "terminal-prevent-clicks",
                label: "Block known wrong clicks",
                description: "Cancels your click only when the layout and target are unambiguous.",
                value: false,
              },
            ],
          },
          {
            id: "spirit-leap",
            label: "Spirit Leap picker",
            description: "Replace only the server's leap chest with class-labelled party heads.",
            value: true,
            children: [
              {
                id: "leap-key",
                label: "Leap hotkey",
                description: "The only way to initiate a leap. Left-click stays vanilla.",
                value: false,
                badge: "recommended",
              },
            ],
          },
          {
            id: "boss-hp",
            label: "Boss health",
            description: "A parsed boss bar for the current floor.",
            value: false,
            actionLabel: "Open details",
            children: [
              {
                id: "boss-hp-hud",
                label: "Boss HP HUD",
                description: "Draw the boss readout on the HUD layer.",
                value: false,
              },
            ],
          },
        ],
      },
      {
        id: "floor-seven",
        title: "Floor VII",
        subtitle: "M7 overlays, dragon alerts and the small things that save a run.",
        icon: "spark",
        settings: [
          {
            id: "m7-overlay",
            label: "Floor VII overlay",
            description: "Relic, device and dragon state at a glance.",
            value: true,
            children: [
              {
                id: "dragon-alerts",
                label: "Dragon alerts",
                description: "A short local cue when a dragon spawns or dies.",
                value: true,
              },
              {
                id: "m7-device-timers",
                label: "Device timers",
                description: "Keep the device timing panel visible during the fight.",
                value: true,
              },
            ],
          },
        ],
      },
      {
        id: "highlights",
        title: "Highlights",
        subtitle: "Cached boxes for the things that matter. Styles stay in one editor.",
        icon: "eye",
        settings: [
          {
            id: "mob-esp",
            label: "Mob highlights",
            description: "Star mobs, minibosses and special mobs, drawn from a cached scan.",
            value: true,
            actionLabel: "Open styles",
          },
          {
            id: "door-esp",
            label: "Door highlights",
            description: "Wither and blood doors with the same thin box styling.",
            value: true,
            actionLabel: "Open styles",
          },
        ],
        notice: {
          tone: "info",
          text: "Unknown room or entity data fails closed: no box, no state change.",
        },
      },
      {
        id: "party-sync",
        title: "Party sync",
        subtitle: "Optional puzzle sharing. Off by default; you see the payload before enabling.",
        icon: "shield",
        settings: [
          {
            id: "dungeon-sync",
            label: "Dungeon Sync",
            description: "Share allow-listed puzzle labels and aligned room coordinates over TLS.",
            value: false,
            actionLabel: "Review privacy",
            children: [
              {
                id: "sync-details",
                label: "Sync diagnostics",
                description: "Session state and transport retries, for support only.",
                value: false,
                advanced: true,
              },
              {
                id: "sync-consent",
                label: "Show consent before connecting",
                description: "The default endpoint is a private service. Disclose it and require a click.",
                value: true,
                badge: "proposed",
              },
            ],
          },
        ],
        notice: {
          tone: "warn",
          text: "Third-party network feature. No socket is created until enabled and a dungeon is detected.",
        },
      },
    ],
  },
  {
    id: "visuals",
    label: "Visuals",
    icon: "eye",
    caption: "Your HUD and the first-person hand. All rendering, no server state.",
    cards: [
      {
        id: "hud",
        title: "HUD",
        subtitle: "Movable elements. Drag them once in the editor, then forget this page.",
        icon: "layers",
        settings: [
          {
            id: "player-doll",
            label: "Player doll",
            description: "A live model of you with armour and your held item.",
            value: true,
          },
          {
            id: "inventory-hud",
            label: "Inventory HUD",
            description: "The 27 main inventory slots, with optional armour.",
            value: true,
          },
          {
            id: "player-dollars",
            label: "Purse",
            description: "Purse from the scoreboard, or a typed value.",
            value: true,
          },
          {
            id: "hud-editor",
            label: "Open HUD editor",
            description: "Move, scale and dim elements on the live HUD.",
            control: "action",
            actionLabel: "Open editor",
          },
        ],
      },
      {
        id: "item-animation",
        title: "Item animation",
        subtitle: "First-person position, size and equip tempo. Vanilla at the defaults.",
        icon: "wrench",
        settings: [
          {
            id: "item-animation",
            label: "Enable item animation",
            description: "Wrap only Minecraft's first-person hand call. Third person and overlays stay vanilla.",
            value: true,
            actionLabel: "Preview",
          },
          {
            id: "item-animation-size",
            label: "Item size",
            description: "Uniform scale for swords, tools, blocks, bows and the bare arm.",
            control: "slider",
            number: 100,
            min: 50,
            max: 200,
            step: 5,
            suffix: "%",
            advanced: true,
          },
          {
            id: "item-animation-speed",
            label: "Equip tempo",
            description: "Interpolation speed only. Attack speed and server timing are untouched.",
            control: "slider",
            number: 100,
            min: 50,
            max: 200,
            step: 5,
            suffix: "%",
          },
          {
            id: "item-animation-offset-x",
            label: "Horizontal offset",
            description: "Nudge the held item left or right.",
            control: "slider",
            number: 0,
            min: -75,
            max: 75,
            step: 1,
            suffix: "u",
            advanced: true,
          },
          {
            id: "item-animation-offset-y",
            label: "Vertical offset",
            description: "Nudge the held item up or down.",
            control: "slider",
            number: 0,
            min: -75,
            max: 75,
            step: 1,
            suffix: "u",
            advanced: true,
          },
          {
            id: "item-animation-reset",
            label: "Reset to vanilla",
            description: "Size and tempo to 100%, offsets to zero.",
            control: "action",
            actionLabel: "Reset",
          },
        ],
      },
    ],
  },
  {
    id: "system",
    label: "System",
    icon: "modules",
    caption: "Appearance, performance and the keys you rarely need.",
    cards: [
      {
        id: "appearance",
        title: "Appearance",
        subtitle: "The Apple surfaces: glass, corners, accent and density.",
        icon: "eye",
        settings: [
          {
            id: "appearance-theme",
            label: "Theme",
            description: "Graphite for late-night dungeons, Frost for daylight.",
            control: "choice",
            options: ["Graphite", "Frost"],
            value: true,
          },
          {
            id: "appearance-accent",
            label: "Accent",
            description: "The single highlight used for selection and focus.",
            control: "choice",
            options: ["Mint", "Sky", "Amber"],
            value: true,
          },
          {
            id: "appearance-corners",
            label: "Corner radius",
            description: "Soft Apple-style corners. Lower values feel more utilitarian.",
            control: "slider",
            number: 12,
            min: 4,
            max: 18,
            step: 1,
            suffix: "px",
            advanced: true,
          },
          {
            id: "appearance-opacity",
            label: "Panel opacity",
            description: "Higher is more readable, lower is more of the game behind it.",
            control: "slider",
            number: 90,
            min: 60,
            max: 100,
            step: 1,
            suffix: "%",
            advanced: true,
          },
        ],
      },
      {
        id: "performance",
        title: "Performance",
        subtitle: "The safe knobs. The GUI is designed to stay smooth without them.",
        icon: "gauge",
        settings: [
          {
            id: "performance-boost",
            label: "Performance Boost Beta",
            description: "Cached geometry and reduced redraw work. Leave off if anything looks wrong.",
            value: false,
            badge: "beta",
          },
          {
            id: "animations",
            label: "Interface animations",
            description: "Short eased transitions. Disabled automatically by `prefers-reduced` style settings.",
            value: true,
          },
          {
            id: "adaptive-quality",
            label: "Adaptive GUI quality",
            description: "Lower curve work and shadows when frame time rises.",
            value: true,
            advanced: true,
          },
          {
            id: "shadows",
            label: "Soft shadows",
            description: "Panel depth without a full-screen blur pass.",
            value: true,
            advanced: true,
          },
        ],
      },
      {
        id: "general",
        title: "General",
        subtitle: "Input behaviour and the settings you actually understand.",
        icon: "plan",
        settings: [
          {
            id: "mod-settings",
            label: "Interface behavior",
            description: "Scrolling and smoothing shared by every Sky VeLor list.",
            value: true,
            children: [
              {
                id: "smooth-scrolling",
                label: "Smooth scrolling",
                description: "Ease list movement instead of jumping.",
                value: true,
              },
              {
                id: "global-scroll",
                label: "Scroll speed",
                description: "One speed for hub lists, editors and chat.",
                control: "slider",
                number: 100,
                min: 50,
                max: 300,
                step: 10,
                suffix: "%",
              },
            ],
          },
        ],
      },
      {
        id: "backup",
        title: "Backup",
        subtitle: "The one place to export, import or start clean.",
        icon: "file",
        settings: [
          {
            id: "export-settings",
            label: "Export a profile",
            description: "Download a readable properties file you can review before sharing.",
            control: "action",
            actionLabel: "Export",
          },
          {
            id: "import-settings",
            label: "Import a profile",
            description: "Validate unknown keys and never apply values outside their ranges.",
            control: "action",
            actionLabel: "Import",
          },
          {
            id: "reset-settings",
            label: "Reset all settings",
            description: "Restore defaults after a confirmation. Locks and pairs are kept.",
            control: "action",
            actionLabel: "Reset",
            badge: "careful",
          },
        ],
      },
      {
        id: "diagnostics",
        title: "Diagnostics",
        subtitle: "Developer surfaces, intentionally out of the everyday path.",
        icon: "code",
        advanced: true,
        settings: [
          {
            id: "commands",
            label: "Client command routes",
            description: "Allow /sv, /qn and diagnostic commands.",
            value: false,
            children: [
              {
                id: "command-itemdebug",
                label: "Item Animation debug",
                description: "Print live offsets and whether the renderer hook was reached.",
                control: "action",
                actionLabel: "Copy status",
              },
              {
                id: "command-selftest",
                label: "Self test",
                description: "One copyable report with every hook state.",
                control: "action",
                actionLabel: "Copy report",
              },
            ],
          },
          {
            id: "sync-details",
            label: "Sync details",
            description: "Hashed session state and transport retries. Never includes names.",
            control: "action",
            actionLabel: "View status",
            advanced: true,
          },
        ],
      },
      {
        id: "about",
        title: "About",
        subtitle: "Version, notices and the limits you should know.",
        icon: "info",
        settings: [
          {
            id: "about-version",
            label: "Sky VeLor Beta 0.10.8.9",
            description: "For Minecraft 1.8.9 + Forge 11.15.1.2318. Client-side only.",
            control: "info",
          },
          {
            id: "about-license",
            label: "Licenses and credits",
            description: "Bundled notices include MIT, LGPL, AGPL and GPL components. Read before redistributing.",
            control: "action",
            actionLabel: "View notices",
          },
          {
            id: "about-rules",
            label: "Use within server rules",
            description: "Automation is removed in this proposal. Visual helpers are not a guarantee of server safety.",
            control: "info",
          },
        ],
      },
    ],
  },
];

export const QUICK_TOGGLES = [
  {
    id: "auto-sprint",
    label: "Sprint",
    icon: "spark" as IconName,
    detail: "Only while forward is held",
  },
  {
    id: "terminal-assist",
    label: "Terminal",
    icon: "wrench" as IconName,
    detail: "Passive slot outline",
  },
  {
    id: "chat-qol",
    label: "Chat",
    icon: "method" as IconName,
    detail: "Attached filter tabs",
  },
  {
    id: "item-animation",
    label: "Hand",
    icon: "eye" as IconName,
    detail: "First-person animation",
  },
];

export interface Preset {
  id: string;
  name: string;
  tagline: string;
  icon: IconName;
  values: Record<string, boolean>;
  note: string;
}

export const PRESETS: Preset[] = [
  {
    id: "vanilla-plus",
    name: "Vanilla+",
    tagline: "Clean screen, no automation.",
    icon: "shield",
    values: {
      "no-block-particles": true,
      "disable-hotbar-scrolling": true,
      "no-hurt-cam": true,
      "auto-sprint": false,
      "item-lock-swap": true,
      "inventory-assist": false,
      "chat-qol": false,
      "terminal-assist": false,
      "mob-esp": false,
      "door-esp": false,
      "dungeon-sync": false,
      "item-animation": true,
    },
    note: "The safest starting point. Only visual and input comfort.",
  },
  {
    id: "quality",
    name: "Quality of Life",
    tagline: "Everything local, nothing automated.",
    icon: "spark",
    values: {
      "no-block-particles": true,
      "disable-hotbar-scrolling": true,
      "no-hurt-cam": true,
      "auto-sprint": true,
      "item-lock-swap": true,
      "inventory-assist": true,
      "chat-qol": true,
      "item-animation": true,
      "player-doll": true,
      "inventory-hud": true,
      "player-dollars": true,
    },
    note: "For everyday SkyBlock. Dungeon and network features stay off.",
  },
  {
    id: "dungeon",
    name: "Dungeon",
    tagline: "Map, leap and highlights.",
    icon: "server",
    values: {
      "dungeon-map": true,
      "terminal-assist": true,
      "spirit-leap": true,
      "boss-hp": true,
      "m7-overlay": true,
      "mob-esp": true,
      "door-esp": true,
      "dungeon-sync": false,
    },
    note: "No auto-click. No sync socket. You still press every key.",
  },
  {
    id: "minimal",
    name: "Minimal",
    tagline: "Leave the screen alone.",
    icon: "eye",
    values: {
      "item-lock-swap": true,
      "player-doll": false,
      "inventory-hud": false,
      "player-dollars": false,
      "mob-esp": false,
      "door-esp": false,
      "m7-overlay": false,
      "dungeon-map": false,
    },
    note: "Protection stays on; almost no drawing. Useful for weak laptops.",
  },
];

export interface MigrationRow {
  id: string;
  oldTab: string;
  oldLabel: string;
  newTab: GuiTabId;
  newCard: string;
  exposure: "Everyday" | "Expand" | "Advanced" | "Removed";
  note: string;
}

export const MIGRATION: MigrationRow[] = [
  { id: "appearance", oldTab: "General", oldLabel: "Appearance", newTab: "system", newCard: "Appearance", exposure: "Everyday", note: "Theme, accent, corners and opacity now share one card." },
  { id: "mod-settings", oldTab: "General", oldLabel: "Mod Settings", newTab: "system", newCard: "General", exposure: "Everyday", note: "Renamed “Interface behavior”." },
  { id: "performance", oldTab: "General", oldLabel: "Performance", newTab: "system", newCard: "Performance", exposure: "Everyday", note: "Unchanged controls; expanded under Advanced." },
  { id: "no-block-particles", oldTab: "Quality of Life", oldLabel: "No Block Particles", newTab: "gameplay", newCard: "Comfort", exposure: "Everyday", note: "One of four comfort switches." },
  { id: "disable-hotbar-scrolling", oldTab: "Quality of Life", oldLabel: "No Hotbar Scrolling", newTab: "gameplay", newCard: "Comfort", exposure: "Everyday", note: "Renamed to a readable action." },
  { id: "no-hurt-cam", oldTab: "Quality of Life", oldLabel: "No Hurt Cam", newTab: "gameplay", newCard: "Comfort", exposure: "Everyday", note: "Description now states damage is untouched." },
  { id: "auto-sprint", oldTab: "Quality of Life", oldLabel: "Auto Sprint", newTab: "gameplay", newCard: "Comfort", exposure: "Advanced", note: "Kept opt-in and under Advanced on purpose." },
  { id: "inventory-assist", oldTab: "Quality of Life", oldLabel: "Inventory Assist", newTab: "gameplay", newCard: "Inventory", exposure: "Expand", note: "One master row, five sub-toggles inline." },
  { id: "movement-shortcuts", oldTab: "Quality of Life", oldLabel: "Movement and Shortcuts", newTab: "gameplay", newCard: "Shortcuts", exposure: "Advanced", note: "Its own Advanced card; two child shortcuts." },
  { id: "item-lock-swap", oldTab: "Quality of Life", oldLabel: "Item Lock and Swap", newTab: "gameplay", newCard: "Inventory", exposure: "Everyday", note: "Everyday master; badges inline, deep settings routed." },
  { id: "chat-qol", oldTab: "Quality of Life", oldLabel: "Chat QoL", newTab: "gameplay", newCard: "Chat", exposure: "Everyday", note: "Now one row, not a whole tab." },
  { id: "commands", oldTab: "Quality of Life", oldLabel: "Commands", newTab: "system", newCard: "Diagnostics", exposure: "Advanced", note: "Moved out of everyday settings." },
  { id: "item-animation", oldTab: "HUD", oldLabel: "Item Animation", newTab: "visuals", newCard: "Item animation", exposure: "Everyday", note: "Slider page inside its card." },
  { id: "hud-player-doll", oldTab: "HUD", oldLabel: "Player Doll", newTab: "visuals", newCard: "HUD", exposure: "Everyday", note: "One list, not four separate rows." },
  { id: "hud-inventory", oldTab: "HUD", oldLabel: "Inventory HUD", newTab: "visuals", newCard: "HUD", exposure: "Everyday", note: "Same toggle, same config key." },
  { id: "hud-dollars", oldTab: "HUD", oldLabel: "Player Dollars", newTab: "visuals", newCard: "HUD", exposure: "Everyday", note: "Renamed “Purse”." },
  { id: "mining-bps", oldTab: "Farming", oldLabel: "Mining BPS", newTab: "gameplay", newCard: "Skills", exposure: "Everyday", note: "First row in Skills." },
  { id: "mining-assistant-settings", oldTab: "Farming", oldLabel: "Mining Assistant", newTab: "gameplay", newCard: "Skills", exposure: "Expand", note: "Three sub-toggles, no extra tab." },
  { id: "door-esp", oldTab: "Dungeon", oldLabel: "Door ESP", newTab: "dungeon", newCard: "Highlights", exposure: "Everyday", note: "Door and mob highlights share one card." },
  { id: "mob-esp", oldTab: "Dungeon", oldLabel: "Mob ESP", newTab: "dungeon", newCard: "Highlights", exposure: "Everyday", note: "Styles route remains available." },
  { id: "dungeon-sync-enabled", oldTab: "Dungeon", oldLabel: "Dungeon Sync", newTab: "dungeon", newCard: "Party sync", exposure: "Everyday", note: "Consent row added before connect." },
  { id: "m7-overlay", oldTab: "Dungeon", oldLabel: "Floor VII (M7) Overlay", newTab: "dungeon", newCard: "Floor VII", exposure: "Everyday", note: "Focused card, dragon sub-toggle inline." },
  { id: "spirit-leap", oldTab: "Dungeon", oldLabel: "Spirit Leap GUI", newTab: "dungeon", newCard: "Run tools", exposure: "Everyday", note: "Picker toggle with an explicit leap-key hint." },
  { id: "terminal-assist", oldTab: "Dungeon", oldLabel: "Terminal Assist", newTab: "dungeon", newCard: "Run tools", exposure: "Everyday", note: "Auto-click no longer exists in the proposal." },
  { id: "dungeon-boss-hud", oldTab: "Dungeon", oldLabel: "Boss HP", newTab: "dungeon", newCard: "Run tools", exposure: "Expand", note: "Master plus a HUD child." },
  { id: "dungeon-map", oldTab: "Dungeon", oldLabel: "Dungeon Map", newTab: "dungeon", newCard: "Run tools", exposure: "Everyday", note: "Map options stay in their focused editor." },
  { id: "dungeon-sync-debug", oldTab: "Dungeon", oldLabel: "Sync Details", newTab: "dungeon", newCard: "Party sync", exposure: "Advanced", note: "Nested in diagnostics to stop accidental use." },
  { id: "slayer-tracker", oldTab: "Slayer", oldLabel: "Slayer Tracker", newTab: "gameplay", newCard: "Skills", exposure: "Everyday", note: "Skills now groups all three trackers." },
  { id: "slayer-hud-route", oldTab: "Slayer", oldLabel: "Slayer HUD", newTab: "gameplay", newCard: "Skills", exposure: "Expand", note: "Child of Slayer tracker." },
  { id: "jawbus", oldTab: "Fishing", oldLabel: "Lord Jawbus", newTab: "gameplay", newCard: "Skills", exposure: "Expand", note: "Child of Fishing tracker." },
  { id: "nearby-encounters", oldTab: "Fishing", oldLabel: "Nearby Encounters", newTab: "gameplay", newCard: "Skills", exposure: "Advanced", note: "Hidden deeper; it is the busiest option." },
  { id: "catch-counter", oldTab: "Fishing", oldLabel: "Catch Counter", newTab: "gameplay", newCard: "Skills", exposure: "Expand", note: "Child of Fishing tracker." },
  { id: "fishing-hud-route", oldTab: "Fishing", oldLabel: "Fishing HUD", newTab: "gameplay", newCard: "Skills", exposure: "Expand", note: "Now the Fishing tracker master." },
  { id: "sea-hp-hud-route", oldTab: "Fishing", oldLabel: "Sea Creature HP", newTab: "gameplay", newCard: "Skills", exposure: "Expand", note: "Child row; same behavior." },
];

export const DESIGN_PRINCIPLES = [
  {
    title: "Four doors, not seven",
    detail: "Home, Gameplay, Dungeon, Visuals, System. Every real setting lives under one of them, and Home only aggregates.",
    metric: "5 destinations",
    icon: "overview" as IconName,
  },
  {
    title: "Simple first, depth on request",
    detail: "First screen shows outcomes, not implementation. Sub-toggles appear inline only after you open the thing you care about.",
    metric: "≤ 5 cards per screen",
    icon: "layers" as IconName,
  },
  {
    title: "One search for everything",
    detail: "Search reads synced labels and synonyms, not config keys. Empty results suggest the closest category instead of a blank panel.",
    metric: "34 routes indexed",
    icon: "search" as IconName,
  },
  {
    title: "Nothing is lost",
    detail: "Every existing option keeps its config key and default. Old positions and keybinds survive the redesign.",
    metric: "0 migrations",
    icon: "shield" as IconName,
  },
];

export const PERFORMANCE_RULES = [
  { label: "Allocations in drawScreen", value: "0", detail: "Cache labels, formatted values and wrapped lore when state changes, never per frame." },
  { label: "Scissor stencil depth", value: "≤ 1", detail: "One scissor push for the scroll pane. No nested scissor per card or tooltip." },
  { label: "Blur passes", value: "0", detail: "1.8.9 full-screen blur is a stencil-heavy fake. Use a static translucent surface instead." },
  { label: "Visible row draw cap", value: "12", detail: "Index range from scroll offset; do not walk 34 rows to draw 8." },
  { label: "Config writes per tweak", value: "1 (debounced)", detail: "250 ms debounce, atomic save on close and world unload. Never on mouse-move." },
  { label: "Search filter recompute", value: "On change", detail: "Dirty flag; do not lowercase every label on every keystroke or every frame." },
];

export const IMPLEMENTATION_STEPS = [
  {
    step: "01",
    title: "Ship the shell first",
    detail: "New AppleSettingsScreen, tab rail, scroll pane, search field and the About/Backup pages. Keep every existing feature route reachable from old keys behind a temporary “Legacy” link in Diagnostics.",
  },
  {
    step: "02",
    title: "Move one domain at a time",
    detail: "Gameplay cards first (Comfort, Inventory, Chat), then Dungeon, then Visuals. After each domain, delete its old Hub row and run the parity table.",
  },
  {
    step: "03",
    title: "Prove parity, then delete",
    detail: "Automate a check that each of the 34 option ids has exactly one reachable new route. No setting can exist only in the old UI.",
  },
  {
    step: "04",
    title: "Measure, don't vibe",
    detail: "Record frame time and allocations opening the screen, scrolling all tabs and typing a search query on a low-end 1.8.9 instance.",
  },
  {
    step: "05",
    title: "Cut over in a beta",
    detail: "Keep keybinds and config keys. Add an “open old settings” command for one release, then remove it once the parity test is green.",
  },
];

export const JAVA_SNIPPET = `public final class AppleSettingsScreen extends AppleScreen {
    private final SettingsRoute route;
    private final SettingsCatalog catalog = SettingsCatalog.shared();
    private final List<SettingRowView> visible = new ArrayList<SettingRowView>();
    private String lastQuery = "";
    private boolean layoutDirty = true;

    @Override
    public void initGui() {
        // Build descriptors once per screen, not inside drawScreen.
        visible.clear();
        visible.addAll(catalog.filter(route, lastQuery, advanced));
        layoutDirty = true;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        renderSurface();                 // one static panel texture
        beginScrollPane();               // exactly one scissor push
        int first = visibleIndexAt(scroll);
        int last  = Math.min(visible.size(), first + VISIBLE_ROWS);
        for (int i = first; i < last; i++) {
            visible.get(i).draw(mouseX, mouseY); // cached strings and hitbox
        }
        endScrollPane();
        renderSearchAndFooter();         // outside the clip, no reflow
    }
}`;

export const PARITY_CHECKS = [
  "Every legacy option id resolves to exactly one new route.",
  "Every default is identical to Beta-0.10.8.9v.",
  "Item Lock keybind and pairing data survive an upgrade and a downgrade.",
  "HUD positions, scales and dim states are untouched by the new theme.",
  "Old retired keys load harmlessly and never reappear as controls.",
  "The 100/150/200% GUI-scale layouts have no clipped labels or overlapping hitboxes.",
];

export const GUI_FAQ = [
  {
    q: "Why not put every feature on one long page?",
    a: "A long page removes tabs but keeps the same number of decisions. Grouping by intent and hiding implementation details until requested reduces both visual noise and mis-clicks.",
  },
  {
    q: "Will power users lose their detailed settings?",
    a: "No. Advanced exposes every existing option; focused editors and style pages remain for ESP, HUD and Chat. The change is where they live, not whether they exist.",
  },
  {
    q: "Does this touch config or server behavior?",
    a: "This is a presentation revamp. Keys, defaults and packets stay the same. The proposal additionally removes terminal auto-click and the left-click leap path from the safety findings.",
  },
  {
    q: "How does it stay lag-free in 1.8.9?",
    a: "One screen, cached labels, a single scissor pane, no full-screen blur and no allocation in the draw path. Animations are optional and disabled when the user asks for a quieter UI.",
  },
];
