import {
  ARTIFACT,
  CHANGES,
  FINDINGS as ALL_FINDINGS,
  METHOD,
  PHASES,
  READINESS,
  REPO,
  SEVERITY_ORDER,
  STRENGTHS,
  VERDICT,
  formatBytes,
  type Severity,
} from "../data/audit";
import type { SharedAuditProps } from "../types";
import { Button, Callout, MeterBar, ScoreRing, SectionLabel, SeverityBadge, Tag } from "../components/Ui";
import { Icon, PixelCube, type IconName } from "../components/Icons";

function HeroStat({
  icon,
  value,
  label,
  sub,
}: {
  icon: IconName;
  value: string;
  label: string;
  sub: string;
}) {
  return (
    <div className="panel panel-lift px-4 py-4">
      <div className="mb-3 flex items-center justify-between">
        <span className="flex h-7 w-7 items-center justify-center rounded-md border border-line bg-panel-2 text-accent/80">
          <Icon name={icon} size={14} />
        </span>
        <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-faint">{label}</span>
      </div>
      <div className="font-display text-[24px] font-semibold leading-none tracking-tight text-ink">{value}</div>
      <div className="mt-1.5 text-[11px] leading-relaxed text-faint">{sub}</div>
    </div>
  );
}

function SurfaceSampler({
  lockedSlots,
  activeSlot,
}: {
  lockedSlots: number[];
  activeSlot: number;
}) {
  return (
    <div className="panel overflow-hidden">
      <div className="flex items-center justify-between border-b border-line-soft px-4 py-3">
        <div className="flex items-center gap-2">
          <span className="relative flex h-1.5 w-1.5">
            <span className="absolute inline-flex h-full w-full rounded-full bg-accent opacity-60 animate-pulse-dot" />
          </span>
          <span className="mono-label text-[#a4b9a9]">Surface sampler</span>
        </div>
        <span className="font-mono text-[9px] uppercase tracking-[0.12em] text-faint">illustrative</span>
      </div>

      <div className="relative grid gap-2 p-3">
        <div className="pointer-events-none absolute inset-0 grid-fade opacity-30" />
        <div className="relative grid grid-cols-2 gap-2">
          <div className="rounded-lg border border-line bg-[#0a100c]/95 p-2.5">
            <div className="mb-2 flex items-center justify-between">
              <span className="font-mono text-[8px] uppercase tracking-[0.14em] text-faint">general</span>
              <Icon name="gauge" size={11} className="text-accent/60" />
            </div>
            <div className="space-y-1.5 font-mono text-[10px]">
              <div className="flex justify-between text-muted"><span className="text-faint">FPS</span><span className="text-accent">247</span></div>
              <div className="flex justify-between text-muted"><span className="text-faint">PING</span><span className="text-accent-soft">28 ms</span></div>
              <div className="flex justify-between text-muted"><span className="text-faint">HEAP</span><span className="text-ink">412 / 1024</span></div>
            </div>
            <div className="mt-2"><MeterBar value={41} height={3} /></div>
          </div>

          <div className="rounded-lg border border-line bg-[#0a100c]/95 p-2.5">
            <div className="mb-2 flex items-center justify-between">
              <span className="font-mono text-[8px] uppercase tracking-[0.14em] text-faint">dungeon map</span>
              <span className="rounded border border-accent/25 bg-accent/10 px-1 font-mono text-[8px] text-accent">F7</span>
            </div>
            <div className="grid grid-cols-5 gap-1">
              {Array.from({ length: 15 }).map((_, i) => {
                const active = [0, 1, 6, 7, 11].includes(i);
                const puzzle = i === 7;
                const current = i === 11;
                return (
                  <div
                    key={i}
                    className="aspect-square rounded-[2px] border"
                    style={{
                      borderColor: current ? "#64e08d" : puzzle ? "rgba(242,179,92,.5)" : active ? "rgba(100,224,141,.24)" : "#1a2820",
                      background: current ? "rgba(100,224,141,.28)" : puzzle ? "rgba(242,179,92,.16)" : active ? "rgba(100,224,141,.08)" : "#0b1310",
                    }}
                  />
                );
              })}
            </div>
            <div className="mt-2 font-mono text-[8px] text-faint">13 rooms · 2 puzzles · 1 current</div>
          </div>
        </div>

        <div className="relative rounded-lg border border-line bg-[#0a100c]/95 p-2.5">
          <div className="mb-2 flex items-center justify-between">
            <span className="font-mono text-[8px] uppercase tracking-[0.14em] text-faint">item animation</span>
            <span className="font-mono text-[8px] text-accent/75">LIVE</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {[
              ["SIZE", 100],
              ["OFFSET", 7],
              ["SPEED", 100],
            ].map(([label, value]) => (
              <div key={String(label)}>
                <div className="mb-1 flex justify-between font-mono text-[8px]">
                  <span className="text-faint">{label}</span>
                  <span className="text-muted">{value}</span>
                </div>
                <div className="h-1.5 rounded-full bg-[#09100b]">
                  <div className="h-full w-2/3 rounded-full bg-accent/60" />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="relative rounded-lg border border-line bg-[#0a100c]/95 p-2.5">
          <div className="mb-2 flex items-center justify-between">
            <span className="font-mono text-[8px] uppercase tracking-[0.14em] text-faint">hotbar · item lock</span>
            <span className="font-mono text-[8px] text-[#f2b35c]">2 locked</span>
          </div>
          <div className="grid grid-cols-9 gap-1">
            {Array.from({ length: 9 }).map((_, i) => {
              const locked = lockedSlots.includes(i);
              return (
                <div
                  key={i}
                  className="relative aspect-square rounded-[3px] border bg-[#111a14]"
                  style={{
                    borderColor: i === activeSlot ? "#64e08d" : "#243528",
                    boxShadow: i === activeSlot ? "0 0 12px -4px rgba(100,224,141,.45)" : undefined,
                  }}
                >
                  <div
                    className="absolute inset-[3px] rounded-[1px] opacity-80"
                    style={{
                      background:
                        i % 4 === 0
                          ? "linear-gradient(135deg,#b8c3bd,#708078)"
                          : i % 4 === 1
                            ? "linear-gradient(135deg,#7fb9f7,#3b5f80)"
                            : i % 4 === 2
                              ? "linear-gradient(135deg,#c9f36b,#5f7a2a)"
                              : "linear-gradient(135deg,#f2b35c,#8b5e2c)",
                    }}
                  />
                  {locked && (
                    <span className="absolute -right-1 -top-1 z-10 flex h-3 w-3 items-center justify-center rounded-sm border border-[#f2b35c]/40 bg-[#1a1207] text-[7px] text-[#f2b35c]">
                      L
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
      <div className="border-t border-line-soft px-4 py-2.5 text-[10px] leading-relaxed text-faint">
        Reconstructed from the shipped feature inventory — not a gameplay screenshot.
      </div>
    </div>
  );
}

export function Overview({ statuses, readiness, navigate, qa, showToast }: SharedAuditProps) {
  const openFindings = ALL_FINDINGS.filter((f) => (statuses[f.id] ?? "open") !== "fixed");
  const blockers = [...ALL_FINDINGS]
    .filter((f) => f.severity === "critical" || f.severity === "high")
    .filter((f) => (statuses[f.id] ?? "open") !== "fixed")
    .sort((a, b) => SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity] || a.id.localeCompare(b.id))
    .slice(0, 3);
  const counts = (["critical", "high", "medium", "low"] as Severity[]).map((severity) => ({
    severity,
    count: ALL_FINDINGS.filter((f) => f.severity === severity).length,
  }));
  const qaDone = Object.values(qa).filter(Boolean).length;
  const criticalOpen = ALL_FINDINGS.filter(
    (f) => f.severity === "critical" && (statuses[f.id] ?? "open") !== "fixed",
  ).length;

  return (
    <div className="animate-fade-up">
      <section className="panel relative overflow-hidden">
        <div className="pointer-events-none absolute -right-24 -top-28 h-72 w-72 rounded-full border border-accent/10 bg-[radial-gradient(circle,rgba(100,224,141,.13),transparent_65%)]" />
        <div className="pointer-events-none absolute inset-y-0 left-0 w-1/2 grid-fade opacity-[0.18]" />
        <div className="relative grid gap-7 p-5 sm:p-7 lg:grid-cols-[minmax(0,1fr)_300px] lg:items-center">
          <div>
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-md border border-accent/25 bg-accent/10 px-2 py-1 font-mono text-[9px] uppercase tracking-[0.12em] text-accent">
                <span className="h-1.5 w-1.5 rounded-full bg-accent animate-pulse-dot" />
                source-verified audit
              </span>
              <span className="font-mono text-[10px] text-faint">v{REPO.numericVersion}</span>
              <span className="font-mono text-[10px] text-faint">{REPO.auditDate}</span>
            </div>
            <h1 className="max-w-2xl font-display text-[32px] font-semibold leading-[1.08] tracking-[-0.04em] text-ink sm:text-[44px]">
              Sky VeLor,
              <br />
              <span className="text-accent-soft glow-text">audited.</span>
            </h1>
            <p className="mt-3 max-w-xl text-[13px] leading-relaxed text-muted sm:text-sm">
              A source-level review of <span className="text-ink">Beta-0.10.8.9v</span> — what is solid, what can break in a
              live dungeon, and what to fix before this build leaves private testing.
            </p>
            <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1.5 font-mono text-[10px] text-faint">
              <span className="inline-flex items-center gap-1.5">
                <Icon name="git" size={11} />
                {REPO.branch}
              </span>
              <span>202 files · 34,449 LOC</span>
              <span>Forge {REPO.forge}</span>
            </div>
            <div className="mb-4 mt-5">
              <button
                type="button"
                onClick={() => navigate("gui")}
                className="focus-ring group flex w-full max-w-xl items-center gap-3 rounded-xl border border-accent/25 bg-[linear-gradient(100deg,rgba(100,224,141,.1),rgba(100,224,141,.02))] px-3 py-2.5 text-left transition-colors hover:border-accent/45 hover:bg-accent/[0.09]"
              >
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-accent/30 bg-accent/10 text-accent">
                  <Icon name="layers" size={15} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex flex-wrap items-center gap-1.5">
                    <span className="text-[11px] font-semibold text-accent-soft">GUI revamp concept</span>
                    <Tag color="#64e08d">new</Tag>
                  </span>
                  <span className="mt-0.5 block truncate text-[10px] text-muted">7 tabs &amp; 34 rows → Home + 4 sections, interactive prototype</span>
                </span>
                <Icon name="arrow" size={14} className="shrink-0 text-accent transition-transform group-hover:translate-x-0.5" />
              </button>
            </div>
            <div className="mt-5 flex flex-wrap gap-2">
              <Button icon="findings" onClick={() => navigate("findings")}>
                Review findings
              </Button>
              <Button variant="secondary" icon="release" onClick={() => navigate("release")}>
                Inspect the artifact
              </Button>
              <Button
                variant="ghost"
                iconRight="arrow"
                onClick={() => {
                  showToast("Fix queue: “Stabilize” is the place to start");
                  navigate("plan");
                }}
              >
                Open fix queue
              </Button>
            </div>
          </div>

          <div className="relative rounded-2xl border border-line bg-[#0a110d]/80 p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="mono-label text-faint">Release posture</div>
                <div className="mt-1 text-[12px] font-medium text-ink">{criticalOpen > 0 ? "Not ready for users" : "Critical path clear"}</div>
              </div>
              <PixelCube size={34} />
            </div>
            <div className="my-4 flex justify-center">
              <ScoreRing value={readiness} size={128} caption="readiness" />
            </div>
            <div className="rounded-lg border border-[#f2b35c]/25 bg-[#f2b35c]/[0.06] px-3 py-2.5">
              <div className="flex items-center gap-2 text-[11px] font-medium text-[#f2b35c]">
                <Icon name="alert" size={13} />
                {VERDICT.label}
              </div>
              <p className="mt-1 text-[10px] leading-relaxed text-muted">{VERDICT.short}. {criticalOpen} critical open.</p>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <div className="rounded-lg border border-line-soft bg-panel px-2.5 py-2">
                <div className="font-mono text-[9px] uppercase tracking-wider text-faint">QA verified</div>
                <div className="mt-1 font-mono text-sm text-ink">{qaDone}/14</div>
              </div>
              <div className="rounded-lg border border-line-soft bg-panel px-2.5 py-2">
                <div className="font-mono text-[9px] uppercase tracking-wider text-faint">Open items</div>
                <div className="mt-1 font-mono text-sm text-ink">{openFindings.length}/16</div>
              </div>
            </div>
          </div>
        </div>

        <div className="relative flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-line-soft bg-[#0a100d]/60 px-5 py-2.5">
          {counts.map(({ severity, count }) => (
            <div key={severity} className="flex items-center gap-1.5">
              <SeverityBadge severity={severity} compact />
              <span className="font-mono text-[10px] text-muted">{count}</span>
            </div>
          ))}
          <span className="ml-auto hidden font-mono text-[9px] uppercase tracking-[0.13em] text-faint sm:block">
            static review + artifact inspection
          </span>
        </div>
      </section>

      <div className="mt-3 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <HeroStat icon="code" value="202" label="java files" sub="34,449 lines across 25 packages" />
        <HeroStat icon="shield" value="65" label="test suites" sub={`1,175 headless assertions · no game launch`} />
        <HeroStat icon="release" value="397" label="jar classes" sub={`${formatBytes(ARTIFACT.sizeBytes)} · verified SHA-256`} />
        <HeroStat icon="layers" value="34" label="hub rows" sub="7 categories · settings rewired this patch" />
      </div>

      <div className="mt-3 grid gap-3 xl:grid-cols-[1.3fr_1fr]">
        <section className="panel p-5">
          <SectionLabel
            icon="alert"
            trailing={
              <button
                type="button"
                onClick={() => navigate("findings")}
                className="focus-ring flex items-center gap-1 rounded font-mono text-[10px] text-accent/80 hover:text-accent"
              >
                all findings <Icon name="arrow" size={11} />
              </button>
            }
          >
            Release blockers
          </SectionLabel>
          <p className="mb-4 max-w-2xl text-[12px] leading-relaxed text-muted">
            The three issues with the shortest path from “working on my machine” to a broken run or a banned user.
          </p>
          <div className="space-y-2">
            {blockers.map((finding) => (
              <button
                key={finding.id}
                type="button"
                onClick={() => navigate("findings")}
                className="focus-ring group flex w-full items-start gap-3 rounded-xl border border-line-soft bg-[#0b120e]/70 px-3.5 py-3 text-left transition-colors hover:border-[#31523f] hover:bg-[#101a14]"
              >
                <span className="mt-0.5">
                  <SeverityBadge severity={finding.severity} compact />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="mb-1 flex items-center gap-2 font-mono text-[9px] uppercase tracking-wider text-faint">
                    {finding.id} · {finding.component}
                  </span>
                  <span className="block text-[12px] font-medium leading-snug text-ink">{finding.title}</span>
                  <span className="mt-1.5 block font-mono text-[9px] text-faint">
                    {finding.file}:{finding.lines}
                  </span>
                </span>
                <Icon name="chevron" size={14} className="mt-1.5 shrink-0 text-faint transition-transform group-hover:translate-x-0.5 group-hover:text-accent" />
              </button>
            ))}
          </div>
          {blockers.length === 0 && (
            <Callout tone="success" initials="OK" title="Critical and high findings are closed">
              Keep the QA gate open until the in-game checks are recorded in the release record.
            </Callout>
          )}
          <div className="mt-3">
            <Callout tone="warn" initials="!" title="Do not call this stable">
              {VERDICT.summary}
            </Callout>
          </div>
        </section>

        <div className="flex flex-col gap-3">
          <SurfaceSampler lockedSlots={[1, 5]} activeSlot={3} />
          <section className="panel flex-1 p-4">
            <SectionLabel icon="spark">Working in your favour</SectionLabel>
            <div className="flex flex-wrap gap-1.5">
              {STRENGTHS.slice(0, 6).map((item) => (
                <span
                  key={item}
                  className="rounded-md border border-accent/15 bg-accent/[0.045] px-2 py-1 text-[10px] leading-relaxed text-[#b8cebe]"
                >
                  {item}
                </span>
              ))}
            </div>
            <div className="mt-3 flex items-center gap-2 border-t border-line-soft pt-3 text-[10px] text-faint">
              <Icon name="info" size={12} className="shrink-0 text-accent/70" />
              These are structural wins, not proof of runtime behaviour.
            </div>
          </section>
        </div>
      </div>

      <div className="mt-3 grid gap-3 xl:grid-cols-[1fr_1.25fr]">
        <section className="panel p-5">
          <SectionLabel icon="gauge" trailing={<span className="font-mono text-[9px] text-faint">weighted review signal</span>}>
            Readiness signals
          </SectionLabel>
          <div className="space-y-3.5">
            {READINESS.map((dimension) => (
              <div key={dimension.label}>
                <div className="mb-1.5 flex items-baseline justify-between gap-3">
                  <span className="text-[11px] font-medium text-[#c7d6cc]">{dimension.label}</span>
                  <span className="font-mono text-[10px] text-faint">{dimension.value}</span>
                </div>
                <MeterBar
                  value={dimension.value}
                  height={5}
                  tone={dimension.value < 45 ? "danger" : dimension.value < 70 ? "ember" : "accent"}
                />
                <div className="mt-1 text-[9px] leading-relaxed text-faint">{dimension.note}</div>
              </div>
            ))}
          </div>
          <div className="mt-4 rounded-lg border border-line-soft bg-[#0a100d] px-3 py-2.5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[10px] text-faint">Interactive QA progress</span>
              <span className="font-mono text-[10px] text-accent">{qaDone}/14 checks</span>
            </div>
            <div className="mt-2"><MeterBar value={(qaDone / 14) * 100} height={4} /></div>
            <button
              type="button"
              onClick={() => navigate("release")}
              className="focus-ring mt-2 flex items-center gap-1 font-mono text-[9px] uppercase tracking-wider text-accent/75 hover:text-accent"
            >
              open the smoke checklist <Icon name="arrow" size={10} />
            </button>
          </div>
        </section>

        <section className="panel p-5">
          <SectionLabel icon="git" trailing={<Tag color="#75baff">delta</Tag>}>
            What changed in 0.10.8.9
          </SectionLabel>
          <div className="divide-y divide-line-soft">
            {CHANGES.map((change, index) => (
              <div key={change.title} className="flex gap-3 py-2.5 first:pt-0 last:pb-0">
                <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded border border-line bg-[#0a110d] font-mono text-[9px] text-faint">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-medium text-ink">{change.title}</span>
                    <Tag>{change.tag}</Tag>
                  </div>
                  <p className="mt-0.5 text-[10px] leading-relaxed text-faint">{change.detail}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      <section className="mt-3 panel p-5">
        <SectionLabel
          icon="wrench"
          trailing={
            <button
              type="button"
              onClick={() => navigate("plan")}
              className="focus-ring flex items-center gap-1 rounded font-mono text-[10px] text-accent/80 hover:text-accent"
            >
              open fix plan <Icon name="arrow" size={11} />
            </button>
          }
        >
          Suggested path to a release
        </SectionLabel>
        <div className="grid gap-2.5 md:grid-cols-3">
          {([1, 2, 3] as const).map((phase) => {
            const info = PHASES[phase];
            const items = ALL_FINDINGS.filter((f) => f.phase === phase).length;
            return (
              <div key={phase} className="relative overflow-hidden rounded-xl border border-line bg-[#0a110d]/70 p-4">
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-accent/35 to-transparent" />
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[9px] uppercase tracking-[0.15em] text-faint">{info.eyebrow}</span>
                  <span className="font-pixel text-[10px] text-accent/80">0{phase}</span>
                </div>
                <div className="mt-1.5 font-display text-[16px] font-semibold text-ink">{info.title}</div>
                <p className="mt-1 min-h-[42px] text-[10px] leading-relaxed text-muted">{info.description}</p>
                <div className="mt-3 flex items-center justify-between border-t border-line-soft pt-2.5">
                  <span className="font-mono text-[9px] text-faint">{items} findings</span>
                  <Button size="sm" variant="ghost" iconRight="arrow" onClick={() => navigate("plan")}>
                    Start
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <div className="mt-4 grid gap-3 md:grid-cols-[1.4fr_1fr]">
        <div className="panel px-4 py-3.5">
          <div className="flex items-start gap-3">
            <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md border border-info/25 bg-info/10 text-info">
              <Icon name="method" size={13} />
            </span>
            <div className="min-w-0">
              <div className="text-[11px] font-medium text-ink">How this audit was built</div>
              <p className="mt-1 text-[10px] leading-relaxed text-muted">
                {METHOD[0].detail} Then: {METHOD[2].detail} No Minecraft client was launched, so runtime
                impact is labelled, not proven.
              </p>
              <button
                type="button"
                onClick={() => navigate("method")}
                className="focus-ring mt-2 inline-flex items-center gap-1 rounded font-mono text-[9px] uppercase tracking-wider text-info/80 hover:text-info"
              >
                read the method <Icon name="arrow" size={10} />
              </button>
            </div>
          </div>
        </div>
        <div className="panel flex items-center justify-between gap-3 px-4 py-3.5">
          <div className="min-w-0">
            <div className="text-[10px] uppercase tracking-[0.14em] text-faint font-mono">Open the source</div>
            <p className="mt-1 truncate font-mono text-[11px] text-muted">{REPO.owner}/{REPO.name}</p>
          </div>
          <a
            href={REPO.branchUrl}
            target="_blank"
            rel="noreferrer"
            className="focus-ring inline-flex shrink-0 items-center gap-1.5 rounded-md border border-line bg-panel-2 px-2.5 py-1.5 font-mono text-[10px] text-muted transition-colors hover:border-[#355443] hover:text-ink"
          >
            GitHub <Icon name="external" size={11} />
          </a>
        </div>
      </div>
    </div>
  );
}
