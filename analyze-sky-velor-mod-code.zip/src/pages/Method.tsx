import { ARTIFACT, FINDINGS, METHOD, REPO, formatBytes, shortHash } from "../data/audit";
import type { SharedAuditProps } from "../types";
import { Button, Callout, CopyButton, KeyValue, PageHeader, SectionLabel, Tag } from "../components/Ui";
import { Icon } from "../components/Icons";

const LIMITS = [
  "No Minecraft client or Forge dev environment was launched for this audit.",
  "The published JAR was inspected as an archive; transformed classes were not executed.",
  "No Gradle build, unit-test run or CI run was reproduced locally.",
  "Runtime impact is inference from code paths and is labelled by confidence.",
  "This is not a security audit, a malware analysis or a statement of server-rule compliance.",
  "The source branch can change after this snapshot; re-audit a new commit hash before acting on a later build.",
];

const CONFIRMED = [
  "JAR and source ZIP hashes and sizes",
  "MANIFEST and mcmod.info content",
  "Class and entry inventory, including the coremod plugin class",
  "Source line counts, package sizes and test-suite counts",
  "Defaults and write paths in the shipped config classes",
  "Presence/absence of license and notice files in the archive",
];

export function Method({ navigate, exportReport, showToast }: SharedAuditProps) {
  return (
    <div className="animate-fade-up">
      <PageHeader
        eyebrow="Method / evidence basis"
        title="How this review was made."
        description={
          <>
            The goal is to be useful without pretending to have run something that was not run. Everything below
            can be traced back to the published Beta-0.10.8.9v source archive or JAR.
          </>
        }
        actions={
          <>
            <Button variant="secondary" icon="download" onClick={exportReport}>Export audit</Button>
            <Button icon="findings" onClick={() => navigate("findings")}>Open findings</Button>
          </>
        }
      />

      <div className="grid gap-3 xl:grid-cols-[1.2fr_1fr]">
        <section className="panel p-5">
          <SectionLabel icon="method">Review sequence</SectionLabel>
          <div className="grid gap-2 sm:grid-cols-2">
            {METHOD.map((item) => (
              <div key={item.step} className="rounded-xl border border-line-soft bg-[#0a100d] p-3.5">
                <div className="mb-2 flex items-center justify-between">
                  <span className="font-pixel text-[10px] text-accent/80">{item.step}</span>
                  <Icon name="check" size={11} className="text-accent/60" />
                </div>
                <h3 className="text-[11px] font-semibold leading-snug text-ink">{item.title}</h3>
                <p className="mt-1 text-[10px] leading-relaxed text-faint">{item.detail}</p>
              </div>
            ))}
          </div>
          <div className="mt-3">
            <Callout tone="info" initials="i" title="What changed for this audit">
              The branch was analysed as a release candidate, not as a diff review. The relevant question was: if a
              user downloads this exact JAR today, what can go wrong, and which claims can be independently checked?
            </Callout>
          </div>
        </section>

        <div className="flex flex-col gap-3">
          <section className="panel p-5">
            <SectionLabel icon="file">Evidence inventory</SectionLabel>
            <div className="divide-y divide-line-soft">
              <KeyValue label="Repository" value={`${REPO.owner}/${REPO.name}`} />
              <KeyValue label="Branch" value={REPO.branch} />
              <KeyValue label="Version" value={REPO.version} />
              <KeyValue label="Source commit" value={REPO.sourceCommit} />
              <KeyValue label="Branch head" value={REPO.branchHead} />
              <KeyValue label="JAR size" value={`${formatBytes(ARTIFACT.sizeBytes)} · ${ARTIFACT.classes} classes`} />
              <KeyValue label="Source size" value={`${formatBytes(ARTIFACT.sourceSizeBytes)} · ${ARTIFACT.javaFiles} Java files`} />
              <KeyValue label="JAR SHA-256" value={shortHash(ARTIFACT.sha256)} />
              <KeyValue label="Source SHA-256" value={shortHash(ARTIFACT.sourceSha256)} />
              <KeyValue label="Reviewed" value={REPO.auditDate} />
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <CopyButton text={`${ARTIFACT.jar}\nsha256 ${ARTIFACT.sha256}\n\n${ARTIFACT.sourceZip}\nsha256 ${ARTIFACT.sourceSha256}`} label="Copy identity" onCopied={showToast} />
              <a
                href={REPO.branchUrl}
                target="_blank"
                rel="noreferrer"
                className="focus-ring inline-flex items-center gap-1.5 rounded-md border border-line bg-panel-2/70 px-2 py-1.5 font-mono text-[10px] text-muted hover:text-ink"
              >
                Branch <Icon name="external" size={11} />
              </a>
            </div>
          </section>

          <section className="panel p-5">
            <SectionLabel icon="check" trailing={<Tag color="#64e08d">confirmed</Tag>}>Direct observations</SectionLabel>
            <ul className="space-y-1.5">
              {CONFIRMED.map((item) => (
                <li key={item} className="flex items-start gap-2 text-[10px] leading-relaxed text-muted">
                  <Icon name="check" size={11} className="mt-0.5 shrink-0 text-accent/70" />
                  {item}
                </li>
              ))}
            </ul>
          </section>
        </div>
      </div>

      <div className="mt-3 grid gap-3 xl:grid-cols-[1fr_1fr]">
        <section className="panel p-5">
          <SectionLabel icon="alert" trailing={<Tag color="#ff8a81">scope</Tag>}>Limits of this audit</SectionLabel>
          <ul className="space-y-2">
            {LIMITS.map((item) => (
              <li key={item} className="flex items-start gap-2 text-[10px] leading-relaxed text-muted">
                <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-[#f2b35c]" />
                {item}
              </li>
            ))}
          </ul>
          <div className="mt-3">
            <Callout tone="warn" initials="!" title="Read the labels">
              “Confirmed” means observed in the archive or source. “High confidence” means the code path is explicit.
              Neither means the effect was reproduced in a live client.
            </Callout>
          </div>
        </section>

        <section className="panel p-5">
          <SectionLabel icon="code" trailing={<span className="font-mono text-[9px] text-faint">reproduce</span>}>
            Reproducing the inspection
          </SectionLabel>
          <p className="mb-2.5 text-[10px] leading-relaxed text-muted">
            No exploit or fabricated runtime evidence is included. The commands below only fetch and inspect the
            public artifacts; network access to GitHub is required.
          </p>
          <pre className="scroll-slim overflow-x-auto rounded-lg border border-line bg-[#070c09] p-3 font-mono text-[9px] leading-[1.85] text-[#a9c7b2]">
{`# source archive
curl -L -o sv-source.zip \\
  ${REPO.branchUrl.replace("tree", "raw")}/dist/${ARTIFACT.sourceZip}
sha256sum sv-source.zip

# published jar
curl -L -o sv.jar \\
  ${REPO.branchUrl.replace("tree", "raw")}/dist/${ARTIFACT.jar}
sha256sum sv.jar
unzip -p sv.jar META-INF/MANIFEST.MF
unzip -p sv.jar mcmod.info
unzip -l sv.jar | tail -n 8

# source facts
unzip -q sv-source.zip
find . -name '*.java' | wc -l
find src/main -name '*.java' -exec wc -l {} + | tail -1`}
          </pre>
          <CopyButton
            className="mt-2"
            label="Copy commands"
            onCopied={showToast}
            text={`curl -L -o sv-source.zip ${REPO.branchUrl.replace("tree", "raw")}/dist/${ARTIFACT.sourceZip}\ncurl -L -o sv.jar ${REPO.branchUrl.replace("tree", "raw")}/dist/${ARTIFACT.jar}\nsha256sum sv-source.zip sv.jar\nunzip -p sv.jar META-INF/MANIFEST.MF\nunzip -p sv.jar mcmod.info\nunzip -l sv.jar | tail -n 8`}
          />
        </section>
      </div>

      <section className="mt-3 panel p-5">
        <SectionLabel icon="shield">Confidence rubric</SectionLabel>
        <div className="grid gap-2 sm:grid-cols-3">
          {[
            {
              label: "High",
              color: "#64e08d",
              detail: "An explicit shipped code path, config default, or file/archive fact. The evidence block shows the exact context.",
            },
            {
              label: "Medium",
              color: "#f2b35c",
              detail: "Behaviour depends on runtime state, another mod, mapping order or a server response that was not exercised.",
            },
            {
              label: "Inference",
              color: "#75baff",
              detail: "Product, trust or design judgement. Useful for prioritisation, not a reproducible defect claim.",
            },
          ].map((item) => (
            <div key={item.label} className="rounded-xl border border-line-soft bg-[#0a100d] p-3.5">
              <div className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="font-mono text-[10px] uppercase tracking-wider" style={{ color: item.color }}>{item.label}</span>
              </div>
              <p className="mt-1.5 text-[10px] leading-relaxed text-muted">{item.detail}</p>
            </div>
          ))}
        </div>
        <div className="mt-4 flex flex-col items-start justify-between gap-3 border-t border-line-soft pt-4 sm:flex-row sm:items-center">
          <p className="max-w-2xl text-[10px] leading-relaxed text-faint">
            Independent review. Not affiliated with Mojang, Hypixel, Fakepixel, or the Sky VeLor authors. Mod names
            and trademarks belong to their respective owners. Use on a server only within its rules.
          </p>
          <Button size="sm" iconRight="arrow" onClick={() => navigate("findings")}>Review all {FINDINGS.length} findings</Button>
        </div>
      </section>
    </div>
  );
}
