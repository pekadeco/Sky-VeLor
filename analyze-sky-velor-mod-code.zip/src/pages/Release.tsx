import { useMemo } from "react";
import {
  ARTIFACT,
  CLAIMS,
  QA_CHECKS,
  RELEASE_CHECKS,
  REPO,
  VERDICT,
  formatBytes,
} from "../data/audit";
import type { SharedAuditProps } from "../types";
import { Button, Callout, CopyButton, KeyValue, MeterBar, PageHeader, SectionLabel, Tag } from "../components/Ui";
import { Icon, type IconName } from "../components/Icons";
import { cn } from "../utils/cn";

const CHECK_ICON: Record<string, { icon: IconName; color: string; label: string }> = {
  pass: { icon: "check", color: "#64e08d", label: "Pass" },
  warn: { icon: "alert", color: "#f2b35c", label: "Review" },
  fail: { icon: "close", color: "#ff8a81", label: "Blocked" },
  manual: { icon: "clock", color: "#75baff", label: "Manual" },
};

const QA_TONE: Record<string, string> = {
  Launch: "#75baff",
  Surface: "#64e08d",
  Dungeon: "#b6a3ff",
  Config: "#f2b35c",
  Safety: "#ff8a81",
  Soak: "#c9f36b",
};

export function Release({ qa, toggleQa, showToast, exportReport, readiness }: SharedAuditProps) {
  const qaDone = QA_CHECKS.filter((check) => qa[check.id]).length;
  const qaPercent = Math.round((qaDone / QA_CHECKS.length) * 100);
  const passCount = RELEASE_CHECKS.filter((check) => check.status === "pass").length;
  const warnCount = RELEASE_CHECKS.filter((check) => check.status === "warn").length;
  const failCount = RELEASE_CHECKS.filter((check) => check.status === "fail").length;
  const groups = useMemo(() => {
    return QA_CHECKS.reduce(
      (acc, check) => {
        acc[check.group] = [...(acc[check.group] ?? []), check];
        return acc;
      },
      {} as Record<string, typeof QA_CHECKS>,
    );
  }, []);

  function resetQa() {
    QA_CHECKS.forEach((check) => {
      if (qa[check.id]) toggleQa(check.id);
    });
    showToast("QA checklist reset");
  }

  return (
    <div className="animate-fade-up">
      <PageHeader
        eyebrow="Release check / artifact 0.10.8.9"
        title="A verified file is not a verified release."
        description={
          <>
            The JAR is real, mapped and structurally complete. The runtime and distribution story is not finished.
            This page separates what was checked byte-for-byte from what still needs a human on Fakepixel.
          </>
        }
        actions={
          <>
            <Button variant="secondary" icon="download" onClick={exportReport}>Export audit</Button>
            <Button icon="plan" onClick={() => document.getElementById("smoke-checklist")?.scrollIntoView({ behavior: "smooth", block: "start" })}>
              Smoke checklist
            </Button>
          </>
        }
      />

      <div className="mb-3 flex flex-col gap-3 rounded-xl border border-[#f2b35c]/25 bg-[linear-gradient(110deg,rgba(242,179,92,.08),rgba(11,17,13,.7))] px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-3">
          <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-[#f2b35c]/30 bg-[#f2b35c]/10 text-[#f2b35c]">
            <Icon name="alert" size={15} />
          </span>
          <div>
            <div className="text-[12px] font-semibold text-[#f6d8a6]">{VERDICT.label}</div>
            <p className="mt-0.5 max-w-2xl text-[10px] leading-relaxed text-muted">
              Verdict is based on unresolved critical and high findings plus runtime evidence. In-game checks completed
              here are a local record, not telemetry sent anywhere.
            </p>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-4">
          <div>
            <div className="font-mono text-[9px] uppercase tracking-wider text-faint">audit score</div>
            <div className="font-display text-lg font-semibold text-ink">{readiness}<span className="text-[10px] text-faint">/100</span></div>
          </div>
          <div className="w-24"><MeterBar value={readiness} height={5} tone={readiness < 60 ? "danger" : readiness < 80 ? "ember" : "accent"} /></div>
        </div>
      </div>

      <div className="grid gap-3 xl:grid-cols-[1.05fr_1fr]">
        <section className="panel overflow-hidden">
          <div className="flex items-center justify-between border-b border-line-soft px-5 py-3.5">
            <SectionLabel className="mb-0" icon="release">Artifact identity</SectionLabel>
            <Tag color="#64e08d">independently checked</Tag>
          </div>
          <div className="p-5">
            <div className="mb-4 rounded-xl border border-line bg-[#0a100d] px-3.5 py-3">
              <div className="mono-label mb-1.5 text-faint">published jar</div>
              <div className="break-all font-mono text-[12px] leading-relaxed text-accent-soft">{ARTIFACT.jar}</div>
              <div className="mt-2 flex flex-wrap gap-1.5">
                <Tag>{formatBytes(ARTIFACT.sizeBytes)}</Tag>
                <Tag>{ARTIFACT.classes} classes</Tag>
                <Tag>{ARTIFACT.entries} entries</Tag>
                <Tag>Java 8</Tag>
              </div>
            </div>

            <div className="mb-4 rounded-xl border border-line-soft bg-[#0a100d] px-3.5 py-3">
              <div className="mb-1.5 flex items-center justify-between">
                <span className="mono-label text-faint">sha-256</span>
                <CopyButton text={ARTIFACT.sha256} label="Hash" onCopied={showToast} />
              </div>
              <div className="break-all font-mono text-[10px] leading-[1.8] text-[#a9c7b2]">{ARTIFACT.sha256}</div>
            </div>

            <div className="divide-y divide-line-soft">
              <KeyValue label="Forge / Minecraft" value={`${REPO.forge} · ${REPO.mc}`} />
              <KeyValue label="Version contract" value={`${REPO.version} → ${REPO.numericVersion}`} />
              <KeyValue label="Mod id" value={REPO.modid} />
              <KeyValue label="Coremod plugin" value={ARTIFACT.coremod} />
              <KeyValue label="Source commit" value={REPO.sourceCommit} />
              <KeyValue label="Branch head" value={`${REPO.branchHead} (CI publish)`} />
              <KeyValue label="Source ZIP" value={ARTIFACT.sourceZip} />
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              <a
                href={`${REPO.branchUrl}/dist/${ARTIFACT.jar}`}
                target="_blank"
                rel="noreferrer"
                className="focus-ring inline-flex items-center gap-1.5 rounded-lg border border-accent/35 bg-accent/10 px-3 py-2 font-mono text-[10px] text-accent hover:bg-accent/15"
              >
                View JAR in repo <Icon name="external" size={11} />
              </a>
              <CopyButton text={`sha256sum ${ARTIFACT.jar}\n${ARTIFACT.sha256}`} label="Copy command" onCopied={showToast} className="px-3 py-2" />
            </div>

            <div className="mt-4 rounded-lg border border-line-soft bg-[#090f0b] px-3 py-2.5">
              <div className="font-mono text-[9px] uppercase tracking-wider text-faint">source verification command</div>
              <pre className="scroll-slim mt-1.5 overflow-x-auto font-mono text-[9px] leading-relaxed text-[#9ab5a2]">
{`python3 tools/verify_release_jar.py \\
  dist/${ARTIFACT.jar} \\
  --version ${REPO.version} \\
  --mcmod-version ${REPO.numericVersion}`}
              </pre>
              <CopyButton
                text={`python3 tools/verify_release_jar.py dist/${ARTIFACT.jar} --version ${REPO.version} --mcmod-version ${REPO.numericVersion}`}
                label="Copy verifier"
                onCopied={showToast}
                className="mt-2"
              />
            </div>
          </div>
        </section>

        <div className="flex flex-col gap-3">
          <section className="panel p-5">
            <SectionLabel
              icon="shield"
              trailing={
                <div className="flex items-center gap-2 font-mono text-[9px]">
                  <span className="text-accent">{passCount} pass</span>
                  <span className="text-[#f2b35c]">{warnCount} review</span>
                  <span className="text-[#ff8a81]">{failCount} blocked</span>
                </div>
              }
            >
              Release verification
            </SectionLabel>
            <div className="space-y-1.5">
              {RELEASE_CHECKS.map((check) => {
                const meta = CHECK_ICON[check.status];
                return (
                  <div key={check.label} className="flex items-start gap-2.5 rounded-lg border border-line-soft bg-[#0a100d] px-3 py-2.5">
                    <span
                      className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded border"
                      style={{ color: meta.color, borderColor: `${meta.color}45`, backgroundColor: `${meta.color}10` }}
                    >
                      <Icon name={meta.icon} size={11} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[11px] font-medium text-ink">{check.label}</span>
                        <span className="shrink-0 font-mono text-[8px] uppercase tracking-wider" style={{ color: meta.color }}>{meta.label}</span>
                      </div>
                      <p className="mt-0.5 text-[9px] leading-relaxed text-faint">{check.detail}</p>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-3">
              <Callout tone="danger" initials="!" title="The three blockers">
                In-game validation is missing, license files contradict the README, and automation remains reachable.
                None of these is fixed by rebuilding the JAR.
              </Callout>
            </div>
          </section>

          <section className="panel p-5">
            <SectionLabel icon="info">What “verified” means here</SectionLabel>
            <p className="text-[10px] leading-relaxed text-muted">
              This audit opened the published JAR and source ZIP. It confirmed identity, metadata, class inventory and
              the absence of unrelated nested archives. It did <span className="text-ink">not</span> run Forge, Gradle
              tests or a Minecraft client. Those are deliberately marked as unverified.
            </p>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <div className="rounded-lg border border-line-soft bg-[#0a100d] px-2.5 py-2">
                <div className="font-mono text-[8px] uppercase tracking-wider text-faint">source zip sha</div>
                <div className="mt-1 truncate font-mono text-[9px] text-muted">{ARTIFACT.sourceSha256.slice(0, 22)}…</div>
              </div>
              <div className="rounded-lg border border-line-soft bg-[#0a100d] px-2.5 py-2">
                <div className="font-mono text-[8px] uppercase tracking-wider text-faint">source size</div>
                <div className="mt-1 font-mono text-[9px] text-muted">{formatBytes(ARTIFACT.sourceSizeBytes)}</div>
              </div>
            </div>
          </section>
        </div>
      </div>

      <section id="smoke-checklist" className="mt-3 panel scroll-mt-20 p-5">
        <div className="flex flex-col gap-3 border-b border-line-soft pb-4 sm:flex-row sm:items-end sm:justify-between">
          <div className="max-w-2xl">
            <SectionLabel icon="plan">In-game smoke checklist</SectionLabel>
            <p className="text-[11px] leading-relaxed text-muted">
              The missing release gate. Work down this list on a clean client. Check items only when observed; the
              score and audit posture update immediately. Progress is stored in this browser.
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-3">
            <div className="text-right">
              <div className="font-display text-2xl font-semibold leading-none text-ink">{qaDone}<span className="text-sm text-faint">/{QA_CHECKS.length}</span></div>
              <div className="mt-1 font-mono text-[8px] uppercase tracking-wider text-faint">verified</div>
            </div>
            <div className="h-8 w-px bg-line" />
            <Button size="sm" variant="ghost" icon="refresh" onClick={resetQa}>Reset</Button>
          </div>
        </div>
        <div className="mt-3 mb-4">
          <MeterBar value={qaPercent} height={6} tone={qaPercent === 100 ? "accent" : qaPercent > 60 ? "ember" : "danger"} />
          <div className="mt-1.5 flex items-center justify-between font-mono text-[9px] text-faint">
            <span>0 verified</span>
            <span className={qaPercent === 100 ? "text-accent" : ""}>{qaPercent}% · {QA_CHECKS.length - qaDone} remaining</span>
            <span>{QA_CHECKS.length} checks</span>
          </div>
        </div>

        <div className="grid gap-3 lg:grid-cols-2 2xl:grid-cols-3">
          {(Object.keys(groups) as string[]).map((group) => (
            <div key={group} className="rounded-xl border border-line-soft bg-[#0a100d]/80 p-3">
              <div className="mb-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: QA_TONE[group] ?? "#64e08d" }} />
                  <span className="font-mono text-[9px] uppercase tracking-[0.14em]" style={{ color: QA_TONE[group] ?? "#64e08d" }}>{group}</span>
                </div>
                <span className="font-mono text-[8px] text-faint">
                  {groups[group].filter((check) => qa[check.id]).length}/{groups[group].length}
                </span>
              </div>
              <div className="space-y-1">
                {groups[group].map((check) => {
                  const checked = Boolean(qa[check.id]);
                  return (
                    <button
                      key={check.id}
                      type="button"
                      onClick={() => toggleQa(check.id)}
                      className={cn(
                        "focus-ring flex w-full items-start gap-2 rounded-md border px-2 py-2 text-left transition-colors",
                        checked ? "border-accent/25 bg-accent/[0.055]" : "border-transparent hover:bg-white/[0.025]",
                      )}
                      aria-pressed={checked}
                    >
                      <span
                        className={cn(
                          "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-[3px] border transition-colors",
                          checked ? "border-accent bg-accent text-[#061109]" : "border-line bg-[#0b120e]",
                        )}
                      >
                        {checked && <Icon name="check" size={10} />}
                      </span>
                      <span className="min-w-0">
                        <span className={cn("block text-[10px] font-medium leading-snug", checked ? "text-accent-soft" : "text-[#cbd9d0]")}>
                          {check.label}
                        </span>
                        <span className="mt-0.5 block text-[9px] leading-relaxed text-faint">{check.detail}</span>
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-line-soft bg-[#090f0b] px-3 py-2.5">
          <span className="text-[9px] leading-relaxed text-faint">
            QA records are local only. Export audit includes your checklist state for a review thread.
          </span>
          <CopyButton
            text={`Sky VeLor ${REPO.version} — in-game QA\n\n${QA_CHECKS.map((check) => `${qa[check.id] ? "[x]" : "[ ]"} ${check.group} · ${check.label}\n    ${check.detail}`).join("\n")}`}
            label="Copy checklist"
            onCopied={showToast}
          />
        </div>
      </section>

      <section className="mt-3 panel p-5">
        <SectionLabel icon="findings" trailing={<Tag>{CLAIMS.length} claims checked</Tag>}>Claims vs evidence</SectionLabel>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[680px] border-collapse text-left">
            <thead>
              <tr className="border-b border-line">
                <th className="pb-2 pr-3 font-mono text-[9px] font-medium uppercase tracking-[0.13em] text-faint">Claim</th>
                <th className="pb-2 pr-3 font-mono text-[9px] font-medium uppercase tracking-[0.13em] text-faint">Verdict</th>
                <th className="pb-2 font-mono text-[9px] font-medium uppercase tracking-[0.13em] text-faint">Evidence</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line-soft">
              {CLAIMS.map((claim) => {
                const color = claim.verdict === "verified" ? "#64e08d" : claim.verdict === "partial" ? "#f2b35c" : "#ff8a81";
                return (
                  <tr key={claim.claim} className="align-top">
                    <td className="w-[34%] py-3 pr-3 text-[11px] leading-snug text-[#cbd9d0]">{claim.claim}</td>
                    <td className="w-[14%] py-3 pr-3">
                      <span
                        className="inline-flex items-center gap-1 rounded border px-1.5 py-1 font-mono text-[8px] uppercase tracking-wider"
                        style={{ color, borderColor: `${color}40`, backgroundColor: `${color}0f` }}
                      >
                        <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: color }} />
                        {claim.verdict}
                      </span>
                    </td>
                    <td className="py-3 text-[10px] leading-relaxed text-muted">{claim.detail}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-line-soft pt-3">
          <span className="text-[9px] leading-relaxed text-faint">
            Verdict definitions: verified = borne out by source/artifact; partial = true with material caveats;
            contradicted = evidence disagrees.
          </span>
          <Button size="sm" variant="secondary" icon="download" onClick={exportReport}>Download report</Button>
        </div>
      </section>
    </div>
  );
}
