import { useMemo, useState } from "react";
import {
  LARGEST_FILES,
  MODULES,
  REPO,
  SEVERITY_META,
  SEVERITY_ORDER,
  type Severity,
} from "../data/audit";
import type { SharedAuditProps } from "../types";
import { Button, Callout, MeterBar, PageHeader, SectionLabel, SeverityBadge, Tag } from "../components/Ui";
import { Icon, type IconName } from "../components/Icons";
import { cn } from "../utils/cn";

const RISKS: Severity[] = ["critical", "high", "medium", "low"];
type SortKey = "risk" | "size" | "tests";

const MODULE_ICONS: Record<string, IconName> = {
  gui: "layers",
  feature: "spark",
  "dungeon-core": "server",
  "dungeon-assist": "alert",
  "dungeon-sync": "server",
  itemlock: "lock",
  hud: "gauge",
  chat: "method",
  config: "file",
  core: "code",
  render: "eye",
  assists: "shield",
};

function ArchitectureLane({
  title,
  hint,
  nodes,
  tone,
}: {
  title: string;
  hint: string;
  nodes: { name: string; sub: string; risk?: Severity }[];
  tone: string;
}) {
  return (
    <div className="rounded-xl border border-line-soft bg-[#0a100d]/80 p-3">
      <div className="mb-2.5 flex items-center justify-between">
        <span className="font-mono text-[9px] uppercase tracking-[0.14em]" style={{ color: tone }}>{title}</span>
        <span className="font-mono text-[8px] text-faint">{hint}</span>
      </div>
      <div className="grid grid-cols-2 gap-1.5">
        {nodes.map((node) => (
          <div key={node.name} className="rounded-md border border-line bg-[#0d1510] px-2 py-1.5">
            <div className="truncate font-mono text-[9px] text-ink">{node.name}</div>
            <div className="mt-0.5 flex items-center justify-between gap-1">
              <span className="truncate font-mono text-[8px] text-faint">{node.sub}</span>
              {node.risk && <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ backgroundColor: SEVERITY_META[node.risk].color }} />}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function Modules({ navigate }: SharedAuditProps) {
  const [sort, setSort] = useState<SortKey>("risk");
  const [riskFilter, setRiskFilter] = useState<Severity | "all">("all");

  const sorted = useMemo(() => {
    return [...MODULES]
      .filter((module) => riskFilter === "all" || module.risk === riskFilter)
      .sort((a, b) => {
        if (sort === "size") return b.loc - a.loc;
        if (sort === "tests") return a.suites - b.suites || b.loc - a.loc;
        return SEVERITY_ORDER[a.risk] - SEVERITY_ORDER[b.risk] || b.loc - a.loc;
      });
  }, [riskFilter, sort]);

  const maxLoc = Math.max(...MODULES.map((module) => module.loc));
  const maxFile = LARGEST_FILES[0].loc;
  const totalSuites = 65;

  return (
    <div className="animate-fade-up">
      <PageHeader
        eyebrow="Architecture / package map"
        title="Where the mod is heavy."
        description={
          <>
            Package-level inventory for {REPO.version}. LOC and tests are counted from the published source archive.
            Risk is an audit judgement based on blast radius and runtime coverage, not a bug count.
          </>
        }
        actions={
          <div className="flex items-center gap-2">
            <div className="rounded-lg border border-line bg-panel px-3 py-2 text-center">
              <div className="font-display text-lg font-semibold leading-none text-ink">202</div>
              <div className="mt-1 font-mono text-[8px] uppercase tracking-wider text-faint">source files</div>
            </div>
            <div className="rounded-lg border border-line bg-panel px-3 py-2 text-center">
              <div className="font-display text-lg font-semibold leading-none text-ink">34.4k</div>
              <div className="mt-1 font-mono text-[8px] uppercase tracking-wider text-faint">lines</div>
            </div>
            <div className="rounded-lg border border-line bg-panel px-3 py-2 text-center">
              <div className="font-display text-lg font-semibold leading-none text-ink">{totalSuites}</div>
              <div className="mt-1 font-mono text-[8px] uppercase tracking-wider text-faint">owned suites</div>
            </div>
          </div>
        }
      />

      <div className="grid gap-3 xl:grid-cols-[1.15fr_1fr]">
        <section className="panel p-5">
          <SectionLabel icon="server" trailing={<Tag>runtime path</Tag>}>
            Architecture at a glance
          </SectionLabel>
          <div className="space-y-2">
            <ArchitectureLane
              title="01 · Forge input"
              hint="1.8.9 event bus"
              tone="#75baff"
              nodes={[
                { name: "ClientTickEvent", sub: "tick + world gate" },
                { name: "GuiScreenEvent", sub: "screen input / draw" },
                { name: "RenderGameOverlay", sub: "HUD surface" },
                { name: "Mouse / Keyboard", sub: "interaction hooks" },
              ]}
            />
            <div className="flex justify-center py-0.5 text-faint">
              <Icon name="chevron" size={12} className="rotate-90" />
            </div>
            <ArchitectureLane
              title="02 · Controllers"
              hint="feature gates + state"
              tone="#64e08d"
              nodes={[
                { name: "Dungeon + ESP", sub: "2,987 + 1,593 LOC", risk: "high" },
                { name: "Terminal Assist", sub: "874 LOC · 1 suite", risk: "critical" },
                { name: "Item Lock + Swap", sub: "2,181 LOC · 7 suites", risk: "high" },
                { name: "Chat + HUD", sub: "2,743 LOC · 10 suites", risk: "medium" },
                { name: "Sync transport", sub: "975 LOC · 0 suites", risk: "medium" },
                { name: "Inventory / visual", sub: "957 LOC · 1 suite", risk: "medium" },
              ]}
            />
            <div className="flex justify-center py-0.5 text-faint">
              <Icon name="chevron" size={12} className="rotate-90" />
            </div>
            <div className="grid gap-2 sm:grid-cols-2">
              <ArchitectureLane
                title="03a · Bytecode"
                hint="class-load time"
                tone="#ff8a81"
                nodes={[
                  { name: "ItemAnimationTransformer", sub: "renderItemInFirstPerson", risk: "critical" },
                  { name: "BlockParticleTransformer", sub: "EffectRenderer target" },
                  { name: "ItemLockSwapTransformer", sub: "windowClick / drops", risk: "high" },
                  { name: "VisualAssistTransformer", sub: "hurt camera", risk: "medium" },
                ]}
              />
              <ArchitectureLane
                title="03b · Persistence"
                hint="atomic file IO"
                tone="#f2b35c"
                nodes={[
                  { name: "AppleSettings", sub: "674 LOC · 5 suites" },
                  { name: "ConfigFiles", sub: "atomic replace + legacy" },
                  { name: "AssistSettings", sub: "opt-in defaults" },
                  { name: "HUD / ESP / Sparkle", sub: "per-module keys" },
                ]}
              />
            </div>
          </div>
        </section>

        <div className="flex flex-col gap-3">
          <section className="panel p-5">
            <SectionLabel icon="alert" trailing={<span className="font-mono text-[9px] text-[#ff8a81]">coverage blind spots</span>}>
              Least-tested, highest-risk
            </SectionLabel>
            <div className="space-y-2">
              {MODULES.filter((module) => module.suites === 0 || module.risk === "critical").map((module) => (
                <div key={module.id} className="flex items-start gap-3 rounded-lg border border-line-soft bg-[#0a100d] px-3 py-2.5">
                  <span
                    className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-md border"
                    style={{
                      color: SEVERITY_META[module.risk].color,
                      borderColor: SEVERITY_META[module.risk].border,
                      backgroundColor: SEVERITY_META[module.risk].bg,
                    }}
                  >
                    <Icon name={MODULE_ICONS[module.id] ?? "layers"} size={13} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-medium text-ink">{module.name}</span>
                      <span className="font-mono text-[9px]" style={{ color: module.suites === 0 ? "#ff8a81" : "#f2b35c" }}>
                        {module.suites} {module.suites === 1 ? "suite" : "suites"}
                      </span>
                    </div>
                    <p className="mt-0.5 text-[9px] leading-relaxed text-faint">{module.signal}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-3">
              <Callout tone="warn" initials="!" title="The features most likely to break are the ones least exercised">
                Socket transport, reflection-based inventory helpers and GUI input interception have no executed test
                suite. Start there after the safety fixes.
              </Callout>
            </div>
          </section>

          <section className="panel p-5">
            <SectionLabel icon="file" trailing={<span className="font-mono text-[9px] text-faint">top 10 by LOC</span>}>
              Complexity hotspots
            </SectionLabel>
            <div className="space-y-2.5">
              {LARGEST_FILES.map((file, index) => (
                <div key={file.name}>
                  <div className="mb-1 flex items-center justify-between gap-2 font-mono text-[9px]">
                    <span className="truncate text-muted">
                      <span className="mr-1.5 text-faint">{String(index + 1).padStart(2, "0")}</span>
                      {file.name}
                    </span>
                    <span className="shrink-0 text-faint">{file.loc.toLocaleString()}</span>
                  </div>
                  <MeterBar value={(file.loc / maxFile) * 100} height={3} tone={file.loc > 1000 ? "ember" : "accent"} />
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>

      <section className="mt-3 panel p-5">
        <div className="flex flex-col gap-3 border-b border-line-soft pb-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <SectionLabel icon="modules">Module inventory</SectionLabel>
            <p className="text-[11px] leading-relaxed text-muted">
              Grouped package map. A high-risk module is not necessarily broken — it is one where a mistake has
              an outsized consequence.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 rounded-lg border border-line bg-[#0a100d] p-1">
              {(["risk", "size", "tests"] as SortKey[]).map((key) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setSort(key)}
                  className={cn(
                    "focus-ring rounded px-2 py-1 font-mono text-[9px] uppercase tracking-wider transition-colors",
                    sort === key ? "bg-panel-3 text-accent" : "text-faint hover:text-ink",
                  )}
                >
                  {key === "risk" ? "risk" : key === "size" ? "LOC" : "tests"}
                </button>
              ))}
            </div>
            <select
              value={riskFilter}
              onChange={(event) => setRiskFilter(event.target.value as Severity | "all")}
              className="focus-ring rounded-lg border border-line bg-[#0a100d] px-2 py-2 font-mono text-[10px] text-muted outline-none"
              aria-label="Filter modules by risk"
            >
              <option value="all">All risk levels</option>
              {RISKS.map((risk) => <option key={risk} value={risk}>{SEVERITY_META[risk].label}</option>)}
            </select>
          </div>
        </div>

        <div className="mt-4 grid gap-2.5 md:grid-cols-2 2xl:grid-cols-3">
          {sorted.map((module) => (
            <article key={module.id} className="group relative overflow-hidden rounded-xl border border-line-soft bg-[#0b120e]/80 p-4 transition-all hover:border-[#31523f] hover:bg-[#101a14]">
              <div className="mb-3 flex items-start justify-between gap-2">
                <div className="flex min-w-0 items-start gap-2.5">
                  <span
                    className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border bg-[#0b1310]"
                    style={{ color: SEVERITY_META[module.risk].color, borderColor: SEVERITY_META[module.risk].border }}
                  >
                    <Icon name={MODULE_ICONS[module.id] ?? "layers"} size={15} />
                  </span>
                  <div className="min-w-0">
                    <h3 className="text-[12px] font-semibold leading-tight text-ink">{module.name}</h3>
                    <div className="mt-1 truncate font-mono text-[9px] text-faint">{module.packages.join(" · ")}</div>
                  </div>
                </div>
                <SeverityBadge severity={module.risk} compact />
              </div>
              <p className="min-h-[42px] text-[10px] leading-relaxed text-muted">{module.summary}</p>
              <div className="mt-3 grid grid-cols-3 gap-1.5">
                <div className="rounded-md border border-line-soft bg-[#0a100d] px-2 py-1.5">
                  <div className="font-mono text-[8px] uppercase tracking-wider text-faint">files</div>
                  <div className="font-mono text-[11px] text-ink">{module.files}</div>
                </div>
                <div className="rounded-md border border-line-soft bg-[#0a100d] px-2 py-1.5">
                  <div className="font-mono text-[8px] uppercase tracking-wider text-faint">lines</div>
                  <div className="font-mono text-[11px] text-ink">{module.loc.toLocaleString()}</div>
                </div>
                <div className="rounded-md border border-line-soft bg-[#0a100d] px-2 py-1.5">
                  <div className="font-mono text-[8px] uppercase tracking-wider text-faint">suites</div>
                  <div
                    className="font-mono text-[11px]"
                    style={{ color: module.suites === 0 ? "#ff8a81" : module.suites < 3 ? "#f2b35c" : "#64e08d" }}
                  >
                    {module.suites}
                  </div>
                </div>
              </div>
              <div className="mt-3">
                <div className="mb-1 flex items-center justify-between font-mono text-[8px] uppercase tracking-wider text-faint">
                  <span>source share</span>
                  <span>{Math.round((module.loc / 34449) * 100)}%</span>
                </div>
                <MeterBar value={(module.loc / maxLoc) * 100} height={3} tone={module.risk === "critical" ? "danger" : module.risk === "high" ? "ember" : "accent"} />
              </div>
              <p className="mt-2.5 rounded-md border border-line-soft bg-[#090f0b] px-2 py-1.5 text-[9px] leading-relaxed text-faint">
                {module.signal}
              </p>
              <div className="mt-2.5 flex flex-wrap gap-1">
                {module.tags.map((tag) => <Tag key={tag}>{tag}</Tag>)}
              </div>
            </article>
          ))}
        </div>
      </section>

      <div className="mt-3 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line-soft bg-[#0a100d] px-4 py-3">
        <p className="text-[10px] leading-relaxed text-faint">
          65 suites exist in the test tree; 64 map cleanly to these module groups. The remaining cross-cutting AssistFeatureTests suite covers shared feature policy.
        </p>
        <Button size="sm" variant="secondary" iconRight="arrow" onClick={() => navigate("findings")}>
          Go to findings
        </Button>
      </div>
    </div>
  );
}
