import { useEffect, useMemo, useRef, useState } from "react";
import {
  FILTER_AREAS,
  FINDINGS,
  REPO,
  SEVERITY_META,
  SEVERITY_ORDER,
  STATUS_META,
  type Area,
  type Finding,
  type FindingStatus,
  type Severity,
} from "../data/audit";
import type { SharedAuditProps } from "../types";
import { Button, Callout, CopyButton, MeterBar, PageHeader, SectionLabel, SeverityBadge, Tag } from "../components/Ui";
import { Icon } from "../components/Icons";
import { cn } from "../utils/cn";

const SEVERITIES: Severity[] = ["critical", "high", "medium", "low"];
const STATUSES: FindingStatus[] = ["open", "planned", "fixed", "accepted"];

function sourceUrl(file: string) {
  let path = file;
  if (!path.includes("/") && path.endsWith(".java")) {
    path = `src/main/java/com/arena/pekaclient/${path}`;
  } else if (/^(gui|dungeon|config|feature|assist|itemlockswap|render|chat|hud)\//.test(path)) {
    path = `src/main/java/com/arena/pekaclient/${path}`;
  }
  return `${REPO.branchUrl}/${path}`;
}

function statusLabel(status: FindingStatus) {
  return STATUS_META[status].label;
}

export function Findings({ statuses, setStatus, planned, togglePlanned, showToast }: SharedAuditProps) {
  const [query, setQuery] = useState("");
  const [severity, setSeverity] = useState<Severity | "all">("all");
  const [area, setArea] = useState<Area | "all">("all");
  const [statusFilter, setStatusFilter] = useState<FindingStatus | "all">("all");
  const [plannedOnly, setPlannedOnly] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const selected = FINDINGS.find((finding) => finding.id === selectedId) ?? null;

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      const target = event.target as HTMLElement | null;
      const typing = target && ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName);
      if (event.key === "/" && !typing) {
        event.preventDefault();
        searchRef.current?.focus();
      }
      if (event.key === "Escape") {
        setSelectedId(null);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (!selected) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [selected]);

  const counts = useMemo(() => {
    return SEVERITIES.reduce(
      (acc, item) => {
        acc[item] = FINDINGS.filter((finding) => finding.severity === item).length;
        return acc;
      },
      {} as Record<Severity, number>,
    );
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return FINDINGS.filter((finding) => {
      const current = statuses[finding.id] ?? "open";
      if (severity !== "all" && finding.severity !== severity) return false;
      if (area !== "all" && finding.area !== area) return false;
      if (statusFilter !== "all" && current !== statusFilter) return false;
      if (plannedOnly && !planned[finding.id]) return false;
      if (!q) return true;
      return [finding.id, finding.title, finding.summary, finding.component, finding.area, finding.file, ...finding.tags]
        .join(" ")
        .toLowerCase()
        .includes(q);
    }).sort(
      (a, b) =>
        SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity] ||
        Number(planned[b.id] ?? false) - Number(planned[a.id] ?? false) ||
        a.id.localeCompare(b.id),
    );
  }, [area, planned, plannedOnly, query, severity, statusFilter, statuses]);

  const fixed = FINDINGS.filter((finding) => statuses[finding.id] === "fixed").length;
  const inPlan = FINDINGS.filter((finding) => planned[finding.id]).length;
  const open = FINDINGS.filter((finding) => (statuses[finding.id] ?? "open") === "open").length;

  function resetFilters() {
    setQuery("");
    setSeverity("all");
    setArea("all");
    setStatusFilter("all");
    setPlannedOnly(false);
  }

  function handleStatus(finding: Finding, next: FindingStatus) {
    setStatus(finding.id, next);
    showToast(`${finding.id} → ${statusLabel(next)}`);
  }

  function handlePlan(finding: Finding) {
    const wasPlanned = Boolean(planned[finding.id]);
    togglePlanned(finding.id);
    showToast(wasPlanned ? `${finding.id} removed from the fix plan` : `${finding.id} added to the fix plan`);
  }

  return (
    <div className="animate-fade-up">
      <PageHeader
        eyebrow={`Findings / ${FINDINGS.length} items`}
        title="The bug list, with receipts."
        description={
          <>
            Every item is tied to a file and line in the 0.10.8.9 source or release archive. Change status locally,
            build a fix queue, and export the brief when you are ready to patch.
          </>
        }
        actions={
          <>
            <div className="flex items-center gap-2 rounded-lg border border-line bg-panel px-3 py-2">
              <span className="font-mono text-[9px] uppercase tracking-wider text-faint">plan</span>
              <span className="font-mono text-[11px] text-accent">{inPlan}</span>
              <span className="text-line">/</span>
              <span className="font-mono text-[9px] uppercase tracking-wider text-faint">fixed</span>
              <span className="font-mono text-[11px] text-accent-soft">{fixed}</span>
            </div>
          </>
        }
      />

      <div className="mb-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
        {SEVERITIES.map((item) => {
          const meta = SEVERITY_META[item];
          const isActive = severity === item;
          return (
            <button
              key={item}
              type="button"
              onClick={() => setSeverity(isActive ? "all" : item)}
              className={cn(
                "focus-ring group flex items-center justify-between rounded-xl border px-3.5 py-3 text-left transition-all",
                isActive ? "bg-panel-2" : "border-line-soft bg-[#0b110e]/70 hover:border-[#31523f]",
              )}
              style={isActive ? { borderColor: meta.border, backgroundColor: meta.bg } : undefined}
            >
              <div>
                <div className="font-mono text-[9px] uppercase tracking-[0.14em]" style={{ color: meta.color }}>
                  {meta.label}
                </div>
                <div className="mt-1 flex items-baseline gap-2">
                  <span className="font-display text-[22px] font-semibold leading-none text-ink">{counts[item]}</span>
                  <span className="text-[10px] text-faint">findings</span>
                </div>
              </div>
              <span
                className="flex h-8 w-8 items-center justify-center rounded-lg border"
                style={{ borderColor: meta.border, color: meta.color, background: meta.bg }}
              >
                <Icon name={item === "critical" ? "alert" : item === "high" ? "wrench" : item === "medium" ? "info" : "shield"} size={14} />
              </span>
            </button>
          );
        })}
      </div>

      <div className="panel mb-3 flex flex-col gap-3 p-3.5">
        <div className="flex flex-col gap-2 lg:flex-row lg:items-center">
          <div className="relative min-w-0 flex-1">
            <Icon name="search" size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-faint" />
            <input
              ref={searchRef}
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search findings, files, components…"
              className="focus-ring w-full rounded-lg border border-line bg-[#0a100d] py-2.5 pl-9 pr-16 text-[12px] text-ink placeholder:text-faint/70"
              aria-label="Search findings"
            />
            <kbd className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 rounded border border-line bg-panel px-1.5 py-0.5 font-mono text-[9px] text-faint">
              /
            </kbd>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <label className="flex items-center gap-2 rounded-lg border border-line bg-[#0a100d] px-2.5 py-2">
              <span className="font-mono text-[9px] uppercase tracking-wider text-faint">area</span>
              <select
                value={area}
                onChange={(event) => setArea(event.target.value as Area | "all")}
                className="focus-ring max-w-[120px] cursor-pointer bg-transparent font-mono text-[10px] text-ink outline-none"
              >
                <option value="all">All areas</option>
                {FILTER_AREAS.map((item) => (
                  <option key={item} value={item}>{item}</option>
                ))}
              </select>
            </label>
            <label className="flex items-center gap-2 rounded-lg border border-line bg-[#0a100d] px-2.5 py-2">
              <span className="font-mono text-[9px] uppercase tracking-wider text-faint">status</span>
              <select
                value={statusFilter}
                onChange={(event) => setStatusFilter(event.target.value as FindingStatus | "all")}
                className="focus-ring cursor-pointer bg-transparent font-mono text-[10px] text-ink outline-none"
              >
                <option value="all">Any</option>
                {STATUSES.map((item) => (
                  <option key={item} value={item}>{statusLabel(item)}</option>
                ))}
              </select>
            </label>
            <button
              type="button"
              onClick={() => setPlannedOnly((value) => !value)}
              className={cn(
                "focus-ring flex items-center gap-1.5 rounded-lg border px-2.5 py-2 font-mono text-[10px] transition-colors",
                plannedOnly ? "border-accent/40 bg-accent/10 text-accent" : "border-line bg-[#0a100d] text-muted hover:border-[#355443]",
              )}
            >
              <Icon name="plan" size={12} />
              In plan
            </button>
            <button
              type="button"
              onClick={resetFilters}
              className="focus-ring flex h-[34px] w-[34px] items-center justify-center rounded-lg border border-line bg-[#0a100d] text-faint transition-colors hover:text-ink"
              title="Reset filters"
            >
              <Icon name="refresh" size={13} />
            </button>
          </div>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-line-soft pt-2.5">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="mr-1 font-mono text-[9px] uppercase tracking-[0.13em] text-faint">severity:</span>
            <button
              type="button"
              onClick={() => setSeverity("all")}
              className={cn(
                "rounded-md border px-2 py-1 font-mono text-[9px] uppercase tracking-wider transition-colors",
                severity === "all" ? "border-accent/35 bg-accent/10 text-accent" : "border-line-soft text-faint hover:text-ink",
              )}
            >
              all {FINDINGS.length}
            </button>
            {SEVERITIES.map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => setSeverity(severity === item ? "all" : item)}
                className={cn(
                  "rounded-md border px-2 py-1 font-mono text-[9px] uppercase tracking-wider transition-colors",
                  severity === item ? "" : "border-line-soft text-faint hover:text-ink",
                )}
                style={severity === item ? { borderColor: SEVERITY_META[item].border, backgroundColor: SEVERITY_META[item].bg, color: SEVERITY_META[item].color } : undefined}
              >
                {SEVERITY_META[item].label} {counts[item]}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-3">
            <span className="font-mono text-[9px] text-faint">{filtered.length} shown · {open} open</span>
            <div className="hidden w-24 sm:block">
              <MeterBar value={(fixed / FINDINGS.length) * 100} height={4} label="Findings fixed" />
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        {filtered.map((finding) => {
          const current = statuses[finding.id] ?? "open";
          const isPlanned = Boolean(planned[finding.id]);
          return (
            <div
              key={finding.id}
              role="button"
              tabIndex={0}
              aria-label={`Open ${finding.id}: ${finding.title}`}
              onClick={() => setSelectedId(finding.id)}
              onKeyDown={(event) => {
                if (event.key === "Enter" || event.key === " ") {
                  event.preventDefault();
                  setSelectedId(finding.id);
                }
              }}
              className={cn(
                "focus-ring group relative flex cursor-pointer flex-col gap-3 overflow-hidden rounded-xl border bg-[#0c120e]/85 px-3.5 py-3.5 transition-all hover:border-[#335741] hover:bg-[#111a14] sm:flex-row sm:items-center",
                current === "fixed" ? "border-accent/20 opacity-75" : "border-line-soft",
              )}
            >
              <span
                className="absolute inset-y-0 left-0 w-[2px]"
                style={{ backgroundColor: current === "fixed" ? "#64e08d" : SEVERITY_META[finding.severity].color, opacity: 0.7 }}
              />
              <div className="flex shrink-0 items-center gap-2 sm:w-[110px] sm:flex-col sm:items-start">
                <SeverityBadge severity={finding.severity} compact />
                <span className="font-mono text-[9px] uppercase tracking-wider text-faint">{finding.id}</span>
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[12px] font-medium leading-snug text-ink group-hover:text-accent-soft">{finding.title}</span>
                  <Tag>{finding.area}</Tag>
                  {isPlanned && <Tag color="#f2b35c">in plan</Tag>}
                </div>
                <p className="mt-1 line-clamp-2 text-[10px] leading-relaxed text-faint">{finding.summary}</p>
                <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-[9px] text-faint/90">
                  <span className="inline-flex items-center gap-1"><Icon name="file" size={9} />{finding.file}:{finding.lines}</span>
                  <span>confidence {finding.confidence.toLowerCase()}</span>
                  <span>effort {finding.effort}</span>
                </div>
              </div>
              <div className="flex shrink-0 items-center gap-2 sm:pl-2">
                <button
                  type="button"
                  onClick={(event) => {
                    event.stopPropagation();
                    handlePlan(finding);
                  }}
                  onKeyDown={(event) => event.stopPropagation()}
                  className={cn(
                    "focus-ring flex h-7 items-center gap-1.5 rounded-md border px-2 font-mono text-[9px] uppercase tracking-wider transition-colors",
                    isPlanned
                      ? "border-[#f2b35c]/35 bg-[#f2b35c]/10 text-[#f2d09b]"
                      : "border-line bg-[#0a100d] text-faint hover:text-ink",
                  )}
                  title={isPlanned ? "Remove from fix plan" : "Add to fix plan"}
                >
                  <Icon name={isPlanned ? "check" : "plan"} size={11} />
                  {isPlanned ? "planned" : "plan"}
                </button>
                <label className="sr-only" htmlFor={`status-${finding.id}`}>Status for {finding.id}</label>
                <select
                  id={`status-${finding.id}`}
                  value={current}
                  onClick={(event) => event.stopPropagation()}
                  onKeyDown={(event) => event.stopPropagation()}
                  onChange={(event) => handleStatus(finding, event.target.value as FindingStatus)}
                  className="focus-ring h-7 cursor-pointer rounded-md border border-line bg-[#0a100d] px-1.5 font-mono text-[9px] text-muted outline-none"
                  style={{ color: STATUS_META[current].color }}
                >
                  {STATUSES.map((item) => (
                    <option key={item} value={item}>{statusLabel(item)}</option>
                  ))}
                </select>
                <Icon name="chevron" size={14} className="hidden text-faint transition-transform group-hover:translate-x-0.5 group-hover:text-accent sm:block" />
              </div>
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="panel flex flex-col items-center px-6 py-14 text-center">
          <Icon name="search" size={22} className="mb-3 text-faint" />
          <div className="text-sm font-medium text-ink">Nothing matches this filter.</div>
          <div className="mt-1 text-xs text-faint">Try clearing search or resetting the severity/area/status filters.</div>
          <Button variant="secondary" size="sm" className="mt-4" onClick={resetFilters}>Reset filters</Button>
        </div>
      )}

      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line-soft bg-[#0a100d] px-4 py-3">
        <div className="flex items-start gap-2 text-[10px] leading-relaxed text-faint">
          <Icon name="info" size={12} className="mt-0.5 shrink-0 text-accent/70" />
          Status changes and plan membership are saved in this browser. They are a working aid, not a code change.
        </div>
        <Button size="sm" variant="secondary" icon="download" onClick={() => showToast("Use Export audit in the top bar to download the full brief")}>
          Export from top bar
        </Button>
      </div>

      {selected && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="drawer-scrim absolute inset-0 animate-fade-in" onClick={() => setSelectedId(null)} />
          <aside className="animate-slide-in relative flex h-full w-full max-w-[620px] flex-col border-l border-line bg-[#0b120e] shadow-2xl">
            <div className="flex items-start gap-3 border-b border-line bg-[#0d1510] px-5 py-4">
              <div className="min-w-0 flex-1">
                <div className="mb-2 flex flex-wrap items-center gap-2">
                  <SeverityBadge severity={selected.severity} />
                  <span className="font-mono text-[10px] text-faint">{selected.id}</span>
                  <Tag>{selected.area}</Tag>
                  <Tag color={SEVERITY_META[selected.severity].color}>{selected.component}</Tag>
                </div>
                <h2 className="font-display text-[20px] font-semibold leading-snug tracking-tight text-ink">{selected.title}</h2>
                <a
                  href={sourceUrl(selected.file)}
                  target="_blank"
                  rel="noreferrer"
                  className="focus-ring mt-2 inline-flex items-center gap-1.5 rounded font-mono text-[10px] text-faint hover:text-accent"
                >
                  <Icon name="file" size={11} />
                  {selected.file}:{selected.lines}
                  <Icon name="external" size={10} />
                </a>
              </div>
              <button
                type="button"
                onClick={() => setSelectedId(null)}
                className="focus-ring flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-line bg-panel text-muted hover:text-ink"
                aria-label="Close finding"
              >
                <Icon name="close" size={15} />
              </button>
            </div>

            <div className="scroll-slim flex-1 space-y-5 overflow-y-auto px-5 py-5">
              <div className="rounded-xl border border-line-soft bg-[#0a100d] px-4 py-3.5">
                <div className="text-[10px] font-medium uppercase tracking-[0.12em] text-faint">TL;DR</div>
                <p className="mt-1.5 text-[12px] leading-relaxed text-[#c6d5cb]">{selected.summary}</p>
              </div>

              <div>
                <SectionLabel icon="code">Evidence</SectionLabel>
                <p className="text-[11px] leading-relaxed text-muted">{selected.evidence}</p>
                <pre className="scroll-slim mt-2.5 overflow-x-auto rounded-lg border border-line bg-[#070c09] p-3 font-mono text-[10px] leading-[1.7] text-[#a9c7b2]">
                  <code>{selected.code}</code>
                </pre>
                <div className="mt-2 flex flex-wrap gap-2">
                  <CopyButton text={`${selected.file}:${selected.lines}\n${selected.code}`} label="Copy snippet" onCopied={showToast} />
                  <a
                    href={sourceUrl(selected.file)}
                    target="_blank"
                    rel="noreferrer"
                    className="focus-ring inline-flex items-center gap-1.5 rounded-md border border-line bg-panel-2/70 px-2 py-1.5 font-mono text-[10px] text-muted hover:text-ink"
                  >
                    Open source <Icon name="external" size={11} />
                  </a>
                </div>
              </div>

              <div>
                <SectionLabel icon="alert">Why it matters</SectionLabel>
                <p className="text-[12px] leading-relaxed text-muted">{selected.impact}</p>
              </div>

              <div>
                <SectionLabel icon="wrench">Recommended fix</SectionLabel>
                <ol className="space-y-2">
                  {selected.fix.map((step, index) => (
                    <li key={step} className="flex gap-2.5">
                      <span className="mt-0.5 flex h-4.5 w-5 shrink-0 items-center justify-center rounded border border-accent/20 bg-accent/[0.06] font-mono text-[9px] text-accent">
                        {index + 1}
                      </span>
                      <span className="text-[11px] leading-relaxed text-[#c6d5cb]">{step}</span>
                    </li>
                  ))}
                </ol>
              </div>

              <div>
                <SectionLabel icon="check">Verify with</SectionLabel>
                <ul className="space-y-1.5">
                  {selected.verification.map((item) => (
                    <li key={item} className="flex items-start gap-2 text-[11px] leading-relaxed text-muted">
                      <Icon name="check" size={11} className="mt-0.5 shrink-0 text-accent/70" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="rounded-lg border border-line-soft bg-[#0a100d] px-3 py-2.5">
                  <div className="font-mono text-[9px] uppercase tracking-wider text-faint">Confidence</div>
                  <div className="mt-1 text-[11px] text-ink">{selected.confidence} · static review</div>
                </div>
                <div className="rounded-lg border border-line-soft bg-[#0a100d] px-3 py-2.5">
                  <div className="font-mono text-[9px] uppercase tracking-wider text-faint">Effort</div>
                  <div className="mt-1 text-[11px] text-ink">{selected.effort} · suggested phase {selected.phase}</div>
                </div>
              </div>

              <div className="flex flex-wrap gap-1.5">
                {selected.tags.map((tag) => <Tag key={tag}>{tag}</Tag>)}
              </div>

              <Callout tone="info" initials="i" title="Honest limit">
                This is a source audit, not a runtime reproduction. The code path is verified; the visual or gameplay
                failure still needs a Forge 1.8.9 smoke test before you close the item.
              </Callout>
            </div>

            <div className="border-t border-line bg-[#0d1510] px-5 py-3.5">
              <div className="mb-2.5 flex items-center justify-between gap-2">
                <span className="font-mono text-[9px] uppercase tracking-[0.13em] text-faint">Status</span>
                <span className="font-mono text-[9px] text-faint">saved locally</span>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                {STATUSES.map((item) => {
                  const active = (statuses[selected.id] ?? "open") === item;
                  return (
                    <button
                      key={item}
                      type="button"
                      onClick={() => handleStatus(selected, item)}
                      className={cn(
                        "focus-ring flex items-center justify-center gap-1.5 rounded-md border px-1.5 py-2 font-mono text-[9px] uppercase tracking-wider transition-colors",
                        active ? "bg-panel-3" : "border-line bg-[#0a100d] text-faint hover:text-ink",
                      )}
                      style={active ? { borderColor: `${STATUS_META[item].dot}55`, color: STATUS_META[item].color, backgroundColor: `${STATUS_META[item].dot}12` } : undefined}
                    >
                      <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: STATUS_META[item].dot }} />
                      {STATUS_META[item].label}
                    </button>
                  );
                })}
              </div>
              <div className="mt-2 flex gap-2">
                <Button
                  variant={planned[selected.id] ? "secondary" : "primary"}
                  icon={planned[selected.id] ? "check" : "plan"}
                  onClick={() => handlePlan(selected)}
                  className="flex-1"
                >
                  {planned[selected.id] ? "In the fix plan" : "Add to fix plan"}
                </Button>
                <CopyButton
                  text={`# ${selected.id} — ${selected.title}\n\nSeverity: ${selected.severity}\nArea: ${selected.area}\nEvidence: ${selected.file}:${selected.lines}\n\n## Summary\n${selected.summary}\n\n## Impact\n${selected.impact}\n\n## Fix\n${selected.fix.map((item) => `- ${item}`).join("\n")}\n\n## Verify\n${selected.verification.map((item) => `- ${item}`).join("\n")}`}
                  label="Copy brief"
                  onCopied={showToast}
                />
              </div>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
