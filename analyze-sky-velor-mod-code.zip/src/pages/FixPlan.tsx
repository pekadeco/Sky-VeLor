import {
  FINDINGS,
  PHASES,
  QA_CHECKS,
  REPO,
  SEVERITY_META,
  SEVERITY_ORDER,
  STATUS_META,
  VERDICT,
  type FindingStatus,
  type Phase,
} from "../data/audit";
import type { SharedAuditProps } from "../types";
import { Button, Callout, CopyButton, MeterBar, PageHeader, SectionLabel, SeverityBadge, Tag } from "../components/Ui";
import { Icon } from "../components/Icons";
import { cn } from "../utils/cn";

const FIRST_PASS = [
  { id: "SV-002", task: "Delete the left-click Spirit Leap route", why: "Smallest change, largest user-facing risk reduction." },
  { id: "SV-003", task: "Remove terminal auto-click from the public build", why: "Closes the ban surface without touching the passive helper." },
  { id: "SV-001", task: "Run the launch and dungeon canary", why: "Turns every static assumption into observed behaviour." },
  { id: "SV-004", task: "Reset terminal cache on screen and world changes", why: "Stops stale state from becoming an intermittent dungeon bug." },
  { id: "SV-005", task: "Make the Controls keybind authoritative", why: "Removes a confusing persistence regression." },
];

function statusDotColor(status: FindingStatus) {
  return STATUS_META[status].dot;
}

export function FixPlan({ statuses, setStatus, planned, togglePlanned, qa, readiness, navigate, showToast, exportReport }: SharedAuditProps) {
  const plannedFindings = FINDINGS.filter((finding) => planned[finding.id]);
  const unplanned = FINDINGS.filter((finding) => !planned[finding.id]);
  const fixed = plannedFindings.filter((finding) => statuses[finding.id] === "fixed");
  const qaDone = QA_CHECKS.filter((check) => qa[check.id]).length;
  const criticalOpen = FINDINGS.filter(
    (finding) => finding.severity === "critical" && (statuses[finding.id] ?? "open") !== "fixed",
  );
  const highOpen = FINDINGS.filter(
    (finding) => finding.severity === "high" && (statuses[finding.id] ?? "open") !== "fixed",
  );
  const licenseFixed = (statuses["SV-012"] ?? "open") === "fixed";
  const publicAutomationFixed =
    (statuses["SV-002"] ?? "open") === "fixed" && (statuses["SV-003"] ?? "open") === "fixed";

  const gates = [
    { label: "No critical findings open", done: criticalOpen.length === 0, detail: `${criticalOpen.length} critical remaining` },
    { label: "No high findings open", done: highOpen.length === 0, detail: `${highOpen.length} high remaining` },
    { label: "In-game smoke pass complete", done: qaDone === QA_CHECKS.length, detail: `${qaDone}/${QA_CHECKS.length} checks` },
    { label: "Public automation + leap route removed", done: publicAutomationFixed, detail: publicAutomationFixed ? "SV-002 / SV-003 closed" : "SV-002 / SV-003 still open" },
    { label: "License and docs reconciled", done: licenseFixed, detail: licenseFixed ? "SV-012 closed" : "SV-012 still open" },
  ];
  const gatesMet = gates.filter((gate) => gate.done).length;

  function complete(findingId: string) {
    const current = statuses[findingId] ?? "open";
    const next: FindingStatus = current === "fixed" ? "planned" : "fixed";
    setStatus(findingId, next);
    showToast(next === "fixed" ? `${findingId} marked fixed` : `${findingId} reopened in the plan`);
  }

  function markAll(phase: Phase) {
    const items = plannedFindings.filter((finding) => finding.phase === phase);
    items.forEach((finding) => {
      if ((statuses[finding.id] ?? "open") !== "fixed") setStatus(finding.id, "fixed");
    });
    showToast(`Phase ${phase}: ${items.length} item${items.length === 1 ? "" : "s"} marked fixed`);
  }

  return (
    <div className="animate-fade-up">
      <PageHeader
        eyebrow="Fix queue / working plan"
        title="A short queue beats a big backlog."
        description={
          <>
            This plan is a working state, not a promise. The first phase is deliberately narrow: remove unsafe
            interaction, validate the client, and make the release tell the truth.
          </>
        }
        actions={
          <>
            <Button variant="secondary" icon="download" onClick={exportReport}>Export brief</Button>
            <Button icon="plan" onClick={() => navigate("findings")}>Add findings</Button>
          </>
        }
      />

      <div className="grid gap-3 xl:grid-cols-[1.1fr_1fr]">
        <section className="panel overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line-soft px-5 py-3.5">
            <SectionLabel className="mb-0" icon="shield">Ship gate</SectionLabel>
            <div className="flex items-center gap-3">
              <span className="font-mono text-[10px] text-muted">{gatesMet}/{gates.length} met</span>
              <div className="w-24"><MeterBar value={(gatesMet / gates.length) * 100} height={4} tone={gatesMet === gates.length ? "accent" : "ember"} /></div>
            </div>
          </div>
          <div className="p-5">
            <div className="mb-4 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <div className="mono-label text-faint">Current posture</div>
                <div className="mt-1 font-display text-xl font-semibold tracking-tight text-ink">{VERDICT.label}</div>
                <p className="mt-1 max-w-md text-[10px] leading-relaxed text-muted">{VERDICT.summary}</p>
              </div>
              <div className="flex shrink-0 gap-4">
                <div>
                  <div className="font-mono text-[8px] uppercase tracking-wider text-faint">readiness</div>
                  <div className="font-display text-xl font-semibold text-ink">{readiness}</div>
                </div>
                <div>
                  <div className="font-mono text-[8px] uppercase tracking-wider text-faint">plan fixed</div>
                  <div className="font-display text-xl font-semibold text-ink">{fixed.length}/{plannedFindings.length}</div>
                </div>
              </div>
            </div>
            <div className="space-y-1.5">
              {gates.map((gate) => (
                <div key={gate.label} className="flex items-center gap-2.5 rounded-lg border border-line-soft bg-[#0a100d] px-3 py-2.5">
                  <span
                    className={cn(
                      "flex h-5 w-5 shrink-0 items-center justify-center rounded border",
                      gate.done ? "border-accent/40 bg-accent/15 text-accent" : "border-line bg-[#0b120e] text-faint",
                    )}
                  >
                    <Icon name={gate.done ? "check" : "clock"} size={11} />
                  </span>
                  <span className={cn("flex-1 text-[11px]", gate.done ? "text-[#cbd9d0]" : "text-muted")}>{gate.label}</span>
                  <span className="font-mono text-[8px] text-faint">{gate.detail}</span>
                </div>
              ))}
            </div>
            <div className="mt-3">
              <Callout tone={criticalOpen.length === 0 ? "success" : "danger"} initials={criticalOpen.length === 0 ? "OK" : "!"} title={criticalOpen.length === 0 ? "Critical path is clear" : `${criticalOpen.length} critical still blocks a public release`}>
                {criticalOpen.length === 0
                  ? "Do not treat that as ship approval: the in-game checklist and high-severity items still gate the release."
                  : "Do not ship a public build until these are fixed and the in-game smoke pass is recorded."}
              </Callout>
            </div>
          </div>
        </section>

        <section className="panel p-5">
          <SectionLabel icon="spark" trailing={<Tag color="#f2b35c">recommended order</Tag>}>First 90 minutes</SectionLabel>
          <p className="mb-3 text-[11px] leading-relaxed text-muted">
            The shortest safe sequence. Each step is independently verifiable and leaves the mod shippable at the
            end of the pass.
          </p>
          <div className="relative space-y-2 before:absolute before:bottom-4 before:left-[13px] before:top-4 before:w-px before:bg-line before:content-['']">
            {FIRST_PASS.map((item, index) => {
              const finding = FINDINGS.find((entry) => entry.id === item.id);
              if (!finding) return null;
              const current = statuses[item.id] ?? "open";
              return (
                <div key={item.id} className="relative flex items-start gap-2.5 rounded-lg border border-line-soft bg-[#0a100d] px-3 py-2.5">
                  <span
                    className="relative z-10 flex h-6 w-6 shrink-0 items-center justify-center rounded-md border font-mono text-[9px]"
                    style={{
                      color: SEVERITY_META[finding.severity].color,
                      borderColor: SEVERITY_META[finding.severity].border,
                      backgroundColor: "#0b120e",
                    }}
                  >
                    {index + 1}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-medium text-[#d3e0d7]">{item.task}</span>
                      <span className="shrink-0 font-mono text-[8px] text-faint">{item.id}</span>
                    </div>
                    <p className="mt-0.5 text-[9px] leading-relaxed text-faint">{item.why}</p>
                  </div>
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full" style={{ backgroundColor: statusDotColor(current) }} title={`Status: ${current}`} />
                </div>
              );
            })}
          </div>
          <div className="mt-3 flex items-center gap-2 rounded-lg border border-accent/15 bg-accent/[0.04] px-3 py-2.5">
            <Icon name="info" size={12} className="shrink-0 text-accent/80" />
            <span className="text-[9px] leading-relaxed text-muted">
              Freeze new settings features during this pass. The release is already broad enough.
            </span>
          </div>
        </section>
      </div>

      <div className="mt-3 grid gap-3 xl:grid-cols-3">
        {([1, 2, 3] as Phase[]).map((phase) => {
          const info = PHASES[phase];
          const items = plannedFindings
            .filter((finding) => finding.phase === phase)
            .sort((a, b) => SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity] || a.id.localeCompare(b.id));
          const done = items.filter((finding) => statuses[finding.id] === "fixed").length;
          return (
            <section key={phase} className="panel flex flex-col overflow-hidden">
              <div className="border-b border-line-soft px-4 py-3.5">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-2.5">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md border border-line bg-[#0a100d] font-pixel text-[10px] text-accent/85">
                      0{phase}
                    </span>
                    <div>
                      <div className="text-[12px] font-semibold text-ink">{info.title}</div>
                      <div className="mt-0.5 font-mono text-[8px] uppercase tracking-[0.12em] text-faint">{info.eyebrow}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-mono text-[10px] text-muted">{done}/{items.length}</div>
                    <div className="font-mono text-[8px] text-faint">fixed</div>
                  </div>
                </div>
                <div className="mt-3">
                  <MeterBar value={items.length ? (done / items.length) * 100 : 0} height={4} tone={phase === 1 ? "danger" : phase === 2 ? "ember" : "accent"} />
                </div>
              </div>

              <div className="flex-1 space-y-2 p-3">
                {items.length === 0 && (
                  <div className="rounded-lg border border-dashed border-line px-3 py-6 text-center">
                    <div className="text-[10px] text-faint">No planned items in this phase.</div>
                    <Button size="sm" variant="ghost" className="mt-1" onClick={() => navigate("findings")}>Add from findings</Button>
                  </div>
                )}
                {items.map((finding) => {
                  const current = statuses[finding.id] ?? "open";
                  const isFixed = current === "fixed";
                  return (
                    <article
                      key={finding.id}
                      className={cn(
                        "rounded-lg border bg-[#0a100d] p-3 transition-colors",
                        isFixed ? "border-accent/20 opacity-80" : "border-line-soft hover:border-[#31523f]",
                      )}
                    >
                      <div className="flex items-start gap-2">
                        <button
                          type="button"
                          onClick={() => complete(finding.id)}
                          className={cn(
                            "focus-ring mt-0.5 flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-[3px] border transition-colors",
                            isFixed ? "border-accent bg-accent text-[#061109]" : "border-line bg-[#0b120e] hover:border-accent/50",
                          )}
                          aria-label={isFixed ? `Reopen ${finding.id}` : `Mark ${finding.id} fixed`}
                          aria-pressed={isFixed}
                        >
                          {isFixed && <Icon name="check" size={11} />}
                        </button>
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="font-mono text-[8px] text-faint">{finding.id}</span>
                            <SeverityBadge severity={finding.severity} compact />
                            <Tag color={SEVERITY_META[finding.severity].color}>{finding.effort}</Tag>
                          </div>
                          <h3 className={cn("mt-1.5 text-[11px] font-medium leading-snug", isFixed ? "text-muted line-through" : "text-ink")}>
                            {finding.title}
                          </h3>
                          <div className="mt-1 font-mono text-[8px] text-faint">{finding.component} · {finding.file}:{finding.lines}</div>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            togglePlanned(finding.id);
                            showToast(`${finding.id} removed from the plan`);
                          }}
                          className="focus-ring shrink-0 rounded p-1 text-faint transition-colors hover:text-danger"
                          title="Remove from plan"
                          aria-label={`Remove ${finding.id} from plan`}
                        >
                          <Icon name="close" size={12} />
                        </button>
                      </div>
                      <div className="mt-2 flex items-center justify-between border-t border-line-soft pt-2">
                        <span className="font-mono text-[8px] uppercase tracking-wider" style={{ color: STATUS_META[current].color }}>
                          {STATUS_META[current].label}
                        </span>
                        <span className="font-mono text-[8px] text-faint">{finding.confidence.toLowerCase()} confidence</span>
                      </div>
                    </article>
                  );
                })}
              </div>

              <div className="border-t border-line-soft px-3 py-2.5">
                <div className="mb-2 text-[9px] leading-relaxed text-faint">
                  <span className="font-mono text-[8px] uppercase tracking-wider text-[#8fa497]">done = </span>
                  {info.done}
                </div>
                <div className="flex items-center gap-1.5">
                  <Button size="sm" variant="secondary" className="flex-1" icon="check" onClick={() => markAll(phase)}>
                    Mark lane fixed
                  </Button>
                  <CopyButton
                    text={`# Sky VeLor ${REPO.version} — Phase ${phase}: ${info.title}\n\n${items.map((finding) => `## ${finding.id} (${finding.severity}) ${finding.title}\n${finding.summary}\n\n### Fix\n${finding.fix.map((step) => `- ${step}`).join("\n")}`).join("\n\n")}`}
                    label="Copy"
                    onCopied={showToast}
                  />
                </div>
              </div>
            </section>
          );
        })}
      </div>

      <section className="mt-3 panel p-5">
        <div className="flex flex-col gap-2 border-b border-line-soft pb-3 sm:flex-row sm:items-center sm:justify-between">
          <SectionLabel className="mb-0" icon="spark">
            {unplanned.length > 0 ? "Backlog / not in the current plan" : "Everything is in the plan"}
          </SectionLabel>
          <span className="font-mono text-[9px] text-faint">{unplanned.length} not planned</span>
        </div>
        {unplanned.length === 0 ? (
          <div className="mt-3 rounded-lg border border-accent/20 bg-accent/[0.04] px-4 py-5 text-center">
            <div className="text-[12px] font-medium text-accent-soft">All {FINDINGS.length} findings are in the fix queue.</div>
            <div className="mt-1 text-[10px] text-muted">That is a large queue — keep the phases and resist adding scope.</div>
          </div>
        ) : (
          <div className="mt-3 grid gap-1.5 md:grid-cols-2">
            {unplanned.map((finding) => (
              <div key={finding.id} className="flex items-center gap-2.5 rounded-lg border border-line-soft bg-[#0a100d] px-3 py-2.5">
                <span className="font-mono text-[8px] text-faint">{finding.id}</span>
                <SeverityBadge severity={finding.severity} compact />
                <span className="min-w-0 flex-1 truncate text-[10px] text-muted">{finding.title}</span>
                <Button size="sm" variant="ghost" icon="plan" onClick={() => { togglePlanned(finding.id); showToast(`${finding.id} added to the plan`); }}>
                  Add
                </Button>
              </div>
            ))}
          </div>
        )}
      </section>

      <div className="mt-3 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line-soft bg-[#0a100d] px-4 py-3">
        <div className="flex items-start gap-2 text-[10px] leading-relaxed text-faint">
          <Icon name="info" size={12} className="mt-0.5 shrink-0 text-accent/70" />
          Plan membership and finding status are local working state. Export the audit to share a review snapshot.
        </div>
        <div className="flex items-center gap-2">
          <CopyButton
            text={plannedFindings.map((finding) => `${statuses[finding.id] === "fixed" ? "[x]" : "[ ]"} ${finding.id} · ${finding.severity} · ${finding.title}`).join("\n")}
            label="Copy queue"
            onCopied={showToast}
          />
          <Button size="sm" variant="secondary" icon="download" onClick={exportReport}>Export</Button>
        </div>
      </div>
    </div>
  );
}
