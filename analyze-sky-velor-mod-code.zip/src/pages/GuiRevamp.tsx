import { useMemo, useState, type CSSProperties } from "react";
import {
  DESIGN_PRINCIPLES,
  GUI_FAQ,
  GUI_TABS,
  IMPLEMENTATION_STEPS,
  JAVA_SNIPPET,
  MIGRATION,
  PARITY_CHECKS,
  PERFORMANCE_RULES,
  PRESETS,
  QUICK_TOGGLES,
  type GuiCard,
  type GuiSetting,
  type GuiTabId,
} from "../data/gui";
import type { SharedAuditProps } from "../types";
import { Button, Callout, CopyButton, PageHeader, SectionLabel, Tag } from "../components/Ui";
import { Icon, PixelCube, type IconName } from "../components/Icons";
import { cn } from "../utils/cn";
import { downloadText } from "../utils/storage";

type ProtoValue = boolean | number | string;

const COMPACT_ITEMS = [
  { title: "One search field", detail: "Find any setting by name or intent.", icon: "search" as IconName },
  { title: "Inline detail", detail: "Subtoggles open under the row you chose.", icon: "chevron" as IconName },
  { title: "Advanced by choice", detail: "Beta and developer options stay out of the way.", icon: "shield" as IconName },
];

function buildInitialValues(): Record<string, ProtoValue> {
  const values: Record<string, ProtoValue> = {};
  const walk = (settings: GuiSetting[]) => {
    settings.forEach((setting) => {
      if (setting.control === "choice") values[setting.id] = setting.options?.[0] ?? "";
      else if (setting.control === "slider") values[setting.id] = setting.number ?? 0;
      else if (setting.control === "switch" || !setting.control) values[setting.id] = setting.value ?? false;
      if (setting.children) walk(setting.children);
    });
  };
  GUI_TABS.forEach((tab) => tab.cards.forEach((card) => walk(card.settings)));
  return values;
}

const INITIAL_VALUES = buildInitialValues();

const ACCENTS: Record<string, string> = { Mint: "#5eda87", Sky: "#6fb5ff", Amber: "#f0b45e" };

function isOn(values: Record<string, ProtoValue>, id: string) {
  return values[id] === true;
}

function toggleSwitch(setting: GuiSetting): boolean {
  return setting.control === "switch" || !setting.control;
}

function settingMatches(setting: GuiSetting, query: string): boolean {
  const hay = [
    setting.label,
    setting.description,
    setting.id,
    ...(setting.children ?? []).flatMap((child) => [child.label, child.description, child.id]),
  ]
    .join(" ")
    .toLowerCase();
  return hay.includes(query);
}

function toggleAction(
  action: string,
  values: Record<string, ProtoValue>,
  setValues: (updater: (current: Record<string, ProtoValue>) => Record<string, ProtoValue>) => void,
  showToast: (message: string) => void,
) {
  if (action === "item-animation-reset") {
    setValues((current) => ({
      ...current,
      "item-animation-size": 100,
      "item-animation-speed": 100,
      "item-animation-offset-x": 0,
      "item-animation-offset-y": 0,
    }));
    showToast("Item animation reset to vanilla");
    return;
  }
  if (action === "reset-settings") {
    setValues(() => ({ ...INITIAL_VALUES }));
    showToast("Prototype settings reset");
    return;
  }
  if (action === "export-settings") {
    downloadText("skyvelor-gui-prototype.json", JSON.stringify(values, null, 2));
    showToast("Prototype profile downloaded");
    return;
  }
  const messages: Record<string, string> = {
    "import-settings": "Import is disabled in the prototype — no local file access",
    "hud-editor": "HUD editor opens on top of this screen in the real client",
    "item-lock-swap": "Focused Item Lock settings open as a subpage",
    "inventory-assist": "Focused Inventory Assist settings open as a subpage",
    "terminal-assist": "Terminal settings open without enabling automation",
    "item-animation": "Preview plays in the HUD layer",
    "about-license": "Notice manifest shown in the real About page",
    "command-itemdebug": "Copyable hook status prepared",
    "command-selftest": "Self-test report prepared",
  };
  showToast(messages[action] ?? "Route wired — no gameplay action in the prototype");
}

function GuiSwitch({
  checked,
  onChange,
  accent,
  label,
}: {
  checked: boolean;
  onChange: () => void;
  accent: string;
  label: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={onChange}
      className="focus-ring relative h-[22px] w-[38px] shrink-0 rounded-full border transition-colors duration-200"
      style={{
        backgroundColor: checked ? accent : "var(--g-switch-off)",
        borderColor: checked ? accent : "var(--g-line)",
      }}
    >
      <span
        className="absolute top-[2px] h-[16px] w-[16px] rounded-full bg-white shadow-sm transition-all duration-200"
        style={{ left: checked ? 18 : 2, opacity: checked ? 1 : 0.92 }}
      />
    </button>
  );
}

function SettingRow({
  setting,
  values,
  expanded,
  showAdvanced,
  accent,
  onChange,
  onExpand,
  onAction,
}: {
  setting: GuiSetting;
  values: Record<string, ProtoValue>;
  expanded: boolean;
  showAdvanced: boolean;
  accent: string;
  onChange: (id: string, value: ProtoValue) => void;
  onExpand: () => void;
  onAction: (id: string) => void;
}) {
  const children = (setting.children ?? []).filter((child) => showAdvanced || !child.advanced);
  const hasChildren = children.length > 0;
  const value = values[setting.id];

  return (
    <div style={{ borderColor: "var(--g-line)" }} className="border-b last:border-b-0">
      <div className="flex items-start gap-3 px-3.5 py-3 sm:px-4">
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[12px] font-medium leading-snug" style={{ color: "var(--g-ink)" }}>{setting.label}</span>
            <span
              className="rounded px-1 py-0.5 font-mono text-[7.5px] uppercase tracking-wider"
              style={{
                backgroundColor: setting.advanced ? "var(--g-chip)" : "transparent",
                color: "var(--g-muted)",
                border: setting.advanced ? "none" : "1px solid var(--g-line)",
              }}
            >
              {setting.advanced ? "advanced" : "everyday"}
            </span>
            {setting.badge && (
              <span
                className="rounded px-1 py-0.5 font-mono text-[8px] uppercase tracking-wider"
                style={{ backgroundColor: "var(--g-chip)", color: "var(--g-muted)" }}
              >
                {setting.badge}
              </span>
            )}
          </div>
          <p className="mt-0.5 text-[10.5px] leading-relaxed" style={{ color: "var(--g-muted)" }}>{setting.description}</p>
          {hasChildren && (
            <button
              type="button"
              onClick={onExpand}
              className="focus-ring mt-1.5 inline-flex items-center gap-1 rounded font-mono text-[9px] uppercase tracking-wider transition-colors"
              style={{ color: expanded ? accent : "var(--g-muted)" }}
              aria-expanded={expanded}
            >
              <Icon name="chevron" size={9} className={cn("transition-transform", expanded && "rotate-90")} />
              {children.length} option{children.length === 1 ? "" : "s"}
            </button>
          )}
        </div>

        <div className="flex shrink-0 items-center gap-1.5 pt-0.5">
          {setting.control === "slider" && (
            <div className="w-[128px] sm:w-[160px]">
              <input
                type="range"
                min={setting.min}
                max={setting.max}
                step={setting.step}
                value={Number(value ?? 0)}
                aria-label={setting.label}
                onChange={(event) => onChange(setting.id, Number(event.target.value))}
                className="gui-range h-1.5 w-full cursor-pointer appearance-none rounded-full"
                style={{
                  accentColor: accent,
                  backgroundColor: "var(--g-switch-off)",
                  backgroundImage: `linear-gradient(90deg, ${accent} ${((Number(value) - (setting.min ?? 0)) / ((setting.max ?? 100) - (setting.min ?? 0))) * 100}%, transparent 0)`,
                }}
              />
              <div className="mt-1 text-right font-mono text-[9px]" style={{ color: "var(--g-muted)" }}>
                {value}{setting.suffix ?? ""}
              </div>
            </div>
          )}
          {setting.control === "choice" && (
            <div className="flex rounded-lg border p-0.5" style={{ borderColor: "var(--g-line)", backgroundColor: "var(--g-chip)" }}>
              {(setting.options ?? []).map((option) => {
                const active = value === option;
                return (
                  <button
                    key={option}
                    type="button"
                    onClick={() => onChange(setting.id, option)}
                    className="focus-ring rounded-md px-2 py-1 text-[9.5px] font-medium transition-colors"
                    style={{
                      backgroundColor: active ? "var(--g-card)" : "transparent",
                      color: active ? "var(--g-ink)" : "var(--g-muted)",
                      boxShadow: active ? "0 1px 2px rgba(0,0,0,.14)" : "none",
                    }}
                  >
                    {option}
                  </button>
                );
              })}
            </div>
          )}
          {setting.control === "action" && (
            <button
              type="button"
              onClick={() => onAction(setting.id)}
              className="focus-ring rounded-md border px-2.5 py-1.5 text-[10px] font-medium transition-colors"
              style={{ borderColor: "var(--g-line)", color: "var(--g-ink)", backgroundColor: "var(--g-card)" }}
            >
              {setting.actionLabel ?? "Open"}
            </button>
          )}
          {setting.control === "info" && (
            <span className="rounded bg-transparent font-mono text-[9px]" style={{ color: "var(--g-muted)" }}>—</span>
          )}
          {toggleSwitch(setting) && (
            <GuiSwitch
              checked={Boolean(value)}
              onChange={() => onChange(setting.id, !value)}
              accent={accent}
              label={setting.label}
            />
          )}
        </div>
      </div>

      {hasChildren && expanded && (
        <div className="animate-fade-in px-3.5 pb-2 sm:px-4" style={{ backgroundColor: "var(--g-subtle)" }}>
          <div className="ml-1 border-l pl-3" style={{ borderColor: "var(--g-line)" }}>
            {children.map((child) => (
              <div key={child.id} className="flex items-start gap-3 border-b py-2.5 last:border-b-0" style={{ borderColor: "var(--g-line)" }}>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] font-medium leading-snug" style={{ color: "var(--g-ink)" }}>{child.label}</span>
                    {child.badge && (
                      <span className="rounded px-1 py-0.5 font-mono text-[8px] uppercase tracking-wider" style={{ backgroundColor: "var(--g-chip)", color: "var(--g-muted)" }}>
                        {child.badge}
                      </span>
                    )}
                  </div>
                  <p className="mt-0.5 text-[9.5px] leading-relaxed" style={{ color: "var(--g-muted)" }}>{child.description}</p>
                </div>
                <div className="flex shrink-0 items-center pt-0.5">
                  {child.control === "slider" && (
                    <div className="w-[110px]">
                      <input
                        type="range"
                        min={child.min}
                        max={child.max}
                        step={child.step}
                        value={Number(values[child.id] ?? 0)}
                        aria-label={child.label}
                        onChange={(event) => onChange(child.id, Number(event.target.value))}
                        className="h-1.5 w-full cursor-pointer appearance-none rounded-full"
                        style={{ accentColor: accent, backgroundColor: "var(--g-switch-off)" }}
                      />
                      <div className="mt-1 text-right font-mono text-[9px]" style={{ color: "var(--g-muted)" }}>{values[child.id]}{child.suffix ?? ""}</div>
                    </div>
                  )}
                  {child.control === "action" && (
                    <button
                      type="button"
                      onClick={() => onAction(child.id)}
                      className="focus-ring rounded border px-2 py-1 text-[9.5px]"
                      style={{ borderColor: "var(--g-line)", color: "var(--g-ink)" }}
                    >
                      {child.actionLabel ?? "Open"}
                    </button>
                  )}
                  {toggleSwitch(child) && (
                    <GuiSwitch
                      checked={Boolean(values[child.id])}
                      onChange={() => onChange(child.id, !values[child.id])}
                      accent={accent}
                      label={child.label}
                    />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function MockCard({
  card,
  values,
  showAdvanced,
  accent,
  expandedRows,
  onChange,
  onExpand,
  onAction,
}: {
  card: GuiCard;
  values: Record<string, ProtoValue>;
  showAdvanced: boolean;
  accent: string;
  expandedRows: Record<string, boolean>;
  onChange: (id: string, value: ProtoValue) => void;
  onExpand: (id: string) => void;
  onAction: (id: string) => void;
}) {
  const settings = card.settings.filter((setting) => showAdvanced || !setting.advanced);
  if (settings.length === 0) return null;
  return (
    <section
      className="overflow-hidden rounded-[10px] border shadow-[0_1px_0_rgba(255,255,255,.03)]"
      style={{ borderColor: "var(--g-line)", backgroundColor: "var(--g-card)" }}
    >
      <div className="flex items-start gap-2.5 px-3.5 pb-2 pt-3.5 sm:px-4">
        <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md" style={{ backgroundColor: "var(--g-chip)", color: accent }}>
          <Icon name={card.icon} size={13} />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-1.5">
            <h3 className="text-[12px] font-semibold leading-snug" style={{ color: "var(--g-ink)" }}>{card.title}</h3>
            {card.advanced && (
              <span
                className="rounded border px-1 py-0.5 font-mono text-[7.5px] uppercase tracking-wider"
                style={{ borderColor: "var(--g-line)", color: "var(--g-muted)" }}
              >
                advanced
              </span>
            )}
          </div>
          <p className="mt-0.5 text-[10px] leading-relaxed" style={{ color: "var(--g-muted)" }}>{card.subtitle}</p>
        </div>
      </div>
      <div className="mt-0.5">
        {settings.map((setting) => (
          <SettingRow
            key={setting.id}
            setting={setting}
            values={values}
            expanded={Boolean(expandedRows[setting.id])}
            showAdvanced={showAdvanced}
            accent={accent}
            onChange={onChange}
            onExpand={() => onExpand(setting.id)}
            onAction={onAction}
          />
        ))}
      </div>
      {card.notice && (
        <div
          className="flex items-start gap-1.5 border-t px-3.5 py-2.5 text-[9px] leading-relaxed sm:px-4"
          style={{ borderColor: "var(--g-line)", backgroundColor: "var(--g-subtle)", color: "var(--g-muted)" }}
        >
          <Icon name={card.notice.tone === "warn" ? "alert" : "info"} size={10} className="mt-0.5 shrink-0" />
          {card.notice.text}
        </div>
      )}
    </section>
  );
}

function GuiMock({
  activeTab,
  setActiveTab,
  values,
  onChange,
  showAdvanced,
  setShowAdvanced,
  expandedRows,
  onExpand,
  onAction,
  query,
  setQuery,
  preset,
  applyPreset,
  resetValues,
  showToast,
}: {
  activeTab: GuiTabId;
  setActiveTab: (id: GuiTabId) => void;
  values: Record<string, ProtoValue>;
  onChange: (id: string, value: ProtoValue) => void;
  showAdvanced: boolean;
  setShowAdvanced: (value: boolean) => void;
  expandedRows: Record<string, boolean>;
  onExpand: (id: string) => void;
  onAction: (id: string) => void;
  query: string;
  setQuery: (value: string) => void;
  preset: string;
  applyPreset: (id: string) => void;
  resetValues: () => void;
  showToast: (message: string) => void;
}) {
  const light = values["appearance-theme"] === "Frost";
  const accent = ACCENTS[String(values["appearance-accent"] ?? "Mint")] ?? ACCENTS.Mint;
  const tab = GUI_TABS.find((entry) => entry.id === activeTab) ?? GUI_TABS[0];
  const normalized = query.trim().toLowerCase();

  const searchResults = useMemo(() => {
    if (!normalized) return [];
    return GUI_TABS.filter((entry) => entry.id !== "home").flatMap((entry) =>
      entry.cards.flatMap((card) =>
        card.settings
          .filter((setting) => (showAdvanced || !setting.advanced) && settingMatches(setting, normalized))
          .map((setting) => ({ tab: entry, card, setting })),
      ),
    );
  }, [normalized, showAdvanced]);

  const tabCards = tab.cards.filter((card) => showAdvanced || !card.advanced);
  const everyday = tabCards
    .flatMap((card) => card.settings)
    .filter((setting) => !setting.advanced && toggleSwitch(setting)).length;

  const themeVars = {
    "--g-bg": light ? "#eef0f2" : "#0b100d",
    "--g-surface": light ? "#f7f7f9" : "#0f1612",
    "--g-rail": light ? "#eceef0" : "#0c120e",
    "--g-card": light ? "#ffffff" : "#131b16",
    "--g-subtle": light ? "#f2f4f5" : "#0f1712",
    "--g-chip": light ? "#e9ecee" : "#1a2620",
    "--g-line": light ? "#dfe3e6" : "#233129",
    "--g-ink": light ? "#1b1f1d" : "#e9f2ec",
    "--g-muted": light ? "#6b7370" : "#8ba095",
    "--g-switch-off": light ? "#d6dadc" : "#2c3a32",
    "--g-header": light ? "#f6f7f8" : "#0d1410",
  } as CSSProperties;

  return (
    <div
      className="relative overflow-hidden rounded-2xl border border-line bg-[#060a07] p-2 sm:p-4"
      style={{ boxShadow: "inset 0 1px 0 rgba(221,255,233,.035), 0 24px 60px -40px #000" }}
    >
      <div className="pointer-events-none absolute inset-0 grid-fade opacity-20" />
      <div className="relative overflow-hidden rounded-xl border border-[#26382c] bg-[#0a110d]" style={themeVars}>
        {/* fake Minecraft window chrome */}
        <div className="hidden items-center gap-2 border-b border-[#233129] bg-[#0a110d] px-3 py-1.5 sm:flex">
          <div className="flex gap-1">
            {[0, 1, 2].map((index) => (
              <span key={index} className="h-1.5 w-1.5 rounded-full border border-[#3a5142] bg-[#1b2b20]" />
            ))}
          </div>
          <span className="font-mono text-[8px] uppercase tracking-[0.16em] text-[#6f8979]">minecraft 1.8.9 · fakepixel skyblock</span>
          <span className="ml-auto flex items-center gap-1 rounded border border-[#2a3d30] bg-[#101a13] px-1.5 py-0.5 font-mono text-[8px] text-[#8da697]">
            <Icon name="lock" size={8} /> right shift
          </span>
        </div>

        <div className="flex min-h-[520px] flex-col" style={{ backgroundColor: "var(--g-bg)", color: "var(--g-ink)" }}>
          {/* top bar */}
          <div
            className="flex flex-wrap items-center gap-2 border-b px-2.5 py-2 sm:flex-nowrap sm:px-4 sm:py-2.5"
            style={{ borderColor: "var(--g-line)", backgroundColor: "var(--g-header)" }}
          >
            <div className="flex min-w-0 items-center gap-2">
              <span className="drop-shadow-[0_4px_8px_rgba(0,0,0,.4)]"><PixelCube size={24} /></span>
              <div className="min-w-0">
                <div className="font-display text-[12px] font-semibold leading-none">Sky VeLor</div>
                <div className="mt-1 font-mono text-[7.5px] uppercase tracking-[0.14em]" style={{ color: "var(--g-muted)" }}>
                  settings · beta 0.10.8.9
                </div>
              </div>
            </div>
            <div className="relative order-3 w-full min-w-0 sm:order-none sm:ml-0 sm:w-[220px] sm:flex-none">
              <Icon name="search" size={11} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2" style={{ color: "var(--g-muted)" }} />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search settings…"
                aria-label="Search prototype settings"
                className="h-7 w-full rounded-md border pl-7 pr-12 text-[10px] outline-none"
                style={{ borderColor: "var(--g-line)", backgroundColor: "var(--g-card)", color: "var(--g-ink)" }}
              />
              {query ? (
                <button
                  type="button"
                  onClick={() => setQuery("")}
                  className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded p-1"
                  style={{ color: "var(--g-muted)" }}
                  aria-label="Clear prototype search"
                >
                  <Icon name="close" size={10} />
                </button>
              ) : (
                <span className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 rounded border px-1 font-mono text-[7px]" style={{ borderColor: "var(--g-line)", color: "var(--g-muted)" }}>/</span>
              )}
            </div>
            <div className="ml-auto flex min-w-0 shrink items-center gap-1.5 sm:ml-0 sm:shrink-0">
              <button
                type="button"
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="focus-ring flex h-7 items-center gap-1 rounded-md border px-2 text-[9px] font-medium transition-colors"
                style={{
                  borderColor: showAdvanced ? `${accent}80` : "var(--g-line)",
                  backgroundColor: showAdvanced ? `${accent}1c` : "var(--g-card)",
                  color: showAdvanced ? accent : "var(--g-muted)",
                }}
                aria-pressed={showAdvanced}
                title="Show advanced and developer options"
              >
                <Icon name="filter" size={10} />
                <span className="hidden sm:inline">{showAdvanced ? "Advanced on" : "Advanced"}</span>
                <span className="sm:hidden">{showAdvanced ? "On" : ""}</span>
              </button>
              <button
                type="button"
                onClick={() => toastFromMock(showToast)}
                className="focus-ring flex h-7 items-center gap-1 rounded-md px-2.5 text-[9px] font-semibold text-[#07100a]"
                style={{ backgroundColor: accent }}
              >
                <Icon name="check" size={10} /> <span>Done</span>
              </button>
            </div>
          </div>

          <div className="flex min-h-0 flex-1 flex-col sm:flex-row">
            {/* rail */}
            <div className="grid shrink-0 grid-cols-3 gap-1 border-b p-2 sm:flex sm:w-[158px] sm:flex-col sm:border-b-0 sm:border-r sm:p-2.5" style={{ borderColor: "var(--g-line)", backgroundColor: "var(--g-rail)" }}>
              {GUI_TABS.map((entry) => {
                const active = activeTab === entry.id;
                return (
                  <button
                    key={entry.id}
                    type="button"
                    onClick={() => {
                      setActiveTab(entry.id);
                      setQuery("");
                    }}
                    className="focus-ring flex min-w-0 items-center gap-1.5 rounded-md px-1.5 py-1.5 text-left transition-colors sm:w-full sm:gap-2 sm:px-2"
                    style={{
                      backgroundColor: active ? `${accent}1a` : "transparent",
                      color: active ? "var(--g-ink)" : "var(--g-muted)",
                    }}
                    aria-current={active ? "page" : undefined}
                  >
                    <span
                      className="flex h-5 w-5 shrink-0 items-center justify-center rounded"
                      style={{ backgroundColor: active ? `${accent}26` : "var(--g-chip)", color: active ? accent : "var(--g-muted)" }}
                    >
                      <Icon name={entry.icon} size={11} />
                    </span>
                    <span className="truncate text-[9.5px] font-medium sm:text-[10.5px]">
                      <span className="sm:hidden">{entry.label === "Gameplay" ? "Play" : entry.label}</span>
                      <span className="hidden sm:inline">{entry.label}</span>
                    </span>
                    {active && <span className="ml-auto hidden h-1 w-1 shrink-0 rounded-full sm:block" style={{ backgroundColor: accent }} />}
                  </button>
                );
              })}
              <div className="ml-auto hidden flex-col gap-1.5 border-t pt-2.5 sm:mt-auto sm:flex sm:w-full" style={{ borderColor: "var(--g-line)" }}>
                <button
                  type="button"
                  onClick={resetValues}
                  className="focus-ring flex items-center gap-1.5 rounded px-2 py-1 text-left font-mono text-[8px] uppercase tracking-wider"
                  style={{ color: "var(--g-muted)" }}
                >
                  <Icon name="refresh" size={9} /> reset prototype
                </button>
                <div className="rounded-md border px-2 py-1.5" style={{ borderColor: "var(--g-line)" }}>
                  <div className="font-mono text-[7px] uppercase tracking-wider" style={{ color: "var(--g-muted)" }}>profile</div>
                  <div className="mt-0.5 text-[9px] font-medium" style={{ color: "var(--g-ink)" }}>
                    {preset ? PRESETS.find((entry) => entry.id === preset)?.name : "Custom"}
                  </div>
                </div>
              </div>
            </div>

            {/* content */}
            <div className="scroll-slim min-h-0 flex-1 overflow-y-auto p-2.5 sm:max-h-[470px] sm:p-3.5">
              {normalized ? (
                <>
                  <div className="mb-2.5 flex items-center justify-between">
                    <div>
                      <div className="font-display text-[15px] font-semibold">Search</div>
                      <div className="font-mono text-[9px]" style={{ color: "var(--g-muted)" }}>
                        {searchResults.length} result{searchResults.length === 1 ? "" : "s"} for “{query}”
                      </div>
                    </div>
                    <button type="button" onClick={() => setQuery("")} className="text-[9px]" style={{ color: accent }}>Clear</button>
                  </div>
                  {searchResults.length === 0 ? (
                    <div className="rounded-lg border p-6 text-center" style={{ borderColor: "var(--g-line)", backgroundColor: "var(--g-card)" }}>
                      <Icon name="search" size={16} className="mx-auto mb-2" style={{ color: "var(--g-muted)" }} />
                      <div className="text-[11px] font-medium">No setting matches.</div>
                      <div className="mt-1 text-[9.5px]" style={{ color: "var(--g-muted)" }}>
                        Try “lock”, “leap”, “particles”, “theme” or “terminal”. Search understands intent words, not keys.
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {searchResults.map(({ tab: owner, card, setting }) => (
                        <div key={`${owner.id}-${card.id}-${setting.id}`} className="overflow-hidden rounded-lg border" style={{ borderColor: "var(--g-line)", backgroundColor: "var(--g-card)" }}>
                          <div className="flex items-center gap-1.5 border-b px-3 py-1.5 font-mono text-[8px] uppercase tracking-wider" style={{ borderColor: "var(--g-line)", color: "var(--g-muted)" }}>
                            {owner.label} <Icon name="chevron" size={7} /> {card.title}
                          </div>
                          <SettingRow
                            setting={setting}
                            values={values}
                            expanded={Boolean(expandedRows[setting.id])}
                            showAdvanced={showAdvanced}
                            accent={accent}
                            onChange={onChange}
                            onExpand={() => onExpand(setting.id)}
                            onAction={onAction}
                          />
                        </div>
                      ))}
                    </div>
                  )}
                </>
              ) : activeTab === "home" ? (
                <div className="space-y-2.5">
                  <div className="flex flex-wrap items-end justify-between gap-2">
                    <div>
                      <div className="font-display text-[17px] font-semibold leading-tight">Set up once.</div>
                      <p className="mt-0.5 text-[10px] leading-relaxed" style={{ color: "var(--g-muted)" }}>
                        Presets are starting points, not permanent modes. Change anything afterwards.
                      </p>
                    </div>
                    <span className="rounded-full px-2 py-1 font-mono text-[8px]" style={{ backgroundColor: `${accent}1c`, color: accent }}>
                      {Object.values(values).filter((value) => value === true).length} switches on
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-1.5">
                    {PRESETS.map((entry) => {
                      const active = preset === entry.id;
                      return (
                        <button
                          key={entry.id}
                          type="button"
                          onClick={() => applyPreset(entry.id)}
                          className="focus-ring flex flex-col items-start gap-1.5 rounded-lg border p-2.5 text-left transition-all"
                          style={{
                            borderColor: active ? `${accent}90` : "var(--g-line)",
                            backgroundColor: active ? `${accent}10` : "var(--g-card)",
                          }}
                        >
                          <div className="flex w-full items-center gap-1.5">
                            <Icon name={entry.icon} size={12} style={{ color: active ? accent : "var(--g-muted)" }} />
                            <span className="text-[10.5px] font-semibold">{entry.name}</span>
                            {active && <Icon name="check" size={10} className="ml-auto" style={{ color: accent }} />}
                          </div>
                          <span className="text-[9px] leading-snug" style={{ color: "var(--g-muted)" }}>{entry.tagline}</span>
                        </button>
                      );
                    })}
                  </div>

                  <div className="pt-0.5">
                    <div className="mb-1.5 flex items-center justify-between">
                      <span className="font-mono text-[8px] uppercase tracking-[0.14em]" style={{ color: "var(--g-muted)" }}>quick controls</span>
                      <button type="button" onClick={() => setActiveTab("gameplay")} className="font-mono text-[8px]" style={{ color: accent }}>
                        all gameplay →
                      </button>
                    </div>
                    <div className="grid grid-cols-2 gap-1.5">
                      {QUICK_TOGGLES.map((quick) => {
                        const checked = isOn(values, quick.id);
                        return (
                          <div key={quick.id} className="flex items-center gap-2 rounded-lg border px-2.5 py-2" style={{ borderColor: "var(--g-line)", backgroundColor: "var(--g-card)" }}>
                            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md" style={{ backgroundColor: "var(--g-chip)", color: checked ? accent : "var(--g-muted)" }}>
                              <Icon name={quick.icon} size={11} />
                            </span>
                            <div className="min-w-0 flex-1">
                              <div className="text-[10px] font-medium">{quick.label}</div>
                              <div className="truncate text-[8px]" style={{ color: "var(--g-muted)" }}>{quick.detail}</div>
                            </div>
                            <GuiSwitch checked={checked} onChange={() => onChange(quick.id, !checked)} accent={accent} label={quick.label} />
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div className="rounded-lg border p-2.5" style={{ borderColor: "var(--g-line)", backgroundColor: "var(--g-card)" }}>
                    <div className="mb-1.5 flex items-center gap-1.5">
                      <Icon name="shield" size={11} style={{ color: accent }} />
                      <span className="text-[10px] font-semibold">Safe by default</span>
                    </div>
                    <p className="text-[9px] leading-relaxed" style={{ color: "var(--g-muted)" }}>
                      Network sync and automation are off. This proposal removes terminal auto-click entirely and
                      never initiates a Spirit Leap from a left click. Presets cannot turn either back on.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-2.5">
                  <div className="flex flex-wrap items-end justify-between gap-2">
                    <div>
                      <div className="font-display text-[17px] font-semibold leading-tight">{tab.label}</div>
                      <p className="mt-0.5 text-[10px] leading-relaxed" style={{ color: "var(--g-muted)" }}>{tab.caption}</p>
                    </div>
                    <div className="flex items-center gap-2 font-mono text-[8px]" style={{ color: "var(--g-muted)" }}>
                      <span>{everyday} everyday switches</span>
                      <span>·</span>
                      <span>{tabCards.length} cards</span>
                    </div>
                  </div>
                  {tabCards.map((card) => (
                    <MockCard
                      key={card.id}
                      card={card}
                      values={values}
                      showAdvanced={showAdvanced}
                      accent={accent}
                      expandedRows={expandedRows}
                      onChange={onChange}
                      onExpand={onExpand}
                      onAction={onAction}
                    />
                  ))}
                  {tabCards.length === 0 && (
                    <div className="rounded-lg border p-6 text-center text-[10px]" style={{ borderColor: "var(--g-line)", color: "var(--g-muted)" }}>
                      Everything in this section is advanced. Turn on Advanced to see it.
                    </div>
                  )}
                  <div className="flex items-center justify-between px-1 pb-1 font-mono text-[8px]" style={{ color: "var(--g-muted)" }}>
                    <span>changes save when you press Done</span>
                    <button type="button" onClick={() => setShowAdvanced(!showAdvanced)} className="underline decoration-dotted">
                      {showAdvanced ? "hide advanced" : "show advanced"}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 px-1">
        <div className="flex items-center gap-2 font-mono text-[8px] uppercase tracking-[0.12em] text-faint">
          <span className="inline-flex items-center gap-1 rounded border border-accent/25 bg-accent/10 px-1.5 py-0.5 text-accent">
            <span className="h-1 w-1 rounded-full bg-accent" /> live prototype
          </span>
          HTML reconstruction, not an in-game screenshot
        </div>
        <button
          type="button"
          onClick={() => {
            setQuery("");
            setActiveTab("home");
            setShowAdvanced(false);
          }}
          className="focus-ring inline-flex items-center gap-1.5 rounded font-mono text-[8px] uppercase tracking-wider text-faint hover:text-accent"
        >
          <Icon name="refresh" size={9} /> return to home
        </button>
      </div>
    </div>
  );
}

function toastFromMock(showToast: (message: string) => void) {
  showToast("Prototype changes kept — in-game this writes only changed keys");
}

function buildSpec() {
  const lines = [
    "# Sky VeLor — GUI revamp concept (based on Beta-0.10.8.9v)",
    "",
    "## Goal",
    "Keep the Apple-style surfaces and the existing settings, but reduce first-screen decisions. 7 flat Hub categories and 34 equal-weight rows become Home + 4 intent sections and 17 grouped cards (16 settings cards plus About).",
    "",
    "## Navigation",
    ...GUI_TABS.map((tab) => `- **${tab.label}** — ${tab.caption}`),
    "",
    "## Interaction rules",
    "- Simple first. Only everyday outcomes appear on the first screen.",
    "- Child settings open inline under their parent row; focused editors remain for HUD, ESP, Chat and Item Animation.",
    "- Advanced reveals beta, diagnostic and network details without changing defaults.",
    "- Search indexes labels, descriptions, synonyms and child options; no config keys are shown to the player.",
    "- Every setting keeps its existing config key, range and default. No data migration.",
    "",
    "## Full migration map",
    "| Old tab | Old feature | New section | New card | Exposure |",
    "| --- | --- | --- | --- | --- |",
    ...MIGRATION.map((row) => {
      const tab = GUI_TABS.find((entry) => entry.id === row.newTab);
      return `| ${row.oldTab} | ${row.oldLabel} | ${tab?.label ?? row.newTab} | ${row.newCard} | ${row.exposure} |`;
    }),
    "",
    "## Performance budget",
    ...PERFORMANCE_RULES.map((rule) => `- **${rule.label}: ${rule.value}** — ${rule.detail}`),
    "",
    "## Rollout",
    ...IMPLEMENTATION_STEPS.map((step) => `${step.step}. **${step.title}** — ${step.detail}`),
    "",
    "## Parity acceptance",
    ...PARITY_CHECKS.map((check) => `- [ ] ${check}`),
    "",
    "## Safety carried into the redesign",
    "- No terminal auto-click route.",
    "- Left-click never initiates Spirit Leap.",
    "- Dungeon Sync stays off and requires explicit consent.",
    "- Automation and third-party transport are not offered from presets.",
    "",
    "Runtime status: design proposal only. Not implemented or tested in Minecraft 1.8.9.",
  ];
  return lines.join("\n");
}

export function GuiRevamp({ showToast, navigate }: SharedAuditProps) {
  const [activeTab, setActiveTab] = useState<GuiTabId>("home");
  const [values, setValues] = useState<Record<string, ProtoValue>>(() => ({ ...INITIAL_VALUES }));
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [query, setQuery] = useState("");
  const [preset, setPreset] = useState("");
  const [expandedRows, setExpandedRows] = useState<Record<string, boolean>>({});
  const [migrationFilter, setMigrationFilter] = useState<"All" | GuiTabId>("All");

  const accent = ACCENTS[String(values["appearance-accent"] ?? "Mint")] ?? ACCENTS.Mint;

  function changeValue(id: string, value: ProtoValue) {
    setValues((current) => ({ ...current, [id]: value }));
    setPreset("");
  }

  function applyPreset(id: string) {
    const next = PRESETS.find((entry) => entry.id === id);
    if (!next) return;
    setValues((current) => ({ ...current, ...next.values }));
    setPreset(id);
    showToast(`${next.name} preset applied to the prototype`);
  }

  function resetValues() {
    setValues({ ...INITIAL_VALUES });
    setPreset("");
    setExpandedRows({});
    showToast("Prototype reset to Beta-0.10.8.9 defaults");
  }

  function action(id: string) {
    toggleAction(id, values, setValues, showToast);
  }

  const normalizedMigration = migrationFilter === "All" ? MIGRATION : MIGRATION.filter((row) => row.newTab === migrationFilter);
  const oldTabs = ["General", "Quality of Life", "HUD", "Farming", "Dungeon", "Slayer", "Fishing"];
  const profileLabel = preset ? PRESETS.find((entry) => entry.id === preset)?.name ?? "Custom" : "Custom";

  return (
    <div className="animate-fade-up">
      <PageHeader
        eyebrow="GUI revamp / interactive concept"
        title="Fewer doors. The same rooms."
        description={
          <>
            The 0.10.8.9 Hub asks a player to learn <span className="text-ink">7 tabs</span>, then pick from{" "}
            <span className="text-ink">34 equal-weight rows</span>. This concept keeps the Apple surfaces and every
            setting, but makes the first screen about intent. Try the live prototype below.
          </>
        }
        actions={
          <>
            <Button variant="secondary" icon="download" onClick={() => { downloadText("skyvelor-gui-revamp-spec.md", buildSpec()); showToast("GUI revamp spec downloaded"); }}>
              Download spec
            </Button>
            <Button icon="findings" onClick={() => navigate("findings")}>
              Related audit items
            </Button>
          </>
        }
      />

      <section className="panel mb-3 overflow-hidden">
        <div className="flex flex-col gap-4 p-4 sm:p-5 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex min-w-0 items-start gap-3">
            <div className="relative shrink-0">
              <PixelCube size={38} />
              <span className="absolute -right-1 -top-1 h-2 w-2 rounded-full border border-[#080b0a] bg-accent" />
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <span className="pixel-title text-[13px] text-ink">GUI REVAMP</span>
                <Tag color="#64e08d">proposal r1</Tag>
                <span className="font-mono text-[9px] text-faint">based on 0.10.8.9</span>
              </div>
              <p className="mt-1.5 max-w-2xl text-[11px] leading-relaxed text-slate-300">
                One settings screen, five sections, a preset row and progressive disclosure. Existing keys,
                defaults and focused editors stay intact; the change is what a player sees first.
              </p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {["No auto-click", "Explicit key for leap", "Sync off + consent", "34/34 options mapped", "No config migration"].map((item) => (
                  <span key={item} className="rounded border border-line bg-[#0a100d] px-1.5 py-0.5 font-mono text-[8px] text-faint">
                    {item}
                  </span>
                ))}
              </div>
            </div>
          </div>
          <div className="flex shrink-0 flex-wrap gap-2">
            <Button size="sm" icon="download" onClick={() => { downloadText("skyvelor-gui-revamp-spec.md", buildSpec()); showToast("GUI revamp spec downloaded"); }}>
              Spec
            </Button>
            <Button size="sm" variant="secondary" icon="search" onClick={() => { setActiveTab("gameplay"); setQuery("leap"); }}>
              Try search
            </Button>
            <Button size="sm" variant="ghost" iconRight="arrow" onClick={() => navigate("plan")}>
              Fix queue
            </Button>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-line-soft bg-[#0a100d]/70 px-4 py-2 sm:px-5">
          <span className="font-mono text-[8px] uppercase tracking-[0.13em] text-faint">prototype map</span>
          {GUI_TABS.map((tab, index) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => { setActiveTab(tab.id); setQuery(""); }}
              className="focus-ring flex items-center gap-1 rounded font-mono text-[9px] text-muted transition-colors hover:text-accent"
            >
              <span className="text-faint">{String(index + 1).padStart(2, "0")}</span>
              {tab.label}
              <span className="text-faint/70">{tab.id === "home" ? "summary" : tab.cards.length}</span>
            </button>
          ))}
          <span className="ml-auto hidden items-center gap-1.5 font-mono text-[8px] uppercase tracking-wider text-faint sm:flex">
            <Icon name="eye" size={10} /> interact with the mock below
          </span>
        </div>
      </section>

      <div className="grid min-w-0 gap-3 xl:grid-cols-[minmax(0,1fr)_292px]">
        <GuiMock
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          values={values}
          onChange={changeValue}
          showAdvanced={showAdvanced}
          setShowAdvanced={setShowAdvanced}
          expandedRows={expandedRows}
          onExpand={(id) => setExpandedRows((current) => ({ ...current, [id]: !current[id] }))}
          onAction={action}
          query={query}
          setQuery={setQuery}
          preset={preset}
          applyPreset={applyPreset}
          resetValues={resetValues}
          showToast={showToast}
        />

        <div className="flex flex-col gap-3">
          <section className="panel p-4">
            <SectionLabel icon="spark">What you are looking at</SectionLabel>
            <p className="text-[11px] leading-relaxed text-muted">
              An interactive HTML reconstruction of the proposed in-game screen at a comfortable desktop scale.
              Everything here is a prototype: switches update this page, not Minecraft.
            </p>
            <div className="mt-3 space-y-2">
              {COMPACT_ITEMS.map((item) => (
                <div key={item.title} className="flex items-start gap-2">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded border border-line bg-[#0a100d] text-accent/80">
                    <Icon name={item.icon} size={10} />
                  </span>
                  <div>
                    <div className="text-[10px] font-medium text-ink">{item.title}</div>
                    <div className="text-[9px] leading-relaxed text-faint">{item.detail}</div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-3 flex items-center justify-between rounded-lg border border-line-soft bg-[#0a100d] px-2.5 py-2">
              <span className="font-mono text-[8px] uppercase tracking-wider text-faint">active profile</span>
              <span className="font-mono text-[9px]" style={{ color: accent }}>{profileLabel}</span>
            </div>
            <div className="mt-2 flex flex-wrap gap-1.5">
              <CopyButton text={buildSpec()} label="Copy spec" onCopied={showToast} />
              <Button size="sm" variant="ghost" icon="refresh" onClick={resetValues}>Reset</Button>
            </div>
          </section>

          <section className="panel p-4">
            <SectionLabel icon="alert" trailing={<Tag color="#f2b35c">carried from audit</Tag>}>Safety in the design</SectionLabel>
            <ul className="space-y-2 text-[10px] leading-relaxed text-muted">
              {[
                ["Terminal auto-click", "removed from the public surface", true],
                ["Left-click Spirit Leap", "deleted; explicit key only", true],
                ["Dungeon Sync", "off, consent before connect", true],
                ["Auto Sprint", "hidden under Advanced", true],
                ["Config keys", "unchanged, no migration", true],
              ].map(([name, detail, ok]) => (
                <li key={String(name)} className="flex items-start gap-2">
                  <Icon name={ok ? "check" : "close"} size={11} className={ok ? "mt-0.5 shrink-0 text-accent/80" : "mt-0.5 shrink-0 text-danger"} />
                  <span><span className="text-ink">{name}</span> — {detail}</span>
                </li>
              ))}
            </ul>
            <p className="mt-2 border-t border-line-soft pt-2 text-[9px] leading-relaxed text-faint">
              Addresses SV-013 (GUI blast radius), SV-002 (leap click), SV-003 (automation) and SV-005 (keybind
              persistence).
            </p>
          </section>

          <section className="panel p-4">
            <SectionLabel icon="info">Usage note</SectionLabel>
            <p className="text-[10px] leading-relaxed text-muted">
              Forge 1.8.9 has no layout engine. Treat the mockup as a specification: fixed 8px grid, 12px card
              padding at scale 2, one scroll pane, and measurements that survive GUI scale 1–3.
            </p>
          </section>
        </div>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2 lg:grid-cols-4">
        {[
          { icon: "modules" as IconName, value: "7 → 4", label: "top-level tabs", sub: "plus a Home summary" },
          { icon: "layers" as IconName, value: "34 → 17", label: "grouped cards", sub: "16 settings cards + About" },
          { icon: "eye" as IconName, value: "21", label: "everyday controls", sub: "13 deeper: expand or advanced" },
          { icon: "shield" as IconName, value: "0", label: "config migrations", sub: "keys, ranges and defaults stay" },
        ].map((stat) => (
          <div key={stat.label} className="panel flex items-center gap-3 px-3.5 py-3">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-line bg-[#0a100d] text-accent/85">
              <Icon name={stat.icon} size={14} />
            </span>
            <div className="min-w-0">
              <div className="font-display text-[18px] font-semibold leading-none text-ink">{stat.value}</div>
              <div className="mt-1 font-mono text-[8px] uppercase tracking-[0.11em] text-faint">{stat.label}</div>
              <div className="mt-0.5 truncate text-[9px] text-muted">{stat.sub}</div>
            </div>
          </div>
        ))}
      </div>

      <section className="mt-3 panel p-5">
        <SectionLabel icon="modules" trailing={<span className="font-mono text-[9px] text-faint">the rules behind the layout</span>}>
          Four rules, applied everywhere
        </SectionLabel>
        <div className="grid gap-2.5 sm:grid-cols-2 xl:grid-cols-4">
          {DESIGN_PRINCIPLES.map((principle) => (
            <div key={principle.title} className="rounded-xl border border-line-soft bg-[#0a100d] p-3.5">
              <div className="mb-2 flex items-center justify-between">
                <span className="flex h-7 w-7 items-center justify-center rounded-md border border-line bg-[#0d1510] text-accent/80">
                  <Icon name={principle.icon} size={13} />
                </span>
                <span className="rounded border border-accent/20 bg-accent/[0.06] px-1.5 py-0.5 font-mono text-[8px] text-accent/85">{principle.metric}</span>
              </div>
              <div className="text-[11px] font-semibold text-ink">{principle.title}</div>
              <p className="mt-1 text-[10px] leading-relaxed text-faint">{principle.detail}</p>
            </div>
          ))}
        </div>
      </section>

      <div className="mt-3 grid gap-3 xl:grid-cols-[1fr_1.15fr]">
        <section className="panel p-5">
          <SectionLabel icon="gauge" trailing={<Tag>before / after</Tag>}>Why it feels calmer</SectionLabel>
          <div className="grid gap-2.5 sm:grid-cols-2">
            <div className="rounded-xl border border-danger/20 bg-[#120d0c]/60 p-3.5">
              <div className="mb-2 flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-wider text-[#ff9a91]">
                <Icon name="close" size={10} /> current hub
              </div>
              <div className="flex flex-wrap gap-1">
                {oldTabs.map((tab) => (
                  <span key={tab} className="rounded border border-[#3a2a27] bg-[#1a1210] px-1.5 py-1 font-mono text-[8.5px] text-[#d1a8a2]">{tab}</span>
                ))}
              </div>
              <div className="mt-3 space-y-1">
                {Array.from({ length: 8 }).map((_, index) => (
                  <div key={index} className="flex items-center gap-1.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-[#7c5a54]" />
                    <span className="h-1 rounded-full bg-[#33221f]" style={{ width: `${92 - index * 7}%` }} />
                  </div>
                ))}
                <div className="pt-0.5 font-mono text-[8px] text-[#b08c86]">+26 more rows below</div>
              </div>
              <p className="mt-2.5 text-[9px] leading-relaxed text-[#b99a94]">
                Every row has equal visual weight, so choosing the safe option is as hard as finding a diagnostic.
              </p>
            </div>
            <div className="rounded-xl border border-accent/25 bg-[#0a1410]/70 p-3.5">
              <div className="mb-2 flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-wider text-accent">
                <Icon name="check" size={10} /> proposed hub
              </div>
              <div className="space-y-1.5">
                {GUI_TABS.map((tab) => (
                  <div
                    key={tab.id}
                    className="flex items-center justify-between rounded-md border border-[#22372b] bg-[#0c1711] px-2 py-1"
                  >
                    <span className="flex items-center gap-1.5 text-[9.5px] text-[#c9dacd]">
                      <Icon name={tab.icon} size={9} className="text-accent/70" /> {tab.label}
                    </span>
                    <span className="font-mono text-[8px] text-faint">{tab.id === "home" ? "summary" : `${tab.cards.length} cards`}</span>
                  </div>
                ))}
              </div>
              <p className="mt-2.5 text-[9px] leading-relaxed text-[#97b3a1]">
                Home is a summary, not a seventh settings page. Dangerous and diagnostic options live behind one
                explicit Advanced switch, never beside everyday comfort.
              </p>
            </div>
          </div>

          <div className="mt-3 grid grid-cols-3 gap-2">
            {[
              ["Old tabs", "7"],
              ["New sections", "5"],
              ["Features lost", "0"],
            ].map(([label, value]) => (
              <div key={label} className="rounded-lg border border-line-soft bg-[#0a100d] px-2.5 py-2">
                <div className="font-mono text-[8px] uppercase tracking-wider text-faint">{label}</div>
                <div className="mt-1 font-display text-lg font-semibold leading-none text-ink">{value}</div>
              </div>
            ))}
          </div>

          <div className="mt-3">
            <Callout tone="warn" initials="!" title="This is a presentation change, not a settings reset">
              A revamp that silently moves or changes a config key would create a second bug list. Keep the schema
              and defaults identical; only change where a control is rendered.
            </Callout>
          </div>
        </section>

        <section className="panel p-5">
          <SectionLabel icon="plan" trailing={<span className="font-mono text-[9px] text-faint">optimised for a first run</span>}>
            Fast starts
          </SectionLabel>
          <p className="mb-3 text-[11px] leading-relaxed text-muted">
            Presets are the replacement for making a player understand 34 toggles before their first dungeon.
            They set a subset; they never silently enable network transport or automation.
          </p>
          <div className="grid gap-2 sm:grid-cols-2">
            {PRESETS.map((presetEntry) => (
              <button
                key={presetEntry.id}
                type="button"
                onClick={() => {
                  applyPreset(presetEntry.id);
                  setActiveTab("home");
                }}
                className="focus-ring group rounded-xl border border-line-soft bg-[#0a100d] p-3 text-left transition-colors hover:border-[#31523f] hover:bg-[#0f1712]"
              >
                <div className="flex items-start justify-between gap-2">
                  <span className="flex items-center gap-1.5">
                    <span className="flex h-6 w-6 items-center justify-center rounded-md border border-line bg-[#0d1510] text-accent/80">
                      <Icon name={presetEntry.icon} size={12} />
                    </span>
                    <span className="text-[11px] font-semibold text-ink">{presetEntry.name}</span>
                  </span>
                  <span className="font-mono text-[8px] text-faint">{preset === presetEntry.id ? "applied" : "apply"}</span>
                </div>
                <p className="mt-1.5 text-[9.5px] leading-relaxed text-muted">{presetEntry.tagline}</p>
                <p className="mt-1 text-[9px] leading-relaxed text-faint">{presetEntry.note}</p>
              </button>
            ))}
          </div>
          <div className="mt-3 flex items-start gap-2 rounded-lg border border-info/20 bg-info/[0.05] px-3 py-2.5">
            <Icon name="info" size={11} className="mt-0.5 shrink-0 text-info" />
            <span className="text-[9px] leading-relaxed text-muted">
              “Apply” previews the resulting switches in the prototype. In-game, applying a preset should show a
              one-line summary and never write to disk until Done is pressed.
            </span>
          </div>
        </section>
      </div>

      <section className="mt-3 panel p-5">
        <div className="flex flex-col gap-3 border-b border-line-soft pb-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <SectionLabel icon="findings" trailing={<Tag color="#64e08d">34 / 34 mapped</Tag>}>Parity map</SectionLabel>
            <p className="max-w-2xl text-[11px] leading-relaxed text-muted">
              Nothing is deleted without an address. This is the exact old → new table to implement against; use it
              as the acceptance test for the redesign.
            </p>
          </div>
          <div className="flex flex-wrap gap-1">
            <button
              type="button"
              onClick={() => setMigrationFilter("All")}
              className={cn(
                "rounded-md border px-2 py-1 font-mono text-[9px] uppercase tracking-wider transition-colors",
                migrationFilter === "All" ? "border-accent/35 bg-accent/10 text-accent" : "border-line text-faint hover:text-ink",
              )}
            >
              all 34
            </button>
            {GUI_TABS.filter((entry) => entry.id !== "home").map((entry) => (
              <button
                key={entry.id}
                type="button"
                onClick={() => setMigrationFilter(entry.id)}
                className={cn(
                  "rounded-md border px-2 py-1 font-mono text-[9px] uppercase tracking-wider transition-colors",
                  migrationFilter === entry.id ? "border-accent/35 bg-accent/10 text-accent" : "border-line text-faint hover:text-ink",
                )}
              >
                {entry.label}
              </button>
            ))}
          </div>
        </div>
        <div className="scroll-slim mt-3 min-w-0 max-h-[420px] overflow-auto">
          <table className="w-full min-w-[720px] border-collapse text-left">
            <thead className="sticky top-0 z-10 bg-[#0d1410]">
              <tr className="border-b border-line">
                {["Old tab", "Existing option", "New section", "New card", "Exposure", "Note"].map((heading) => (
                  <th key={heading} className="px-2 py-2 font-mono text-[8px] font-medium uppercase tracking-[0.12em] text-faint">{heading}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-line-soft">
              {normalizedMigration.map((row) => {
                const newTab = GUI_TABS.find((entry) => entry.id === row.newTab);
                const color = row.exposure === "Everyday" ? "#64e08d" : row.exposure === "Expand" ? "#75baff" : row.exposure === "Advanced" ? "#f2b35c" : "#ff8a81";
                return (
                  <tr key={row.id} className="align-top transition-colors hover:bg-white/[0.02]">
                    <td className="px-2 py-2 text-[9.5px] text-faint">{row.oldTab}</td>
                    <td className="px-2 py-2 text-[10px] font-medium text-[#cbd9d0]">{row.oldLabel}</td>
                    <td className="px-2 py-2">
                      <span className="inline-flex items-center gap-1 rounded border border-line bg-[#0a100d] px-1.5 py-0.5 text-[9px] text-muted">
                        <Icon name={newTab?.icon ?? "layers"} size={8} /> {newTab?.label}
                      </span>
                    </td>
                    <td className="px-2 py-2 text-[9.5px] text-muted">{row.newCard}</td>
                    <td className="px-2 py-2">
                      <span className="rounded border px-1.5 py-0.5 font-mono text-[8px] uppercase tracking-wider" style={{ color, borderColor: `${color}3d`, backgroundColor: `${color}0d` }}>
                        {row.exposure}
                      </span>
                    </td>
                    <td className="px-2 py-2 text-[9px] leading-relaxed text-faint">{row.note}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 border-t border-line-soft pt-2.5">
          <span className="text-[9px] leading-relaxed text-faint">
            Focused editors (HUD, Mob/Door ESP, Chat, Item Animation) stay intact. The map only moves their entry
            points into a clearer parent.
          </span>
          <CopyButton
            text={MIGRATION.map((row) => `${row.oldTab} · ${row.oldLabel} → ${row.newTab}/${row.newCard} (${row.exposure})`).join("\n")}
            label="Copy map"
            onCopied={showToast}
          />
        </div>
      </section>

      <div className="mt-3 grid gap-3 xl:grid-cols-[1.1fr_1fr]">
        <section className="panel min-w-0 p-5">
          <SectionLabel icon="gauge" trailing={<Tag color="#64e08d">budget, not vibes</Tag>}>Lag-free by construction</SectionLabel>
          <p className="mb-3 text-[11px] leading-relaxed text-muted">
            A cleaner layout can still feel worse if it draws more. These are the engineering constraints for the
            actual Forge screen, written to be measurable.
          </p>
          <div className="grid gap-1.5 sm:grid-cols-2">
            {PERFORMANCE_RULES.map((rule) => (
              <div key={rule.label} className="rounded-lg border border-line-soft bg-[#0a100d] px-3 py-2.5">
                <div className="flex items-baseline justify-between gap-2">
                  <span className="text-[10px] font-medium text-[#cbd9d0]">{rule.label}</span>
                  <span className="shrink-0 font-mono text-[10px] text-accent">{rule.value}</span>
                </div>
                <p className="mt-1 text-[9px] leading-relaxed text-faint">{rule.detail}</p>
              </div>
            ))}
          </div>
          <div className="mt-3 min-w-0 overflow-hidden rounded-lg border border-line bg-[#070c09] p-3">
            <div className="mb-2 flex items-center justify-between">
              <span className="font-mono text-[8px] uppercase tracking-[0.13em] text-faint">java 8 · screen skeleton</span>
              <CopyButton text={JAVA_SNIPPET} label="Copy" onCopied={showToast} />
            </div>
            <pre className="scroll-slim max-h-[280px] overflow-auto font-mono text-[9px] leading-[1.75] text-[#a9c7b2]">
              <code>{JAVA_SNIPPET}</code>
            </pre>
          </div>
        </section>

        <div className="flex min-w-0 flex-col gap-3">
          <section className="panel min-w-0 p-5">
            <SectionLabel icon="plan">Implementation order</SectionLabel>
            <div className="relative space-y-1.5 before:absolute before:bottom-3 before:left-[13px] before:top-3 before:w-px before:bg-line before:content-['']">
              {IMPLEMENTATION_STEPS.map((step) => (
                <div key={step.step} className="relative flex items-start gap-2.5 rounded-lg px-1.5 py-1.5">
                  <span className="relative z-10 flex h-6 w-6 shrink-0 items-center justify-center rounded-md border border-line bg-[#0b120e] font-mono text-[8px] text-accent/85">
                    {step.step}
                  </span>
                  <div>
                    <div className="text-[10.5px] font-medium text-ink">{step.title}</div>
                    <p className="mt-0.5 text-[9px] leading-relaxed text-faint">{step.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="panel p-5">
            <SectionLabel icon="check" trailing={<Tag>{PARITY_CHECKS.length} checks</Tag>}>Definition of done</SectionLabel>
            <ul className="space-y-1.5">
              {PARITY_CHECKS.map((check) => (
                <li key={check} className="flex items-start gap-2 text-[10px] leading-relaxed text-muted">
                  <span className="mt-0.5 flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded-[2px] border border-line bg-[#0a100d]" />
                  {check}
                </li>
              ))}
            </ul>
          </section>
        </div>
      </div>

      <section className="mt-3 panel p-5">
        <SectionLabel icon="info" trailing={<Tag>decisions, not decoration</Tag>}>Questions this design answers</SectionLabel>
        <div className="grid gap-2 md:grid-cols-2">
          {GUI_FAQ.map((item) => (
            <div key={item.q} className="rounded-xl border border-line-soft bg-[#0a100d] p-3.5">
              <div className="text-[11px] font-semibold leading-snug text-ink">{item.q}</div>
              <p className="mt-1 text-[10px] leading-relaxed text-faint">{item.a}</p>
            </div>
          ))}
        </div>
        <div className="mt-4 flex flex-col items-start justify-between gap-3 border-t border-line-soft pt-4 sm:flex-row sm:items-center">
          <div className="flex items-start gap-2">
            <Icon name="wrench" size={13} className="mt-0.5 shrink-0 text-accent/80" />
            <p className="max-w-2xl text-[10px] leading-relaxed text-faint">
              Next step: implement the shell against the existing config schema, keep the current Hub reachable for one
              beta, then delete it once the 34-route parity test is green. Design proposal only — not tested in-game.
            </p>
          </div>
          <div className="flex shrink-0 gap-2">
            <Button
              size="sm"
              variant="secondary"
              icon="download"
              onClick={() => { downloadText("skyvelor-gui-revamp-spec.md", buildSpec()); showToast("Spec downloaded"); }}
            >
              Download spec
            </Button>
            <Button size="sm" icon="plan" onClick={() => navigate("plan")}>Fix queue</Button>
          </div>
        </div>
      </section>
    </div>
  );
}
