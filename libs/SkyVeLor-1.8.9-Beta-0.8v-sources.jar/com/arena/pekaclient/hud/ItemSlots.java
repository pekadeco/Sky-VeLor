package com.arena.pekaclient.hud;

import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.item.ItemStack;

/**
 * Draws item icons, stack counts and durability bars for HUD slots.
 *
 * Shapes are drawn first with {@link com.arena.pekaclient.render.UIRender}. Icons are drawn in a
 * separate pass between {@link #beginItems()} and {@link #endItems()}, because vanilla item rendering
 * needs texturing and lighting enabled. Depth is disabled for the pass, since this is a 2D overlay.
 */
public final class ItemSlots {

    /** Edge length of one item icon in GUI pixels. */
    static final int ICON = 16;

    private ItemSlots() {
    }

    public static void beginItems() {
        GlStateManager.func_179098_w();
        GlStateManager.func_179091_B();
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i();
        GlStateManager.func_179131_c(1f, 1f, 1f, 1f);
        RenderHelper.func_74520_c();
    }

    public static void endItems() {
        RenderHelper.func_74518_a();
        GlStateManager.func_179101_C();
        GlStateManager.func_179140_f();
        GlStateManager.func_179126_j();
        GlStateManager.func_179090_x();
        GlStateManager.func_179131_c(1f, 1f, 1f, 1f);
    }

    /** Draws one stack with its count and durability. An empty slot draws nothing. */
    public static void drawStack(RenderItem renderItem, FontRenderer fr, ItemStack stack, int x, int y) {
        if (stack == null) {
            return;
        }
        renderItem.func_180450_b(stack, x, y);
        renderItem.func_175030_a(fr, stack, x, y);
    }
}
