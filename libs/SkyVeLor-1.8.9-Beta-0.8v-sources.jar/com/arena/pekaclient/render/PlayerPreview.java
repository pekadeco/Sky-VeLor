package com.arena.pekaclient.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLivingBase;

/**
 * Draws a living entity (the local player, for the doll HUD) inside a GUI, with an explicit yaw.
 *
 * This follows the vanilla {@link GuiInventory#drawEntityOnScreen} sequence: the same matrix steps, the same
 * lighting, and the same temporary shadow and view-yaw settings. The difference is that the yaw is given
 * directly instead of being derived from the mouse. It uses only the public {@link RenderManager} calls that
 * vanilla GUIs use. No renderer, event, model or layer is changed, and no entity is added or moved in the world.
 *
 * Every field this class changes on the entity or the render manager is restored afterwards, and the GL
 * state is put back to the custom-drawing state that {@link UIRender} expects.
 */
public final class PlayerPreview {

    /** Vanilla's view yaw for GUI entity drawing. Applied the same way vanilla applies it. */
    private static final float GUI_VIEW_YAW = 180f;

    private PlayerPreview() {
    }

    /**
     * Draws {@code entity} centred on {@code cx}, with its feet on {@code feetY}, in the current GUI coordinate space.
     *
     * @param size    pixels per block (about 26 gives a figure a little under 50 px tall)
     * @param yawDeg  horizontal facing in degrees. 0 is the vanilla default facing
     */
    public static void draw(float cx, float feetY, float size, float yawDeg, EntityLivingBase entity) {
        if (entity == null) {
            return;
        }
        Minecraft mc = Minecraft.func_71410_x();
        RenderManager rm = mc.func_175598_ae();
        if (rm == null) {
            return;
        }

        // Hand the GL state to vanilla entity rendering: flush our batch, turn on texturing and alpha test.
        // The model needs depth testing to hide its own limbs correctly. The depth buffer is cleared first so
        // the world's depth cannot hide the figure. Depth is turned off again afterwards, as UI drawing expects.
        UIRender.flush();
        GlStateManager.func_179094_E();
        GlStateManager.func_179126_j();
        GlStateManager.func_179086_m(256);
        GlStateManager.func_179142_g();
        GlStateManager.func_179098_w();
        GlStateManager.func_179141_d();
        GlStateManager.func_179131_c(1f, 1f, 1f, 1f);

        // Save the entity fields that the draw changes, so they can be restored in the finally block.
        float savedBodyYaw = entity.field_70761_aq;
        float savedYaw = entity.field_70177_z;
        float savedPitch = entity.field_70125_A;
        float savedPrevHead = entity.field_70758_at;
        float savedHead = entity.field_70759_as;
        float savedViewYaw = rm.field_78735_i;
        boolean savedShadow = rm.func_178627_a();

        try {
            GlStateManager.func_179109_b(cx, feetY, 50f);
            GlStateManager.func_179152_a(-size, size, size);
            GlStateManager.func_179114_b(180f, 0f, 0f, 1f);

            GlStateManager.func_179114_b(135f, 0f, 1f, 0f);
            RenderHelper.func_74519_b();
            GlStateManager.func_179114_b(-135f, 0f, 1f, 0f);

            // The yaw is set on the entity, so the body, head and limbs all face the requested angle.
            float yaw = normalise(yawDeg);
            entity.field_70761_aq = yaw;
            entity.field_70177_z = yaw;
            entity.field_70125_A = 0f;
            entity.field_70759_as = yaw;
            entity.field_70758_at = yaw;

            rm.func_178631_a(GUI_VIEW_YAW);
            rm.func_178633_a(false);
            rm.func_147940_a(entity, 0.0D, 0.0D, 0.0D, 0f, 1f);
        } finally {
            rm.func_178633_a(savedShadow);
            rm.func_178631_a(savedViewYaw);
            entity.field_70761_aq = savedBodyYaw;
            entity.field_70177_z = savedYaw;
            entity.field_70125_A = savedPitch;
            entity.field_70758_at = savedPrevHead;
            entity.field_70759_as = savedHead;

            GlStateManager.func_179121_F();
            RenderHelper.func_74518_a();
            GlStateManager.func_179101_C();
            GlStateManager.func_179138_g(OpenGlHelper.field_77476_b);
            GlStateManager.func_179090_x();
            GlStateManager.func_179138_g(OpenGlHelper.field_77478_a);

            // Back to the custom-drawing state that UIRender.beginFrame sets.
            GlStateManager.func_179119_h();
            // UI drawing is 2D and runs with depth testing off (see UIRender.beginFrame).
            GlStateManager.func_179097_i();
            GlStateManager.func_179147_l();
            GlStateManager.func_179120_a(770, 771, 1, 0);
            GlStateManager.func_179090_x();
            GlStateManager.func_179118_c();
            GlStateManager.func_179131_c(1f, 1f, 1f, 1f);
        }
    }

    /** Wraps an angle into the range -180 .. 180. */
    public static float normalise(float deg) {
        float d = deg % 360f;
        if (d > 180f) {
            d -= 360f;
        } else if (d < -180f) {
            d += 360f;
        }
        return d;
    }
}
