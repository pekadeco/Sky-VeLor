package com.arena.pekaclient.render;

import com.arena.pekaclient.config.AppleSettings;
import com.arena.pekaclient.feature.DungeonContext;
import com.arena.pekaclient.feature.MobMarkers;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;

/**
 * Outlines dungeon mobs. A dungeon mob has its name tag on a separate armour stand that floats above it, so the
 * name tag is not the mob. For each name tag that {@link MobMarkers} classifies (a level tag, or the elite star),
 * the mob standing under it is found and its own bounding box is outlined. A living entity that carries the name
 * tag itself is outlined directly.
 *
 * It is drawn in the world overlay pass, after the world, so entity renderers, models, layers and visibility are
 * not touched. It runs only inside a dungeon.
 *
 * Cost: one pass over the loaded entities each frame, a string check only on name tags within {@link #RANGE}, and
 * a short search for the mob under each marked tag.
 */
public final class MobHighlight {

    /** Mobs further away than this are skipped. */
    private static final double RANGE = 64.0;
    private static final double RANGE_SQ = RANGE * RANGE;
    /** Horizontal distance allowed between a name tag and the mob it belongs to. */
    private static final double MOB_REACH = 2.5;
    private static final double MOB_REACH_SQ = MOB_REACH * MOB_REACH;
    /** Vertical range of the mob's feet relative to the name tag: the tag floats above the mob's head. */
    private static final double MOB_BELOW_TAG = 4.0;
    private static final double MOB_ABOVE_TAG = -1.0;
    private static final int NORMAL_COLOR = 0xFF7CFC8A;
    private static final int ELITE_COLOR = 0xFFFFD84D;

    private MobHighlight() {
    }

    /** Colour for a mob class, or 0 when the mob is not highlighted. */
    static int colorFor(MobMarkers.Kind kind) {
        switch (kind) {
            case ELITE:
                return ELITE_COLOR;
            case NORMAL:
                return NORMAL_COLOR;
            default:
                return 0;
        }
    }

    /** Called from RenderWorldLastEvent. */
    public static void draw(float partialTicks) {
        if (!AppleSettings.mobHighlights || !DungeonContext.inDungeon() || !WorldBox.ready()) {
            return;
        }
        Minecraft mc = Minecraft.func_71410_x();
        EntityPlayerSP player = mc.field_71439_g;
        RenderManager rm = mc.func_175598_ae();
        List<Entity> loaded = mc.field_71441_e.field_72996_f;
        Set<Entity> drawn = Collections.newSetFromMap(new IdentityHashMap<Entity, Boolean>());
        boolean open = false;
        for (int i = 0, n = loaded.size(); i < n; i++) {
            Entity tag = loaded.get(i);
            if (!(tag instanceof EntityLivingBase) || tag instanceof EntityPlayer || tag == player || tag.field_70128_L) {
                continue;
            }
            if (tag.func_70068_e(player) > RANGE_SQ) {
                continue;
            }
            String name = tag.func_95999_t();
            if (name == null || name.isEmpty()) {
                continue;
            }
            int colour = colorFor(MobMarkers.classify(name));
            if (colour == 0) {
                continue;
            }
            Entity mob = tag instanceof EntityArmorStand ? findMobUnder(loaded, tag) : tag;
            if (mob == null || !drawn.add(mob)) {
                continue;
            }
            if (!open) {
                // Through walls, so a mob behind a pillar is still marked. The overlay is drawn on top only.
                WorldBox.begin(rm.field_78730_l, rm.field_78731_m, rm.field_78728_n, true);
                open = true;
            }
            // Follow the entity's interpolated position for this frame, so the outline does not lag.
            double ox = mob.field_70142_S + (mob.field_70165_t - mob.field_70142_S) * partialTicks - mob.field_70165_t;
            double oy = mob.field_70137_T + (mob.field_70163_u - mob.field_70137_T) * partialTicks - mob.field_70163_u;
            double oz = mob.field_70136_U + (mob.field_70161_v - mob.field_70136_U) * partialTicks - mob.field_70161_v;
            AxisAlignedBB bb = mob.func_174813_aQ();
            WorldBox.outline(bb.field_72340_a + ox, bb.field_72338_b + oy, bb.field_72339_c + oz,
                    bb.field_72336_d + ox, bb.field_72337_e + oy, bb.field_72334_f + oz, colour);
        }
        if (open) {
            WorldBox.end();
        }
    }

    /**
     * The mob that a floating name tag belongs to: the nearest living, non-player, non-stand entity that is close
     * to the tag horizontally and sits below it. Returns null when none is close enough.
     */
    static Entity findMobUnder(List<Entity> loaded, Entity tag) {
        Entity best = null;
        double bestD = Double.MAX_VALUE;
        for (int i = 0, n = loaded.size(); i < n; i++) {
            Entity m = loaded.get(i);
            if (m == tag || m.field_70128_L || !(m instanceof EntityLivingBase)
                    || m instanceof EntityPlayer || m instanceof EntityArmorStand) {
                continue;
            }
            double dx = m.field_70165_t - tag.field_70165_t;
            double dz = m.field_70161_v - tag.field_70161_v;
            double horizontal = dx * dx + dz * dz;
            if (horizontal > MOB_REACH_SQ) {
                continue;
            }
            double dy = tag.field_70163_u - m.field_70163_u;
            if (dy < MOB_ABOVE_TAG || dy > MOB_BELOW_TAG) {
                continue;
            }
            double d = horizontal + dy * dy;
            if (d < bestD) {
                bestD = d;
                best = m;
            }
        }
        return best;
    }
}
