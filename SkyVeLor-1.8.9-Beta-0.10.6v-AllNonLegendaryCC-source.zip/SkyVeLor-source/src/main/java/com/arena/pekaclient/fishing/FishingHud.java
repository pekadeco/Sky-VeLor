package com.arena.pekaclient.fishing;

import com.arena.pekaclient.hud.HudElement;
import com.arena.pekaclient.hud.HudPlacement;
import com.arena.pekaclient.render.Theme;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/** Fishing counter HUD: legendary rows, a combined Common Creature row, and the total. */
public final class FishingHud extends HudElement {

    private static final float LINE_HEIGHT = 10f;

    /** Shown when on. Retained in config for compatibility with previous layouts. */
    public boolean showCatches = true;

    public FishingHud() {
        super("fishing", "Fishing counter",
                new HudPlacement(HudPlacement.Anchor.START, 6, HudPlacement.Anchor.CENTER, 0), false);
    }

    /**
     * Shows each legendary creature separately. Every tracked non-legendary rarity is combined into
     * Common Creature (CC), followed by the total. Zero-count creature rows stay hidden.
     */
    static String[] counterLines() {
        List<String> out = new ArrayList<String>();
        for (LegendaryCreature creature : LegendaryCreature.values()) {
            if (!creature.legendary) {
                continue;
            }
            long count = FishingStats.count(creature);
            if (count > 0L) {
                out.add(creature.displayName + ": " + count);
            }
        }
        long common = FishingStats.commonCreatureCount();
        if (common > 0L) {
            out.add("Common Creature (CC): " + common);
        }
        out.add("Total: " + FishingStats.totalCount());
        return out.toArray(new String[0]);
    }

    private String[] lines() {
        return showCatches ? counterLines() : new String[0];
    }

    @Override
    public float width() {
        float max = 0f;
        for (String s : lines()) {
            max = Math.max(max, textWidth(s));
        }
        return 20f + max;
    }

    @Override
    public float height() {
        return 12f + lines().length * LINE_HEIGHT * textScale();
    }

    @Override
    protected void drawContent() {
        String[] lines = lines();
        drawPanel(width(), height());
        float y = 6f;
        for (String s : lines) {
            text(s, 10f, y, Theme.textPrimary);
            y += LINE_HEIGHT * textScale();
        }
    }

    @Override
    protected void resetExtra() {
        showCatches = true;
    }

    @Override
    protected void loadExtra(Properties p, String k) {
        showCatches = bool(p, k + "catches", true);
    }

    @Override
    protected void saveExtra(Properties p, String k) {
        p.setProperty(k + "catches", String.valueOf(showCatches));
    }
}
