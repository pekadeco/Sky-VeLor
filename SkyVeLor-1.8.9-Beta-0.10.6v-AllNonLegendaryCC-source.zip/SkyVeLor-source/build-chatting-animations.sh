#!/bin/sh
# Builds Sky VeLor, then combines the official Chatting 2.0.6 Forge classes used by the animation layer.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
./gradlew clean build
BASE="$ROOT/build/libs/SkyVeLor-1.8.9-Beta-0.10.6v-ChattingAnimations-NoCopy-HPFix.jar"
CHAT="$ROOT/build/Chatting-1.8.9-forge-2.0.6.jar"
OUT="$ROOT/build/libs/SkyVeLor-1.8.9-Beta-0.10.6v-ChattingAnimations-NoCopy-HPFix-combined.jar"
curl -L --fail -o "$CHAT" \
  https://github.com/Polyfrost/Chatting/releases/download/v2.0.6/Chatting-1.8.9-forge-2.0.6.jar
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
(cd "$TMP" && unzip -q "$BASE" && rm -f META-INF/MANIFEST.MF && \
  unzip -qo "$CHAT" -x META-INF/MANIFEST.MF mcmod.info && \
  rm -f assets/chatting/copy.png org/polyfrost/chatting/mixin/compat/ChatTabsMixin_SkytilsCopyChat.class && \
  sed -i '/compat.ChatTabsMixin_SkytilsCopyChat/d' mixins.chatting.json)
cat > "$TMP/combined.mf" <<'EOF'
Manifest-Version: 1.0
ModSide: CLIENT
ForceLoadAsMod: true
TweakOrder: 0
MixinConfigs: mixins.chatting.json
TweakClass: cc.polyfrost.oneconfig.loader.stage0.LaunchWrapperTweaker

EOF
rm -f "$OUT"
(cd "$TMP" && jar cfm "$OUT" combined.mf . && zip -qd "$OUT" combined.mf)
echo "Wrote $OUT"
