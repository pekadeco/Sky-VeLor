package com.arena.applegui.gui;

import com.arena.applegui.widget.Widget;

import java.util.Locale;

/**
 * One entry in a settings list. Rows are laid out in a single vertical flow that
 * the screen scrolls, and every row is plain data, so search can reuse them.
 */
final class Row {

    static final int SECTION = 0;
    static final int ITEM = 1;
    static final int CUSTOM = 2;

    /** Paints custom content (charts, stat cards) into the given card rectangle. */
    interface Painter {
        void paint(float x, float y, float w, float h);
    }

    final int kind;
    final String label;
    final String desc;
    final Widget control;
    final Painter painter;
    final float height;
    float y;

    private Row(int kind, String label, String desc, Widget control, Painter painter, float height) {
        this.kind = kind;
        this.label = label;
        this.desc = desc;
        this.control = control;
        this.painter = painter;
        this.height = height;
    }

    static Row section(String title) {
        return new Row(SECTION, title.toUpperCase(Locale.ROOT), null, null, null, 20f);
    }

    static Row item(String label, String desc, Widget control) {
        return new Row(ITEM, label, desc, control, null, 40f);
    }

    static Row custom(float height, Painter painter) {
        return new Row(CUSTOM, null, null, null, painter, height);
    }
}
