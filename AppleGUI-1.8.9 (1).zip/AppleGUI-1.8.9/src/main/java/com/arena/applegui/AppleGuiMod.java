package com.arena.applegui;

import com.arena.applegui.config.AppleSettings;
import com.arena.applegui.gui.AppleHubScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

/**
 * Entry point. Client-only. Adds:
 *  - a keybind (default Right Shift) that opens the hub from gameplay,
 *  - an "Apple GUI" button on the main menu and pause menu.
 * All hooks are standard Forge 1.8.9 events; no reflection and no mixins.
 */
@Mod(modid = AppleGuiMod.MODID,
        name = AppleGuiMod.NAME,
        version = AppleGuiMod.VERSION,
        acceptedMinecraftVersions = "[1.8.9]",
        clientSideOnly = true)
public class AppleGuiMod {

    public static final String MODID = "applegui";
    public static final String NAME = "Apple GUI";
    public static final String VERSION = "1.0.0";

    /** Unique-enough id for our injected menu button (vanilla ids are < 200). */
    private static final int MENU_BUTTON_ID = 0x41504C;

    public static final KeyBinding OPEN_KEY =
            new KeyBinding("key.applegui.open", Keyboard.KEY_RSHIFT, "key.categories.applegui");

    @EventHandler
    public void init(FMLInitializationEvent event) {
        AppleSettings.load();
        ClientRegistry.registerKeyBinding(OPEN_KEY);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getMinecraft();
        if (OPEN_KEY.isPressed() && mc.currentScreen == null) {
            mc.displayGuiScreen(new AppleHubScreen(null));
        }
    }

    @SubscribeEvent
    public void onInitGui(GuiScreenEvent.InitGuiEvent.Post event) {
        if (event.gui instanceof GuiMainMenu || event.gui instanceof GuiIngameMenu) {
            // Top-right corner: does not collide with vanilla's centred column.
            event.buttonList.add(new GuiButton(MENU_BUTTON_ID, event.gui.width - 92, 8, 84, 20, "Apple GUI"));
        }
    }

    @SubscribeEvent
    public void onActionPerformed(GuiScreenEvent.ActionPerformedEvent.Pre event) {
        if (event.button != null && event.button.id == MENU_BUTTON_ID) {
            event.setCanceled(true);
            Minecraft.getMinecraft().displayGuiScreen(new AppleHubScreen(event.gui));
        }
    }
}
