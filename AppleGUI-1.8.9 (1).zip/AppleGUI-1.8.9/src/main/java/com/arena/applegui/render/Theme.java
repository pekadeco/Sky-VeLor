package com.arena.applegui.render;

import com.arena.applegui.config.AppleSettings;

/**
 * Colour palette and motion settings. Static fields are rebuilt by {@link #refresh()}
 * whenever a setting changes, so drawing code never allocates or recomputes palettes.
 */
public final class Theme {

    public static int accent = 0xFF0A84FF;
    public static int textPrimary = 0xFFF5F5F7;
    public static int textSecondary = 0xFFA1A1A8;
    public static int textTertiary = 0xFF707078;
    public static int windowTop = 0xF01E1E21;
    public static int windowBottom = 0xF0101012;
    public static int card = 0x14FFFFFF;
    public static int cardHover = 0x22FFFFFF;
    public static int buttonFill = 0x26FFFFFF;
    public static int buttonHover = 0x3DFFFFFF;
    public static int border = 0x1FFFFFFF;
    public static int divider = 0x18FFFFFF;
    public static int track = 0xFF3A3A3D;
    public static int segSelected = 0xFF5A5A5E;
    public static int popup = 0xF22A2A2E;
    public static int veil = 0x73000000;

    public static int radius = 12;
    public static boolean animations = true;
    public static float speed = 1f;

    private Theme() {
    }

    public static void refresh() {
        int glass = Math.round(AppleSettings.glassOpacity * 2.55f);
        radius = AppleSettings.cornerRadius;
        accent = AppleSettings.accentColor();
        animations = AppleSettings.animations;
        speed = AppleSettings.animSpeed / 100f;

        if (AppleSettings.darkMode) {
            windowTop = (glass << 24) | 0x1E1E21;
            windowBottom = (glass << 24) | 0x101012;
            card = 0x14FFFFFF;
            cardHover = 0x22FFFFFF;
            buttonFill = 0x26FFFFFF;
            buttonHover = 0x3DFFFFFF;
            border = 0x1FFFFFFF;
            divider = 0x18FFFFFF;
            track = 0xFF3A3A3D;
            segSelected = 0xFF5A5A5E;
            popup = 0xF22A2A2E;
            veil = 0x73000000;
            textPrimary = 0xFFF5F5F7;
            textSecondary = 0xFFA1A1A8;
            textTertiary = 0xFF707078;
        } else {
            windowTop = (glass << 24) | 0xF8F8FA;
            windowBottom = (glass << 24) | 0xEBEBF0;
            card = 0x99FFFFFF;
            cardHover = 0xCCFFFFFF;
            buttonFill = 0xCCFFFFFF;
            buttonHover = 0xFFFFFFFF;
            border = 0x1F000000;
            divider = 0x14000000;
            track = 0xFFD8D8DE;
            segSelected = 0xFFFFFFFF;
            popup = 0xF7FFFFFF;
            veil = 0x40000000;
            textPrimary = 0xFF1D1D1F;
            textSecondary = 0xFF6E6E73;
            textTertiary = 0xFF8E8E93;
        }
    }
}
