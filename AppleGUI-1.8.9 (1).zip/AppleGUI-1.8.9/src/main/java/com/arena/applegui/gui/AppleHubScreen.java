package com.arena.applegui.gui;

import com.arena.applegui.config.AppleSettings;
import com.arena.applegui.render.Anim;
import com.arena.applegui.render.Icons;
import com.arena.applegui.render.Theme;
import com.arena.applegui.render.UIRender;
import com.arena.applegui.widget.AppleButton;
import com.arena.applegui.widget.AppleDropdown;
import com.arena.applegui.widget.AppleSegmented;
import com.arena.applegui.widget.AppleSlider;
import com.arena.applegui.widget.AppleToggle;
import com.arena.applegui.widget.SearchField;
import com.arena.applegui.widget.Widget;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiControls;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiScreenResourcePacks;
import net.minecraft.client.gui.GuiVideoSettings;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The Apple GUI hub: a macOS-style window with traffic lights, a sidebar (or tab bar on
 * narrow screens), a search field and scrollable grouped cards.
 *
 * Responsive: the sidebar collapses to tabs under 460 px wide, and the header compacts
 * when the window is short. The list scrolls with the mouse wheel, touch drag (with
 * inertia) or the scroll bar drawn on the right edge.
 */
public class AppleHubScreen extends GuiScreen {

    private static final float TITLE_H = 34f;
    private static final float SIDEBAR_W = 136f;
    private static final float PAD = 14f;
    private static final float ROW_GAP = 6f;
    private static final float NAV_H = 26f;
    private static final float NAV_STEP = 30f;
    private static final float DRAG_THRESHOLD = 5f;

    private static final String[] PAGE_NAMES = {"Home", "Appearance", "Performance"};
    private static final String[] PAGE_SUBS = {
            "Your client at a glance", "Make it yours", "Tune rendering for your device"
    };
    private static final int[] PAGE_ICONS = {Icons.HOME, Icons.PALETTE, Icons.BOLT};
    private static final String[] STAT_LABELS = {"FRAME RATE", "MEMORY", "FRAME TIME"};

    private final GuiScreen parent;
    private final List<List<Row>> pages = new ArrayList<List<Row>>();
    private int pageIndex;

    private final SearchField search = new SearchField("Search settings");
    private final List<Row> searchRows = new ArrayList<Row>();
    private int searchVersion = -1;
    private boolean searching;
    private String query = "";

    private final Anim openAnim = new Anim(0f);
    private final Anim fadeAnim = new Anim(1f);
    private final Anim[] navSel = new Anim[PAGE_NAMES.length];
    private final Anim[] navHover = new Anim[PAGE_NAMES.length];
    private final Anim indicator = new Anim(0f);

    // Scrolling state
    private float scroll;
    private float scrollTarget;
    private float scrollVel;
    private float contentH;
    private boolean gesture;
    private boolean gestureMoved;
    private float gestureStartY;
    private float gestureStartScroll;
    private float lastDragY;
    private long lastDragNs;
    private Widget active;
    private AppleDropdown openDropdown;

    // Layout (recomputed every frame, in GUI-scaled pixels)
    private float wx, wy, ww, wh;
    private float cx0, cw, headY;
    private float vx, vy, vw, vh;
    private boolean wide;
    private boolean tall;

    // Timing and stats
    private long lastNs;
    private final float[] frameHistory = new float[90];
    private int histIdx;
    private float dtEma = 1f / 60f;
    private int slowFrames;
    private int fastFrames;
    private boolean autoLow;
    private float statTimer;
    private final String[] statValues = {"--", "--", "--"};
    private int scaleKey = -1;
    private float sf = 2f;

    public AppleHubScreen(GuiScreen parent) {
        this.parent = parent;
        Theme.refresh();
        openAnim.to(1f);
        for (int i = 0; i < PAGE_NAMES.length; i++) {
            navSel[i] = new Anim(i == 0 ? 1f : 0f);
            navHover[i] = new Anim(0f);
        }
        buildPages();
    }

    // ------------------------------------------------------------------ pages

    private void buildPages() {
        final Minecraft mc = Minecraft.getMinecraft();

        List<Row> home = new ArrayList<Row>();
        home.add(Row.section("Overview"));
        home.add(Row.custom(86f, this::paintStats));
        home.add(Row.section("Shortcuts"));
        home.add(Row.item("Video Settings", "Graphics quality, render distance and FPS",
                button("Open", () -> mc.displayGuiScreen(new GuiVideoSettings(this, mc.gameSettings)))));
        home.add(Row.item("Controls", "Key bindings and mouse sensitivity",
                button("Open", () -> mc.displayGuiScreen(new GuiControls(this, mc.gameSettings)))));
        home.add(Row.item("Resource Packs", "Textures, sounds and language packs",
                button("Open", () -> mc.displayGuiScreen(new GuiScreenResourcePacks(this)))));
        home.add(Row.item("All Options", "Every vanilla setting in one place",
                button("Open", () -> mc.displayGuiScreen(new GuiOptions(this, mc.gameSettings)))));
        pages.add(home);

        List<Row> look = new ArrayList<Row>();
        look.add(Row.section("Theme"));
        look.add(Row.item("Appearance", "Dark or light interface",
                new AppleSegmented(new String[]{"Dark", "Light"}, 132f, 24f,
                        () -> AppleSettings.darkMode ? 0 : 1,
                        v -> {
                            AppleSettings.darkMode = v == 0;
                            Theme.refresh();
                        })));
        look.add(Row.item("Accent color", "Selection, toggles and sliders",
                new AppleDropdown(AppleSettings.ACCENT_NAMES, AppleSettings.ACCENT_COLORS, 124f, 24f,
                        () -> AppleSettings.accent,
                        v -> {
                            AppleSettings.accent = v;
                            Theme.refresh();
                        })));
        look.add(Row.section("Shape and glass"));
        look.add(Row.item("Corner radius", "Roundness of panels and controls",
                new AppleSlider(4, 18, 1, "px", 150f,
                        () -> AppleSettings.cornerRadius,
                        v -> {
                            AppleSettings.cornerRadius = v;
                            Theme.refresh();
                        })));
        look.add(Row.item("Glass opacity", "How much of the game shows through",
                new AppleSlider(60, 100, 5, "%", 150f,
                        () -> AppleSettings.glassOpacity,
                        v -> {
                            AppleSettings.glassOpacity = v;
                            Theme.refresh();
                        })));
        pages.add(look);

        List<Row> perf = new ArrayList<Row>();
        perf.add(Row.section("Rendering"));
        perf.add(Row.item("Curve quality", "Smoothness of rounded corners",
                new AppleDropdown(AppleSettings.CURVE_NAMES, null, 124f, 24f,
                        () -> AppleSettings.curveQuality,
                        v -> AppleSettings.curveQuality = v)));
        perf.add(Row.item("Soft shadows", "Shadows behind panels and menus",
                new AppleToggle(() -> AppleSettings.shadows, v -> AppleSettings.shadows = v)));
        perf.add(Row.item("Animations", "Smooth transitions and motion",
                new AppleToggle(() -> AppleSettings.animations,
                        v -> {
                            AppleSettings.animations = v;
                            Theme.refresh();
                        })));
        perf.add(Row.item("Animation speed", "Tempo of transitions",
                new AppleSlider(40, 200, 10, "%", 150f,
                        () -> AppleSettings.animSpeed,
                        v -> {
                            AppleSettings.animSpeed = v;
                            Theme.refresh();
                        })));
        perf.add(Row.item("Adaptive quality", "Lowers detail automatically when FPS drops",
                new AppleToggle(() -> AppleSettings.adaptive, v -> AppleSettings.adaptive = v)));
        perf.add(Row.section("Live"));
        perf.add(Row.custom(76f, this::paintGraph));
        pages.add(perf);
    }

    private static AppleButton button(String label, Runnable action) {
        return new AppleButton(label, 64f, 22f, false, action);
    }

    private List<Row> currentRows() {
        return searching ? searchRows : pages.get(pageIndex);
    }

    private void selectPage(int index) {
        if (index == pageIndex && !searching) {
            return;
        }
        pageIndex = index;
        scroll = 0f;
        scrollTarget = 0f;
        scrollVel = 0f;
        openDropdown = null;
        search.clear();
        search.setFocused(false);
        fadeAnim.snap(0f);
        fadeAnim.to(1f);
    }

    // ------------------------------------------------------------------ frame loop

    @Override
    public void initGui() {
        super.initGui();
        Keyboard.enableRepeatEvents(true);
    }

    @Override
    public void onGuiClosed() {
        super.onGuiClosed();
        Keyboard.enableRepeatEvents(false);
        AppleSettings.save();
    }

    @Override
    public void drawScreen(int mx, int my, float partialTicks) {
        Minecraft mc = Minecraft.getMinecraft();
        long now = System.nanoTime();
        float dt = lastNs == 0L ? 1f / 60f : Math.min(0.1f, (now - lastNs) / 1.0e9f);
        lastNs = now;

        refreshScale(mc);
        trackFrame(dt);
        syncSearch();
        updateStats(dt);
        updateAnims(dt);
        computeLayout();

        int q = autoLow ? 2 : AppleSettings.curveQuality;
        UIRender.segCap = AppleSettings.CURVE_SEGMENTS[q];
        UIRender.shadows = AppleSettings.shadows && !autoLow;

        drawDefaultBackground();

        UIRender.beginFrame();
        float open = openAnim.get();
        float fade = fadeAnim.get();

        UIRender.alphaMul = open;
        UIRender.rect(0f, 0f, width, height, Theme.veil);
        drawWindowChrome(mx, my);

        UIRender.alphaMul = open * fade;
        drawHeader();
        search.draw(mx, my);
        boolean inView = inside(mx, my, vx, vy, vw, vh);
        drawContent(inView ? mx : -10000, inView ? my : -10000);

        UIRender.alphaMul = open;
        if (openDropdown != null) {
            openDropdown.drawPopup(mx, my, wy, wy + wh, wx + ww, wx);
        }
        UIRender.alphaMul = 1f;
        UIRender.endFrame();
    }

    private void refreshScale(Minecraft mc) {
        int key = mc.displayWidth * 31 + mc.displayHeight * 7 + mc.gameSettings.guiScale;
        if (key != scaleKey) {
            scaleKey = key;
            sf = new ScaledResolution(mc).getScaleFactor();
        }
    }

    /** Tracks frame times and drops detail when the client is struggling (adaptive quality). */
    private void trackFrame(float dt) {
        frameHistory[histIdx] = dt * 1000f;
        histIdx = (histIdx + 1) % frameHistory.length;
        dtEma += (dt - dtEma) * 0.1f;

        if (!AppleSettings.adaptive) {
            autoLow = false;
            slowFrames = 0;
            fastFrames = 0;
            return;
        }
        if (dt > 0.05f) {
            slowFrames++;
            fastFrames = 0;
            if (slowFrames > 30) {
                autoLow = true;
            }
        } else if (dt < 0.03f) {
            fastFrames++;
            slowFrames = 0;
            if (fastFrames > 180) {
                autoLow = false;
            }
        }
    }

    private void syncSearch() {
        if (search.version() == searchVersion) {
            return;
        }
        searchVersion = search.version();
        query = search.text().toLowerCase(Locale.ROOT).trim();
        searchRows.clear();
        if (!query.isEmpty()) {
            for (List<Row> page : pages) {
                for (Row r : page) {
                    if (r.kind != Row.ITEM) {
                        continue;
                    }
                    if (r.label.toLowerCase(Locale.ROOT).contains(query)
                            || (r.desc != null && r.desc.toLowerCase(Locale.ROOT).contains(query))) {
                        searchRows.add(r);
                    }
                }
            }
        }
        searching = !query.isEmpty();
        scroll = 0f;
        scrollTarget = 0f;
        scrollVel = 0f;
        openDropdown = null;
    }

    private void updateStats(float dt) {
        statTimer -= dt;
        if (statTimer > 0f) {
            return;
        }
        statTimer = 0.5f;
        Runtime rt = Runtime.getRuntime();
        statValues[0] = Minecraft.getDebugFPS() + " fps";
        statValues[1] = ((rt.totalMemory() - rt.freeMemory()) >> 20) + " MB";
        statValues[2] = String.format(Locale.ROOT, "%.1f ms", dtEma * 1000f);
    }

    private void updateAnims(float dt) {
        openAnim.update(dt, 10f);
        fadeAnim.update(dt, 14f);
        indicator.update(dt, 10f);
        for (int i = 0; i < navSel.length; i++) {
            navSel[i].to(!searching && i == pageIndex ? 1f : 0f);
            navSel[i].update(dt, 14f);
            navHover[i].update(dt, 16f);
        }

        float max = maxScroll();
        if (!gesture) {
            if (scrollVel != 0f) {
                scrollTarget += scrollVel * dt;
                scrollVel *= (float) Math.exp(-dt * 5f);
                if (Math.abs(scrollVel) < 4f) {
                    scrollVel = 0f;
                }
            }
            if (scrollTarget < 0f) {
                scrollTarget = 0f;
                scrollVel = 0f;
            } else if (scrollTarget > max) {
                scrollTarget = max;
                scrollVel = 0f;
            }
            if (Theme.animations) {
                scroll += (scrollTarget - scroll) * (1f - (float) Math.exp(-dt * 16f * Theme.speed));
            } else {
                scroll = scrollTarget;
            }
            if (Math.abs(scrollTarget - scroll) < 0.05f) {
                scroll = scrollTarget;
            }
        }
        boolean moving = gesture || scrollVel != 0f || Math.abs(scrollTarget - scroll) > 0.5f;
        indicator.to(moving ? 1f : 0f);

        List<Row> rows = currentRows();
        for (int i = 0, n = rows.size(); i < n; i++) {
            Widget c = rows.get(i).control;
            if (c != null) {
                c.update(dt);
            }
        }
    }

    // ------------------------------------------------------------------ layout

    private void computeLayout() {
        ww = Math.max(160f, Math.min(width - 16f, 620f));
        wh = Math.max(120f, Math.min(height - 16f, 400f));
        wide = ww >= 460f;
        tall = wh >= 230f;
        wx = (width - ww) * 0.5f;
        wy = (height - wh) * 0.5f + (1f - openAnim.get()) * 12f;

        float side = wide ? SIDEBAR_W : 0f;
        float inset = wide ? 16f : PAD;
        cx0 = wx + side + inset;
        cw = ww - side - inset - PAD;
        headY = wy + TITLE_H + (wide ? 12f : 40f);

        if (tall) {
            search.x = cx0;
            search.y = headY + 36f;
            search.w = cw;
            search.h = 22f;
        } else {
            float sw = Math.min(170f, cw * 0.5f);
            search.x = cx0 + cw - sw;
            search.y = headY - 3f;
            search.w = sw;
            search.h = 20f;
        }

        vx = cx0;
        vw = cw;
        vy = tall ? headY + 68f : headY + 26f;
        vh = Math.max(20f, wy + wh - 12f - vy);

        contentH = layoutRows(currentRows(), vy - scroll);
    }

    private float layoutRows(List<Row> rows, float top) {
        float y = top;
        for (int i = 0, n = rows.size(); i < n; i++) {
            Row r = rows.get(i);
            r.y = y;
            Widget c = r.control;
            if (c != null) {
                c.x = cx0 + cw - 12f - c.w;
                c.y = y + (r.height - c.h) * 0.5f;
            }
            y += r.height + ROW_GAP;
        }
        return Math.max(0f, y - top - ROW_GAP);
    }

    private float maxScroll() {
        return Math.max(0f, contentH + 4f - vh);
    }

    // ------------------------------------------------------------------ drawing

    private void drawWindowChrome(int mx, int my) {
        UIRender.shadow(wx, wy, ww, wh, Theme.radius);
        UIRender.roundRectBorder(wx, wy, ww, wh, Theme.radius, Theme.windowTop, Theme.windowBottom, Theme.border);
        UIRender.rect(wx + 1f, wy + TITLE_H, ww - 2f, 1f, Theme.divider);

        float cy = wy + 17f;
        UIRender.circle(wx + 16f, cy, 5.5f, 0xFFFF5F57);
        UIRender.circle(wx + 30f, cy, 5.5f, 0xFFFEBC2E);
        UIRender.circle(wx + 44f, cy, 5.5f, 0xFF28C840);
        if (inside(mx, my, wx + 10.5f, cy - 5.5f, 11f, 11f)) {
            UIRender.line(wx + 13.5f, cy - 2.5f, wx + 18.5f, cy + 2.5f, 1.1f, 0x99000000);
            UIRender.line(wx + 18.5f, cy - 2.5f, wx + 13.5f, cy + 2.5f, 1.1f, 0x99000000);
        }

        FontRenderer fr = fr();
        String title = searching ? "Search" : "Apple GUI";
        UIRender.text(fr, title, wx + (ww - fr.getStringWidth(title)) * 0.5f, wy + 12.5f,
                Theme.textSecondary, 1f, false);

        if (wide) {
            UIRender.rect(wx + SIDEBAR_W, wy + TITLE_H + 1f, 1f, wh - TITLE_H - 2f, Theme.divider);
            drawSidebar(mx, my);
        } else {
            drawTabs();
        }
    }

    private void drawSidebar(int mx, int my) {
        FontRenderer fr = fr();
        for (int i = 0; i < PAGE_NAMES.length; i++) {
            float x = wx + 8f;
            float w = SIDEBAR_W - 16f;
            float y = wy + TITLE_H + 10f + i * NAV_STEP;
            boolean hov = inside(mx, my, x, y, w, NAV_H);
            navHover[i].to(hov ? 1f : 0f);
            float sel = navSel[i].get();
            float hv = navHover[i].get();

            if (hv > 0.01f) {
                UIRender.roundRect(x, y, w, NAV_H, 8f, UIRender.withAlpha(Theme.cardHover, hv), UIRender.withAlpha(Theme.cardHover, hv), 1f);
            }
            if (sel > 0.01f) {
                int pill = UIRender.withAlpha(Theme.accent, 0.20f * sel);
                UIRender.roundRect(x, y, w, NAV_H, 8f, pill, pill, 1f);
            }
            int iconCol = UIRender.mix(Theme.textSecondary, Theme.accent, sel);
            Icons.draw(PAGE_ICONS[i], x + 13f, y + NAV_H * 0.5f, 12f, iconCol);
            UIRender.text(fr, PAGE_NAMES[i], x + 28f, y + (NAV_H - 9f) * 0.5f + 1f,
                    UIRender.mix(Theme.textSecondary, Theme.textPrimary, sel), 1f, false);
        }
    }

    private void drawTabs() {
        FontRenderer fr = fr();
        float x = wx + PAD;
        float y = wy + TITLE_H + 6f;
        float w = ww - PAD * 2f;
        float h = 24f;
        UIRender.roundRect(x, y, w, h, h * 0.5f, Theme.track, Theme.track, 1f);
        float seg = w / PAGE_NAMES.length;
        for (int i = 0; i < PAGE_NAMES.length; i++) {
            float sx = x + i * seg;
            float sel = navSel[i].get();
            if (sel > 0.01f) {
                float inner = h - 4f;
                int pill = UIRender.withAlpha(Theme.segSelected, sel);
                UIRender.roundRect(sx + 2f, y + 2f, seg - 4f, inner, inner * 0.5f, pill, pill, 1f);
            }
            float tw = fr.getStringWidth(PAGE_NAMES[i]);
            UIRender.text(fr, PAGE_NAMES[i], sx + (seg - tw) * 0.5f, y + (h - 9f) * 0.5f + 1f,
                    UIRender.mix(Theme.textSecondary, Theme.textPrimary, sel), 1f, false);
        }
    }

    private void drawHeader() {
        FontRenderer fr = fr();
        String title = searching ? "Search" : PAGE_NAMES[pageIndex];
        String sub = searching ? searchRows.size() + (searchRows.size() == 1 ? " match" : " matches")
                : PAGE_SUBS[pageIndex];
        UIRender.text(fr, title, cx0, headY, Theme.textPrimary, 1.5f, false);
        if (tall) {
            UIRender.text(fr, sub, cx0, headY + 19f, Theme.textSecondary, 1f, false);
        }
    }

    private void drawContent(int mx, int my) {
        FontRenderer fr = fr();
        List<Row> rows = currentRows();
        UIRender.scissorBegin(vx, vy, vw, vh, sf);

        if (searching && rows.isEmpty()) {
            String none = "No matching settings";
            UIRender.text(fr, none, vx + (vw - fr.getStringWidth(none)) * 0.5f, vy + 16f,
                    Theme.textTertiary, 1f, false);
        }

        float top = vy;
        float bottom = vy + vh;
        for (int i = 0, n = rows.size(); i < n; i++) {
            Row r = rows.get(i);
            if (r.y + r.height < top || r.y > bottom) {
                continue;
            }
            if (r.kind == Row.SECTION) {
                UIRender.text(fr, r.label, vx + 2f, r.y + 4f, Theme.textTertiary, 0.85f, false);
            } else if (r.kind == Row.ITEM) {
                drawItem(fr, r, mx, my);
            } else {
                r.painter.paint(vx, r.y, vw, r.height);
            }
        }
        drawScrollIndicator();
        UIRender.scissorEnd();
    }

    private void drawItem(FontRenderer fr, Row r, int mx, int my) {
        float x = vx;
        float y = r.y;
        float w = vw;
        float h = r.height;
        UIRender.roundRectBorder(x, y, w, h, cardRadius(), Theme.card, Theme.card, Theme.border);

        float maxW = w - 24f - (r.control != null ? r.control.w + 12f : 0f);
        String label = fit(fr, r.label, maxW);
        if (r.desc != null) {
            UIRender.text(fr, label, x + 12f, y + 7f, Theme.textPrimary, 1f, false);
            UIRender.text(fr, fit(fr, r.desc, maxW), x + 12f, y + 21f, Theme.textSecondary, 1f, false);
        } else {
            UIRender.text(fr, label, x + 12f, y + (h - 9f) * 0.5f + 1f, Theme.textPrimary, 1f, false);
        }
        if (r.control != null) {
            r.control.draw(mx, my);
        }
    }

    private void drawScrollIndicator() {
        float ind = indicator.get();
        float maxS = maxScroll();
        if (ind <= 0.01f || maxS <= 0f) {
            return;
        }
        float track = vh - 8f;
        float thumb = Math.max(24f, track * vh / (contentH + 4f));
        float ty = vy + 4f + (track - thumb) * (scroll / maxS);
        float prev = UIRender.alphaMul;
        UIRender.alphaMul = prev * ind;
        UIRender.roundRect(vx + vw - 3f, ty, 3f, thumb, 1.5f, Theme.textSecondary, Theme.textSecondary, 0.5f);
        UIRender.alphaMul = prev;
    }

    /** Stat cards for the Home page. Painter, no widgets. */
    private void paintStats(float x, float y, float w, float h) {
        FontRenderer fr = fr();
        float gap = 8f;
        float cardW = (w - gap * 2f) / 3f;
        for (int i = 0; i < 3; i++) {
            float cx = x + i * (cardW + gap);
            UIRender.roundRectBorder(cx, y, cardW, h, cardRadius(), Theme.card, Theme.card, Theme.border);
            UIRender.text(fr, STAT_LABELS[i], cx + 10f, y + 11f, Theme.textTertiary, 0.8f, false);
            int valueCol = i == 0 ? Theme.accent : Theme.textPrimary;
            UIRender.text(fr, statValues[i], cx + 10f, y + h - 26f, valueCol, 1.4f, false);
        }
    }

    /** Frame-time bar chart for the Performance page. Batched into one draw call. */
    private void paintGraph(float x, float y, float w, float h) {
        FontRenderer fr = fr();
        UIRender.roundRectBorder(x, y, w, h, cardRadius(), Theme.card, Theme.card, Theme.border);
        UIRender.text(fr, "FRAME TIME", x + 12f, y + 9f, Theme.textTertiary, 0.8f, false);
        String v = statValues[2];
        UIRender.text(fr, v, x + w - 12f - fr.getStringWidth(v), y + 8f, Theme.textPrimary, 1f, false);

        float px = x + 12f;
        float pw = w - 24f;
        float py = y + 26f;
        float ph = h - 36f;
        UIRender.rect(px, py + ph * 0.5f, pw, 1f, Theme.divider);

        int n = frameHistory.length;
        float bw = pw / n;
        UIRender.beginBatch();
        for (int i = 0; i < n; i++) {
            float ms = frameHistory[(histIdx + i) % n];
            float bh = Math.max(1f, Math.min(1f, ms / 33.3f) * ph);
            int c = ms > 33.3f ? 0xFFFF9F0A : Theme.accent;
            UIRender.rect(px + i * bw, py + ph - bh, Math.max(1f, bw - 1f), bh, c);
        }
        UIRender.endBatch();
    }

    private static String fit(FontRenderer fr, String s, float maxW) {
        if (s == null) {
            return "";
        }
        int mw = (int) maxW;
        if (fr.getStringWidth(s) <= mw) {
            return s;
        }
        return fr.trimStringToWidth(s, Math.max(0, mw - 6)) + "...";
    }

    private float cardRadius() {
        return Math.max(4f, Theme.radius - 4f);
    }

    private static FontRenderer fr() {
        return Minecraft.getMinecraft().fontRendererObj;
    }

    private static boolean inside(float px, float py, float x, float y, float w, float h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    // ------------------------------------------------------------------ input

    @Override
    protected void mouseClicked(int mx, int my, int button) throws IOException {
        if (button != 0) {
            return;
        }
        if (openDropdown != null) {
            AppleDropdown dd = openDropdown;
            int opt = dd.optionAt(mx, my);
            openDropdown = null;
            if (opt >= 0) {
                dd.choose(opt);
            }
            return;
        }
        if (!inside(mx, my, wx, wy, ww, wh)) {
            close();
            return;
        }
        float cy = wy + 17f;
        if (inside(mx, my, wx + 8f, cy - 9f, 16f, 18f)) {
            close();
            return;
        }
        int nav = navIndexAt(mx, my);
        if (nav >= 0) {
            selectPage(nav);
            return;
        }
        if (search.contains(mx, my)) {
            search.setFocused(true);
            return;
        }
        search.setFocused(false);
        if (!inside(mx, my, vx, vy, vw, vh)) {
            return;
        }

        Widget w = widgetAt(mx, my);
        gesture = true;
        gestureMoved = false;
        gestureStartY = my;
        gestureStartScroll = scroll;
        lastDragY = my;
        lastDragNs = System.nanoTime();
        scrollVel = 0f;
        active = w;
        if (w != null) {
            w.onPress(mx, my);
        }
    }

    @Override
    protected void mouseClickMove(int mx, int my, int button, long timeSinceLastClick) {
        if (!gesture) {
            return;
        }
        if (active instanceof AppleSlider) {
            active.onDrag(mx, my);
            return;
        }
        if (!gestureMoved && Math.abs(my - gestureStartY) > DRAG_THRESHOLD) {
            gestureMoved = true;
            if (active != null) {
                active.onRelease(mx, my, false);
                active = null;
            }
        }
        if (gestureMoved) {
            long now = System.nanoTime();
            float dt = (now - lastDragNs) / 1.0e9f;
            if (dt > 0.002f) {
                float v = (lastDragY - my) / dt;
                scrollVel = scrollVel * 0.5f + v * 0.5f;
                lastDragY = my;
                lastDragNs = now;
            }
            float target = gestureStartScroll + (gestureStartY - my);
            scroll = Math.max(0f, Math.min(maxScroll(), target));
            scrollTarget = scroll;
        }
    }

    @Override
    protected void mouseReleased(int mx, int my, int button) {
        if (active != null) {
            boolean activate = !gestureMoved && active.contains(mx, my);
            Widget a = active;
            active = null;
            a.onRelease(mx, my, activate);
            if (activate && a instanceof AppleDropdown) {
                AppleDropdown d = (AppleDropdown) a;
                openDropdown = (openDropdown == d) ? null : d;
                if (openDropdown != null) {
                    openDropdown.onExpand();
                }
            }
        }
        boolean moved = gestureMoved;
        gesture = false;
        gestureMoved = false;
        if (!moved) {
            scrollVel = 0f;
        }
    }

    /** Mouse wheel. 1.8.9 has no wheel callback, so read the event before the default handling. */
    @Override
    public void handleMouseInput() throws IOException {
        int wheel = Mouse.getEventDWheel();
        super.handleMouseInput();
        if (wheel != 0) {
            scrollTarget = Math.max(0f, Math.min(maxScroll(), scrollTarget - wheel / 120f * 40f));
            scrollVel = 0f;
        }
    }

    @Override
    protected void keyTyped(char c, int code) throws IOException {
        if (search.isFocused()) {
            if (code == Keyboard.KEY_ESCAPE) {
                if (!search.isEmpty()) {
                    search.clear();
                } else {
                    search.setFocused(false);
                }
                return;
            }
            if (search.keyTyped(c, code)) {
                return;
            }
        }
        if (code == Keyboard.KEY_ESCAPE) {
            if (openDropdown != null) {
                openDropdown = null;
                return;
            }
            close();
            return;
        }
        if (isCtrlKeyDown()) {
            if (code == Keyboard.KEY_F) {
                search.setFocused(true);
                return;
            }
            if (code >= Keyboard.KEY_1 && code <= Keyboard.KEY_3) {
                selectPage(code - Keyboard.KEY_1);
            }
            return;
        }
        if (c >= 32 && c != 127) {
            search.setFocused(true);
            search.keyTyped(c, code);
        }
    }

    private void close() {
        Minecraft.getMinecraft().displayGuiScreen(parent);
    }

    private int navIndexAt(int mx, int my) {
        if (wide) {
            float x = wx + 8f;
            float w = SIDEBAR_W - 16f;
            for (int i = 0; i < PAGE_NAMES.length; i++) {
                float y = wy + TITLE_H + 10f + i * NAV_STEP;
                if (inside(mx, my, x, y, w, NAV_H)) {
                    return i;
                }
            }
            return -1;
        }
        float y = wy + TITLE_H + 6f;
        if (my < y || my >= y + 24f) {
            return -1;
        }
        float x0 = wx + PAD;
        float seg = (ww - PAD * 2f) / PAGE_NAMES.length;
        if (mx < x0) {
            return -1;
        }
        int i = (int) ((mx - x0) / seg);
        return (i >= 0 && i < PAGE_NAMES.length) ? i : -1;
    }

    private Widget widgetAt(int mx, int my) {
        List<Row> rows = currentRows();
        for (int i = rows.size() - 1; i >= 0; i--) {
            Widget c = rows.get(i).control;
            if (c != null && c.contains(mx, my)) {
                return c;
            }
        }
        return null;
    }
}
