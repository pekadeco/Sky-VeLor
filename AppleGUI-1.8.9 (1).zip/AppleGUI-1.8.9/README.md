# Apple GUI for Minecraft Java 1.8.9 (Forge)

An Apple-inspired, macOS-style settings hub for Minecraft **1.8.9 + Forge 11.15.1.2318**.
Translucent rounded window, traffic-light title bar, sidebar (tab bar on narrow screens),
search, animated switches / sliders / dropdowns / segmented controls, live FPS and
frame-time charts, and adaptive quality for low-end devices.

Works on desktop Minecraft and on Android Java launchers such as PojavLauncher.

---

## 1. Project layout and where each file belongs

```
AppleGUI-1.8.9/                          <- Forge project root (ForgeGradle workspace)
├── build.gradle                         <- ForgeGradle 2.1 build script for 1.8.9
├── settings.gradle
├── README.md
└── src/main/
    ├── java/com/arena/applegui/
    │   ├── AppleGuiMod.java             <- @Mod entry point, keybind, menu buttons
    │   ├── config/
    │   │   └── AppleSettings.java       <- persistent settings (.minecraft/applegui.properties)
    │   ├── render/
    │   │   ├── UIRender.java            <- rounded rects, shadows, text, scissor (Tessellator)
    │   │   ├── Theme.java               <- dark/light palette and accent handling
    │   │   ├── Anim.java                <- frame-rate independent animation values
    │   │   └── Icons.java               <- vector icons (no textures needed)
    │   ├── widget/
    │   │   ├── Widget.java              <- base class: hit test, hover/press, touch model
    │   │   ├── AppleButton.java
    │   │   ├── AppleToggle.java
    │   │   ├── AppleSlider.java
    │   │   ├── AppleSegmented.java
    │   │   ├── AppleDropdown.java
    │   │   └── SearchField.java
    │   └── gui/
    │       ├── AppleHubScreen.java      <- the hub: layout, pages, scrolling, input
    │       └── Row.java                 <- one settings row / section / custom card
    └── resources/
        ├── mcmod.info
        └── assets/applegui/lang/en_US.lang
```

Package names must match the folders exactly (`com.arena.applegui...`).

---

## 2. Setup and build

Requirements: **JDK 8** (Forge 1.8.9 does not run on newer Java) and **Gradle 2.14.x**
(ForgeGradle 2.1 needs Gradle 2.x). The shipped jar was built with JDK 1.8.0_504 and Gradle 2.14.1.

**ForgeGradle plugin.** `build.gradle` loads the ForgeGradle 2.1 plugin as version `0.0.0` from
`mavenLocal()`. Either:
- build it yourself from the FG_2.1 branch: `git clone -b FG_2.1 https://github.com/MinecraftForge/ForgeGradle`,
  then `gradle install` inside that folder (this installs `net.minecraftforge.gradle:ForgeGradle:0.0.0`); or
- change the classpath line in `build.gradle` to `'net.minecraftforge.gradle:ForgeGradle:2.1-SNAPSHOT'`
  if that artifact resolves from the Forge Maven on your network.

```bash
cd AppleGUI-1.8.9
gradle setupDecompWorkspace                # downloads Minecraft 1.8.9 + Forge + MCP mappings, decompiles
gradle build                               # output: build/libs/AppleGUI-1.8.9-1.0.0.jar
```

Use a system Gradle 2.14.x install. A Gradle wrapper was not generated, so `./gradlew` does not exist
in this folder. To add one later, run `gradle wrapper --gradle-version 2.14.1` with that install.

If the build runs out of memory in `decompileMc` (Fernflower), raise the heap in
`gradle.properties`: `org.gradle.jvmargs=-Xmx2G`. Machines with about 2 GB of RAM can skip decompilation
with `gradle build -x decompileMc`. That produces the same jar, since compiling uses the deobfuscated
classes and not the decompiled sources.

## 3. Test it on desktop

- Development client: `./gradlew runClient` (Eclipse/IntelliJ: `./gradlew genIntellijRuns` / `genEclipseRuns`).
- Or install the jar: copy `build/libs/AppleGUI-1.8.9-1.0.0.jar` into `.minecraft/mods/` of a Forge 1.8.9 profile.

Test checklist:
1. **Main menu / pause menu:** an "Apple GUI" button appears at the top-right. Clicking it opens the hub.
2. **In-game:** press **Right Shift** (rebindable under Controls → Apple GUI).
3. **Close:** click the red traffic light, click outside the window, or press Esc.
4. **Pages:** click sidebar items, or press Ctrl+1 / Ctrl+2 / Ctrl+3.
5. **Search:** click the field or just start typing. Esc clears it. Results span all pages.
6. **Controls:** toggle switches, drag sliders, open dropdowns and choose an option, switch segments.
7. **Scrolling:** mouse wheel, or drag the list. Release a fast drag and it coasts (inertia).
8. **Layout:** resize the window or change GUI Scale (1 to 4). The sidebar becomes tabs under 460 px wide and the header compacts when the window is short.
9. **Persistence:** change settings, close, reopen the game. Values come back from `.minecraft/applegui.properties`.

## 4. Android (PojavLauncher and compatible launchers)

1. In Pojav, create or select a **Forge 1.8.9** instance.
2. Copy `AppleGUI-1.8.9-1.0.0.jar` into that instance's `mods` folder.
3. Use GUI Scale 2 or 3 on phones. The hub adapts, but the larger scale makes touch targets easier to hit.
4. Tap to activate. Drag to scroll and to move sliders.

Pojav support depends on the device and on the Forge build. Test a desktop build first, and report any crash log with the device model.

Android-specific choices:
- Only Tessellator / WorldRenderer `POSITION_COLOR` quads, fixed-function blend, texture enable and alpha test, plus `glScissor`. No shaders, FBOs, VBOs, stencil, GL extensions or desktop-only APIs.
- Taps are handled on release, so a touch that turns into a scroll never presses a button.
- The mouse wheel is read from `Mouse.getEventDWheel()`, which is harmless when no wheel exists.
- No external libraries, no Java AWT fonts, no image loading.

---

## 5. Design and performance notes

- **Rendering:** rounded shapes are triangle fans with a 1-px feathered edge (anti-aliased without MSAA). Shadows are one feathered rounded rect. Bar charts are batched into one draw call.
- **No per-frame allocation in steady state:** unit-circle tables and scratch arrays are static. Palettes are rebuilt only when a setting changes (`Theme.refresh()`).
- **Frame-rate independent motion:** animations use exponential smoothing with real frame delta time. Animation speed is adjustable.
- **Adaptive quality:** when a frame takes longer than 50 ms for 30 frames in a row, the hub drops curve quality and turns off shadows. It restores them after 180 fast frames in a row. This is on by default and toggled under Performance.
- **Clipping:** the settings list uses a scissor rectangle, so only visible rows are drawn and culled rows are skipped.
- **Touch model:** `Widget` has press / drag / release. Sliders respond while dragged. Everything else fires on release, and only if the gesture did not move more than 5 px.

I have not measured FPS in-game, so I have no benchmark numbers. The design keeps the work per frame small (a few dozen draw calls), but please check it on your hardware.

## 6. Customising

- **Add a setting row:** in `AppleHubScreen.buildPages()`, add `Row.item(label, description, control)` to a page, or `Row.section("Title")` to start a group. Controls are the classes in `widget/`.
- **Add a page:** extend `PAGE_NAMES`, `PAGE_SUBS`, `PAGE_ICONS`, and `navSel` / `navHover` size (they derive from `PAGE_NAMES.length`), then add a list in `buildPages()`.
- **Accent colours:** `AppleSettings.ACCENT_NAMES` / `ACCENT_COLORS`.
- **Palette:** `Theme.refresh()` (dark and light sets).
- **Icons:** `Icons.draw(type, cx, cy, size, color)`. Add a case to create new ones.
- **Shortcut to another screen:** use `Minecraft.getMinecraft().displayGuiScreen(...)` inside a button action, and pass `this` as the parent so Back returns to the hub.

## 7. Known limitations (honest notes)

- **Typography:** Minecraft's bitmap font is the only font in 1.8.9 that works everywhere. The Apple feel comes from size scale, colour hierarchy and spacing, not from SF Pro. A custom TTF would need Java2D rasterisation, which is slow and unreliable on Android JVMs.
- **Blur:** there is no real background blur. 1.8.9 has no blur pass, and building one needs shaders or FBOs, which Pojav does not reliably support. The glass effect is translucency plus a dim veil.
- **Touch gestures:** long-press and right-click are not implemented. They depend on how the launcher maps touches.
- **Verification status:**
  - **Compiled against real Minecraft 1.8.9.** The build ran `compileJava` against the deobfuscated Minecraft 1.8.9 client jar and Forge 11.15.1.2318-1.8.9 (MCP stable_22) with JDK 8. All 15 source files compiled with no errors and no warnings. This confirms the 1.8.9 signatures the mod uses (`GuiScreen` input hooks, `GuiScreenEvent`, `GlStateManager`, `Tessellator` / `WorldRenderer`, `Mouse`).
  - **Not run in-game.** I could not launch Minecraft in this environment, so rendering, input, and persistence are untested in a live client. Run the test checklist in section 3 before relying on it.
  - **Not tested on PojavLauncher.** The Android code path is designed to the constraints in section 4, but it has not been run on a device.
  - **Decompiled workspace not generated.** `setupDecompWorkspace` was not completed in the build environment, because decompilation ran out of memory on a 2 GB machine. The jar does not depend on it.

## 8. Credits

Designed as an Apple-style counterpart to the vanilla options menus, built only on Minecraft's own rendering and input infrastructure.
