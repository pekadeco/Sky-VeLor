package com.arena.pekaclient.render;

import com.arena.pekaclient.config.AppleSettings;

/**
 * The one design-token authority for Lunaria GUI surfaces.
 *
 * <p>The settings shell uses the Lunaria dark-and-orange palette, with named surfaces and a warm accent. Existing
 * appearance values remain loadable in {@link AppleSettings}; current UI behavior keeps the shell deterministic so
 * an old configuration cannot silently fork the navigation or control hierarchy into a second design system. Keep
 * concrete GUI colours, typography, spacing, radii, shadows and dim layers here; renderers consume these semantic
 * tokens rather than introducing local hexadecimal literals.</p>
 */
public final class Theme {

    // ------------------------------------------------------------------ colour tokens

    /** Shared masks/opaque neutrals for render helpers; these are colour tokens, not ad-hoc caller literals. */
    public static final int RGB_MASK = 0x00FFFFFF;
    public static final int TRANSPARENT = 0x00000000;
    public static final int OPAQUE_BLACK = 0xFF000000;
    public static final int OPAQUE_WHITE = 0xFFFFFFFF;
    /** Minecraft-native textured-button text values retained for vanilla integration widgets. */
    public static final int VANILLA_BUTTON_DISABLED_TEXT = 0x00A0A0A0;
    public static final int VANILLA_BUTTON_TEXT = 0x00E0E0E0;
    public static final int VANILLA_BUTTON_HOVER_TEXT = 0x00FFFFA0;

    /** Reference palette. Alpha is opaque; individual surfaces may apply opacity as needed. */
    public static final int BACKGROUND = 0xFF0B0D12;
    public static final int PANEL = 0xFF151922;
    public static final int CARD = 0xFF222936;
    public static final int ACCENT_ORANGE = 0xFFFF6500;
    public static final int HIGHLIGHT = 0xFFFF8738;
    public static final int TEXT = 0xFFF0F1F5;
    public static final int MUTED = 0xFF9299A8;
    public static final int PALETTE_BORDER = 0xFF363D4A;
    /** Kept for binary/source compatibility with legacy callers. */
    public static final int MOON_BLUE = 0xFF3ACFFF;
    public static final int MOON_VIOLET = 0xFF704BFF;
    public static final int ACCENT_BLUE = 0xFF0A84FF;
    public static final int ACCENT_BLUE_HOVER = 0xFF409CFF;
    public static final int STATUS_WARNING = 0xFFF0B45E;
    /** Semantic success is reserved for compact health/availability indicators, not a second interaction accent. */
    public static final int STATUS_SUCCESS = 0xFF5EDC87;
    public static final int STATUS_CRITICAL = 0xFFFF6B6B;
    public static final int STATUS_UNAVAILABLE = 0xFF8E8E93;

    /** Graphite glass, directly restored from the shipped Apple settings visual system. */
    public static final int SURFACE_TOP_RGB = 0x151922;
    public static final int SURFACE_BOTTOM_RGB = 0x0B0D12;
    public static final int SURFACE_CARD = CARD;
    public static final int SURFACE_CARD_HOVER = 0xFF2C3442;
    public static final int SURFACE_CONTROL = 0xFF191E29;
    public static final int SURFACE_CONTROL_HOVER = 0xFF303848;
    public static final int SURFACE_POPUP = 0xF2151922;
    /** Dropdowns use an opaque-enough graphite popup and explicit state layers for readable one-level choices. */
    public static final int DROPDOWN_TRIGGER = 0xFF151922;
    public static final int DROPDOWN_TRIGGER_HOVER = 0xFF303848;
    public static final int DROPDOWN_POPUP = 0xFA151922;
    public static final int DROPDOWN_BORDER = 0xEA363D4A;
    public static final int DROPDOWN_ROW_HOVER = 0xFF303848;
    public static final int DROPDOWN_ROW_SELECTED = 0xA0FF6500;
    public static final int DROPDOWN_DIVIDER = 0xA0363D4A;
    /** Inset accordion panels stay readable even when the optional window glass is highly transparent. */
    public static final int EXPANDED_PANEL = 0xF0151922;
    public static final int EXPANDED_BORDER = 0xEA363D4A;
    public static final int EXPANDED_HEADER = 0x80FF6500;
    public static final int EXPANDED_ROW_HOVER = 0xFF303848;
    public static final int EXPANDED_DIVIDER = 0x20FFFFFF;
    /** Master-off children remain editable but use muted, still-readable labels rather than a near-invisible veil. */
    public static final int DEPENDENT_TEXT_PRIMARY = 0xFFC4C4CA;
    public static final int DEPENDENT_TEXT_SECONDARY = 0xFF94949C;
    public static final float DEPENDENT_CONTROL_ALPHA = .78f;
    public static final int SURFACE_DISABLED = 0x52000000;
    public static final int BORDER = 0xA0363D4A;
    public static final int DIVIDER = 0x80363D4A;
    public static final int TRACK = 0xFF363D4A;
    public static final int SEGMENT_SELECTED = 0xFF414A5A;
    public static final int TEXT_PRIMARY = TEXT;
    public static final int TEXT_SECONDARY = MUTED;
    public static final int TEXT_TERTIARY = 0xFF7D8595;
    public static final int TEXT_DISABLED = 0xFF626269;
    public static final int CONTROL_KNOB = OPAQUE_WHITE;
    public static final int ICON_INK = TEXT_SECONDARY;
    public static final int NEUTRAL_DOT = TEXT_TERTIARY;
    public static final int NOTICE_WARNING = STATUS_WARNING;

    /** Non-interactive semantic surfaces shared by diagnostics and app-specific utility screens. */
    public static final int SHADOW = 0x40000000;
    public static final int DIM = 0x73000000;
    /** Light, transparent canvas veil for direct HUD placement; the game remains readable underneath. */
    public static final int HUD_EDITOR_DIM = 0x30000000;
    public static final int TOOLTIP = 0xF2151922;
    public static final int DEBUG_THIN = 0xC8E85D5D;
    public static final int DEBUG_HOT = 0xFFFF4545;
    public static final int DEBUG_FILL = 0x35FF4545;
    public static final int LOADING_BLACK = OPAQUE_BLACK;
    public static final int LOADING_BLUE = 0xFF0B2350;
    public static final int LOADING_DEEP_BLUE = LOADING_BLUE;
    public static final int LOADING_WORDMARK = TEXT_PRIMARY;
    public static final int LOADING_SUBTITLE = 0xFF9CC3FF;
    public static final int LOADING_VERSION = LOADING_SUBTITLE;
    public static final int LOADING_STATUS = TEXT_SECONDARY;
    public static final int LOADING_DIM = TEXT_TERTIARY;
    public static final int LOADING_TRACK = 0xFF151922;
    public static final int LOADING_ERROR = STATUS_CRITICAL;
    /** Full-bleed supplied-art loading treatment; both screens retain their distinct panel opacity. */
    public static final int LOADING_ART_SCRIM_TOP = 0x33070B22;
    public static final int LOADING_ART_SCRIM_BOTTOM = 0x66140B33;
    public static final int LOADING_STARTUP_GLOW_TOP = 0x552462C8;
    public static final int LOADING_STARTUP_GLOW_BOTTOM = 0x664A1E9E;
    public static final int LOADING_STARTUP_PANEL_TOP = 0xD91A2048;
    public static final int LOADING_STARTUP_PANEL_BOTTOM = 0xD91E163D;
    public static final int LOADING_TERRAIN_GLOW_TOP = 0x553A78E6;
    public static final int LOADING_TERRAIN_GLOW_BOTTOM = 0x665B39B0;
    public static final int LOADING_TERRAIN_PANEL_TOP = 0xDA1A2048;
    public static final int LOADING_TERRAIN_PANEL_BOTTOM = 0xDA1E163D;
    public static final int LOADING_PROGRESS_GLOW_START = 0x303CA8FF;
    public static final int LOADING_PROGRESS_GLOW_END = 0x305E45D6;
    public static final int LOADING_PROGRESS_TRACK = 0x99383C72;
    public static final int LOADING_PROGRESS_START = 0xFF66C7FF;
    public static final int LOADING_PROGRESS_END = 0xFFA875FF;
    public static final int LOADING_STARTUP_VERSION = 0xFFB8C8FF;
    public static final int LOADING_STARTUP_STATUS = 0xFFF1EEFF;
    public static final int LOADING_STARTUP_ERROR = 0xFFFFB3BF;
    public static final int LOADING_STARTUP_DETAIL = 0xFFBAC0DF;
    public static final int LOADING_TERRAIN_STATUS = 0xFFF6F1FF;
    public static final int LOADING_TERRAIN_DETAIL = 0xFFBEC4E3;
    public static final int CHAT_FIELD_ERROR = 0xFFFF453A;
    public static final int WINDOW_HINT_BACKGROUND = 0xE6101820;
    /** Default colours for client-only world outlines; settings can still override each configurable variant. */
    public static final int HIGHLIGHT_BLOOD_MOB = 0xFF00FF00;
    public static final int HIGHLIGHT_NORMAL_MOB = 0xFF7CFC8A;
    public static final int HIGHLIGHT_STARRED_MOB = 0x5C9AFFFF;
    public static final int HIGHLIGHT_STORMY = 0xADD8E6FF;
    public static final int HIGHLIGHT_WITHERMANCER = 0xA9A9A9FF;
    public static final int HIGHLIGHT_ZOMBIE_COMMANDER = 0xFF0000FF;
    public static final int HIGHLIGHT_SKELETON_MASTER = 0xFF6400FF;
    private static final int[] MINECRAFT_FORMATTING_PALETTE = {
            0x000000, 0x0000AA, 0x00AA00, 0x00AAAA, 0xAA0000, 0xAA00AA, 0xFFAA00, 0xAAAAAA,
            0x555555, 0x5555FF, 0x55FF55, 0x55FFFF, 0xFF5555, 0xFF55FF, 0xFFFF55, 0xFFFFFF
    };
    public static final int LEAP_CARD = 0xFF20242C;
    public static final int LEAP_CARD_HOVER = 0xFF2A313D;
    public static final int LEAP_BORDER = 0xFF465264;
    public static final int LEAP_BORDER_HOVER = 0xFF617189;
    public static final int LEAP_HEAD_LETTER = 0xFF2C3E5C;
    public static final int LEAP_TEXT = OPAQUE_WHITE;
    public static final int LEAP_TEXT_DIM = 0xFFE0E5EC;
    public static final int NOTE_PANEL = 0xF0171B24;
    public static final int NOTE_BORDER = 0xFF566173;
    public static final int NOTE_BOX = 0xFF11151D;
    public static final int NOTE_BOX_BORDER = 0xFF424D5E;
    public static final int NOTE_TITLE = TEXT_PRIMARY;
    public static final int NOTE_TEXT = 0xFFE7EBF2;
    public static final int NOTE_HINT = 0xFF98A3B4;
    public static final int NOTE_SAVED = ACCENT_BLUE;
    public static final int NOTE_PENDING = STATUS_WARNING;
    public static final int NOTE_CURSOR = OPAQUE_WHITE;
    public static final int NOTE_SIDEBAR = NOTE_BOX;
    public static final int NOTE_SIDEBAR_BORDER = NOTE_BOX_BORDER;
    public static final int NOTE_ROW = NOTE_HINT;
    public static final int NOTE_ROW_SELECTED = ACCENT_BLUE;
    public static final int NOTE_ROW_COUNT = 0xFF7F8998;
    /** Standalone Item Animation is intentionally opaque: game/HUD pixels never bleed through its controls. */
    public static final int ITEM_ANIMATION_PANEL = PANEL;
    public static final int ITEM_ANIMATION_PANEL_BORDER = PALETTE_BORDER;

    // ------------------------------------------------------------------ typography, geometry and motion tokens

    public static final float TYPE_DISPLAY = 1.34f;
    public static final float TYPE_TITLE = 1.08f;
    public static final float TYPE_HEADING = .88f;
    public static final float TYPE_BODY = .72f;
    public static final float TYPE_META = .62f;
    public static final float TYPE_CAPTION = .52f;

    public static final float SPACE_4 = 4f;
    public static final float SPACE_8 = 8f;
    public static final float SPACE_12 = 12f;
    public static final float SPACE_16 = 16f;

    public static final float RADIUS_WINDOW = 12f;
    public static final float RADIUS_CARD = 7f;
    public static final float RADIUS_BUTTON = 8f;
    public static final float RADIUS_FIELD = 7f;
    public static final float RADIUS_POPUP = 7f;
    public static final float RADIUS_SMALL = 4f;
    public static final float RADIUS_PILL = 10f;
    public static final float RADIUS_THEME_BASE = 12f;
    public static final float OUTLINE = 1f;
    public static final float AA_FRINGE = 1f;
    public static final float SHADOW_OFFSET_X = 0f;
    public static final float SHADOW_OFFSET_Y = 3f;
    public static final float SHADOW_GROWTH = 2f;

    /** All GUI settle durations intentionally stay in the requested subtle 120–180 ms range. */
    public static final int MOTION_HOVER_MS = 140;
    public static final int MOTION_PRESS_MS = 120;
    public static final int MOTION_TOGGLE_MS = 150;
    public static final int MOTION_TAB_MS = 160;
    public static final int MOTION_SLIDER_MS = 150;
    public static final int MOTION_PULSE_MS = 150;

    // ------------------------------------------------------------------ resolved palette used by existing render call sites

    public static int accent = ACCENT_ORANGE;
    public static int textPrimary = TEXT_PRIMARY;
    public static int textSecondary = TEXT_SECONDARY;
    public static int textTertiary = TEXT_TERTIARY;
    public static int windowTop = 0xF0151922;
    public static int windowBottom = 0xF00B0D12;
    public static int card = SURFACE_CARD;
    public static int cardHover = SURFACE_CARD_HOVER;
    public static int buttonFill = SURFACE_CONTROL;
    public static int buttonHover = SURFACE_CONTROL_HOVER;
    /** Dedicated resolved dropdown tokens keep trigger, popup, hover, and selected states coherent. */
    public static int dropdownTrigger = DROPDOWN_TRIGGER;
    public static int dropdownTriggerHover = DROPDOWN_TRIGGER_HOVER;
    public static int dropdownPopup = DROPDOWN_POPUP;
    public static int dropdownBorder = DROPDOWN_BORDER;
    public static int dropdownRowHover = DROPDOWN_ROW_HOVER;
    public static int dropdownRowSelected = DROPDOWN_ROW_SELECTED;
    public static int dropdownDivider = DROPDOWN_DIVIDER;
    /** Resolved disclosure tokens prevent transparent glass from washing out expanded feature controls. */
    public static int expandedPanel = EXPANDED_PANEL;
    public static int expandedBorder = EXPANDED_BORDER;
    public static int expandedHeader = EXPANDED_HEADER;
    public static int expandedRowHover = EXPANDED_ROW_HOVER;
    public static int expandedDivider = EXPANDED_DIVIDER;
    public static int dependentTextPrimary = DEPENDENT_TEXT_PRIMARY;
    public static int dependentTextSecondary = DEPENDENT_TEXT_SECONDARY;
    public static int border = BORDER;
    public static int divider = DIVIDER;
    public static int track = TRACK;
    public static int segSelected = SEGMENT_SELECTED;
    public static int popup = SURFACE_POPUP;
    public static int veil = DIM;

    public static int radius = (int) RADIUS_THEME_BASE;
    public static boolean animations = true;
    public static float speed = 1f;

    private Theme() {
    }

    /** Returns an isolated copy of the vanilla chat-format palette used by the optional dynamic-font atlas. */
    public static int[] minecraftFormattingPalette() {
        return MINECRAFT_FORMATTING_PALETTE.clone();
    }

    /** Applies the Lunaria palette while retaining opacity, radius and motion accessibility preferences. */
    public static void applyReferenceSettingsPalette() {
        applyAppleGlass();
    }

    /** Rebuilds the resolved tokens after an allowed geometry, opacity, or motion preference changes. */
    public static void refresh() {
        applyAppleGlass();
    }

    private static void applyAppleGlass() {
        int glass = Math.round(AppleSettings.effectiveGlassOpacity() * 2.55f);
        radius = AppleSettings.effectiveCornerRadius();
        animations = AppleSettings.animations;
        speed = AppleSettings.effectiveAnimSpeed() / 100f;
        accent = ACCENT_ORANGE;
        windowTop = (glass << 24) | SURFACE_TOP_RGB;
        windowBottom = (glass << 24) | SURFACE_BOTTOM_RGB;
        card = SURFACE_CARD;
        cardHover = SURFACE_CARD_HOVER;
        buttonFill = SURFACE_CONTROL;
        buttonHover = SURFACE_CONTROL_HOVER;
        dropdownTrigger = DROPDOWN_TRIGGER;
        dropdownTriggerHover = DROPDOWN_TRIGGER_HOVER;
        dropdownPopup = DROPDOWN_POPUP;
        dropdownBorder = DROPDOWN_BORDER;
        dropdownRowHover = DROPDOWN_ROW_HOVER;
        dropdownRowSelected = DROPDOWN_ROW_SELECTED;
        dropdownDivider = DROPDOWN_DIVIDER;
        expandedPanel = EXPANDED_PANEL;
        expandedBorder = EXPANDED_BORDER;
        expandedHeader = EXPANDED_HEADER;
        expandedRowHover = EXPANDED_ROW_HOVER;
        expandedDivider = EXPANDED_DIVIDER;
        dependentTextPrimary = DEPENDENT_TEXT_PRIMARY;
        dependentTextSecondary = DEPENDENT_TEXT_SECONDARY;
        border = BORDER;
        divider = DIVIDER;
        track = TRACK;
        segSelected = SEGMENT_SELECTED;
        popup = SURFACE_POPUP;
        veil = DIM;
        textPrimary = TEXT_PRIMARY;
        textSecondary = TEXT_SECONDARY;
        textTertiary = TEXT_TERTIARY;
    }
}
