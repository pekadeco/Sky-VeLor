package com.arena.pekaclient.assist;

import com.arena.pekaclient.assist.dungeon.BossHealthParser;
import com.arena.pekaclient.assist.dungeon.TerminalAssistPolicy;
import com.arena.pekaclient.assist.inventory.RarityPalette;
import com.arena.pekaclient.assist.inventory.RomanNumeralPolicy;
import com.arena.pekaclient.assist.inventory.TooltipWindow;
import com.arena.pekaclient.assist.mining.MiningAbilityPolicy;
import com.arena.pekaclient.assist.mining.PuzzlerRoute;
import com.arena.pekaclient.assist.movement.AutoSprintPolicy;

import java.util.Arrays;

/** Headless behavioral regression suite for all clean-room assist policies. */
public final class AssistFeatureTests {
    private static int passed;
    private static int failed;

    public static void main(String[] args) {
        miningPolicies();
        inventoryPolicies();
        bossAndTerminalPolicies();
        movementPolicies();
        done();
    }

    private static void miningPolicies() {
        MiningAbilityPolicy.Activation pick = MiningAbilityPolicy.parseActivation("\u00a7aYou used your Pickobulus Pickaxe Ability!");
        check("parse Pickobulus", pick != null && pick.cooldownSeconds == 60);
        check("unknown ability ignored", MiningAbilityPolicy.parseActivation("You used your Unknown Pickaxe Ability!") == null);
        check("remaining seconds round up", MiningAbilityPolicy.remainingSeconds(2501L, 1501L) == 1L);
        int[] route = PuzzlerRoute.decode("[NPC] Puzzler: \u25c0\u25b2\u25ba");
        check("puzzler route decodes", route != null && route[0] == PuzzlerRoute.ORIGIN_X && route[1] == PuzzlerRoute.ORIGIN_Y
                && route[2] == PuzzlerRoute.ORIGIN_Z + 1);
        check("puzzler rejects unknown glyph", PuzzlerRoute.decode("[NPC] Puzzler: X") == null);
    }

    private static void inventoryPolicies() {
        // Inventory Search is intentionally absent. Remaining inventory behavior is limited to normal tooltip/rarity helpers.
        check("rarity parser rejects unknown and reads explicit lore", RarityPalette.colorForText("plain item") == 0
                && RarityPalette.colorForText("\u00a76LEGENDARY SWORD") == 0xFFFFAA00);
        check("roman canonical parse", RomanNumeralPolicy.parse("XIV") == 14 && RomanNumeralPolicy.parse("IIX") < 0);
        check("roman replaces bounded token", "Sharpness 5".equals(RomanNumeralPolicy.replaceLevels("Sharpness V")));
        check("tooltip window clamps", TooltipWindow.clampOffset(99, 15, 12) == 3
                && TooltipWindow.visible(Arrays.asList("1", "2", "3"), 1, 2).size() == 2);
    }

    private static void bossAndTerminalPolicies() {
        BossHealthParser.Entry entry = BossHealthParser.parse("\u00a7c[BOSS] Storm 400M/400M\u2764");
        check("boss parser recognizes faction boss", entry != null && "Storm".equals(entry.name) && entry.hasHealth());
        check("boss parser rejects unrelated text", BossHealthParser.parse("A healthy zombie") == null);
        check("terminal title is explicit", "select-colors".equals(TerminalAssistPolicy.kindForTitle("Select all the RED items!")));
        check("terminal automation needs both switches", !TerminalAssistPolicy.allowAutoClick(true, false, "maze", 500L, 0L)
                && TerminalAssistPolicy.allowAutoClick(true, true, "maze", 500L, 0L));
    }

    private static void movementPolicies() {
        check("auto sprint requires vanilla-safe movement", AutoSprintPolicy.mayStart(1F, false, false, false, false, true, false)
                && !AutoSprintPolicy.mayStart(.5F, false, false, false, false, true, false));
        check("auto sprint releases when forward is not held", AutoSprintPolicy.shouldHoldSprintKey(true, 1F,
                false, false, false, false, true, false)
                && !AutoSprintPolicy.shouldHoldSprintKey(false, 1F, false, false, false, false, true, false));
    }

    private static void check(String name, boolean ok) {
        if (ok) { passed++; System.out.println("ok   " + name); }
        else { failed++; System.err.println("FAIL " + name); }
    }

    private static void done() {
        System.out.println("assist features: passed " + passed + ", failed " + failed);
        if (failed != 0) throw new AssertionError(failed + " assist feature checks failed");
    }
}
